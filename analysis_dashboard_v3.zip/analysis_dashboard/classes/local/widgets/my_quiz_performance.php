<?php
namespace local_analysis_dashboard\local\widgets;

use local_analysis_dashboard\local\base_widget;

class my_quiz_performance extends base_widget {
    public function get_name(): string { return 'widget_my_quiz_performance'; }
    public function get_type(): string { return 'bar'; }
    public function get_required_capability(): string { return 'local/analysis_dashboard:viewown'; }
    public function get_supported_context_levels(): array { return [CONTEXT_USER]; }

    public function get_data(array $params = []): array {
        global $DB;
        $userid = (int) ($params['userid'] ?? 0);
        if (!$userid) {
            return ['labels' => [], 'datasets' => []];
        }

        // Get quiz attempts for user across enrolled courses.
        $sql = "SELECT q.id as quizid, q.name, q.grade as quizgrade,
                       MAX(qa.sumgrades) as bestsumgrades,
                       COUNT(qa.id) as attemptcount,
                       q.sumgrades as quizsumgrades
                  FROM {quiz_attempts} qa
                  JOIN {quiz} q ON q.id = qa.quiz
                  JOIN {enrol} e ON e.courseid = q.course
                  JOIN {user_enrolments} ue ON ue.enrolid = e.id
                 WHERE qa.userid = :userid AND ue.userid = :userid2
                   AND ue.status = 0 AND qa.state = 'finished'
              GROUP BY q.id, q.name, q.grade, q.sumgrades
              ORDER BY q.name
                 LIMIT 15";
        $quizzes = $DB->get_records_sql($sql, ['userid' => $userid, 'userid2' => $userid]);

        $labels = [];
        $bestscores = [];
        $attempts = [];

        foreach ($quizzes as $quiz) {
            $labels[] = $quiz->name;
            $max = max((float) $quiz->quizsumgrades, 1);
            $bestscore = round(((float) $quiz->bestsumgrades / $max) * 100, 1);
            $bestscores[] = $bestscore;
            $attempts[] = (int) $quiz->attemptcount;
        }

        return [
            'labels' => $labels,
            'datasets' => [
                [
                    'label' => get_string('best_score_pct', 'local_analysis_dashboard'),
                    'data' => $bestscores,
                    'backgroundColor' => 'rgba(54, 162, 235, 0.8)',
                    'borderColor' => 'rgba(54, 162, 235, 1)',
                ],
                [
                    'label' => get_string('attempts_used', 'local_analysis_dashboard'),
                    'data' => $attempts,
                    'backgroundColor' => 'rgba(255, 159, 64, 0.8)',
                    'borderColor' => 'rgba(255, 159, 64, 1)',
                ],
            ],
        ];
    }
}
