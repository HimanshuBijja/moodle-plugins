<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_analysis_dashboard\local\widgets;

use local_analysis_dashboard\local\base_widget;

/**
 * Course Categories Overview table widget.
 *
 * Displays all course categories with their course counts
 * and total enrolment counts in a sortable table.
 *
 * @package    local_analysis_dashboard
 * @copyright  2026 Analysis Dashboard
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class course_categories_overview extends base_widget {

    /**
     * Get the widget display name.
     *
     * @return string Language string key.
     */
    public function get_name(): string {
        return 'widget_course_categories_overview';
    }

    /**
     * Get the widget type.
     *
     * @return string Widget type.
     */
    public function get_type(): string {
        return 'table';
    }

    /**
     * Get the required capability.
     *
     * @return string Capability string.
     */
    public function get_required_capability(): string {
        return 'local/analysis_dashboard:viewsite';
    }

    /**
     * Get the cache key.
     *
     * @return string Cache key.
     */
    public function get_cache_key(): string {
        return 'course_categories_overview';
    }

    /**
     * Get course categories data.
     *
     * Queries course_categories joined with courses and enrolments
     * to produce a summary table.
     *
     * @param array $params Optional parameters (unused).
     * @return array Widget data with headers and rows for table display.
     */
    public function get_data(array $params = []): array {
        global $DB;

        $sql = "SELECT cc.id,
                       cc.name AS category_name,
                       COUNT(DISTINCT c.id) AS course_count,
                       COUNT(DISTINCT ue.id) AS enrolment_count
                  FROM {course_categories} cc
             LEFT JOIN {course} c ON c.category = cc.id AND c.id != :siteid
             LEFT JOIN {enrol} e ON e.courseid = c.id
             LEFT JOIN {user_enrolments} ue ON ue.enrolid = e.id
              GROUP BY cc.id, cc.name
              ORDER BY cc.sortorder ASC";

        $records = $DB->get_records_sql($sql, ['siteid' => SITEID]);

        $rows = [];
        foreach ($records as $record) {
            $rows[] = [
                $record->category_name,
                (int) $record->course_count,
                (int) $record->enrolment_count,
            ];
        }

        return [
            'headers' => [
                get_string('category_name', 'local_analysis_dashboard'),
                get_string('course_count', 'local_analysis_dashboard'),
                get_string('enrolment_count', 'local_analysis_dashboard'),
            ],
            'rows' => $rows,
        ];
    }
}
