<?php
namespace local_analysis_dashboard\local\widgets;

use local_analysis_dashboard\local\base_widget;

class upcoming_deadlines extends base_widget {
    public function get_name(): string { return 'widget_upcoming_deadlines'; }
    public function get_type(): string { return 'table'; }
    public function get_required_capability(): string { return 'local/analysis_dashboard:viewown'; }
    public function get_supported_context_levels(): array { return [CONTEXT_USER]; }

    public function get_data(array $params = []): array {
        global $DB;
        $userid = (int) ($params['userid'] ?? 0);
        if (!$userid) {
            return ['headers' => [], 'rows' => []];
        }

        $now = time();
        $fourteendays = $now + (14 * DAYSECS);

        // Get upcoming calendar events for user's enrolled courses.
        $sql = "SELECT e.id, e.name, e.timestart, e.modulename, e.instance,
                       c.shortname as coursename, e.courseid
                  FROM {event} e
                  JOIN {enrol} en ON en.courseid = e.courseid
                  JOIN {user_enrolments} ue ON ue.enrolid = en.id
                  JOIN {course} c ON c.id = e.courseid
                 WHERE ue.userid = :userid AND ue.status = 0
                   AND e.timestart >= :now
                   AND e.timestart <= :future
                   AND e.courseid > 1
                   AND e.eventtype IN ('due', 'close', 'expectcompletionon')
              ORDER BY e.timestart ASC
                 LIMIT 30";
        $events = $DB->get_records_sql($sql, [
            'userid' => $userid,
            'now' => $now,
            'future' => $fourteendays,
        ]);

        $rows = [];
        foreach ($events as $event) {
            $daysuntil = ceil(($event->timestart - $now) / DAYSECS);
            $status = $daysuntil <= 2
                ? '<span class="badge badge-danger">' . get_string('urgent', 'local_analysis_dashboard') . '</span>'
                : '<span class="badge badge-info">' . $daysuntil . ' ' . get_string('days', 'local_analysis_dashboard') . '</span>';

            $rows[] = [
                $event->coursename,
                $event->name,
                userdate($event->timestart, get_string('strftimedatetime', 'core_langconfig')),
                $status,
            ];
        }

        return [
            'headers' => [
                get_string('course'),
                get_string('activity'),
                get_string('duedate', 'local_analysis_dashboard'),
                get_string('status'),
            ],
            'rows' => $rows,
        ];
    }
}
