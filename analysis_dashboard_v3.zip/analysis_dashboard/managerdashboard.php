<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Manager analytics dashboard page.
 *
 * Shows a curated subset of site-level widgets, excluding
 * server-admin-only widgets like disk_usage and server_performance.
 *
 * @package    local_analysis_dashboard
 * @copyright  2026 Analysis Dashboard
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

require_login();

$context = context_system::instance();
require_capability('local/analysis_dashboard:viewsite', $context);

$PAGE->set_url(new moodle_url('/local/analysis_dashboard/managerdashboard.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('manager_dashboard', 'local_analysis_dashboard'));
$PAGE->set_heading(get_string('manager_dashboard', 'local_analysis_dashboard'));
$PAGE->set_pagelayout('report');

$output = $PAGE->get_renderer('local_analysis_dashboard');
$page = new \local_analysis_dashboard\output\manager_dashboard_page();

echo $output->header();
echo $output->render($page);
echo $output->footer();
