#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_DIR="$HOME/.config/rush"

chmod +x "$SCRIPT_DIR/rush"

if [ -w /usr/local/bin ]; then
    cp "$SCRIPT_DIR/rush" /usr/local/bin/rush
else
    sudo cp "$SCRIPT_DIR/rush" /usr/local/bin/rush
fi

mkdir -p "$CONFIG_DIR"

# Point rush at the repo's commands.json as the single source of truth.
# Editing commands.json here OR running 'rush add' both touch the same file.
echo "$SCRIPT_DIR/commands.json" > "$CONFIG_DIR/source"
echo "Pointed rush at: $SCRIPT_DIR/commands.json"

echo "Installed: rush -> /usr/local/bin/rush"
echo "Run 'rush' to get started."
