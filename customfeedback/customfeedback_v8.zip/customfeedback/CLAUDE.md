# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## Project Overview

`mod_customfeedback` is a Moodle 4.5 activity module (v2 of the `local_custom_feedback` plugin). It provides a lightweight feedback activity supporting two question types: **Text Answer** and **Star Rating (1–5)**. Teachers add instances to course sections via "Add an activity or resource"; each instance has its own independent question set, submissions, and reports.

The legacy local plugin lives at `../../local/custom_feedback/` and is still installed but superseded.

---

## Environment

The instance runs in Docker. The web container is `moodle-web-8092`; the DB container is `moodle-db-8092`.

```bash
# Run a PHP CLI command inside the web container (from the instance root):
docker exec -it moodle-web-8092 php /var/www/html/admin/cli/upgrade.php

# Purge all caches (required after any PHP/lang/CSS change):
docker exec -it moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php

# Direct DB access:
docker exec -it moodle-db-8092 mysql -u moodleuser -pmoodlepass moodle

# Tail Moodle debug log (if debug enabled in config.php):
docker exec moodle-web-8092 tail -f /var/www/moodledata/php_errors.log
```

Site URL: `http://100.71.234.30:8092`
Table prefix: `mdl_` (so `customfeedback` → `mdl_customfeedback` in MariaDB).

### Install / upgrade the plugin

```bash
docker exec -it moodle-web-8092 php /var/www/html/admin/cli/upgrade.php
# OR visit http://100.71.234.30:8092/admin (Site admin → Notifications)
```

### Uninstall the old local plugin

```bash
docker exec -it moodle-web-8092 php /var/www/html/admin/cli/uninstall_plugins.php --plugins=local_custom_feedback --run
```

---

## Database Schema

Four tables (all prefixed `mdl_` in MariaDB):

| Table | Purpose |
|---|---|
| `customfeedback` | One row per activity instance (name, intro, `allowmulti`) |
| `customfeedback_q` | Questions per instance — `type` is `'text'` or `'star'` |
| `customfeedback_r` | One submission (response header) per user per instance |
| `customfeedback_a` | One answer row per question per submission; `valuestar` (1-5) or `valuetext` populated based on type |

The `allowmulti` flag (0/1 on `customfeedback`) gates whether a student can submit more than once. The check in `view.php` is enforced both pre-form and server-side at insert time to handle races.

---

## Architecture & Request Flow

```
Teacher adds activity → mod_form.php (name / intro / allowmulti)
                       → lib.php::customfeedback_add_instance()

Activity link clicked → view.php?id=<cmid>
  ├── Student: shows submission_form; on POST saves to customfeedback_r + customfeedback_a
  └── Teacher: same view + secondary nav tabs injected by lib.php::customfeedback_extend_settings_navigation()
                  ├── Questions tab → manage.php?id=<cmid>
                  └── Reports tab  → report.php?id=<cmid>
```

All entry-point scripts (`view.php`, `manage.php`, `report.php`) begin with:
```php
list($course, $cm) = get_course_and_cm_from_cmid($id, 'customfeedback');
require_login($course, true, $cm);
$context = context_module::instance($cm->id);
```

---

## Key Files

| File | Role |
|---|---|
| `lib.php` | `customfeedback_supports()`, `add/update/delete_instance()`, `extend_settings_navigation()` for tabs |
| `mod_form.php` | Instance settings form (extends `moodleform_mod`) |
| `view.php` | Student submission + already-submitted gate |
| `manage.php` | Question CRUD + moveup/movedown (requires `sesskey` on every state change) |
| `report.php` | Aggregate stats, Google-Forms bar charts, paginated table, CSV + XLSX export |
| `classes/form/question_form.php` | Add/edit question form; `type` is fixed at creation, passed via hidden field. The question id hidden field is named `questionid` (not `id`) — see "Param-shadow gotcha" below |
| `tests/lib_test.php` | PHPUnit coverage for lib.php lifecycle callbacks (add/update/delete instance + supports) |
| `classes/form/submission_form.php` | Renders one element per question; star questions use a custom HTML widget backed by a hidden `<input>` written to by `js/stars.js` |
| `classes/privacy/provider.php` | GDPR — operates at `CONTEXT_MODULE` level |
| `db/install.xml` | XMLDB schema; edit this + run upgrade CLI to add columns |
| `db/access.php` | Four capabilities: `addinstance` (CONTEXT_COURSE), `manage`/`viewreport`/`submit` (CONTEXT_MODULE) |
| `js/stars.js` | Vanilla JS star widget — **never uses `innerHTML` with user data**, only `textContent` / class toggling |
| `styles.css` | Scoped to `.mod-customfeedback` body class; light theme only |

---

## Security Rules (must not regress)

- **SQL**: Always use `$DB->*` parameterised methods. Never concatenate user input into SQL.
- **XSS output**: `format_string()` for names, `format_text()` for rich intro, `s()` for attribute values.
- **CSRF**: All state-changing GET/redirect actions call `require_sesskey()`. Forms use `moodleform` (sesskey embedded automatically).
- **Capability checks**: `require_capability()` at the top of every page after `require_login()`. `report.php` accepts either `manage` or `viewreport`; check order matters (manage checked first).
- **JS**: `js/stars.js` must not assign untrusted data to `innerHTML` or `insertAdjacentHTML`.

---

## Adding a Schema Change

1. Edit `db/install.xml` (XMLDB format).
2. Create `db/upgrade.php` with a `xmldb_customfeedback_upgrade($oldversion)` function.
3. Bump `$plugin->version` in `version.php`.
4. Run `docker exec -it moodle-web-8092 php /var/www/html/admin/cli/upgrade.php`.

## Adding a Language String

All strings are in `lang/en/customfeedback.php`. Retrieve with `get_string('key', 'mod_customfeedback')`. After adding strings, purge caches.

## Changing Capabilities

Edit `db/access.php`. Changes take effect after `upgrade.php` runs (version bump required) or via "Reset roles to defaults" in Site admin.

---

## Testing

PHPUnit is wired up against this instance. `config.php` carries:
```php
$CFG->phpunit_prefix   = 'phpu_';
$CFG->phpunit_dataroot = '/var/www/phpunitdata';
```

One-time setup (already done in `moodle-web-8092`):
```bash
docker exec moodle-web-8092 bash -c "cd /var/www/html && composer install"
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
```

Run the module's suite:
```bash
docker exec moodle-web-8092 bash -c "cd /var/www/html && vendor/bin/phpunit mod/customfeedback/tests/lib_test.php"
```

Re-run `init.php` whenever `db/install.xml`, `db/access.php`, or `version.php` changes (it rebuilds the `phpu_*` test DB).

---

## Param-shadow gotcha (manage.php)

`manage.php` reads the cmid via `required_param('id', PARAM_INT)`. Moodle's `optional_param` resolves `$_POST` **before** `$_GET`, so any form posting back to `manage.php` with a hidden field named `id` would clobber the URL cmid → `get_course_and_cm_from_cmid(0, ...)` → "Can't find data record in database". For this reason:

- `question_form` uses `questionid` (not `id`) for its hidden question-id field.
- Any future form whose action posts back to `manage.php` / `report.php` / `view.php` must avoid hidden fields named `id`.
