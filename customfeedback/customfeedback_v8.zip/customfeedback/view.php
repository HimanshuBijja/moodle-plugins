<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main view + student submission entry point.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // course_module id.

list($course, $cm) = get_course_and_cm_from_cmid($id, 'customfeedback');
require_login($course, true, $cm);
$context = context_module::instance($cm->id);

$customfeedback = $DB->get_record('customfeedback', ['id' => $cm->instance], '*', MUST_EXIST);

$baseurl = new moodle_url('/mod/customfeedback/view.php', ['id' => $cm->id]);
$PAGE->set_url($baseurl);
$PAGE->set_context($context);
$PAGE->set_cm($cm, $course);
$PAGE->set_title(format_string($customfeedback->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_activity_record($customfeedback);
$PAGE->add_body_class('mod-customfeedback');
$PAGE->requires->css(new moodle_url('/mod/customfeedback/styles.css'));
$PAGE->requires->js(new moodle_url('/mod/customfeedback/js/stars.js'));

require_capability('mod/customfeedback:submit', $context);

$cansubmit = has_capability('mod/customfeedback:submit', $context);

echo $OUTPUT->header();
echo html_writer::start_div('cfb-view-container');
echo $OUTPUT->heading(format_string($customfeedback->name));

if (!empty($customfeedback->intro)) {
    echo $OUTPUT->box(format_module_intro('customfeedback', $customfeedback, $cm->id), 'generalbox mod_introbox');
}

// Already-submitted gate (skipped when multi enabled).
$alreadysubmitted = false;
if (empty($customfeedback->allowmulti) && !isguestuser() && $USER->id > 0) {
    $alreadysubmitted = $DB->record_exists('customfeedback_r', [
        'customfeedbackid' => $customfeedback->id,
        'userid' => $USER->id,
    ]);
}

if ($alreadysubmitted) {
    echo $OUTPUT->notification(get_string('alreadysubmitted', 'mod_customfeedback'),
        \core\output\notification::NOTIFY_INFO);
    echo html_writer::end_div(); // Close cfb-view-container.
    echo $OUTPUT->footer();
    exit;
}

$questions = $DB->get_records('customfeedback_q',
    ['customfeedbackid' => $customfeedback->id], 'sortorder ASC');

if (!$questions) {
    echo $OUTPUT->notification(get_string('noactivequestions', 'mod_customfeedback'), 'info');
    echo html_writer::end_div(); // Close cfb-view-container.
    echo $OUTPUT->footer();
    exit;
}

$form = new \mod_customfeedback\form\submission_form($baseurl,
    ['questions' => $questions, 'cmid' => $cm->id, 'context' => $context]);

if ($data = $form->get_data()) {
    // Double-check the multi gate server-side to defend against race.
    if (empty($customfeedback->allowmulti) && $USER->id > 0
        && $DB->record_exists('customfeedback_r',
            ['customfeedbackid' => $customfeedback->id, 'userid' => $USER->id])) {
        redirect($baseurl, get_string('alreadysubmitted', 'mod_customfeedback'),
            null, \core\output\notification::NOTIFY_INFO);
    }

    $now = time();
    $response = (object)[
        'customfeedbackid' => $customfeedback->id,
        'userid' => (int)$USER->id,
        'timecreated' => $now,
    ];
    $response->id = $DB->insert_record('customfeedback_r', $response);

    foreach ($questions as $q) {
        $field = 'q_' . $q->id;
        $val = $data->$field ?? null;
        $answer = (object)[
            'responseid' => $response->id,
            'questionid' => $q->id,
            'valuestar' => null,
            'valuetext' => null,
        ];
        if ($q->type === 'star') {
            if ($val !== null && $val !== '') {
                $intv = (int)$val;
                if ($intv >= 1 && $intv <= 5) {
                    $answer->valuestar = $intv;
                }
            }
            if ($answer->valuestar === null && (int)$q->required === 0) {
                continue;
            }
        } else {
            $trimmed = trim((string)$val);
            if ($trimmed === '' && (int)$q->required === 0) {
                continue;
            }
            $answer->valuetext = $trimmed;
        }
        $DB->insert_record('customfeedback_a', $answer);
    }

    redirect(new moodle_url('/course/view.php', ['id' => $course->id]),
        get_string('submitsuccess', 'mod_customfeedback'),
        null, \core\output\notification::NOTIFY_SUCCESS);
}

$form->display();
echo html_writer::end_div(); // Close cfb-view-container.

echo $OUTPUT->footer();
