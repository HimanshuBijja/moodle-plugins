# Design: Backup Fix + Export Average Row

**Date:** 2026-05-24  
**Package:** `mod_customfeedback`  
**Status:** Approved

---

## Task 1 — Disable `FEATURE_BACKUP_MOODLE2`

### Problem

`lib.php::customfeedback_supports()` returns `true` for `FEATURE_BACKUP_MOODLE2`, but no backup classes exist under `backup/moodle2/`. Moodle's backup framework calls `backup_factory::get_backup_activity_task('customfeedback')`, which expects `backup_customfeedback_activity_task` to exist. The class is missing → fatal exception when any backup is initiated on a course containing this activity.

### Fix

Change `FEATURE_BACKUP_MOODLE2` to return `false` in `lib.php`. The backup button will gracefully skip the activity rather than crashing.

**Files changed:**

| File | Change |
|---|---|
| `lib.php` | Line 37: `case FEATURE_BACKUP_MOODLE2: return false;` |
| `tests/lib_test.php` | Flip assertion: `assertFalse(customfeedback_supports(FEATURE_BACKUP_MOODLE2))` |

### Trade-offs

- Activity data will not survive course backup/restore. Acceptable short-term; full backup implementation can be added later as a separate task.
- No DB or schema changes required.

---

## Task 2 — Average Row in Exports and HTML Report Table

### Goal

Append an "Average" summary row at the bottom of the response data (inside the main response table, not in the separate Summary section) in all three surfaces:

1. CSV export
2. XLSX export (Responses sheet)
3. HTML paginated report table

### Data model

`$starstats` is already computed in `report.php` before any output:

```php
$starstats[$q->id] = ['count' => 0, 'sum' => 0, 'dist' => [...]];
```

This is the authoritative source for per-question averages.

### Average row format

| Column | Value |
|---|---|
| Respondent | `"Average"` (new lang string `'average'`) |
| Submitted on | `""` (empty — no date for a summary row) |
| Star question (responses exist) | `"3.67 / 5"` (PHP: `round($sum/$count, 2) . ' / 5'`) |
| Star question (no responses) | `"N/A"` |
| Text question | `""` (empty — no average for free text) |

### Implementation: exports

After `$rows` is fully built (current line ~121 of `report.php`), compute the average row and append it before the CSV/XLSX generation loops:

```php
$avgrow = [get_string('average', 'mod_customfeedback'), ''];
foreach ($questions as $q) {
    if ($q->type === 'star') {
        $st = $starstats[$q->id];
        $avgrow[] = $st['count'] > 0
            ? round($st['sum'] / $st['count'], 2) . ' / 5'
            : 'N/A';
    } else {
        $avgrow[] = '';
    }
}
$rows[] = $avgrow;
```

Both CSV and XLSX loops already iterate `$rows` — no further changes to those loops.

### Implementation: HTML table

The HTML table is built from `$pageresponses` (current page slice). The average row is appended **after** `html_writer::table($table)` as a separate `<tfoot>` row, shown on every page. It is rendered outside the `html_table` object to avoid polluting the pagination-sliced data:

```html
<table class="generaltable cfb-avg-row">
  <tr>
    <th>Average</th>
    <td></td>  <!-- submitted on -->
    <!-- per question -->
    <td>3.67 / 5</td>  <!-- star -->
    <td></td>           <!-- text -->
  </tr>
</table>
```

CSS class `cfb-avg-row` added to `styles.css` with a subtle background (`background: #f8f9fa; font-weight: bold`) to visually distinguish it from response rows.

### Files changed

| File | Change |
|---|---|
| `report.php` | Build `$avgrow`, append to `$rows`, render HTML avg row after main table |
| `lang/en/customfeedback.php` | Add `'average' => 'Average'` |
| `styles.css` | Add `.cfb-avg-row td, .cfb-avg-row th` styling |

### Constraints

- Only star values in range 1–5 are included in averages (`$starstats` already enforces this — see lines 78–81 of `report.php`).
- The existing `$summary` block (separate summary rows below the data, listing overall stats) is left unchanged.
- No changes to `$starstats` computation — reuse as-is.
- No new DB queries.

---

## Out of scope

- Implementing `FEATURE_BACKUP_MOODLE2` with real backup/restore classes (separate future task).
- Changing the HTML average row visibility by page (it appears on every page).
