# Backup Fix + Export Average Row Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the fatal backup crash by disabling `FEATURE_BACKUP_MOODLE2`, and add an "Average" summary row at the bottom of both the CSV/XLSX exports and the HTML report table.

**Architecture:** Task 1 is a single-line `lib.php` change plus a flipped PHPUnit assertion. Task 2 appends a computed average row to the `$rows` array (already used by both CSV and XLSX exporters) and adds the same row as a styled `html_table_row` at the end of the HTML table — all within `report.php`.

**Tech Stack:** PHP 8.1, Moodle 4.5, Moodle `html_table` / `csv_export_writer` / `MoodleExcelWorkbook`, PHPUnit 9.6 inside Docker (`moodle-web-8092`).

---

## File Map

| File | Action | What changes |
|---|---|---|
| `lib.php` | Modify | Line 37: `FEATURE_BACKUP_MOODLE2 → false` |
| `tests/lib_test.php` | Modify | Flip one `assertTrue` → `assertFalse` for FEATURE_BACKUP_MOODLE2 |
| `lang/en/customfeedback.php` | Modify | Add `'average'` string |
| `report.php` | Modify | Append average `$row` to `$rows`; append average `html_table_row` to HTML table |
| `styles.css` | Modify | Add `.cfb-avg-row` rule |

---

## Task 1: Disable FEATURE_BACKUP_MOODLE2 in lib.php

**Files:**
- Modify: `mod/customfeedback/lib.php:37`
- Modify: `mod/customfeedback/tests/lib_test.php:208`

- [ ] **Step 1: Update the test first (TDD — make it fail)**

Open `tests/lib_test.php`. Find the method `test_supports_declared_features()`. Change:

```php
$this->assertTrue(customfeedback_supports(FEATURE_BACKUP_MOODLE2));
```

to:

```php
$this->assertFalse(customfeedback_supports(FEATURE_BACKUP_MOODLE2));
```

- [ ] **Step 2: Run the test — verify it fails**

```bash
docker exec moodle-web-8092 bash -c "cd /var/www/html && vendor/bin/phpunit mod/customfeedback/tests/lib_test.php --filter test_supports_declared_features"
```

Expected output contains `FAILURES! Tests: 1, Assertions: N, Failures: 1`.

- [ ] **Step 3: Change lib.php**

Open `lib.php`. Find this block (around line 37):

```php
        case FEATURE_BACKUP_MOODLE2:
            return true;
```

Change `true` to `false`:

```php
        case FEATURE_BACKUP_MOODLE2:
            return false;
```

- [ ] **Step 4: Run the test — verify it passes**

```bash
docker exec moodle-web-8092 bash -c "cd /var/www/html && vendor/bin/phpunit mod/customfeedback/tests/lib_test.php"
```

Expected: `OK (7 tests, 38 assertions)`.

- [ ] **Step 5: Verify the fix in the browser**

Visit `http://100.71.234.30:8092`. Go to Site administration → Courses → any course that has a Feedback Form activity. Click the course's gear icon (or three-dot menu) → Backup. The backup wizard should complete without throwing `Class "backup_customfeedback_activity_task" not found`.

- [ ] **Step 6: Commit**

```bash
git add mod/customfeedback/lib.php mod/customfeedback/tests/lib_test.php
git commit -m "fix: disable FEATURE_BACKUP_MOODLE2 — backup classes not yet implemented"
```

---

## Task 2: Add the `average` language string

**Files:**
- Modify: `mod/customfeedback/lang/en/customfeedback.php:91` (after the `overallaverage` line)

- [ ] **Step 1: Add the string**

Open `lang/en/customfeedback.php`. After line 91 (`$string['overallaverage'] = ...`), insert:

```php
$string['average'] = 'Average';
```

The final lines of the Report section should look like:

```php
$string['overallaverage'] = 'Overall average across star questions';
$string['average'] = 'Average';
```

- [ ] **Step 2: Purge caches**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php
```

Expected: completes with no output (or "Purging all caches...Done.").

- [ ] **Step 3: Commit**

```bash
git add mod/customfeedback/lang/en/customfeedback.php
git commit -m "feat: add 'average' lang string for report average row"
```

---

## Task 3: Append average row to the export `$rows` array

**Files:**
- Modify: `mod/customfeedback/report.php:121` (after the `$rows[] = $row;` inside the response loop, before the export format check)

The export section of `report.php` currently looks like this (lines 93–193). The `$rows` array is fully populated around line 121 (end of `foreach ($responses as $r)` loop). The average row must be appended right after that loop, before the CSV and XLSX code paths consume `$rows`.

- [ ] **Step 1: Add the average row computation**

Open `report.php`. Find the closing brace of the `foreach ($responses as $r)` loop (around line 121, ending `$rows[] = $row;`). Immediately **after** that loop's closing `}`, insert:

```php
    // Append average row — star columns show "X.XX / 5", text columns are empty.
    $avgrow = [get_string('average', 'mod_customfeedback'), ''];
    foreach ($questions as $q) {
        if ($q->type === 'star') {
            $st = $starstats[$q->id];
            $avgrow[] = $st['count'] > 0
                ? round($st['sum'] / $st['count'], 2) . ' / 5'
                : 'N/A';
        } else {
            $avgrow[] = '';
        }
    }
    $rows[] = $avgrow;
```

The result should look like this in context:

```php
    $rows = [];
    foreach ($responses as $r) {
        $row = [];
        // ... existing code building $row ...
        $rows[] = $row;
    }

    // Append average row — star columns show "X.XX / 5", text columns are empty.
    $avgrow = [get_string('average', 'mod_customfeedback'), ''];
    foreach ($questions as $q) {
        if ($q->type === 'star') {
            $st = $starstats[$q->id];
            $avgrow[] = $st['count'] > 0
                ? round($st['sum'] / $st['count'], 2) . ' / 5'
                : 'N/A';
        } else {
            $avgrow[] = '';
        }
    }
    $rows[] = $avgrow;

    $summary = [];
    // ... existing summary code ...
```

- [ ] **Step 2: Manually verify CSV export**

Visit `http://100.71.234.30:8092`, open a Feedback Form activity that has at least one star question and one or more submitted responses. Go to the Reports tab. Click "Export as CSV". Open the downloaded file in a text editor or spreadsheet.

Verify:
- Last row before the blank Summary rows is labelled "Average".
- Star question column in that row shows e.g. `3.67 / 5`.
- Text question column in that row is empty.

- [ ] **Step 3: Manually verify XLSX export**

Click "Export as Excel". Open in a spreadsheet app. On the "Responses" sheet:
- Last row before the blank row is "Average".
- Star columns show `3.67 / 5` (written as string — that is correct since the value contains " / 5").
- Text columns are blank.
- The separate "Summary" sheet is unchanged.

- [ ] **Step 4: Commit**

```bash
git add mod/customfeedback/report.php
git commit -m "feat: append average row to CSV/XLSX export"
```

---

## Task 4: Add average row to the HTML report table

**Files:**
- Modify: `mod/customfeedback/report.php` — HTML table section (around line 280)

The HTML table is built between roughly lines 252–281. After `echo html_writer::table($table);`, add an `html_table_row` object with class `cfb-avg-row` appended to the table's `data` array before rendering. The cleanest approach is to build the row object and push it onto `$table->data` before the `html_writer::table()` call.

- [ ] **Step 1: Build and append the HTML average row**

Open `report.php`. Find the HTML table section — specifically the foreach loop that builds `$table->data`, around line 261:

```php
    foreach ($pageresponses as $r) {
        $row = [];
        // ... cells ...
        $table->data[] = $row;
    }
    echo html_writer::table($table);
```

After the `foreach` loop's closing `}` and **before** `echo html_writer::table($table);`, insert:

```php
    // Average row — shown on every page, all responses contribute.
    $avgtablerow = new html_table_row();
    $avgtablerow->attributes['class'] = 'cfb-avg-row';
    $labelcell = new html_table_cell(get_string('average', 'mod_customfeedback'));
    $labelcell->header = true;
    $avgtablerow->cells[] = $labelcell;
    $avgtablerow->cells[] = new html_table_cell(''); // submitted on — no date for avg row
    foreach ($questions as $q) {
        if ($q->type === 'star') {
            $st = $starstats[$q->id];
            $val = $st['count'] > 0
                ? round($st['sum'] / $st['count'], 2) . ' / 5'
                : 'N/A';
        } else {
            $val = '';
        }
        $avgtablerow->cells[] = new html_table_cell($val);
    }
    $table->data[] = $avgtablerow;
```

The surrounding context should look like:

```php
    foreach ($pageresponses as $r) {
        $row = [];
        // ... existing cell-building code ...
        $table->data[] = $row;
    }

    // Average row — shown on every page, all responses contribute.
    $avgtablerow = new html_table_row();
    $avgtablerow->attributes['class'] = 'cfb-avg-row';
    $labelcell = new html_table_cell(get_string('average', 'mod_customfeedback'));
    $labelcell->header = true;
    $avgtablerow->cells[] = $labelcell;
    $avgtablerow->cells[] = new html_table_cell('');
    foreach ($questions as $q) {
        if ($q->type === 'star') {
            $st = $starstats[$q->id];
            $val = $st['count'] > 0
                ? round($st['sum'] / $st['count'], 2) . ' / 5'
                : 'N/A';
        } else {
            $val = '';
        }
        $avgtablerow->cells[] = new html_table_cell($val);
    }
    $table->data[] = $avgtablerow;

    echo html_writer::table($table);
```

- [ ] **Step 2: Purge caches and verify in browser**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php
```

Visit the Reports tab for a Feedback Form activity with submissions. The table should have a final "Average" row:
- First cell: bold "Average" header cell.
- Second cell (Submitted on): empty.
- Star question columns: `3.67 / 5`.
- Text question columns: empty.
- Row appears on every page of the paginated table.

- [ ] **Step 3: Commit**

```bash
git add mod/customfeedback/report.php
git commit -m "feat: add average row to HTML report table"
```

---

## Task 5: Style the average row in CSS

**Files:**
- Modify: `mod/customfeedback/styles.css` (append after line 140)

- [ ] **Step 1: Add the CSS rule**

Open `styles.css`. After the last existing rule (`.cfb-chart-count`), append:

```css

/* Average summary row in the report table. */
.mod-customfeedback .cfb-avg-row td,
.mod-customfeedback .cfb-avg-row th {
    background-color: #f8f9fa;
    font-weight: 600;
    border-top: 2px solid #dee2e6;
}
```

- [ ] **Step 2: Purge caches and verify styling**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php
```

Hard-refresh the report page (Ctrl+Shift+R). The "Average" row should be visually distinct: light grey background, bold text, slightly thicker top border separating it from the response rows.

- [ ] **Step 3: Commit**

```bash
git add mod/customfeedback/styles.css
git commit -m "feat: style average row in report table"
```

---

## Final Verification

- [ ] Run the full PHPUnit suite to confirm nothing regressed:

```bash
docker exec moodle-web-8092 bash -c "cd /var/www/html && vendor/bin/phpunit mod/customfeedback/tests/lib_test.php"
```

Expected: `OK (7 tests, 38 assertions)`.

- [ ] Navigate to a Feedback Form with multiple responses spanning more than one page (if available). Confirm the Average row appears on every paginated page.

- [ ] Initiate a course backup from Moodle's site admin. Confirm no fatal error occurs for the customfeedback activity.
