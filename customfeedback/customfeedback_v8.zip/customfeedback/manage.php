<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Manage questions for a customfeedback instance.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // cmid.
$action = optional_param('action', '', PARAM_ALPHA);
$qid = optional_param('qid', 0, PARAM_INT);
$type = optional_param('type', '', PARAM_ALPHA);

list($course, $cm) = get_course_and_cm_from_cmid($id, 'customfeedback');
require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/customfeedback:manage', $context);

$customfeedback = $DB->get_record('customfeedback', ['id' => $cm->instance], '*', MUST_EXIST);

$baseurl = new moodle_url('/mod/customfeedback/manage.php', ['id' => $cm->id]);
$PAGE->set_url($baseurl);
$PAGE->set_context($context);
$PAGE->set_cm($cm, $course);
$PAGE->set_activity_record($customfeedback);
$PAGE->set_title(format_string($customfeedback->name) . ': ' . get_string('managequestions', 'mod_customfeedback'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->add_body_class('mod-customfeedback');
$PAGE->requires->css(new moodle_url('/mod/customfeedback/styles.css'));

// --- State-changing actions ------------------------------------------------

if ($action === 'delete' && $qid) {
    require_sesskey();
    $question = $DB->get_record('customfeedback_q',
        ['id' => $qid, 'customfeedbackid' => $customfeedback->id], '*', MUST_EXIST);
    $answerids = $DB->get_fieldset_select('customfeedback_a', 'id',
        'questionid = :qid', ['qid' => $question->id]);
    if ($answerids) {
        list($insql, $params) = $DB->get_in_or_equal($answerids, SQL_PARAMS_NAMED);
        $DB->delete_records_select('customfeedback_a', "id $insql", $params);
    }
    $DB->delete_records('customfeedback_q', ['id' => $question->id]);
    redirect($baseurl);
}

if (($action === 'moveup' || $action === 'movedown') && $qid) {
    require_sesskey();
    $current = $DB->get_record('customfeedback_q',
        ['id' => $qid, 'customfeedbackid' => $customfeedback->id], '*', MUST_EXIST);
    $op = $action === 'moveup' ? '<' : '>';
    $order = $action === 'moveup' ? 'DESC' : 'ASC';
    $sql = "SELECT * FROM {customfeedback_q}
             WHERE customfeedbackid = :cfid AND sortorder $op :so
          ORDER BY sortorder $order";
    $neighbour = $DB->get_records_sql($sql,
        ['cfid' => $customfeedback->id, 'so' => $current->sortorder], 0, 1);
    if ($neighbour) {
        $neighbour = reset($neighbour);
        $tmp = $current->sortorder;
        $DB->set_field('customfeedback_q', 'sortorder', $neighbour->sortorder, ['id' => $current->id]);
        $DB->set_field('customfeedback_q', 'sortorder', $tmp, ['id' => $neighbour->id]);
    }
    redirect($baseurl);
}

// --- Add / edit form -------------------------------------------------------

if ($action === 'add' || $action === 'edit') {
    if ($action === 'edit') {
        $question = $DB->get_record('customfeedback_q',
            ['id' => $qid, 'customfeedbackid' => $customfeedback->id], '*', MUST_EXIST);
        $formtype = $question->type;
    } else {
        if (!in_array($type, ['text', 'star'], true)) {
            throw new moodle_exception('invalidrequest', 'error');
        }
        $question = null;
        $formtype = $type;
    }

    $form = new \mod_customfeedback\form\question_form(
        new moodle_url($baseurl, ['action' => $action, 'qid' => $qid, 'type' => $formtype]),
        ['cmid' => $cm->id, 'type' => $formtype]
    );

    if ($question) {
        $form->set_data([
            'questionid' => $question->id,
            'cmid' => $cm->id,
            'type' => $question->type,
            'name' => $question->name,
            'intro_editor' => [
                'text' => $question->intro,
                'format' => $question->introformat,
            ],
            'required' => $question->required,
        ]);
    } else {
        $form->set_data([
            'questionid' => 0,
            'cmid' => $cm->id,
            'type' => $formtype,
            'required' => 0,
        ]);
    }

    if ($form->is_cancelled()) {
        redirect($baseurl);
    } else if ($data = $form->get_data()) {
        $now = time();
        $record = (object)[
            'customfeedbackid' => $customfeedback->id,
            'type' => $formtype,
            'name' => $data->name,
            'intro' => $data->intro_editor['text'],
            'introformat' => $data->intro_editor['format'],
            'required' => empty($data->required) ? 0 : 1,
            'timemodified' => $now,
        ];
        if (!empty($data->questionid)) {
            $record->id = $data->questionid;
            $DB->update_record('customfeedback_q', $record);
        } else {
            $max = $DB->get_field_sql(
                'SELECT MAX(sortorder) FROM {customfeedback_q} WHERE customfeedbackid = :cfid',
                ['cfid' => $customfeedback->id]
            );
            $record->sortorder = ((int)$max) + 1;
            $record->timecreated = $now;
            $DB->insert_record('customfeedback_q', $record);
        }
        redirect($baseurl);
    }

    echo $OUTPUT->header();
    echo $OUTPUT->heading($action === 'edit'
        ? get_string('editquestion', 'mod_customfeedback')
        : get_string('addquestion', 'mod_customfeedback'));
    $form->display();
    echo $OUTPUT->footer();
    exit;
}

// --- List view -------------------------------------------------------------

$questions = $DB->get_records('customfeedback_q',
    ['customfeedbackid' => $customfeedback->id], 'sortorder ASC');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('managequestions', 'mod_customfeedback'));

$addtexturl = new moodle_url($baseurl, ['action' => 'add', 'type' => 'text']);
$addstarurl = new moodle_url($baseurl, ['action' => 'add', 'type' => 'star']);
echo html_writer::div(
    html_writer::link($addtexturl, get_string('addquestion_text', 'mod_customfeedback'),
        ['class' => 'btn btn-primary me-2']) . ' ' .
    html_writer::link($addstarurl, get_string('addquestion_star', 'mod_customfeedback'),
        ['class' => 'btn btn-secondary']),
    'cfb-actions mb-3'
);

if (!$questions) {
    echo $OUTPUT->notification(get_string('noquestions', 'mod_customfeedback'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        '#',
        get_string('questionname', 'mod_customfeedback'),
        get_string('questiontype', 'mod_customfeedback'),
        get_string('questionrequired', 'mod_customfeedback'),
        get_string('actions', 'mod_customfeedback'),
    ];
    $table->attributes['class'] = 'generaltable cfb-question-table';
    $i = 1;
    $last = count($questions);
    foreach ($questions as $q) {
        $typestr = $q->type === 'star'
            ? get_string('questiontype_star', 'mod_customfeedback')
            : get_string('questiontype_text', 'mod_customfeedback');
        $editurl = new moodle_url($baseurl, ['action' => 'edit', 'qid' => $q->id]);
        $deleteurl = new moodle_url($baseurl,
            ['action' => 'delete', 'qid' => $q->id, 'sesskey' => sesskey()]);
        $upurl = new moodle_url($baseurl,
            ['action' => 'moveup', 'qid' => $q->id, 'sesskey' => sesskey()]);
        $downurl = new moodle_url($baseurl,
            ['action' => 'movedown', 'qid' => $q->id, 'sesskey' => sesskey()]);

        $actions = '';
        if ($i > 1) {
            $actions .= html_writer::link($upurl,
                $OUTPUT->pix_icon('t/up', get_string('moveup', 'mod_customfeedback')));
        }
        if ($i < $last) {
            $actions .= ' ' . html_writer::link($downurl,
                $OUTPUT->pix_icon('t/down', get_string('movedown', 'mod_customfeedback')));
        }
        $actions .= ' ' . html_writer::link($editurl,
            $OUTPUT->pix_icon('t/edit', get_string('editquestion', 'mod_customfeedback')));
        $actions .= ' ' . html_writer::link($deleteurl,
            $OUTPUT->pix_icon('t/delete', get_string('deletequestion', 'mod_customfeedback')),
            ['onclick' => 'return confirm(' . json_encode(get_string('confirmdelete', 'mod_customfeedback')) . ');']);

        $table->data[] = [
            $i,
            format_string($q->name),
            $typestr,
            $q->required ? '✓' : '',
            $actions,
        ];
        $i++;
    }
    echo html_writer::table($table);
}

echo $OUTPUT->footer();
