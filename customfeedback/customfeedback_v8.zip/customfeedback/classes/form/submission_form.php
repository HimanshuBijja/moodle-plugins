<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Submission form for mod_customfeedback.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_customfeedback\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class submission_form extends \moodleform {

    protected function definition() {
        $mform = $this->_form;
        $mform->updateAttributes(['class' => 'mform cfb-submission-form']);
        $customdata = $this->_customdata;
        $questions = $customdata['questions'];
        $cmid = (int)$customdata['cmid'];
        $context = $customdata['context'];

        $mform->addElement('hidden', 'id', $cmid);
        $mform->setType('id', PARAM_INT);

        $count = count($questions);
        $i = 0;
        foreach ($questions as $q) {
            $i++;
            $heading = \format_string($q->name);
            if ((int)$q->required === 1) {
                $heading .= ' <span class="text-danger" title="' . s(get_string('required')) . '">*</span>';
            }
            $intro = \format_text($q->intro, $q->introformat, ['context' => $context]);
            $headerhtml = '<div class="cfb-question-header">'
                . '<div class="cfb-question-name">' . $heading . '</div>'
                . '<div class="cfb-question-intro">' . $intro . '</div>'
                . '</div>';
            $mform->addElement('html', $headerhtml);

            $fieldname = 'q_' . $q->id;

            if ($q->type === 'star') {
                $required = (int)$q->required;
                $error = $mform->getElementError($fieldname);
                $starshtml = self::render_star_widget($fieldname, $required, $error);
                $mform->addElement('html', $starshtml);
                $mform->addElement('hidden', $fieldname, '');
                $mform->setType($fieldname, PARAM_INT);
            } else {
                $mform->addElement('textarea', $fieldname, '',
                    ['rows' => 5, 'cols' => 70, 'maxlength' => 2000, 'class' => 'cfb-textarea']);
                $mform->setType($fieldname, PARAM_TEXT);
            }

            if ($i < $count) {
                $mform->addElement('html', '<hr class="cfb-question-divider">');
            }
        }

        if (!empty($questions)) {
            $this->add_action_buttons(false, get_string('submitanswers', 'mod_customfeedback'));
        }
    }

    private static function render_star_widget(string $fieldname, int $required, ?string $error = null): string {
        $html = '<div class="cfb-star-rating-container">';
        $html .= '<div class="cfb-star-rating" data-cfb-field="' . s($fieldname) . '" role="radiogroup"'
            . ' aria-label="' . s(get_string('rateprompt', 'mod_customfeedback')) . '">';
        for ($i = 1; $i <= 5; $i++) {
            $aria = s(get_string('rating_aria', 'mod_customfeedback', $i));
            $html .= '<button type="button" class="cfb-star" data-value="' . $i . '"'
                . ' role="radio" aria-checked="false" aria-label="' . $aria . '" tabindex="' . ($i === 1 ? '0' : '-1') . '">'
                . '<svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true" focusable="false">'
                . '<path d="M12 2l2.95 6.36L22 9.27l-5.5 4.78L18.18 22 12 18.27 5.82 22l1.68-7.95L2 9.27l7.05-.91L12 2z" '
                . 'fill="currentColor"/></svg>'
                . '</button>';
        }
        $html .= '</div>';
        if ($error) {
            $html .= '<div class="cfb-error text-danger font-weight-bold mt-1">' . s($error) . '</div>';
        }
        $html .= '</div>';
        return $html;
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        $questions = $this->_customdata['questions'];
        foreach ($questions as $q) {
            $field = 'q_' . $q->id;
            $value = $data[$field] ?? '';
            if ($q->type === 'star') {
                if ($value === '' || $value === null) {
                    if ((int)$q->required === 1) {
                        $errors[$field] = get_string('requiredfield', 'mod_customfeedback');
                    }
                } else {
                    $intval = (int)$value;
                    if ($intval < 1 || $intval > 5 || (string)$intval !== (string)$value) {
                        $errors[$field] = get_string('invalidrating', 'mod_customfeedback');
                    }
                }
            } else {
                $trimmed = trim((string)$value);
                if ((int)$q->required === 1 && $trimmed === '') {
                    $errors[$field] = get_string('requiredfield', 'mod_customfeedback');
                }
            }
        }
        return $errors;
    }
}
