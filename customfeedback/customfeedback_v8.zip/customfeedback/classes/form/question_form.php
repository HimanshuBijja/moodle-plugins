<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Form for adding / editing a feedback question.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_customfeedback\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class question_form extends \moodleform {

    protected function definition() {
        $mform = $this->_form;
        $customdata = $this->_customdata;

        // NB: Field is named 'questionid' (not 'id') to avoid shadowing the
        // cmid URL parameter that manage.php reads via required_param('id').
        // POST values take precedence over GET in Moodle's optional_param, so
        // a hidden 'id' here would clobber the cmid on form submission.
        $mform->addElement('hidden', 'questionid', 0);
        $mform->setType('questionid', PARAM_INT);

        $mform->addElement('hidden', 'cmid', $customdata['cmid']);
        $mform->setType('cmid', PARAM_INT);

        $mform->addElement('hidden', 'type', $customdata['type']);
        $mform->setType('type', PARAM_ALPHA);

        $typelabel = $customdata['type'] === 'star'
            ? get_string('questiontype_star', 'mod_customfeedback')
            : get_string('questiontype_text', 'mod_customfeedback');
        $mform->addElement('static', 'typelabel', get_string('questiontype', 'mod_customfeedback'), s($typelabel));

        $mform->addElement('text', 'name', get_string('questionname', 'mod_customfeedback'), ['size' => 60]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', null, 'maxlength', 255, 'client');

        $mform->addElement('editor', 'intro_editor',
            get_string('questionintro', 'mod_customfeedback'), null,
            ['maxfiles' => 0, 'noclean' => false]);
        $mform->setType('intro_editor', PARAM_RAW);
        $mform->addRule('intro_editor', null, 'required', null, 'client');

        $mform->addElement('advcheckbox', 'required', get_string('questionrequired', 'mod_customfeedback'));
        $mform->setType('required', PARAM_INT);

        $this->add_action_buttons();
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        if (!in_array($data['type'], ['text', 'star'], true)) {
            $errors['typelabel'] = get_string('invalidrequest', 'error');
        }
        return $errors;
    }
}
