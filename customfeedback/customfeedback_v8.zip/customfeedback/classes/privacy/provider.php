<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy provider for mod_customfeedback.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_customfeedback\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\contextlist;

defined('MOODLE_INTERNAL') || die();

class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\core_userlist_provider,
    \core_privacy\local\request\plugin\provider {

    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('customfeedback_r', [
            'userid' => 'privacy:metadata:customfeedback_r:userid',
            'customfeedbackid' => 'privacy:metadata:customfeedback_r:customfeedbackid',
            'timecreated' => 'privacy:metadata:customfeedback_r:timecreated',
        ], 'privacy:metadata:customfeedback_r');
        $collection->add_database_table('customfeedback_a', [
            'valuestar' => 'privacy:metadata:customfeedback_a:valuestar',
            'valuetext' => 'privacy:metadata:customfeedback_a:valuetext',
        ], 'privacy:metadata:customfeedback_a');
        return $collection;
    }

    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();
        $sql = "SELECT ctx.id
                  FROM {customfeedback_r} r
                  JOIN {customfeedback} cf ON cf.id = r.customfeedbackid
                  JOIN {course_modules} cm ON cm.instance = cf.id AND cm.module = (
                       SELECT id FROM {modules} WHERE name = 'customfeedback')
                  JOIN {context} ctx ON ctx.instanceid = cm.id AND ctx.contextlevel = :modctx
                 WHERE r.userid = :userid";
        $contextlist->add_from_sql($sql, ['modctx' => CONTEXT_MODULE, 'userid' => $userid]);
        return $contextlist;
    }

    public static function get_users_in_context(\core_privacy\local\request\userlist $userlist) {
        global $DB;
        $context = $userlist->get_context();
        if ($context->contextlevel !== CONTEXT_MODULE) {
            return;
        }
        $cm = get_coursemodule_from_id('customfeedback', $context->instanceid);
        if (!$cm) {
            return;
        }
        $sql = "SELECT userid FROM {customfeedback_r}
                 WHERE customfeedbackid = :cfid AND userid <> 0";
        $userlist->add_from_sql('userid', $sql, ['cfid' => $cm->instance]);
    }

    public static function export_user_data(\core_privacy\local\request\approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel !== CONTEXT_MODULE) {
                continue;
            }
            $cm = get_coursemodule_from_id('customfeedback', $context->instanceid);
            if (!$cm) {
                continue;
            }
            $responses = $DB->get_records('customfeedback_r',
                ['customfeedbackid' => $cm->instance, 'userid' => $userid]);
            foreach ($responses as $response) {
                $answers = $DB->get_records('customfeedback_a', ['responseid' => $response->id]);
                $data = (object)[
                    'timecreated' => \core_privacy\local\request\transform::datetime($response->timecreated),
                    'answers' => array_values($answers),
                ];
                \core_privacy\local\request\writer::with_context($context)->export_data(
                    [get_string('pluginname', 'mod_customfeedback'), 'response-' . $response->id],
                    $data
                );
            }
        }
    }

    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        if ($context->contextlevel !== CONTEXT_MODULE) {
            return;
        }
        $cm = get_coursemodule_from_id('customfeedback', $context->instanceid);
        if (!$cm) {
            return;
        }
        $responses = $DB->get_fieldset_select('customfeedback_r', 'id',
            'customfeedbackid = :cfid', ['cfid' => $cm->instance]);
        if ($responses) {
            list($insql, $params) = $DB->get_in_or_equal($responses, SQL_PARAMS_NAMED);
            $DB->delete_records_select('customfeedback_a', "responseid $insql", $params);
        }
        $DB->delete_records('customfeedback_r', ['customfeedbackid' => $cm->instance]);
    }

    public static function delete_data_for_user(\core_privacy\local\request\approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel !== CONTEXT_MODULE) {
                continue;
            }
            $cm = get_coursemodule_from_id('customfeedback', $context->instanceid);
            if (!$cm) {
                continue;
            }
            $responses = $DB->get_fieldset_select('customfeedback_r', 'id',
                'customfeedbackid = :cfid AND userid = :u',
                ['cfid' => $cm->instance, 'u' => $userid]);
            if ($responses) {
                list($insql, $params) = $DB->get_in_or_equal($responses, SQL_PARAMS_NAMED);
                $DB->delete_records_select('customfeedback_a', "responseid $insql", $params);
                $DB->delete_records_select('customfeedback_r', "id $insql", $params);
            }
        }
    }

    public static function delete_data_for_users(\core_privacy\local\request\approved_userlist $userlist) {
        global $DB;
        $context = $userlist->get_context();
        if ($context->contextlevel !== CONTEXT_MODULE) {
            return;
        }
        $cm = get_coursemodule_from_id('customfeedback', $context->instanceid);
        if (!$cm) {
            return;
        }
        $userids = $userlist->get_userids();
        if (!$userids) {
            return;
        }
        list($insql, $params) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
        $params['cfid'] = $cm->instance;
        $responses = $DB->get_fieldset_select('customfeedback_r', 'id',
            "customfeedbackid = :cfid AND userid $insql", $params);
        if ($responses) {
            list($insql2, $params2) = $DB->get_in_or_equal($responses, SQL_PARAMS_NAMED);
            $DB->delete_records_select('customfeedback_a', "responseid $insql2", $params2);
            $DB->delete_records_select('customfeedback_r', "id $insql2", $params2);
        }
    }
}
