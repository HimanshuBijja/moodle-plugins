<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for mod_customfeedback.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Feedback Form
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'Feedback Form';
$string['modulenameplural'] = 'Feedback Forms';
$string['modulename_help'] = 'A lightweight feedback activity supporting text answers and 1-5 star ratings.';
$string['pluginname'] = 'Feedback Form';
$string['pluginadministration'] = 'Feedback Form administration';
$string['customfeedback:addinstance'] = 'Add a new Feedback Form activity';
$string['customfeedback:manage'] = 'Manage questions and reports for Feedback Form';
$string['customfeedback:viewreport'] = 'View Feedback Form reports';
$string['customfeedback:submit'] = 'Submit a Feedback Form response';

$string['name'] = 'Name';
$string['allowmulti'] = 'Allow multiple submissions';
$string['allowmulti_help'] = 'If enabled, students may submit feedback more than once.';
$string['recordusernames'] = 'Record user names';
$string['non_anonymous'] = 'User\'s name will be logged and shown with answers';

// Tabs.
$string['tab_view'] = 'View';
$string['tab_questions'] = 'Questions';
$string['tab_reports'] = 'Reports';

// Pages.
$string['managequestions'] = 'Manage questions';
$string['submitfeedback'] = 'Submit feedback';
$string['feedbackreport'] = 'Feedback report';
$string['alreadysubmitted'] = 'You have already completed this feedback.';

// Question fields.
$string['questiontype'] = 'Question type';
$string['questiontype_text'] = 'Text answer';
$string['questiontype_star'] = 'Star rating (1-5)';
$string['questionname'] = 'Question name';
$string['questionintro'] = 'Question prompt';
$string['questionrequired'] = 'Required';
$string['addquestion'] = 'Add question';
$string['addquestion_text'] = 'Add text question';
$string['addquestion_star'] = 'Add star rating question';
$string['editquestion'] = 'Edit question';
$string['deletequestion'] = 'Delete question';
$string['confirmdelete'] = 'Delete this question? All answers submitted for this question will also be deleted.';
$string['noquestions'] = 'No questions have been configured yet.';
$string['moveup'] = 'Move up';
$string['movedown'] = 'Move down';
$string['actions'] = 'Actions';

// Submission.
$string['rateprompt'] = 'Select a rating from 1 to 5 stars';
$string['rating_aria'] = '{$a} stars';
$string['submitanswers'] = 'Submit feedback';
$string['submitsuccess'] = 'Thank you, your feedback has been recorded.';
$string['noactivequestions'] = 'There are no feedback questions to answer.';
$string['requiredfield'] = 'This question is required.';
$string['invalidrating'] = 'Rating must be a whole number from 1 to 5.';

// Report.
$string['totalresponses'] = 'Total responses';
$string['averagerating'] = 'Average rating';
$string['responserate'] = 'Response rate';
$string['exportcsv'] = 'Export as CSV';
$string['exportxlsx'] = 'Export as Excel';
$string['respondent'] = 'Respondent';
$string['submittedon'] = 'Submitted on';
$string['anonymous'] = 'Anonymous';
$string['noresponses'] = 'No responses yet.';
$string['starscount'] = '{$a} stars';
$string['overallaverage'] = 'Overall average across star questions';
$string['average'] = 'Average';

// Privacy.
$string['privacy:metadata:customfeedback_r'] = 'Stores one submission per user per activity.';
$string['privacy:metadata:customfeedback_r:userid'] = 'The ID of the user who submitted the feedback.';
$string['privacy:metadata:customfeedback_r:customfeedbackid'] = 'The activity instance the submission belongs to.';
$string['privacy:metadata:customfeedback_r:timecreated'] = 'When the submission was created.';
$string['privacy:metadata:customfeedback_a'] = 'Stores individual answers for each question.';
$string['privacy:metadata:customfeedback_a:valuestar'] = 'Star rating value (1-5).';
$string['privacy:metadata:customfeedback_a:valuetext'] = 'Free-text answer.';
