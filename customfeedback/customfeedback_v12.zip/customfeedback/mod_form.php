<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Instance settings form for mod_customfeedback.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/moodleform_mod.php');

class mod_customfeedback_mod_form extends moodleform_mod {

    protected function definition() {
        $mform = $this->_form;

        $mform->addElement('header', 'general', get_string('general', 'form'));

        $mform->addElement('text', 'name', get_string('name', 'mod_customfeedback'), ['size' => 64]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');

        $this->standard_intro_elements();

        $mform->addElement('header', 'cfsettings', get_string('pluginname', 'mod_customfeedback'));
        $options = [
            1 => get_string('anonymous', 'mod_customfeedback'),
            2 => get_string('non_anonymous', 'mod_customfeedback'),
        ];
        $mform->addElement('select', 'anonymous', get_string('recordusernames', 'mod_customfeedback'), $options);
        $mform->setDefault('anonymous', 1);
        $mform->addElement('advcheckbox', 'allowmulti', get_string('allowmulti', 'mod_customfeedback'));
        $mform->addHelpButton('allowmulti', 'allowmulti', 'mod_customfeedback');
        $mform->setDefault('allowmulti', 0);

        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }
}
