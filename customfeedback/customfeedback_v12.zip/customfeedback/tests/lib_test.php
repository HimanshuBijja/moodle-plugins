<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Tests for mod_customfeedback lib.php lifecycle callbacks.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_customfeedback;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot . '/mod/customfeedback/lib.php');

/**
 * @covers ::customfeedback_add_instance
 * @covers ::customfeedback_update_instance
 * @covers ::customfeedback_delete_instance
 * @covers ::customfeedback_supports
 */
final class lib_test extends \advanced_testcase {

    /**
     * Build a minimal data object usable by customfeedback_add_instance().
     */
    private function make_instance_data(\stdClass $course, array $overrides = []): \stdClass {
        $data = (object)[
            'course'       => $course->id,
            'name'         => 'Sample feedback',
            'intro'        => 'Tell us how it went.',
            'introformat'  => FORMAT_HTML,
            'allowmulti'   => 0,
            'anonymous'    => 1,
        ];
        foreach ($overrides as $k => $v) {
            $data->$k = $v;
        }
        return $data;
    }

    public function test_add_instance_inserts_record_and_sets_timestamps(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $before = time();
        $id = customfeedback_add_instance($this->make_instance_data($course));
        $after = time();

        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);

        $record = $DB->get_record('customfeedback', ['id' => $id], '*', MUST_EXIST);
        $this->assertEquals('Sample feedback', $record->name);
        $this->assertEquals($course->id, $record->course);
        $this->assertEquals(0, (int)$record->allowmulti);
        $this->assertGreaterThanOrEqual($before, (int)$record->timecreated);
        $this->assertLessThanOrEqual($after, (int)$record->timecreated);
        $this->assertEquals($record->timecreated, $record->timemodified);
    }

    public function test_add_instance_normalises_allowmulti(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();

        $idoff = customfeedback_add_instance($this->make_instance_data($course));
        $idon  = customfeedback_add_instance($this->make_instance_data($course, ['allowmulti' => 1]));
        $idstr = customfeedback_add_instance($this->make_instance_data($course, ['allowmulti' => '1']));
        $idempty = customfeedback_add_instance($this->make_instance_data($course, ['allowmulti' => '']));

        $this->assertEquals(0, (int)$DB->get_field('customfeedback', 'allowmulti', ['id' => $idoff]));
        $this->assertEquals(1, (int)$DB->get_field('customfeedback', 'allowmulti', ['id' => $idon]));
        $this->assertEquals(1, (int)$DB->get_field('customfeedback', 'allowmulti', ['id' => $idstr]));
        $this->assertEquals(0, (int)$DB->get_field('customfeedback', 'allowmulti', ['id' => $idempty]));
    }

    public function test_add_instance_normalises_anonymous(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();

        $idempty = customfeedback_add_instance($this->make_instance_data($course, ['anonymous' => '']));
        $idnon   = customfeedback_add_instance($this->make_instance_data($course, ['anonymous' => 2]));
        $idstr   = customfeedback_add_instance($this->make_instance_data($course, ['anonymous' => '2']));

        $this->assertEquals(1, (int)$DB->get_field('customfeedback', 'anonymous', ['id' => $idempty]));
        $this->assertEquals(2, (int)$DB->get_field('customfeedback', 'anonymous', ['id' => $idnon]));
        $this->assertEquals(2, (int)$DB->get_field('customfeedback', 'anonymous', ['id' => $idstr]));
    }

    public function test_update_instance_persists_anonymous(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $id = customfeedback_add_instance($this->make_instance_data($course));

        $update = (object)[
            'instance'    => $id,
            'course'      => $course->id,
            'name'        => 'Renamed',
            'intro'       => 'Updated description',
            'introformat' => FORMAT_HTML,
            'allowmulti'  => 1,
            'anonymous'   => 2,
        ];
        $result = customfeedback_update_instance($update);
        $this->assertTrue((bool)$result);

        $reloaded = $DB->get_record('customfeedback', ['id' => $id], '*', MUST_EXIST);
        $this->assertEquals(2, (int)$reloaded->anonymous);
    }

    public function test_add_instance_supplies_intro_defaults(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $data = (object)[
            'course' => $course->id,
            'name'   => 'No intro fields supplied',
        ];
        $id = customfeedback_add_instance($data);

        $record = $DB->get_record('customfeedback', ['id' => $id], '*', MUST_EXIST);
        $this->assertSame('', (string)$record->intro);
        $this->assertEquals(FORMAT_HTML, (int)$record->introformat);
    }

    public function test_update_instance_persists_changes(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $id = customfeedback_add_instance($this->make_instance_data($course));
        $original = $DB->get_record('customfeedback', ['id' => $id], '*', MUST_EXIST);

        // Force the modified timestamp to advance.
        sleep(1);

        $update = (object)[
            'instance'    => $id,
            'course'      => $course->id,
            'name'        => 'Renamed',
            'intro'       => 'Updated description',
            'introformat' => FORMAT_HTML,
            'allowmulti'  => 1,
        ];
        $result = customfeedback_update_instance($update);
        $this->assertTrue((bool)$result);

        $reloaded = $DB->get_record('customfeedback', ['id' => $id], '*', MUST_EXIST);
        $this->assertEquals('Renamed', $reloaded->name);
        $this->assertEquals('Updated description', $reloaded->intro);
        $this->assertEquals(1, (int)$reloaded->allowmulti);
        $this->assertGreaterThan((int)$original->timemodified, (int)$reloaded->timemodified);
        // timecreated must NOT change on update.
        $this->assertEquals((int)$original->timecreated, (int)$reloaded->timecreated);
    }

    public function test_delete_instance_returns_false_for_unknown_id(): void {
        $this->resetAfterTest();
        $this->assertFalse(customfeedback_delete_instance(99999));
    }

    public function test_delete_instance_cascades_to_questions_responses_and_answers(): void {
        $this->resetAfterTest();
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $cfid = customfeedback_add_instance($this->make_instance_data($course));
        $otherid = customfeedback_add_instance($this->make_instance_data(
            $course, ['name' => 'Other instance']));

        $now = time();
        $qtext = (object)[
            'customfeedbackid' => $cfid,
            'type' => 'text', 'name' => 'Q1',
            'intro' => '', 'introformat' => FORMAT_HTML,
            'required' => 1, 'sortorder' => 1,
            'timecreated' => $now, 'timemodified' => $now,
        ];
        $qtext->id = $DB->insert_record('customfeedback_q', $qtext);
        $qstar = (object)[
            'customfeedbackid' => $cfid,
            'type' => 'star', 'name' => 'Q2',
            'intro' => '', 'introformat' => FORMAT_HTML,
            'required' => 0, 'sortorder' => 2,
            'timecreated' => $now, 'timemodified' => $now,
        ];
        $qstar->id = $DB->insert_record('customfeedback_q', $qstar);

        // A question on the other instance — must survive the delete.
        $otherq = clone $qtext;
        unset($otherq->id);
        $otherq->customfeedbackid = $otherid;
        $otherq->id = $DB->insert_record('customfeedback_q', $otherq);

        $response = (object)['customfeedbackid' => $cfid, 'userid' => 0, 'timecreated' => $now];
        $response->id = $DB->insert_record('customfeedback_r', $response);

        $DB->insert_record('customfeedback_a', (object)[
            'responseid' => $response->id, 'questionid' => $qtext->id,
            'valuestar' => null, 'valuetext' => 'hello',
        ]);
        $DB->insert_record('customfeedback_a', (object)[
            'responseid' => $response->id, 'questionid' => $qstar->id,
            'valuestar' => 4, 'valuetext' => null,
        ]);

        $this->assertTrue(customfeedback_delete_instance($cfid));

        $this->assertFalse($DB->record_exists('customfeedback', ['id' => $cfid]));
        $this->assertEquals(0, $DB->count_records('customfeedback_q', ['customfeedbackid' => $cfid]));
        $this->assertEquals(0, $DB->count_records('customfeedback_r', ['customfeedbackid' => $cfid]));
        $this->assertEquals(0, $DB->count_records('customfeedback_a', ['responseid' => $response->id]));

        // Sibling instance untouched.
        $this->assertTrue($DB->record_exists('customfeedback', ['id' => $otherid]));
        $this->assertTrue($DB->record_exists('customfeedback_q', ['id' => $otherq->id]));
    }

    public function test_supports_declared_features(): void {
        $this->assertTrue(customfeedback_supports(FEATURE_MOD_INTRO));
        $this->assertFalse(customfeedback_supports(FEATURE_BACKUP_MOODLE2));
        $this->assertTrue(customfeedback_supports(FEATURE_SHOW_DESCRIPTION));
        $this->assertTrue(customfeedback_supports(FEATURE_COMPLETION_TRACKS_VIEWS));
        $this->assertFalse(customfeedback_supports(FEATURE_GROUPS));
        $this->assertFalse(customfeedback_supports(FEATURE_GROUPINGS));
        $this->assertFalse(customfeedback_supports(FEATURE_GRADE_HAS_GRADE));
        $this->assertNull(customfeedback_supports('something_that_does_not_exist'));
    }
}
