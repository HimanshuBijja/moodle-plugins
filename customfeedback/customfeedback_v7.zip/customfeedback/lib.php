<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Activity lifecycle and integration callbacks for mod_customfeedback.
 *
 * @package    mod_customfeedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Capability declarations for course features.
 *
 * @param string $feature
 * @return mixed
 */
function customfeedback_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_BACKUP_MOODLE2:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return true;
        case FEATURE_GROUPS:
            return false;
        case FEATURE_GROUPINGS:
            return false;
        case FEATURE_GRADE_HAS_GRADE:
            return false;
        case FEATURE_MOD_PURPOSE:
            return defined('MOD_PURPOSE_COMMUNICATION') ? MOD_PURPOSE_COMMUNICATION : null;
        default:
            return null;
    }
}

/**
 * Create a new instance.
 *
 * @param stdClass $data
 * @param mod_customfeedback_mod_form|null $mform
 * @return int new instance id
 */
function customfeedback_add_instance($data, $mform = null) {
    global $DB;
    $data->timecreated = time();
    $data->timemodified = $data->timecreated;
    $data->allowmulti = empty($data->allowmulti) ? 0 : 1;
    if (!isset($data->introformat)) {
        $data->introformat = FORMAT_HTML;
    }
    if (!isset($data->intro)) {
        $data->intro = '';
    }
    return $DB->insert_record('customfeedback', $data);
}

/**
 * Update an existing instance.
 *
 * @param stdClass $data
 * @param mod_customfeedback_mod_form|null $mform
 * @return bool
 */
function customfeedback_update_instance($data, $mform = null) {
    global $DB;
    $data->id = $data->instance;
    $data->timemodified = time();
    $data->allowmulti = empty($data->allowmulti) ? 0 : 1;
    if (!isset($data->introformat)) {
        $data->introformat = FORMAT_HTML;
    }
    if (!isset($data->intro)) {
        $data->intro = '';
    }
    return $DB->update_record('customfeedback', $data);
}

/**
 * Delete an instance and all associated rows.
 *
 * @param int $id customfeedback instance id
 * @return bool
 */
function customfeedback_delete_instance($id) {
    global $DB;
    if (!$DB->record_exists('customfeedback', ['id' => $id])) {
        return false;
    }
    // Delete answers belonging to this instance's responses.
    $responseids = $DB->get_fieldset_select('customfeedback_r', 'id',
        'customfeedbackid = :cfid', ['cfid' => $id]);
    if ($responseids) {
        list($insql, $params) = $DB->get_in_or_equal($responseids, SQL_PARAMS_NAMED);
        $DB->delete_records_select('customfeedback_a', "responseid $insql", $params);
    }
    $DB->delete_records('customfeedback_r', ['customfeedbackid' => $id]);
    $DB->delete_records('customfeedback_q', ['customfeedbackid' => $id]);
    $DB->delete_records('customfeedback', ['id' => $id]);
    return true;
}

/**
 * Inject Questions / Reports tabs into the activity secondary navigation.
 *
 * Moodle 4.x renders children of the modulesettings node as tabs in the
 * activity's secondary navigation.
 *
 * @param settings_navigation $settingsnav
 * @param navigation_node $modulenode
 */
function customfeedback_extend_settings_navigation(settings_navigation $settingsnav, navigation_node $modulenode) {
    global $PAGE;

    $cm = $PAGE->cm ?? null;
    if (!$cm || $cm->modname !== 'customfeedback') {
        return;
    }
    $context = context_module::instance($cm->id);

    if (has_capability('mod/customfeedback:manage', $context)) {
        $modulenode->add(
            get_string('tab_questions', 'mod_customfeedback'),
            new moodle_url('/mod/customfeedback/manage.php', ['id' => $cm->id]),
            navigation_node::TYPE_SETTING,
            null,
            'customfeedback_questions'
        );
    }
    if (has_capability('mod/customfeedback:manage', $context)
        || has_capability('mod/customfeedback:viewreport', $context)) {
        $modulenode->add(
            get_string('tab_reports', 'mod_customfeedback'),
            new moodle_url('/mod/customfeedback/report.php', ['id' => $cm->id]),
            navigation_node::TYPE_SETTING,
            null,
            'customfeedback_reports'
        );
    }
}
