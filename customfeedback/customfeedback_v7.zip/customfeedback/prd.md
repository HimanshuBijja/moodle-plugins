# Project Requirements Document (PRD): Custom Feedback Moodle Plugin

## 1. Document Control
*   **Project Name:** Custom Feedback Moodle Plugin (`local_custom_feedback`)
*   **Status:** Draft / Awaiting Review
*   **Author:** Antigravity AI
*   **Target Moodle Version:** Moodle 4.x (PHP 8.1 / MariaDB 10.11.6)

---

## 2. Objective & Scope

### 2.1 Objective
The goal is to develop a lightweight, secure, and modern custom feedback plugin for Moodle. The plugin will be developed as a **Local Plugin** (`local_custom_feedback`). Unlike the heavy core `mod_feedback` activity, this plugin will offer a streamlined administrative interface to configure feedback questions and an intuitive, modern interface for users to submit responses.

### 2.2 Scope Constraints
To keep the plugin highly focused, it will support **exactly two** feedback item types:
1.  **Text Answer**: A multi-line textarea input for open-ended comments.
2.  **Star Rating**: An interactive 1-to-5 star rating component.

No other question types (e.g., multiple choice, numeric, captcha) will be included.

---

## 3. User Roles & Capabilities

The plugin defines three primary capabilities using Moodle's capability system to separate management, viewing, and submission permissions:

| Role / Archetype | Required Capability | Permissions & Actions |
| :--- | :--- | :--- |
| **Students / Respondents** | `local/custom_feedback:submit` | View active feedback forms, select star ratings, type text responses, and submit feedback. |
| **Auditor / Manager** | `local/custom_feedback:viewreport` | Read-only access to view aggregate responses, individual response details, and export reports. Cannot add, edit, delete, or re-order questions. |
| **Teachers / Admins** | `local/custom_feedback:manage` | Manage questions (add, edit, delete, re-order) and view/export all reports. |

---

## 4. Functional Requirements

### 4.1 Question Configuration (Teacher/Admin View)
Teachers and administrators can manage questions via a dedicated management interface (`/local/custom_feedback/manage.php`).
*   **Access from Course Navbar**: This management interface (and reporting dashboard) will be accessible directly from Moodle's course settings/tertiary navigation navbar. In modern Moodle 4.x themes, this is achieved by registering callback functions in `lib.php` (such as `local_custom_feedback_extend_navigation_course` or using `navigation_node` extension APIs) to inject navigation nodes into the course page navbar.
*   **Add Question**: Add a new question of type `Text Answer` or `Star Rating`.
*   **Question Fields**:
    *   *Question Name*: A short identifier.
    *   *Question Prompt/Description*: The actual question text shown to users.
    *   *Required Checkbox*: If checked, users cannot submit the feedback without answering this question.
*   **Reorder**: Adjust the order of questions using drag-and-drop or simple ordering buttons.
*   **Delete**: Delete questions. *Warning: Deleting a question will delete all associated answers.*

### 4.2 Feedback Submission (Student/Respondent View)
Users can view and submit feedback via `/local/custom_feedback/index.php`:
*   **Dynamic Loading**: The page loads all active questions in their specified sort order.
*   **Interactive Star Rating**:
    *   Renders five empty stars.
    *   Hovering over a star highlights it and all preceding stars.
    *   Clicking a star selects that rating (1 to 5).
    *   Responsive design for mobile/touch screens.
*   **Text Answer**: A clean, spacious text area with a character counter (optional, default max 2000 characters).
*   **Validation**:
    *   Client-side and server-side validation to ensure required questions are answered.
    *   Star rating values are strictly validated to be integers in the range `[1, 5]`.
*   **Submission Handling**: Submitting saves responses to the database, prevents double-submission (if configured), and redirects the user with a success notification.

### 4.3 Reporting & Analytics (Teacher/Auditor View)
Available at `/local/custom_feedback/report.php` for users with either `local/custom_feedback:manage` or `local/custom_feedback:viewreport` capabilities:
*   **Overview Metrics**:
    *   Total number of submissions.
    *   Average rating for each `Star Rating` question.
    *   A distribution bar chart (1 to 5 stars) for star ratings (Google Forms style).
*   **Response List Table**:
    *   Paginated list of all submissions.
    *   Displays respondent name (or "Anonymous" if the feedback is configured to be anonymous), date, and answers.
*   **Data Export**:
    *   Export all responses as a CSV or Excel file.
    *   **Exported File Metrics & Metadata**: The export file must include:
        1.  *Tabular Data*: Rows showing user responses to each question.
        2.  *Summary Section (Footer or separate sheet/header)*:
            *   Total responses count.
            *   Average rating calculated per individual Star Rating question.
            *   Overall average rating calculated across all Star Rating questions combined.
            *   Response Rate (percentage of enrolled course users who completed the feedback, based on course enrollment query).

---

## 5. UI/UX Design & Aesthetic Specifications

The user interface must be clean, light-themed, and align with Moodle's active default themes (such as the standard Boost theme).

*   **Aesthetics & Moodle Integration**:
    *   **Light Theme Only**: Avoid custom dark themes or dark mode overrides. The design must integrate seamlessly with Moodle's default styling.
    *   **Standard Moodle Components**: Use built-in Moodle CSS classes, form widgets, page layouts, and HTML templates from Moodle's theme engine to ensure consistency.
*   **Star Rating Component**:
    *   Avoid using standard dropdowns or number input boxes.
    *   Use SVG stars rendering inline that scale cleanly.
    *   Hover/Active state: Gold/amber color (e.g., `#FFC107` or standard Bootstrap warning yellow) indicating selection.
    *   Inactive state: Soft grey (e.g., `#E0E0E0` or Bootstrap muted grey).
    *   Focus & accessibility support following standard keyboard interaction cues.
*   **Text Area**:
    *   Use standard Moodle forms API rendering (`moodleform` textarea element).
    *   Standard Moodle theme styling for input fields (Bootstrap control borders, focus state glows).
*   **Google Forms Style Bar Graph (Star Rating Distribution)**:
    *   Render aggregate rating breakdowns using horizontal bar charts styled like Google Forms.
    *   Each of the 5 rating scores (1-5 stars) is represented as a row containing:
        *   The rating value label (e.g., "5 stars").
        *   A horizontal track bar containing a colored fill representing the percentage of total responses.
        *   The exact response count and percentage (e.g., "15 (55.6%)").
    *   Use standard Bootstrap utility classes for progress bars (e.g., `<div class="progress">` and `<div class="progress-bar">`) with a light primary color (e.g., light blue `#4285F4` or Boost primary brand color) to ensure styling matches Moodle's default styles cleanly.

---

## 6. Technical Architecture & Database Design

### 6.1 Database Schema (`db/install.xml`)
We will create three custom tables using Moodle's XMLDB scheme.

```mermaid
erDiagram
    local_cust_feedback_q {
        bigint id PK
        varchar type "text or star"
        varchar name
        text intro "question prompt"
        smallint introformat
        tinyint required "0 or 1"
        bigint sortorder
        bigint timecreated
        bigint timemodified
    }
    local_cust_feedback_r {
        bigint id PK
        bigint userid "FK to mdl_user (0 if anonymous)"
        bigint timecreated
    }
    local_cust_feedback_a {
        bigint id PK
        bigint responseid FK "local_cust_feedback_r.id"
        bigint questionid FK "local_cust_feedback_q.id"
        bigint valuestar "1-5 rating (NULL if text)"
        text valuetext "text response (NULL if star)"
    }
    local_cust_feedback_r ||--o{ local_cust_feedback_a : contains
    local_cust_feedback_q ||--o{ local_cust_feedback_a : answers
```

### 6.2 Plugin Structure
```
local/custom_feedback/
├── classes/
│   ├── form/
│   │   ├── question_form.php   (Form for adding/editing questions)
│   │   └── submission_form.php (Form for students submitting answers)
│   └── privacy/
│       └── provider.php        (GDPR Compliance)
├── db/
│   ├── access.php              (Capabilities definitions)
│   └── install.xml             (Database schema definition)
├── lang/
│   └── en/
│       └── local_custom_feedback.php (Language strings)
├── pix/
│   └── icon.svg                (Plugin icon)
├── index.php                   (Student response submission page)
├── manage.php                  (Admin question management page)
├── report.php                  (Admin reporting/export page)
├── version.php                 (Plugin version details)
└── lib.php                     (Navigation node injection / API helpers)
```

---

## 7. Security Architecture & Guidelines

We must adhere strictly to Moodle's security framework and the **Mandatory Secure Web Skills** to eliminate vulnerabilities (XSS, SQL Injection, CSRF, and Privilege Escalation):

### 7.1 SQL Injection Prevention
*   **No Raw SQL Concatenation**: Under no circumstances should database queries be built using string concatenation containing user input.
*   **Moodle DB API Usage**: All operations must use Moodle's `$DB` global object methods:
    *   *Inserting data*: `$DB->insert_record('local_cust_feedback_a', $answerrecord)`
    *   *Fetching records*: `$DB->get_records_menu('local_cust_feedback_q', ['required' => 1])`
    *   *Safe placeholders*: For custom SQL queries, always use parameter arrays: `$DB->get_records_sql("SELECT ... WHERE userid = :userid", ['userid' => $USER->id])`

### 7.2 Cross-Site Scripting (XSS) Prevention
*   **Output Encoding**: Any content retrieved from the database (e.g., question prompts, user-submitted text answers) must be escaped before being rendered.
*   **Moodle Output Functions**:
    *   Use `format_string($question->name)` for short plain-text names.
    *   Use `format_text($question->intro, $question->introformat)` for rich-text descriptions.
    *   Use `s($value)` or `p($value)` inside HTML attribute tags to prevent attribute breakout.
*   **Vanilla JavaScript Safety**: If any dynamic JS is used to render stats or handle stars:
    *   **NEVER** assign user data to `innerHTML` or `insertAdjacentHTML`.
    *   Always use `textContent` or use dynamic element creation (`document.createElement()`) to populate values.

### 7.3 CSRF Protection
*   **Form Security**: All state-changing actions (creating a question, deleting a question, submitting feedback) must be wrapped in Moodle's `moodleform` class, which automatically embeds a secure session key (`sesskey`).
*   **Manual Request Validation**: If processing simple GET/POST URLs for operations like deletion or sorting, always validate the session key manually:
    ```php
    require_sesskey();
    ```

### 7.4 Privilege Escalation & Authorization
*   **Session Checks**: Every entry point script must start with:
    ```php
    require_login($courseorcategorycontext);
    ```
*   **Capability Validation**: Protect files with strict capability checks:
    ```php
    // In manage.php
    require_capability('local/custom_feedback:manage', $coursecontext);

    // In report.php
    // Access allowed if user has viewreport OR manage capability.
    if (!has_capability('local/custom_feedback:manage', $coursecontext)) {
        require_capability('local/custom_feedback:viewreport', $coursecontext);
    }

    // In index.php
    require_capability('local/custom_feedback:submit', $coursecontext);
    ```

---

## 8. Verification & Testing Plan

To ensure functional correctness and high security, we will conduct automated and manual verification:

### 8.1 Security Validation (Verification Plan)
*   **SQL Injection Check**: Verify that SQL queries are fully parameterized. Scan codebase with a security scanner.
*   **XSS Payloads**:
    *   Attempt to save a question name or description containing `<script>alert('XSS')</script>`. Verify it is outputted safely as plain text/escaped elements.
    *   Attempt to submit a text answer containing HTML injection payloads. Verify that reporting views escape this input correctly.
*   **CSRF Test**: Attempt to trigger a question deletion or feedback submission without a valid `sesskey` parameter. Verify that the request is rejected with a Moodle error.
*   **Access Bypass**: Attempt to access `/local/custom_feedback/manage.php` as a Guest or Student user. Verify that access is denied.

### 8.2 Functional Validation
*   **Submission Workflow**: Verify that a user can successfully submit answers, and that required field validation blocks submissions when required questions are empty.
*   **Database Inspection**: Inspect the tables in MariaDB to confirm records are structured correctly.
*   **Star Rating Interaction**: Manually verify star rating styling, hovering states, click selection, and keyboard/touch responsiveness.

---

## 9. Version 2: Transition to Moodle Activity Module (`mod_customfeedback`)

To integrate the custom feedback plugin seamlessly into Moodle's course workflow, Version 2 transitions the plugin from a global/local plugin (`local_custom_feedback`) to a standard **Moodle Activity Module** (`mod_customfeedback`). This allows the feedback to behave like any other Moodle activity (e.g., Quiz, Assignment, or Choice).

### 9.1 Key Module Behaviors & User Flows
1.  **Add Activity or Resource**:
    *   Teachers can add a "Custom Feedback" instance directly to any course topic/section using Moodle's standard "Add an activity or resource" chooser dialog.
    *   Adding an activity triggers the standard configuration form (`mod_form.php`), allowing teachers to define the instance name, intro description, completion criteria, and the **"Allow multiple submissions"** setting (a checkbox that determines if students can submit feedback more than once).
2.  **Navigation & Reporting Tab**:
    *   Clicking the activity link on the course page redirects to `/mod/customfeedback/view.php?id=<course_module_id>`.
    *   **Student view**:
        *   If the activity has "Allow multiple submissions" disabled (default) and the student has already submitted feedback, the page displays a secure notice: "You have already completed this feedback."
        *   Otherwise, it displays the interactive feedback questionnaire form.
    *   **Teacher/Auditor view**: Renders the questionnaire alongside Moodle's standard 4.x activity navigation tabs. The tabs are injected into the activity navbar:
        *   *View*: Displays the student form preview.
        *   *Questions*: Direct link to configure/manage questions for this specific instance (`/mod/customfeedback/manage.php?id=<course_module_id>`).
        *   *Reports*: Direct link to view aggregate data, Google Forms style bar charts, and individual answers (`/mod/customfeedback/report.php?id=<course_module_id>`).

### 9.2 Updated Database Schema (`mod/customfeedback/db/install.xml`)
To support multiple independent activity instances across different courses, the database tables must store the association with each module instance (`customfeedbackid`):

```mermaid
erDiagram
    mdl_customfeedback {
        bigint id PK
        bigint course "FK to mdl_course"
        varchar name
        text intro
        smallint introformat
        tinyint allowmulti "0 = submit once, 1 = allow multiple"
        bigint timecreated
        bigint timemodified
    }
    mdl_customfeedback_q {
        bigint id PK
        bigint customfeedbackid FK "mdl_customfeedback.id"
        varchar type "text or star"
        varchar name
        text intro
        smallint introformat
        tinyint required
        bigint sortorder
        bigint timecreated
        bigint timemodified
    }
    mdl_customfeedback_r {
        bigint id PK
        bigint customfeedbackid FK "mdl_customfeedback.id"
        bigint userid "FK to mdl_user"
        bigint timecreated
    }
    mdl_customfeedback_a {
        bigint id PK
        bigint responseid FK "mdl_customfeedback_r.id"
        bigint questionid FK "mdl_customfeedback_q.id"
        bigint valuestar
        text valuetext
    }
    mdl_customfeedback ||--o{ mdl_customfeedback_q : owns
    mdl_customfeedback ||--o{ mdl_customfeedback_r : receives
    mdl_customfeedback_r ||--o{ mdl_customfeedback_a : contains
    mdl_customfeedback_q ||--o{ mdl_customfeedback_a : answers
```

### 9.3 Directory Structure & Core Callback Implementation
The plugin files are relocated to `/mod/customfeedback/`:
```
mod/customfeedback/
├── classes/
│   └── privacy/provider.php      (GDPR Compliance)
├── db/
│   ├── access.php                (Capabilities: addinstance, submit, viewreport, manage)
│   └── install.xml               (Four-table schema)
├── lang/en/
│   └── customfeedback.php        (Module language strings)
├── pix/icon.svg                  (Chooser icon)
├── mod_form.php                  (Instance settings form: Name, Description, Allow Multiple Submissions)
├── lib.php                       (Core module lifecycle callbacks)
├── view.php                      (Main view/student submission)
├── manage.php                    (Question setup per instance)
├── report.php                    (Google-forms style reports and CSV export)
├── version.php                   (Module version details)
└── styles.css                    (Moodle Boost-native CSS overrides)
```

#### Core Activity Callbacks in `lib.php`
To function as a Moodle activity, the following life-cycle functions are implemented in `lib.php`:
*   `customfeedback_add_instance($customfeedback)`: Inserts instance settings into `mdl_customfeedback` table upon creation.
*   `customfeedback_update_instance($customfeedback)`: Updates instance settings in `mdl_customfeedback`.
*   `customfeedback_delete_instance($id)`: Deletes the activity instance from `mdl_customfeedback`, and performs cascading deletes for all associated questions (`mdl_customfeedback_q`), submissions (`mdl_customfeedback_r`), and answers (`mdl_customfeedback_a`) to ensure no orphaned database data.
*   `customfeedback_supports($feature)`: Returns capability declarations indicating compatibility with course features (e.g., `FEATURE_MOD_INTRO`, `FEATURE_BACKUP_MOODLE2`).
```,StartLine:233,TargetContent:
