// Custom Feedback — star rating UI.
// No user input is ever assigned via innerHTML; only textContent / class toggling.
(function () {
    'use strict';

    function applyState(group, value) {
        var stars = group.querySelectorAll('.cfb-star');
        stars.forEach(function (s) {
            var v = parseInt(s.getAttribute('data-value'), 10);
            if (v <= value) {
                s.classList.add('cfb-active');
            } else {
                s.classList.remove('cfb-active');
            }
            s.setAttribute('aria-checked', v === value ? 'true' : 'false');
            s.setAttribute('tabindex', v === value ? '0' : '-1');
        });
        if (value === 0) {
            // Reset: first star focusable.
            var first = group.querySelector('.cfb-star');
            if (first) {
                first.setAttribute('tabindex', '0');
            }
        }
    }

    function previewHover(group, value) {
        var stars = group.querySelectorAll('.cfb-star');
        stars.forEach(function (s) {
            var v = parseInt(s.getAttribute('data-value'), 10);
            if (v <= value) {
                s.classList.add('cfb-hover');
            } else {
                s.classList.remove('cfb-hover');
            }
        });
    }

    function clearHover(group) {
        var stars = group.querySelectorAll('.cfb-star');
        stars.forEach(function (s) { s.classList.remove('cfb-hover'); });
    }

    function init(group) {
        var fieldname = group.getAttribute('data-cfb-field');
        if (!fieldname) { return; }
        var hidden = document.querySelector('input[type=hidden][name="' + fieldname + '"]');
        if (!hidden) { return; }

        // Restore initial value if present.
        var initial = parseInt(hidden.value, 10);
        if (initial >= 1 && initial <= 5) {
            applyState(group, initial);
        }

        group.addEventListener('mouseover', function (e) {
            var btn = e.target.closest('.cfb-star');
            if (!btn) { return; }
            previewHover(group, parseInt(btn.getAttribute('data-value'), 10));
        });
        group.addEventListener('mouseleave', function () { clearHover(group); });

        group.addEventListener('click', function (e) {
            var btn = e.target.closest('.cfb-star');
            if (!btn) { return; }
            e.preventDefault();
            var v = parseInt(btn.getAttribute('data-value'), 10);
            // Click same value again to clear.
            if (parseInt(hidden.value, 10) === v) {
                hidden.value = '';
                applyState(group, 0);
            } else {
                hidden.value = String(v);
                applyState(group, v);
            }
        });

        group.addEventListener('keydown', function (e) {
            var btn = e.target.closest('.cfb-star');
            if (!btn) { return; }
            var current = parseInt(btn.getAttribute('data-value'), 10);
            var next = null;
            if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { next = Math.min(5, current + 1); }
            else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { next = Math.max(1, current - 1); }
            else if (e.key === ' ' || e.key === 'Enter') {
                e.preventDefault();
                hidden.value = String(current);
                applyState(group, current);
                return;
            }
            if (next !== null) {
                e.preventDefault();
                var target = group.querySelector('.cfb-star[data-value="' + next + '"]');
                if (target) { target.focus(); }
            }
        });
    }

    function bootstrap() {
        document.querySelectorAll('.cfb-star-rating').forEach(init);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootstrap);
    } else {
        bootstrap();
    }
})();
