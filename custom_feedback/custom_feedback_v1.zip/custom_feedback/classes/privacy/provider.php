<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy provider for local_custom_feedback.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_custom_feedback\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\contextlist;

defined('MOODLE_INTERNAL') || die();

class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\core_userlist_provider,
    \core_privacy\local\request\plugin\provider {

    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table(
            'local_cust_feedback_r',
            [
                'userid' => 'privacy:metadata:local_cust_feedback_r:userid',
                'courseid' => 'privacy:metadata:local_cust_feedback_r:courseid',
                'timecreated' => 'privacy:metadata:local_cust_feedback_r:timecreated',
            ],
            'privacy:metadata:local_cust_feedback_r'
        );
        $collection->add_database_table(
            'local_cust_feedback_a',
            [
                'valuestar' => 'privacy:metadata:local_cust_feedback_a:valuestar',
                'valuetext' => 'privacy:metadata:local_cust_feedback_a:valuetext',
            ],
            'privacy:metadata:local_cust_feedback_a'
        );
        return $collection;
    }

    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();
        $sql = "SELECT ctx.id
                  FROM {local_cust_feedback_r} r
                  JOIN {context} ctx ON ctx.instanceid = r.courseid AND ctx.contextlevel = :coursectx
                 WHERE r.userid = :userid";
        $contextlist->add_from_sql($sql, ['coursectx' => CONTEXT_COURSE, 'userid' => $userid]);
        return $contextlist;
    }

    public static function get_users_in_context(\core_privacy\local\request\userlist $userlist) {
        $context = $userlist->get_context();
        if ($context->contextlevel !== CONTEXT_COURSE) {
            return;
        }
        $sql = "SELECT userid FROM {local_cust_feedback_r} WHERE courseid = :courseid AND userid <> 0";
        $userlist->add_from_sql('userid', $sql, ['courseid' => $context->instanceid]);
    }

    public static function export_user_data(\core_privacy\local\request\approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel !== CONTEXT_COURSE) {
                continue;
            }
            $responses = $DB->get_records('local_cust_feedback_r',
                ['courseid' => $context->instanceid, 'userid' => $userid]);
            foreach ($responses as $response) {
                $answers = $DB->get_records('local_cust_feedback_a', ['responseid' => $response->id]);
                $data = (object)[
                    'timecreated' => \core_privacy\local\request\transform::datetime($response->timecreated),
                    'answers' => array_values($answers),
                ];
                \core_privacy\local\request\writer::with_context($context)->export_data(
                    [get_string('pluginname', 'local_custom_feedback'), 'response-' . $response->id],
                    $data
                );
            }
        }
    }

    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        if ($context->contextlevel !== CONTEXT_COURSE) {
            return;
        }
        $responses = $DB->get_fieldset_select('local_cust_feedback_r', 'id', 'courseid = :c',
            ['c' => $context->instanceid]);
        if ($responses) {
            list($insql, $params) = $DB->get_in_or_equal($responses, SQL_PARAMS_NAMED);
            $DB->delete_records_select('local_cust_feedback_a', "responseid $insql", $params);
        }
        $DB->delete_records('local_cust_feedback_r', ['courseid' => $context->instanceid]);
    }

    public static function delete_data_for_user(\core_privacy\local\request\approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel !== CONTEXT_COURSE) {
                continue;
            }
            $responses = $DB->get_fieldset_select('local_cust_feedback_r', 'id',
                'courseid = :c AND userid = :u', ['c' => $context->instanceid, 'u' => $userid]);
            if ($responses) {
                list($insql, $params) = $DB->get_in_or_equal($responses, SQL_PARAMS_NAMED);
                $DB->delete_records_select('local_cust_feedback_a', "responseid $insql", $params);
                $DB->delete_records_select('local_cust_feedback_r', "id $insql", $params);
            }
        }
    }

    public static function delete_data_for_users(\core_privacy\local\request\approved_userlist $userlist) {
        global $DB;
        $context = $userlist->get_context();
        if ($context->contextlevel !== CONTEXT_COURSE) {
            return;
        }
        $userids = $userlist->get_userids();
        if (!$userids) {
            return;
        }
        list($insql, $params) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
        $params['courseid'] = $context->instanceid;
        $responses = $DB->get_fieldset_select('local_cust_feedback_r', 'id',
            "courseid = :courseid AND userid $insql", $params);
        if ($responses) {
            list($insql2, $params2) = $DB->get_in_or_equal($responses, SQL_PARAMS_NAMED);
            $DB->delete_records_select('local_cust_feedback_a', "responseid $insql2", $params2);
            $DB->delete_records_select('local_cust_feedback_r', "id $insql2", $params2);
        }
    }
}
