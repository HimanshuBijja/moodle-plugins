<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Form for submitting feedback responses.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_custom_feedback\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

/**
 * Submission form. Renders one element per question.
 *
 * Star ratings are rendered as a custom HTML element backed by a hidden field
 * — JS toggles the selection — but server-side validation is authoritative.
 */
class submission_form extends \moodleform {

    protected function definition() {
        global $OUTPUT;
        $mform = $this->_form;
        $customdata = $this->_customdata;
        $questions = $customdata['questions'];
        $courseid = (int)$customdata['courseid'];

        $mform->addElement('hidden', 'courseid', $courseid);
        $mform->setType('courseid', PARAM_INT);

        foreach ($questions as $q) {
            // Question header: name + formatted intro. Both escaped via Moodle output APIs.
            $heading = \format_string($q->name);
            $intro = \format_text($q->intro, $q->introformat, ['context' => \context_course::instance($courseid)]);
            $headerhtml = '<div class="cfb-question-header">'
                . '<div class="cfb-question-name">' . $heading . '</div>'
                . '<div class="cfb-question-intro">' . $intro . '</div>'
                . '</div>';
            $mform->addElement('html', $headerhtml);

            $fieldname = 'q_' . $q->id;

            if ($q->type === 'star') {
                $required = (int)$q->required;
                $starshtml = self::render_star_widget($fieldname, $required);
                $mform->addElement('html', $starshtml);
                // Hidden field that carries the actual rating value.
                $mform->addElement('hidden', $fieldname, '');
                $mform->setType($fieldname, PARAM_INT);
            } else {
                $mform->addElement('textarea', $fieldname, '',
                    ['rows' => 5, 'cols' => 70, 'maxlength' => 2000, 'class' => 'cfb-textarea']);
                $mform->setType($fieldname, PARAM_TEXT);
            }
        }

        if (!empty($questions)) {
            $this->add_action_buttons(false, get_string('submitanswers', 'local_custom_feedback'));
        }
    }

    /**
     * Build the visual star rating widget. Server-side validation is what counts;
     * this is purely UI.
     */
    private static function render_star_widget(string $fieldname, int $required): string {
        $html = '<div class="cfb-star-rating" data-cfb-field="' . s($fieldname) . '" role="radiogroup"'
            . ' aria-label="' . s(get_string('rateprompt', 'local_custom_feedback')) . '">';
        for ($i = 1; $i <= 5; $i++) {
            $aria = s(get_string('rating_aria', 'local_custom_feedback', $i));
            $html .= '<button type="button" class="cfb-star" data-value="' . $i . '"'
                . ' role="radio" aria-checked="false" aria-label="' . $aria . '" tabindex="' . ($i === 1 ? '0' : '-1') . '">'
                . '<svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true" focusable="false">'
                . '<path d="M12 2l2.95 6.36L22 9.27l-5.5 4.78L18.18 22 12 18.27 5.82 22l1.68-7.95L2 9.27l7.05-.91L12 2z" '
                . 'fill="currentColor"/></svg>'
                . '</button>';
        }
        if ($required) {
            $html .= '<span class="cfb-required" aria-hidden="true">*</span>';
        }
        $html .= '</div>';
        return $html;
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        $questions = $this->_customdata['questions'];
        foreach ($questions as $q) {
            $field = 'q_' . $q->id;
            $value = $data[$field] ?? '';
            if ($q->type === 'star') {
                if ($value === '' || $value === null) {
                    if ((int)$q->required === 1) {
                        $errors[$field] = get_string('requiredfield', 'local_custom_feedback');
                    }
                } else {
                    $intval = (int)$value;
                    if ($intval < 1 || $intval > 5 || (string)$intval !== (string)$value) {
                        $errors[$field] = get_string('invalidrating', 'local_custom_feedback');
                    }
                }
            } else {
                $trimmed = trim((string)$value);
                if ((int)$q->required === 1 && $trimmed === '') {
                    $errors[$field] = get_string('requiredfield', 'local_custom_feedback');
                }
            }
        }
        return $errors;
    }
}
