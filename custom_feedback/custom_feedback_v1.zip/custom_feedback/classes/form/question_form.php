<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Form for adding / editing a feedback question.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_custom_feedback\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class question_form extends \moodleform {

    protected function definition() {
        $mform = $this->_form;
        $customdata = $this->_customdata;

        $mform->addElement('hidden', 'id', 0);
        $mform->setType('id', PARAM_INT);

        $mform->addElement('hidden', 'courseid', $customdata['courseid']);
        $mform->setType('courseid', PARAM_INT);

        // The type is fixed at creation (chosen via the "Add" button) and not editable.
        $mform->addElement('hidden', 'type', $customdata['type']);
        $mform->setType('type', PARAM_ALPHA);

        $typelabel = $customdata['type'] === 'star'
            ? get_string('questiontype_star', 'local_custom_feedback')
            : get_string('questiontype_text', 'local_custom_feedback');
        $mform->addElement('static', 'typelabel', get_string('questiontype', 'local_custom_feedback'), s($typelabel));

        $mform->addElement('text', 'name', get_string('questionname', 'local_custom_feedback'), ['size' => 60]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', null, 'maxlength', 255, 'client');

        $mform->addElement('editor', 'intro_editor',
            get_string('questionintro', 'local_custom_feedback'), null,
            ['maxfiles' => 0, 'noclean' => false]);
        $mform->setType('intro_editor', PARAM_RAW);
        $mform->addRule('intro_editor', null, 'required', null, 'client');

        $mform->addElement('advcheckbox', 'required', get_string('questionrequired', 'local_custom_feedback'));
        $mform->setType('required', PARAM_INT);

        $this->add_action_buttons();
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        if (!in_array($data['type'], ['text', 'star'], true)) {
            $errors['typelabel'] = get_string('invalidrequest', 'error');
        }
        return $errors;
    }
}
