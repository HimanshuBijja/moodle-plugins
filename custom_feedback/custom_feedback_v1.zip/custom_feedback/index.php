<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Submit feedback for a course.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$courseid = required_param('courseid', PARAM_INT);

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($course->id);
require_capability('local/custom_feedback:submit', $context);

$baseurl = new moodle_url('/local/custom_feedback/index.php', ['courseid' => $courseid]);
$PAGE->set_url($baseurl);
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('submitfeedback', 'local_custom_feedback'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->add_body_class('local-custom-feedback');
$PAGE->requires->css('/local/custom_feedback/styles.css');
$PAGE->requires->js('/local/custom_feedback/js/stars.js');

$questions = $DB->get_records('local_cust_feedback_q',
    ['courseid' => $courseid], 'sortorder ASC');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('submitfeedback', 'local_custom_feedback'));

if (!$questions) {
    echo $OUTPUT->notification(get_string('noactivequestions', 'local_custom_feedback'), 'info');
    echo $OUTPUT->footer();
    exit;
}

$form = new \local_custom_feedback\form\submission_form($baseurl,
    ['questions' => $questions, 'courseid' => $courseid]);

if ($data = $form->get_data()) {
    $now = time();
    $response = (object)[
        'courseid' => $courseid,
        'userid' => (int)$USER->id,
        'timecreated' => $now,
    ];
    $response->id = $DB->insert_record('local_cust_feedback_r', $response);

    foreach ($questions as $q) {
        $field = 'q_' . $q->id;
        $val = $data->$field ?? null;
        $answer = (object)[
            'responseid' => $response->id,
            'questionid' => $q->id,
            'valuestar' => null,
            'valuetext' => null,
        ];
        if ($q->type === 'star') {
            if ($val !== null && $val !== '') {
                $intv = (int)$val;
                if ($intv >= 1 && $intv <= 5) {
                    $answer->valuestar = $intv;
                }
            }
            // Skip insert if star not provided and not required (validator would have caught required).
            if ($answer->valuestar === null && (int)$q->required === 0) {
                continue;
            }
        } else {
            $trimmed = trim((string)$val);
            if ($trimmed === '' && (int)$q->required === 0) {
                continue;
            }
            $answer->valuetext = $trimmed;
        }
        $DB->insert_record('local_cust_feedback_a', $answer);
    }

    redirect(new moodle_url('/course/view.php', ['id' => $courseid]),
        get_string('submitsuccess', 'local_custom_feedback'),
        null, \core\output\notification::NOTIFY_SUCCESS);
}

$form->display();

echo $OUTPUT->footer();
