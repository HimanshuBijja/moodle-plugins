<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library functions for local_custom_feedback.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Inject Custom Feedback links into the course navigation node.
 *
 * @param navigation_node $navigation
 * @param stdClass $course
 * @param context_course $context
 */
function local_custom_feedback_extend_navigation_course(navigation_node $navigation, stdClass $course, context_course $context) {
    if (has_capability('local/custom_feedback:manage', $context)) {
        $navigation->add(
            get_string('nav_manage', 'local_custom_feedback'),
            new moodle_url('/local/custom_feedback/manage.php', ['courseid' => $course->id]),
            navigation_node::TYPE_SETTING,
            null,
            'custom_feedback_manage'
        );
    }

    if (has_capability('local/custom_feedback:submit', $context)) {
        $navigation->add(
            get_string('nav_submit', 'local_custom_feedback'),
            new moodle_url('/local/custom_feedback/index.php', ['courseid' => $course->id]),
            navigation_node::TYPE_SETTING,
            null,
            'custom_feedback_submit'
        );
    }

    if (has_capability('local/custom_feedback:manage', $context)
        || has_capability('local/custom_feedback:viewreport', $context)) {
        $navigation->add(
            get_string('nav_report', 'local_custom_feedback'),
            new moodle_url('/local/custom_feedback/report.php', ['courseid' => $course->id]),
            navigation_node::TYPE_SETTING,
            null,
            'custom_feedback_report'
        );
    }
}
