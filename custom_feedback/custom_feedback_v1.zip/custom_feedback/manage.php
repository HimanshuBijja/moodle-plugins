<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Manage feedback questions for a course.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$courseid = required_param('courseid', PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$id = optional_param('id', 0, PARAM_INT);
$type = optional_param('type', '', PARAM_ALPHA);

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($course->id);
require_capability('local/custom_feedback:manage', $context);

$baseurl = new moodle_url('/local/custom_feedback/manage.php', ['courseid' => $courseid]);
$PAGE->set_url($baseurl);
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('managequestions', 'local_custom_feedback'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->add_body_class('local-custom-feedback');

// --- Handle simple state-changing actions (require sesskey) ----------------

if ($action === 'delete' && $id) {
    require_sesskey();
    $question = $DB->get_record('local_cust_feedback_q',
        ['id' => $id, 'courseid' => $courseid], '*', MUST_EXIST);
    $answerids = $DB->get_fieldset_select('local_cust_feedback_a', 'id',
        'questionid = :qid', ['qid' => $question->id]);
    if ($answerids) {
        list($insql, $params) = $DB->get_in_or_equal($answerids, SQL_PARAMS_NAMED);
        $DB->delete_records_select('local_cust_feedback_a', "id $insql", $params);
    }
    $DB->delete_records('local_cust_feedback_q', ['id' => $question->id]);
    redirect($baseurl);
}

if (($action === 'moveup' || $action === 'movedown') && $id) {
    require_sesskey();
    $current = $DB->get_record('local_cust_feedback_q',
        ['id' => $id, 'courseid' => $courseid], '*', MUST_EXIST);
    $op = $action === 'moveup' ? '<' : '>';
    $order = $action === 'moveup' ? 'DESC' : 'ASC';
    $sql = "SELECT * FROM {local_cust_feedback_q}
             WHERE courseid = :cid AND sortorder $op :so
          ORDER BY sortorder $order";
    $neighbour = $DB->get_records_sql($sql,
        ['cid' => $courseid, 'so' => $current->sortorder], 0, 1);
    if ($neighbour) {
        $neighbour = reset($neighbour);
        $tmp = $current->sortorder;
        $DB->set_field('local_cust_feedback_q', 'sortorder', $neighbour->sortorder, ['id' => $current->id]);
        $DB->set_field('local_cust_feedback_q', 'sortorder', $tmp, ['id' => $neighbour->id]);
    }
    redirect($baseurl);
}

// --- Add / Edit form -------------------------------------------------------

if ($action === 'add' || $action === 'edit') {
    if ($action === 'edit') {
        $question = $DB->get_record('local_cust_feedback_q',
            ['id' => $id, 'courseid' => $courseid], '*', MUST_EXIST);
        $formtype = $question->type;
    } else {
        if (!in_array($type, ['text', 'star'], true)) {
            throw new moodle_exception('invalidrequest', 'error');
        }
        $question = null;
        $formtype = $type;
    }

    $form = new \local_custom_feedback\form\question_form(
        new moodle_url($baseurl, ['action' => $action, 'id' => $id, 'type' => $formtype]),
        ['courseid' => $courseid, 'type' => $formtype]
    );

    if ($question) {
        $form->set_data([
            'id' => $question->id,
            'courseid' => $courseid,
            'type' => $question->type,
            'name' => $question->name,
            'intro_editor' => [
                'text' => $question->intro,
                'format' => $question->introformat,
            ],
            'required' => $question->required,
        ]);
    } else {
        $form->set_data([
            'id' => 0,
            'courseid' => $courseid,
            'type' => $formtype,
            'required' => 0,
        ]);
    }

    if ($form->is_cancelled()) {
        redirect($baseurl);
    } else if ($data = $form->get_data()) {
        $now = time();
        $record = (object)[
            'courseid' => $courseid,
            'type' => $formtype,
            'name' => $data->name,
            'intro' => $data->intro_editor['text'],
            'introformat' => $data->intro_editor['format'],
            'required' => empty($data->required) ? 0 : 1,
            'timemodified' => $now,
        ];
        if (!empty($data->id)) {
            $record->id = $data->id;
            $DB->update_record('local_cust_feedback_q', $record);
        } else {
            $max = $DB->get_field_sql(
                'SELECT MAX(sortorder) FROM {local_cust_feedback_q} WHERE courseid = :cid',
                ['cid' => $courseid]
            );
            $record->sortorder = ((int)$max) + 1;
            $record->timecreated = $now;
            $DB->insert_record('local_cust_feedback_q', $record);
        }
        redirect($baseurl);
    }

    echo $OUTPUT->header();
    echo $OUTPUT->heading($action === 'edit'
        ? get_string('editquestion', 'local_custom_feedback')
        : get_string('addquestion', 'local_custom_feedback'));
    $form->display();
    echo $OUTPUT->footer();
    exit;
}

// --- Default: list view ----------------------------------------------------

$PAGE->requires->css('/local/custom_feedback/styles.css');

$questions = $DB->get_records('local_cust_feedback_q',
    ['courseid' => $courseid], 'sortorder ASC');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('managequestions', 'local_custom_feedback'));

$addtexturl = new moodle_url($baseurl, ['action' => 'add', 'type' => 'text']);
$addstarurl = new moodle_url($baseurl, ['action' => 'add', 'type' => 'star']);
echo html_writer::div(
    html_writer::link($addtexturl, get_string('addquestion_text', 'local_custom_feedback'),
        ['class' => 'btn btn-primary me-2']) . ' ' .
    html_writer::link($addstarurl, get_string('addquestion_star', 'local_custom_feedback'),
        ['class' => 'btn btn-secondary']),
    'cfb-actions mb-3'
);

if (!$questions) {
    echo $OUTPUT->notification(get_string('noquestions', 'local_custom_feedback'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        '#',
        get_string('questionname', 'local_custom_feedback'),
        get_string('questiontype', 'local_custom_feedback'),
        get_string('questionrequired', 'local_custom_feedback'),
        get_string('actions', 'local_custom_feedback'),
    ];
    $table->attributes['class'] = 'generaltable cfb-question-table';
    $i = 1;
    $last = count($questions);
    foreach ($questions as $q) {
        $typestr = $q->type === 'star'
            ? get_string('questiontype_star', 'local_custom_feedback')
            : get_string('questiontype_text', 'local_custom_feedback');
        $editurl = new moodle_url($baseurl, ['action' => 'edit', 'id' => $q->id]);
        $deleteurl = new moodle_url($baseurl,
            ['action' => 'delete', 'id' => $q->id, 'sesskey' => sesskey()]);
        $upurl = new moodle_url($baseurl,
            ['action' => 'moveup', 'id' => $q->id, 'sesskey' => sesskey()]);
        $downurl = new moodle_url($baseurl,
            ['action' => 'movedown', 'id' => $q->id, 'sesskey' => sesskey()]);

        $actions = '';
        if ($i > 1) {
            $actions .= html_writer::link($upurl,
                $OUTPUT->pix_icon('t/up', get_string('moveup', 'local_custom_feedback')));
        }
        if ($i < $last) {
            $actions .= ' ' . html_writer::link($downurl,
                $OUTPUT->pix_icon('t/down', get_string('movedown', 'local_custom_feedback')));
        }
        $actions .= ' ' . html_writer::link($editurl,
            $OUTPUT->pix_icon('t/edit', get_string('editquestion', 'local_custom_feedback')));
        $actions .= ' ' . html_writer::link($deleteurl,
            $OUTPUT->pix_icon('t/delete', get_string('deletequestion', 'local_custom_feedback')),
            ['onclick' => 'return confirm(' . json_encode(get_string('confirmdelete', 'local_custom_feedback')) . ');']);

        $table->data[] = [
            $i,
            format_string($q->name),
            $typestr,
            $q->required ? '✓' : '',
            $actions,
        ];
        $i++;
    }
    echo html_writer::table($table);
}

echo $OUTPUT->footer();
