<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for local_custom_feedback.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Custom Feedback';

// Capabilities.
$string['custom_feedback:manage'] = 'Manage custom feedback questions and view reports';
$string['custom_feedback:viewreport'] = 'View custom feedback reports';
$string['custom_feedback:submit'] = 'Submit a custom feedback response';

// Navigation.
$string['nav_manage'] = 'Manage feedback questions';
$string['nav_submit'] = 'Submit feedback';
$string['nav_report'] = 'Feedback report';

// Pages / headings.
$string['managequestions'] = 'Manage feedback questions';
$string['submitfeedback'] = 'Submit feedback';
$string['feedbackreport'] = 'Feedback report';

// Question fields.
$string['questiontype'] = 'Question type';
$string['questiontype_text'] = 'Text answer';
$string['questiontype_star'] = 'Star rating (1-5)';
$string['questionname'] = 'Question name';
$string['questionintro'] = 'Question prompt';
$string['questionrequired'] = 'Required';
$string['addquestion'] = 'Add question';
$string['addquestion_text'] = 'Add text question';
$string['addquestion_star'] = 'Add star rating question';
$string['editquestion'] = 'Edit question';
$string['deletequestion'] = 'Delete question';
$string['confirmdelete'] = 'Delete this question? All answers submitted for this question will also be deleted.';
$string['noquestions'] = 'No questions have been configured yet.';
$string['moveup'] = 'Move up';
$string['movedown'] = 'Move down';
$string['actions'] = 'Actions';

// Submission.
$string['rateprompt'] = 'Select a rating from 1 to 5 stars';
$string['rating_aria'] = '{$a} stars';
$string['submitanswers'] = 'Submit feedback';
$string['submitsuccess'] = 'Thank you, your feedback has been recorded.';
$string['noactivequestions'] = 'There are no feedback questions to answer.';
$string['requiredfield'] = 'This question is required.';
$string['invalidrating'] = 'Rating must be a whole number from 1 to 5.';

// Report.
$string['totalresponses'] = 'Total responses';
$string['averagerating'] = 'Average rating';
$string['responserate'] = 'Response rate';
$string['exportcsv'] = 'Export as CSV';
$string['exportxlsx'] = 'Export as Excel';
$string['respondent'] = 'Respondent';
$string['submittedon'] = 'Submitted on';
$string['anonymous'] = 'Anonymous';
$string['noresponses'] = 'No responses yet.';
$string['ratingcount'] = '{$a->count} ({$a->percent}%)';
$string['starscount'] = '{$a} stars';
$string['overallaverage'] = 'Overall average across star questions';

// Privacy.
$string['privacy:metadata:local_cust_feedback_r'] = 'Stores one submission per user per course.';
$string['privacy:metadata:local_cust_feedback_r:userid'] = 'The ID of the user who submitted the feedback (0 if anonymous).';
$string['privacy:metadata:local_cust_feedback_r:courseid'] = 'The ID of the course the feedback belongs to.';
$string['privacy:metadata:local_cust_feedback_r:timecreated'] = 'When the submission was created.';
$string['privacy:metadata:local_cust_feedback_a'] = 'Stores individual answers for each question.';
$string['privacy:metadata:local_cust_feedback_a:valuestar'] = 'Star rating value (1-5).';
$string['privacy:metadata:local_cust_feedback_a:valuetext'] = 'Free-text answer.';
