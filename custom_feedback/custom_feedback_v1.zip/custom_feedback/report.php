<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Report and export for custom feedback.
 *
 * @package    local_custom_feedback
 * @copyright  2026 Custom Feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/excellib.class.php');
require_once($CFG->libdir . '/csvlib.class.php');

$courseid = required_param('courseid', PARAM_INT);
$format = optional_param('format', '', PARAM_ALPHA);
$page = optional_param('page', 0, PARAM_INT);
$perpage = 25;

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($course->id);

if (!has_capability('local/custom_feedback:manage', $context)) {
    require_capability('local/custom_feedback:viewreport', $context);
}

$baseurl = new moodle_url('/local/custom_feedback/report.php', ['courseid' => $courseid]);
$PAGE->set_url($baseurl);
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('feedbackreport', 'local_custom_feedback'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->add_body_class('local-custom-feedback');

// Fetch shared data.
$questions = $DB->get_records('local_cust_feedback_q',
    ['courseid' => $courseid], 'sortorder ASC');
$responses = $DB->get_records('local_cust_feedback_r',
    ['courseid' => $courseid], 'timecreated DESC');

// Build an answers map: [responseid][questionid] => answer record.
$answersmap = [];
if ($responses) {
    list($insql, $params) = $DB->get_in_or_equal(array_keys($responses), SQL_PARAMS_NAMED);
    $allanswers = $DB->get_records_select('local_cust_feedback_a', "responseid $insql", $params);
    foreach ($allanswers as $a) {
        $answersmap[$a->responseid][$a->questionid] = $a;
    }
}

// Aggregate star stats per question.
$starstats = []; // qid => ['count'=>n, 'sum'=>n, 'dist'=>[1..5 counts]]
foreach ($questions as $q) {
    if ($q->type !== 'star') {
        continue;
    }
    $starstats[$q->id] = ['count' => 0, 'sum' => 0, 'dist' => [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0]];
}
foreach ($answersmap as $rid => $byq) {
    foreach ($byq as $qid => $a) {
        if (isset($starstats[$qid]) && $a->valuestar !== null) {
            $v = (int)$a->valuestar;
            if ($v >= 1 && $v <= 5) {
                $starstats[$qid]['count']++;
                $starstats[$qid]['sum'] += $v;
                $starstats[$qid]['dist'][$v]++;
            }
        }
    }
}

// Response rate: based on enrolled users (with the submit capability).
$enrolled = count_enrolled_users($context, 'local/custom_feedback:submit');
$totalresponses = count($responses);
$responserate = $enrolled > 0 ? round(($totalresponses / $enrolled) * 100, 1) : 0.0;

// ---- Export branches ------------------------------------------------------

if ($format === 'csv' || $format === 'xlsx') {
    require_sesskey();
    $headers = [get_string('respondent', 'local_custom_feedback'),
                get_string('submittedon', 'local_custom_feedback')];
    foreach ($questions as $q) {
        $headers[] = format_string($q->name);
    }

    $rows = [];
    foreach ($responses as $r) {
        $row = [];
        if ($r->userid && ($u = $DB->get_record('user', ['id' => $r->userid], 'id,firstname,lastname'))) {
            $row[] = fullname($u);
        } else {
            $row[] = get_string('anonymous', 'local_custom_feedback');
        }
        $row[] = userdate($r->timecreated);
        foreach ($questions as $q) {
            $a = $answersmap[$r->id][$q->id] ?? null;
            if (!$a) {
                $row[] = '';
            } else if ($q->type === 'star') {
                $row[] = $a->valuestar === null ? '' : (int)$a->valuestar;
            } else {
                $row[] = (string)$a->valuetext;
            }
        }
        $rows[] = $row;
    }

    // Summary rows.
    $summary = [];
    $summary[] = []; // blank.
    $summary[] = ['Summary'];
    $summary[] = [get_string('totalresponses', 'local_custom_feedback'), $totalresponses];
    $summary[] = [get_string('responserate', 'local_custom_feedback'),
                  $responserate . '%  (' . $totalresponses . '/' . $enrolled . ')'];
    $overallsum = 0;
    $overallcount = 0;
    foreach ($questions as $q) {
        if ($q->type !== 'star') {
            continue;
        }
        $st = $starstats[$q->id];
        $avg = $st['count'] > 0 ? round($st['sum'] / $st['count'], 2) : 0;
        $summary[] = [get_string('averagerating', 'local_custom_feedback') . ': ' . format_string($q->name), $avg];
        $overallsum += $st['sum'];
        $overallcount += $st['count'];
    }
    if ($overallcount > 0) {
        $summary[] = [get_string('overallaverage', 'local_custom_feedback'),
                      round($overallsum / $overallcount, 2)];
    }

    $filename = clean_filename('custom_feedback_course_' . $courseid . '_' . date('Ymd_His'));

    if ($format === 'csv') {
        $csv = new csv_export_writer();
        $csv->set_filename($filename);
        $csv->add_data($headers);
        foreach ($rows as $r) {
            $csv->add_data($r);
        }
        foreach ($summary as $s) {
            $csv->add_data($s);
        }
        $csv->download_file();
        exit;
    }

    // xlsx.
    $workbook = new MoodleExcelWorkbook('-');
    $workbook->send($filename . '.xlsx');
    $sheet = $workbook->add_worksheet('Responses');
    $row = 0;
    foreach ($headers as $col => $h) {
        $sheet->write_string($row, $col, $h);
    }
    $row++;
    foreach ($rows as $r) {
        foreach ($r as $col => $v) {
            if (is_numeric($v)) {
                $sheet->write_number($row, $col, $v);
            } else {
                $sheet->write_string($row, $col, (string)$v);
            }
        }
        $row++;
    }
    $summarysheet = $workbook->add_worksheet('Summary');
    $sr = 0;
    foreach ($summary as $s) {
        foreach ($s as $col => $v) {
            if (is_numeric($v)) {
                $summarysheet->write_number($sr, $col, $v);
            } else {
                $summarysheet->write_string($sr, $col, (string)$v);
            }
        }
        $sr++;
    }
    $workbook->close();
    exit;
}

// ---- HTML view ------------------------------------------------------------

$PAGE->requires->css('/local/custom_feedback/styles.css');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('feedbackreport', 'local_custom_feedback'));

// Overview metrics card.
echo '<div class="cfb-overview row">';
echo '<div class="col-md-4"><div class="cfb-stat-card"><div class="cfb-stat-num">'
    . (int)$totalresponses . '</div><div class="cfb-stat-label">'
    . s(get_string('totalresponses', 'local_custom_feedback')) . '</div></div></div>';
echo '<div class="col-md-4"><div class="cfb-stat-card"><div class="cfb-stat-num">'
    . s($responserate) . '%</div><div class="cfb-stat-label">'
    . s(get_string('responserate', 'local_custom_feedback'))
    . ' (' . (int)$totalresponses . '/' . (int)$enrolled . ')</div></div></div>';
$overallsum = 0; $overallcount = 0;
foreach ($starstats as $st) { $overallsum += $st['sum']; $overallcount += $st['count']; }
$overallavg = $overallcount > 0 ? round($overallsum / $overallcount, 2) : '—';
echo '<div class="col-md-4"><div class="cfb-stat-card"><div class="cfb-stat-num">'
    . s($overallavg) . '</div><div class="cfb-stat-label">'
    . s(get_string('overallaverage', 'local_custom_feedback')) . '</div></div></div>';
echo '</div>';

// Star distribution charts per question.
foreach ($questions as $q) {
    if ($q->type !== 'star') {
        continue;
    }
    $st = $starstats[$q->id];
    $count = $st['count'];
    $avg = $count > 0 ? round($st['sum'] / $count, 2) : 0;
    echo '<div class="cfb-chart-block">';
    echo '<h4>' . format_string($q->name) . '</h4>';
    echo '<div class="cfb-chart-meta">'
        . s(get_string('averagerating', 'local_custom_feedback')) . ': <strong>' . s($avg) . '</strong> '
        . '· ' . s(get_string('totalresponses', 'local_custom_feedback')) . ': ' . (int)$count
        . '</div>';
    for ($star = 5; $star >= 1; $star--) {
        $c = $st['dist'][$star];
        $pct = $count > 0 ? round(($c / $count) * 100, 1) : 0;
        echo '<div class="cfb-chart-row">';
        echo '<div class="cfb-chart-label">' . s(get_string('starscount', 'local_custom_feedback', $star)) . '</div>';
        echo '<div class="progress cfb-chart-bar"><div class="progress-bar" role="progressbar"'
            . ' style="width:' . s($pct) . '%" aria-valuenow="' . s($pct) . '" aria-valuemin="0" aria-valuemax="100"></div></div>';
        echo '<div class="cfb-chart-count">' . (int)$c . ' (' . s($pct) . '%)</div>';
        echo '</div>';
    }
    echo '</div>';
}

// Response list (paginated).
echo '<h3 class="mt-4">' . s(get_string('feedbackreport', 'local_custom_feedback')) . '</h3>';

if (!$responses) {
    echo $OUTPUT->notification(get_string('noresponses', 'local_custom_feedback'), 'info');
} else {
    $pageresponses = array_slice($responses, $page * $perpage, $perpage, true);

    $table = new html_table();
    $table->head = [
        get_string('respondent', 'local_custom_feedback'),
        get_string('submittedon', 'local_custom_feedback'),
    ];
    foreach ($questions as $q) {
        $table->head[] = format_string($q->name);
    }
    $table->attributes['class'] = 'generaltable cfb-response-table';
    foreach ($pageresponses as $r) {
        $row = [];
        if ($r->userid && ($u = $DB->get_record('user', ['id' => $r->userid]))) {
            $row[] = fullname($u);
        } else {
            $row[] = get_string('anonymous', 'local_custom_feedback');
        }
        $row[] = userdate($r->timecreated);
        foreach ($questions as $q) {
            $a = $answersmap[$r->id][$q->id] ?? null;
            if (!$a) {
                $row[] = '';
            } else if ($q->type === 'star') {
                $row[] = $a->valuestar === null ? '' : str_repeat('★', (int)$a->valuestar);
            } else {
                $row[] = s((string)$a->valuetext);
            }
        }
        $table->data[] = $row;
    }
    echo html_writer::table($table);
    echo $OUTPUT->paging_bar(count($responses), $page, $perpage, $baseurl);

    $csvurl = new moodle_url($baseurl, ['format' => 'csv', 'sesskey' => sesskey()]);
    $xlsxurl = new moodle_url($baseurl, ['format' => 'xlsx', 'sesskey' => sesskey()]);
    echo '<div class="cfb-export mt-3">'
        . html_writer::link($csvurl, get_string('exportcsv', 'local_custom_feedback'),
            ['class' => 'btn btn-outline-primary me-2'])
        . html_writer::link($xlsxurl, get_string('exportxlsx', 'local_custom_feedback'),
            ['class' => 'btn btn-outline-primary'])
        . '</div>';
}

echo $OUTPUT->footer();
