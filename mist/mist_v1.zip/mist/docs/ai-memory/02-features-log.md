# Features Log: Mist Theme

Log of custom features implemented.

## [2026-07-14] Theme Initialization
- Created initial Moodle theme scaffolding (version, config, lib, settings).
- Created a modular SCSS structure under `scss/` directory.

## [2026-07-14] Custom SVG Loader on Login
- Implemented a custom SVG leaf-blossoming loader animation restricted to `login.mustache`.
- Added state machine logic in `theme_mist/loader` to play at least one complete animation loop, loop if page is not ready, and hide loader cleanly when finished.
- Created `scss/components/_loader.scss` with staggered animations for 30 leaf nodes and glowing star animations.
- Manually created pre-built `amd/build/loader.min.js` to ensure module loading without requiring host-level Grunt building.

## [2026-07-15] Login Screen Redesign
- Redesigned the login page wrapper (`login.mustache`) to use a modern symmetrical 50%/50% split layout.
- Structured the left branding panel with a light-grey rounded container (`#f3f4f6`, `18px` border radius) that fills the column leaving exactly a `12px` margin boundary.
- Integrated the official academy crest (`pix/tgpa_logo.svg`) centered inside the grey container at a custom prominent size of `440px` max-width and `100%` max-height.
- Preserved Moodle's parent theme native CSS styles for the login form elements on the right panel, adjusting only the layout wrapper to center the card on the page.
