# Current State: Mist Theme

## Current Build
- Initial scaffolding successfully built.
- Login screen split-panel redesign implemented with symmetrical 50%/50% columns, a full-panel framed container, and a 12px margin.
- Checked using `purge_caches.php` compilation and cache purging.

## Active Files
- **Scaffolding**: `version.php`, `config.php`, `lib.php`, `settings.php`, `lang/en/theme_mist.php`.
- **SCSS Entrypoint & Components**: `scss/theme.scss`, `scss/components/_loader.scss`, `scss/pages/_login.scss` (styled layout).
- **Templates**: `templates/components/loader.mustache`, `templates/theme_boost/login.mustache` (modified for split screen with logo container).
- **AMD JavaScript**: `amd/src/loader.js`, `amd/build/loader.min.js`.
- **Images**: `pix/tgpa_logo.svg`.
- **Partials**: Empty placeholders under `scss/utilities/`, `scss/layouts/`, `scss/components/` (except loader), `scss/features/`, and `scss/pages/` (except login).
