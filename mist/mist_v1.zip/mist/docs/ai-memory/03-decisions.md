# Decisions Log: Mist Theme

Log of major decisions affecting Mist's architecture.

## 01: Modular SCSS Structure
- **Decision**: Reject a flat single-file preset or SCSS design in favor of partitioned categories (`utilities`, `layouts`, `components`, `features`, `pages`).
- **Rationale**: Keeps responsibilities isolated, avoids collision risks, and makes long-term maintainability scalable.

## 02: Login Redesign Layout Strategy
- **Decision**: Redesign the page layout wrapper (`login.mustache`) to place Moodle's unmodified main content in the right column, and the visual image in the left column.
- **Rationale**: Meets the client's split-panel layout request without modifying or overriding the complex `core/loginform` template. This keeps the login logic (such as focus, validation tokens, and error handling) highly maintainable and less error-prone.

## 03: Direct Image Path and CSS Preservation
- **Decision**: Serve the login illustration via direct relative URL `/theme/mist/pix/tgpa_logo.svg` (centered horizontally and vertically) and keep left-panel background white. Preserve the parent theme's native CSS for the login form elements.
- **Rationale**: Bypasses Moodle's built-in `{{#pix}}` helper constraints (which adds unwanted classes like `.icon` and causes scaling issues). Setting the background to white matches the design request, and avoiding changes to login form CSS ensures the original styling and validation states of Moodle are completely untouched.

## 04: Equal Width Columns and Logo Frame Container
- **Decision**: Set the left and right panels to equal widths (`50%/50%`), decrease the TGPA logo sizing to `160px`, and wrap it inside a rounded (`16px`) light-grey container with generous outer padding.
- **Rationale**: Achieves symmetry and visual balance, and frames the logo cleanly while ensuring uncluttered spacing.

## 05: Compact Layout and Logo Frame Refinements
- **Decision**: Resize the left panel height to `min-height: 520px` to reduce empty vertical space.
- **Rationale**: Balances the branding panel's weight with Moodle's login form height, eliminating excessively large blank areas while making the logo the primary visual focal point.

## 06: Expanded Logo Container with a 12px Margin
- **Decision**: Modify the logo container to occupy the entire left panel, reducing the outer panel padding to exactly `12px` (which acts as a margin). Scale the logo max-width to `440px` and max-height to `100%` within the container.
- **Rationale**: Direct response to the client's request to have the grey container occupy the full left column except for a thin `12px` border margin, highlighting the academy crest prominently at its maximum balanced size.
