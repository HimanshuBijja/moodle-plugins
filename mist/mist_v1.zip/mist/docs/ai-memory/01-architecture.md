# Architecture: Mist Theme

Mist inherits layout rendering and core style structures from `theme_boost`.

## Layout Pipeline
- Moodle's theme renderer compiles layouts using the parent theme templates (`drawers.php`, `login.php`, etc.).
- The custom renderer overrides point to `theme_overridden_renderer_factory` for maximum presentation customisation.

## SCSS Pipeline
- Moodle invokes the callback `theme_mist_get_main_scss_content` defined in `lib.php`.
- The callback reads the entry point SCSS file `theme.scss` directly.
- The entry point compiled SCSS imports modular partials in a structured hierarchy (Utilities -> Layouts -> Components -> Features -> Pages).
