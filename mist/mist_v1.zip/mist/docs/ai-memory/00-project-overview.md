# Project Overview: Mist Theme

Mist is a custom Moodle theme structured as a child theme extending the parent theme Boost.

## Goals
- Provide a clean, modular starting point for a custom Moodle theme.
- Align with modern, highly structured SCSS directory layout patterns.
- Inherit default Moodle layout components and styling from Boost while maintaining complete layout flexibility.
