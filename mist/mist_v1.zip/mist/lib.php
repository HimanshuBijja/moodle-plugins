<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Mist theme functions and callbacks.
 *
 * @package    theme_mist
 * @copyright  2026 Antigravity
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Returns the main SCSS content.
 *
 * @param theme_config $theme The theme config object.
 * @return string
 */
function theme_mist_get_main_scss_content($theme) {
    global $CFG;

    $csspath = $CFG->dirroot . '/theme/mist/scss/theme.scss';
    if (file_exists($csspath)) {
        return file_get_contents($csspath);
    }
    return '';
}

/**
 * Get SCSS to prepend.
 *
 * @param theme_config $theme The theme config object.
 * @return string
 */
function theme_mist_get_pre_scss($theme) {
    return '';
}

/**
 * Inject additional SCSS/CSS.
 *
 * @param theme_config $theme The theme config object.
 * @return string
 */
function theme_mist_get_extra_scss($theme) {
    $content = '';
    
    // Custom CSS setting
    if (!empty($theme->settings->customcss)) {
        $content .= $theme->settings->customcss;
    }
    
    return $content;
}
