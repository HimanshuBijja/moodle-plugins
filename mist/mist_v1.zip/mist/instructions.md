# Rules
- task completion - proceed with next task, no permission required, just inform; unless its a deciding change 
- do not output: code changes,read, write, bash, edit  (to save tokens) 
- do not commit
- Report only failures 

## Git Rules:
### always allow commands: 
- show
- log
- diff
- commit
- add
- checkout

## Terminal rules
### always allow
- grep
- npx eslint
- lint checks commands
- mkdir

## Output Suppression

Do not output:

* Read operations
* Edit operations
* Bash commands
* Command results
* Test logs
* Lint output
* Typecheck output
* File diffs
* Tool traces
* Subagent transcripts

Run them silently.

Only output:

* Current task status
* Blocking issues
* Important decisions requiring user input
* Final git commit message
* Final completion summary

For tests, lint, typecheck, and verification:

* Run automatically.
* Do not print logs.
* Report only failures with a concise error summary.
* If all checks pass, simply state: "Verification passed."

For file edits:

* Do not show diffs or edited code unless explicitly requested.

For command execution:

* Execute approved commands silently.
* Do not echo commands before or after execution.

# Guardrails
- service-account.json - do not read , ask permission 
- Do not run google cloud services like veo 3 and image generation , i will smoke test manually

# Project Rules

Before coding, read:
- theme/mist/docs/ai-memory/00-project-overview.md
- theme/mist/docs/ai-memory/01-architecture.md
- theme/mist/docs/ai-memory/04-current-state.md

After every feature update:
1. Update theme/mist/docs/ai-memory/02-features-log.md
2. Update theme/mist/docs/ai-memory/04-current-state.md
3. Add major decisions to theme/mist/docs/ai-memory/03-decisions.md
4. Mention changed files, new APIs, DB changes, and pending bugs

create files/folders inside docs if it dosent exists

full path: /home/himanshu/moodle-instances/moodle-instance-8093/moodle/theme/mist/docs

read /home/himanshu/moodle-instances/moodle-instance-8093/moodle/theme/boost/CLAUDE.md before starting

# Moodle rules 

- always purge cache after code/settings changes : 
    
    docker exec -it moodle-web-8093 bash -c "cd /var/www/html && php admin/cli/purge_caches.php"

- Running Grunt tooling and Linters from moodle root:
  - CSS Compilation: `grunt css` (Run style sheets compiler to check precompiled output)
  - StyleLint validation: `grunt stylelint` (To lint SCSS files)

# SCSS Architecture 

## Purpose

Organize SCSS into a modular, scalable, and maintainable structure. Each file should have a single responsibility to improve readability, reusability, and long-term maintenance.

## Directory Structure

```text
scss/
├── pages/
├── features/
├── components/
├── layouts/
├── utilities/
└── theme.scss
```

`theme.scss` is the single entry point that imports all SCSS partials.

## Folder Responsibilities

### `pages/`

Styles for individual pages or screens.

**Examples**

* `_login.scss`
* `_dashboard.scss`
* `_frontpage.scss`
* `_profile.scss`

**Rules**

* One file per page.
* Use Moodle page/body classes for scoping.
* No reusable component styles.

---

### `features/`

Styles for Moodle modules and functional areas.

**Examples**

* `_course.scss`
* `_quiz.scss`
* `_forum.scss`
* `_calendar.scss`
* `_chat.scss`

**Rules**

* One file per feature.
* Keep styles feature-specific.
* No global UI components.

---

### `components/`

Reusable UI elements shared across the theme.

**Examples**

* `_buttons.scss`
* `_cards.scss`
* `_forms.scss`
* `_tables.scss`
* `_modal.scss`

**Rules**

* Must be reusable.
* Independent of pages and features.

---

### `layouts/`

Overall application structure.

**Examples**

* `_header.scss`
* `_footer.scss`
* `_sidebar.scss`
* `_navigation.scss`

**Rules**

* Only layout-related styles.
* No feature or page-specific styling.

---

### `utilities/`

Global design tokens and helper files.

**Examples**

* `_variables.scss`
* `_colors.scss`
* `_mixins.scss`
* `_functions.scss`
* `_typography.scss`

**Rules**

* Store variables, mixins, functions, and helpers.
* No page or component styling.

---

## Import Order

```text
Utilities (variables, colors, mixins, typography)
→ Parent Theme Core Styles (fontawesome, bootstrap, moodle)
→ Layouts
→ Components
→ Features
→ Pages
```

## Naming Conventions

* Use lowercase filenames.
* Use hyphens (`-`) for multi-word names.
* Prefix SCSS partials with `_`.
* One responsibility per file.

## Goals

* Modular architecture
* Clear separation of concerns
* Reusable components
* Minimal duplication
* Easy maintenance
* Scalable for future development
