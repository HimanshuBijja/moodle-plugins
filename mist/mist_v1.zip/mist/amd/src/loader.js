/**
 * Custom loader animation controller for theme_mist.
 *
 * @module     theme_mist/loader
 * @copyright  2026 Antigravity
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

export const init = () => {
    const loader = document.getElementById('loader');
    if (!loader) {
        return;
    }

    const svg = loader.querySelector('svg');
    const lastLeaf = document.getElementById('leaf-30');
    if (!svg || !lastLeaf) {
        // Fallback: if SVG or last leaf not found, hide loader immediately
        loader.style.display = 'none';
        return;
    }

    // States definition
    const STATES = {
        INITIAL: 'INITIAL',
        PLAYING_FIRST_CYCLE: 'PLAYING_FIRST_CYCLE',
        WAITING: 'WAITING',
        HIDE: 'HIDE'
    };

    let currentState = STATES.INITIAL;
    let isPageReady = document.readyState === 'complete';

    if (!isPageReady) {
        window.addEventListener('load', () => {
            isPageReady = true;
        });
        // Also register DOMContentLoaded as a fallback readiness signal
        document.addEventListener('DOMContentLoaded', () => {
            // Give extra time for theme layout init if DOM is ready but window hasn't fired
            setTimeout(() => {
                isPageReady = true;
            }, 500);
        });
    }

    const startAnimation = () => {
        svg.classList.add('animating');
    };

    const restartAnimation = () => {
        svg.classList.remove('animating');
        // Force reflow to restart CSS keyframe animation
        void svg.offsetWidth;
        svg.classList.add('animating');
    };

    const hideLoader = () => {
        currentState = STATES.HIDE;
        loader.classList.add('fade-out');
        setTimeout(() => {
            loader.style.display = 'none';
            loader.remove();
        }, 600); // Matches the 0.6s opacity transition in CSS
    };

    // Event listener for animation loop completion on the last leaf
    lastLeaf.addEventListener('animationend', (e) => {
        // Ensure we only react to the leafFadeIn animation on this leaf
        if (e.animationName !== 'leafFadeIn') {
            return;
        }

        if (currentState === STATES.PLAYING_FIRST_CYCLE) {
            if (isPageReady) {
                hideLoader();
            } else {
                currentState = STATES.WAITING;
                restartAnimation();
            }
        } else if (currentState === STATES.WAITING) {
            if (isPageReady) {
                hideLoader();
            } else {
                restartAnimation();
            }
        }
    });

    // Start the state machine
    currentState = STATES.PLAYING_FIRST_CYCLE;
    startAnimation();
};
