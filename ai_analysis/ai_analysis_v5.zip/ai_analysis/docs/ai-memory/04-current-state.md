# Current State

**As of 2026-06-01.**

## Done
- Sprint 1 (security foundation): sql_validator, manifest_builder, audit_writer, capabilities. Merged.
- Sprint 2 (pipeline + Claude): full NL→SQL pipeline, AJAX gateway, rate limiter, read-only executor, settings page. Merged.
- Sprint 3a (PII scrubber + format_result): layer-7 AI formatting pass guarded by a reversible-token PII scrubber. Merged.
- Sprint 3b (OpenAI + Gemini providers): provider made pluggable via `base_http_ai_client` template-method base + `openai_client`/`gemini_client`; factory + settings dispatch. Merged.
- Sprint 4 (frontend chat widget): floating widget (`lib.php` before_footer + `templates/chat_widget.mustache` + `amd/src/chat_widget.js` + `styles.css`) consuming `local_ai_analysis_query`; FAB → drawer → fullscreen, table + Chart.js bar chart + AI answer, in-memory history. version.php = 2026053002.
- Sprint 5 (admin/management & compliance): audit-log report page (`audit.php` + `classes/report/audit_table.php`, Site admin → Reports, cap `viewaudit`); decrypt-prompt AJAX fn (`local_ai_analysis_decrypt_prompt`, cap `decryptprompt`, writes `PROMPT_REVEALED` self-audit); GDPR `classes/privacy/provider.php` (export + delete, all 13 audit columns declared); retention scheduled task (`classes/task/purge_audit_task.php` + `db/tasks.php`, daily, `retentiondays` default 365, 0=forever); settings grouped under headings + retention field + audit link; shared cipher `classes/audit/audit_crypto.php`; HTTP 429/5xx → `transport_exception`. Merged → `main` (commit `140fde1d`).
- Sprint 3c (Ollama provider): `classes/ai/ollama_client.php` extends `openai_client` (OpenAI-compat `/v1/chat/completions`); 3 overrides (configurable base_url, no Bearer, `DEFAULT_MODEL=qwen2.5-coder`). Factory `'ollama'` case + `ollama_base_url`/`ollama_model` settings + dropdown + 4 lang strings. **Also rebuilt AMD for real** via a `node:22-slim` Docker container (fixed an ESLint `no-bitwise` in chat_widget.js; regenerated both modules + real source maps — retires the hand-authored-builds caveat).
- Sprint 3c addendum (configurable timeout + live Ollama): added global `request_timeout` setting threaded `factory → client ctor → base_http_ai_client::post() → transport` (was hard-coded 30s). **Live-verified Ollama end-to-end through the real pipeline** (`ai_client_factory::make()` → generate_sql → valid SQL). **151 plugin tests pass.** version.php = 2026060101 / 0.6.1.

## Pipeline status
End-to-end works with stubbed AI in tests. Admin picks provider (claude/openai/gemini) + per-provider key + model in settings. With `format=true`, returns a de-tokenised plain-language `answer` alongside raw rows. Live calls need the chosen provider's API key set (+ `$CFG->ai_analysis_dbuser/dbpass/audit_key` in config.php per INSTALL.md).

## AI client layer (for future providers)
- Interface: `ai_client_interface` (`generate_sql`, `format_result`).
- Base: `base_http_ai_client` — implement `endpoint()`, `auth_headers()`, `build_sql_payload()`, `build_format_payload()`, `extract_text()`; declare `DEFAULT_MODEL`. Add a `match` case in `ai_client_factory` + dropdown option + key/model settings + lang strings. Mirror `openai_client`/`gemini_client`.

## Next
- **Manual browser smoke-tests** (only remaining hand-off — needs a logged-in browser): chat widget (FAB by role, query→table+chart+answer, state transitions, history); audit report (load, sort, filter, CSV download, Reveal button for decrypt-cap admins, plaintext swap). AMD/template/CSS — purge caches first.
- **Active provider as of 2026-06-01: `gemini`** (gemini-2.5-flash-lite, key set). The user owns provider switching — flip it in Settings, not via scripts. Ollama debugging/UX is parked for later.
- **Ollama — verified working but PARKED** (not the active provider). It was proven end-to-end on this instance (`ollama_model=qwen2.5:3b`, `request_timeout=90`; warm ~10s / cold ~42s on CPU). The ollama_* config values remain set, so re-enabling is just selecting `ollama` as the provider in Settings. Full bring-up chain in 02-features-log.md "Sprint 3c addendum": (1) `OLLAMA_HOST=0.0.0.0`, (2) `ollama_base_url=http://172.26.0.1:11434` (docker gateway, not localhost), (3) host iptables rule allowing `br-213e02bb1a10`→11434 (**not reboot-persistent**), (4) `config.php` curlsecurity allow (`curlsecurityblockedhosts=''`, `curlsecurityallowedport="80\n443\n11434"`), (5) small model + 90s timeout (no GPU). **Deferred items**: browser-test the widget Ollama path; persist the iptables rule; set Ollama `keep_alive` to avoid cold loads; consider prompt tuning for the `WHERE courseid=0` quirk weak models add.
- **Browser smoke-test the Ollama widget path**: ask a simple question (e.g. "how many users"), expect ~10–42s then a result. Set Ollama `keep_alive` to avoid repeated cold loads.
- Weak local models (3b/7b) over-apply the "Course ID: 0" prompt line (append bad `WHERE courseid=…`); caught by `sql_validator`. Prompt-design tuning is the fix if it bites — affects all providers, not just Ollama.

## Manifest (allow-listed tables the AI may query)
8 tables: `mdl_user`, `mdl_course`, `mdl_grade_grades`, `mdl_grade_items`, `mdl_course_modules`, `mdl_enrol`, `mdl_user_enrolments`, `mdl_logstore_standard_log`. RO user granted SELECT on all 8 (db/readonly_grants.sql is the source of truth; applied live). Non-admin + courseid>0 gets `_scope_note`s filtering user/course/grade_items/enrol/log to the current course.
- `mdl_course` (added 2026-05-31): course-identity questions.
- `mdl_grade_items` + `mdl_enrol` + `mdl_user_enrolments` (added 2026-05-31): grades link to a course only via grade_items (grade_grades has no courseid) → enables "top students in this course"; enrolment tables → "who/how many enrolled".
- **Intentionally NOT in manifest:** role/context tables (`mdl_role`, `mdl_role_assignments`, `mdl_context`). So "who is the teacher" returns OUT_OF_SCOPE by design (user declined that expansion — it would expose site-wide role structure to the AI + RO user). Revisit if needed.

## Deployment (this instance)
- Live pipeline verified end-to-end with Gemini on 2026-05-31 (prompt → SQL → RO execution → answer, status SUCCESS). "what is this course" (courseid 23) → "Introduction to Programming".
- **Developer debugging turned OFF** (`set_config('debug',0)` + `debugdisplay=0`) — needed because four unrelated half-installed plugins (`auth/secureotp`, `theme/sprout`, `theme/verdant`, `local/tgpa_timetable`) have a directory but no `version.php`; `moodle_needs_upgrading`'s plugin scan emits a warning that, under developer-display, escalated to a fatal Whoops page. With display off the warning is just logged. Re-enable via Site admin → Development → Debugging once those dirs are removed/completed. Not our code.
- **Gemini free-tier quota is PER-DAY, PER-MODEL.** `gemini-2.0-flash` = `limit: 0` (unusable on this key); `gemini-2.5-flash` = 20 requests/day (exhausted quickly by testing → HTTP 429 that does NOT recover until daily reset); `gemini-2.5-flash-lite` = higher daily limit. HTTP 429 surfaces in the widget as the generic "could not complete" message.
- **Currently `gemini_model=gemini-2.5-flash-lite`** — chosen because flash's daily quota was exhausted. Trade-off: flash-lite has more quota but weaker reasoning (it returned `cannot_answer` for the 3-table top-students grade join that 2.5-flash would handle). For complex multi-join questions, switch back to `gemini-2.5-flash` in settings (mind the 20/day cap), or add billing.
- **Verified 2026-05-31:** "how many students enrolled in this course" → SUCCESS (30, via user_enrolments⋈enrol). "top students" capability proven independently: a correct grade-join SQL passes `sql_validator` and runs on the RO connection (0 rows only because course 23 has no `grade_grades` recorded — it has 1 grade_item, no grades). So grade questions work on any course that has grades + a capable model.
- Read-only user `moodle_ai_ro` created (4 SELECT grants). `config.php` has `ai_analysis_dbuser`/`dbpass`/`audit_key` (backup `config.php.bak.aianalysis`).

## Pending bugs / notes
- ~~HTTP 429 mis-mapped~~ **FIXED in Sprint 5 (T2)** — 429/5xx now throw `transport_exception` → `AI_TRANSPORT_ERROR`.
- ~~AMD builds are hand-authored~~ **RESOLVED in Sprint 3c** — both `chat_widget` + `audit_reveal` `.min.js` + real source maps now generated by genuine `grunt amd`, run inside a `node:22-slim` Docker container (host node is 20; grunt gates ≥22.11). Repeat recipe: `docker run --rm -u "$(id -u):33" -v "$PWD":/app -w /app node:22-slim node_modules/.bin/grunt amd --root=local/ai_analysis` from the moodle dir (the `:33` = www-data gid lets it write the group-owned `.eslintignore`/`.stylelintignore`). ESLint runs as part of it — keep the source lint-clean (`no-bitwise` etc.). After deploy, purge caches so new AMD/template/CSS load.
- **audit_reveal AMD not browser-verified** — the report page's Reveal-prompt button JS was unit-tested only at the build_filter seam; verify in a browser (decrypt-cap admin clicks Reveal → cell shows plaintext).
- PII curated map (`pii_scrubber::PII_MAP`) covers `mdl_user` columns only; extend as manifest tables grow.
- Provider model fields are free-text — no validation that the model name is real (a bad name surfaces as an API error → AI_INVALID_JSON).
- Settings page `locate()` returns NOT_FOUND under raw CLI; renders fine in browser.
- Chat widget never auto-verified in a real browser — run the manual smoke-test checklist in the plan (FAB visibility by role, query → table+chart+answer, state transitions, history).