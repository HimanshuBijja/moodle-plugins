# Major Decisions

## Sprint 2

- **Constructor injection everywhere** for test seams — no live API/network in PHPUnit. `claude_client` takes transport; `ai_client_factory` has PHPUNIT_TEST-gated override; `query_executor` takes optional $DB.
- **No exceptions to the AJAX layer** — gateway catches every domain exception, returns typed envelope + audit row. Only capability denials propagate (Moodle's external API handles those).
- **Manifest is single source of truth** — validator receives the exact array sent to the AI so the allow-list cannot drift.
- **Read-only DB user** (`$CFG->ai_analysis_dbuser`) is the last line of defence — even if PHP validation is bypassed, DML/DDL fails at the server. Tests fall back to global $DB when creds absent.
- **Prefix translation in gateway** — AI + validator always work with canonical `mdl_`; gateway swaps to runtime prefix at execution. Keeps the manifest/validator environment-independent.
- **Rows JSON-encoded as strings** in the response envelope — `external_multiple_structure` can't declare arbitrary row shapes statically.
- **PHPUnit by file path, never `--filter`** — unrelated half-installed plugins (auth/secureotp, theme/sprout, theme/verdant, local/tgpa_timetable) disrupt filter-based discovery.

## Sprint 3a (PII scrubber + format_result)

- **Reversible tokens, not redaction** — PII is tokenised (`PERSON_1`) before the formatting AI call and de-tokenised in the answer afterward. The teacher is authorised and sees real values; only the external AI ever sees tokens. Token map is in-memory/per-request, never persisted or logged.
- **Column classification, curated map** — the scrubber owns an explicit `table.column → prefix` map (deterministic, auditable), not value-pattern heuristics. PII knowledge lives only in `pii_scrubber`; `sql_validator` stays PII-agnostic and just surfaces source/reference maps.
- **Alias-safe via validator** — tokenisation keys off the validator's resolved column-source map, not raw row keys, so `firstname AS fn` is still masked. Derived expressions referencing PII are wholesale-redacted (`__REDACT__`); pure aggregates pass through.
- **`strtr` for detokenise** — single-pass simultaneous replacement avoids the cascade bug where a real value equal to another person's token gets double-substituted.
- **Per-request `format` flag + graceful fallback** — formatting is opt-in per call; an AI #2 failure never blocks results (status stays SUCCESS, raw rows + `format_note` returned). No new status codes; Sprint-1 audit schema untouched.
- **Verbatim-token-echo rule in the AI #2 prompt** — de-tokenisation is a literal string swap, so the prompt forbids the AI from expanding/renaming tokens; tested by round-trip assertions.

## Sprint 3b (OpenAI + Gemini providers)

- **Template-method base, not duplication** — `base_http_ai_client` owns the provider-independent flow with `final generate_sql()`/`format_result()`; the SQL-output parsing (the part feeding the validator) lives in exactly one place and cannot drift between providers. New providers are ~30-line subclasses implementing five hooks. A truly different provider (e.g. streaming) would implement `ai_client_interface` directly instead.
- **Refactor guarded by existing tests** — `claude_client`'s 15 tests are the behaviour-preservation contract; they passed unchanged after moving its logic to the base.
- **Native JSON-output mode per provider** — OpenAI `response_format:{type:json_object}` and Gemini `responseMimeType:application/json`, applied to SQL generation only (not the prose formatting pass), to cut `AI_INVALID_JSON`.
- **Gemini key as header, not query param** — `x-goog-api-key` keeps the key out of any URL logging (vs `?key=`).
- **Free-text model settings with defaults** — per-provider model is an `admin_setting_configtext` pre-filled with a default, so new model names need no code change (chosen over a fixed dropdown).
- **OpenAI + Gemini only; Ollama deferred** — the two hosted APIs share Claude's shape; self-hosted Ollama (local HTTP, no key) is a separate slice.

## Sprint 4 (frontend chat widget)

- **Legacy `before_footer` callback returning a string, not the hook class** — `local_ai_analysis_before_footer()` is simpler and trivially unit-testable (call it, assert on the returned HTML). Moodle 4.5 still captures legacy-callback return values via `before_footer_html_generation::process_legacy_callbacks()`. A full `db/hooks.php` subscriber was unnecessary for a one-shot footer injection.
- **Capability checked against `$PAGE->context`, not `context_system`** — `local/ai_analysis:query` is CONTEXT_COURSE level, so a teacher holds it inside their course, not site-wide. Checking the page context shows the FAB wherever the user can actually query (course pages for teachers; everywhere for system-level grant holders). The external function re-checks server-side, so this is only a display gate.
- **Single shared panel for drawer + fullscreen** — one DOM skeleton; `data-state` + CSS switch geometry. Avoids duplicate markup and keeps the state machine to three values. Welcome vs results toggled by `data-view`.
- **Client-side chart auto-detection** — first column that is all-numeric across rows (with ≥2 rows) becomes the bar-chart series, first other column the labels; otherwise table + answer only. No server hint needed; keeps the external API unchanged.
- **In-memory, single-shot history** — each query is independent (never sent back to the AI); history lives in JS for the page load only, with a `resultCache` for click-to-revisit. No persistence, no DB, no extra privacy surface.
- **Hand-authored AMD build** — environment lacked a node-22 toolchain for grunt, so `amd/build/chat_widget.min.js` was written directly as a named `define()` module (Moodle requires the `build/*.min.js` filename, not true minification). Must be regenerated via grunt on a node-22 host before release (also runs ESLint).

## Sprint 5 (admin / management & compliance)

- **Decrypt reveal = capability + sesskey + self-audit, no password re-entry** — admins holding `decryptprompt` reveal a prompt with one click; every reveal writes its own `PROMPT_REVEALED` audit row (who revealed which id, when). Accountability via the audit trail itself was preferred over per-reveal re-authentication friction.
- **Retention = hard delete, configurable, default 365, 0 = forever** — a daily scheduled task deletes audit rows older than `retentiondays`. Chosen over anonymise-in-place: simpler, and the audit table's only real PII (encrypted prompt + block_reason) is exactly what should disappear on expiry.
- **GDPR erasure = delete the rows (not anonymise)** — matches 'right to erasure' cleanly and is consistent with the retention policy; export returns the user's rows (metadata + SQL, prompt left encrypted).
- **One shared cipher (`audit_crypto`)** — encrypt (writer) and decrypt (reveal) must use the identical key-normalisation + AES-CBC format, so the logic was extracted to a single helper rather than duplicated; drift here would corrupt or expose data.
- **429/5xx are transport, not parse errors** — provider rate-limit/transient failures are retry-able and distinct from a malformed AI response; mapping them to `transport_exception`/`AI_TRANSPORT_ERROR` lets the UI message them correctly instead of the misleading `AI_INVALID_JSON`.
- **Audit viewer = Moodle `table_sql` admin report (system-level)** — reused the platform's sorting/pagination/CSV/download rather than a custom page; viewer is admin-only by the existing `viewaudit` system capability (no per-course teacher view, by design).
- **Roles/teacher still NOT exposed** — unchanged from Sprint 4; manifest deliberately omits role/context tables.

## Sprint 3c (Ollama provider)

- **Subclass `openai_client`, don't extend `base_http_ai_client` directly** — Ollama ships an OpenAI-compatible `/v1/chat/completions` endpoint, so the entire payload/extraction/error surface is already correct. The new client is ~3 overrides (endpoint, auth, default model) + a constructor. Maximum reuse, zero new wire-format code, no risk of SQL-parsing drift (still inherited as `final` from the base).
- **base_url occupies the api_key constructor slot** — `base_http_ai_client.__construct(transport, api_key, model)` is fixed; rather than widen it, `ollama_client`'s own constructor takes `(transport, base_url, model)` and passes `''` for api_key upward. Keeps the base contract untouched while giving Ollama the one config it actually needs.
- **No Authorization header** — Ollama has no auth; `auth_headers()` returns content-type only. Sending an empty Bearer would be harmless but misleading.
- **Default model `qwen2.5-coder`** — code/SQL-tuned, best at the structured JSON+SQL task; field is free-text so admins can switch to any pulled model.
- **Inherited `response_format: json_object`** — Ollama's OpenAI-compat layer honors it on recent versions; on older ones it's ignored and JSON still arrives via the system prompt + `strip_fences`. Either way the base parser copes. Verified live: qwen2.5 returned a clean JSON object.
- **AMD rebuilt in a node:22 container, not on host** — Moodle's grunt hard-gates node ≥22.11 and the host has node-20; a throwaway `node:22-slim` container mounting the moodle tree (run as the www-data gid for the group-writable ignore files) regenerates builds + real source maps without touching the host toolchain. This retires the "hand-authored AMD builds" caveat from Sprints 4–5.

## Sprint 3c addendum (configurable timeout)

- **Single global `request_timeout`, threaded via the factory, not per-provider** — every provider can be slow under some condition (cloud APIs near 30s on big prompts; local CPU models far beyond). One setting, read once in `ai_client_factory::make()` and passed to each client's constructor, keeps the knob discoverable and avoids four near-identical settings. Default 30 preserves prior behaviour; raise only when needed.
- **Timeout lives on the client, applied in `base_http_ai_client::post()`** — the transport already accepted a `$timeout` arg but the base never passed it. Storing it on the client (ctor param) and forwarding in the one `post()` call is the minimal, single-point change; the `http_transport_interface` contract is untouched.
- **Pull a small model rather than only widen the timeout** — on CPU, qwen2.5:7b ≈ 64s is unusable as widget UX even if it technically completes. qwen2.5:3b (same family, ≈10s warm) is the pragmatic default for CPU hosts; the timeout still rises to absorb cold-load (~42s) and occasional slow generations.
