# Features Log

## Sprint 2 — Pipeline + Claude provider (2026-05-30, complete)

Branch: `feat/ai-analysis-pipeline-claude`. Plan: `docs/superpowers/plans/2026-05-25-ai-analysis-pipeline-claude.md`.

Wired Sprint 1's security primitives into a working end-to-end NL→SQL pipeline.

### New classes
- `classes/exception/{ai_client,transport,query_execution}_exception.php`
- `classes/ai/http_transport_interface.php` + `transport/moodle_curl_transport.php`
- `classes/ai/prompt_builder.php` — system prompt build + user sanitisation (3–800 chars, injection blocklist)
- `classes/ai/ai_client_interface.php` + `ai_client_factory.php` (PHPUNIT_TEST override seam)
- `classes/ai/claude_client.php` — Anthropic Messages API, model `claude-sonnet-4-20250514`, max_tokens 800
- `classes/security/rate_limiter.php` — per-user token bucket, admin bypass
- `classes/db/query_executor.php` — injectable $DB / lazy readonly connection
- `classes/external/query.php` — AJAX gateway, full 8-layer orchestration + `translate_prefix()`

### New APIs
- External function `local_ai_analysis_query` (`db/services.php`) — ajax read, loginrequired.
- `ratelimit` cache definition (`db/caches.php`, MODE_APPLICATION).

### DB changes
- No schema changes. version.php → 2026052503. Registered external function + cache.

### Settings
- `settings.php`: provider select, claude_api_key (passwordunmask), rate_limit_per_min.

### Tests (72 total across plugin)
prompt_builder 17, claude_client 11, rate_limiter 5, query_executor 3, external_query 7 (new) + Sprint 1's manifest 7, audit 6, sql_validator 16.

### Deviations from plan
- Gateway added `translate_prefix()` (mdl_→runtime prefix) — not in original plan; needed for PHPUnit's `phpu_` prefix.
- `mdl_external_functions` has no `ajax` column in this Moodle 4.5.10 build (verification query adjusted).

## Sprint 3a — PII scrubber + format_result (2026-05-30, complete)

Branch: `feat/ai-analysis-format-scrub`. Spec: `docs/superpowers/specs/2026-05-30-ai-analysis-format-and-scrub-design.md`. Plan: `docs/superpowers/plans/2026-05-30-ai-analysis-format-and-scrub.md`. Executed subagent-driven (per-task implement + spec + quality review); Task 5 finished inline after a session-limit interruption.

Adds the layer-7 AI formatting pass (deferred from Sprint 2), guarded by a reversible-token PII scrubber so real student data never reaches the external AI.

### New classes / methods
- `classes/security/pii_scrubber.php` — curated `table.column → prefix` PII map; `classify_columns()`, `tokenize()` (stable reversible tokens), `detokenize()` (single-pass `strtr`, cascade-safe), `is_pii()`. Token map is per-request instance state, never persisted.
- `sql_validator` — new `get_column_source_map()` + `get_column_references()` (alias-safe, populated during `validate()`; aggregates yield no refs). Maps reset at top of `validate()`.
- `ai_client_interface::format_result()` + `claude_client` impl. Extracted shared `post_and_extract_text()` / `strip_fences()` helpers (DRY with `generate_sql`).
- `prompt_builder::build_format_system()` — AI #2 system prompt; verbatim-token-echo rule is critical (de-tokenise is literal string swap).
- `external/query.php` — per-request `format` (PARAM_BOOL) param; after L6 runs scrub → `format_result` → detokenise; new envelope fields `answer` + `format_note`; graceful fallback (AI #2 failure → SUCCESS + raw rows + note, logs via `debugging()`).

### New API / DB / settings
- External function gains optional `format` param + `answer`/`format_note` return fields. No DB schema change. version.php → 2026053000. No new plugin settings (format is per-request).

### Tests (98 total plugin-wide, +26)
sql_validator 20, prompt_builder 19, claude_client 15, pii_scrubber 12 (new), external_query 11. Includes PII-leak guard (asserts only tokens reach the stubbed AI) and `format=false` Sprint-2 regression parity.

### Deviations from plan
- `test_format_failure_falls_back_to_raw_rows` needed `$this->assertDebuggingCalled()` to acknowledge the fallback's `debugging()` call (Moodle PHPUnit treats unhandled debugging as an error).
- Review-driven fixes added: validator map reset + single-quoted-alias handling (Task 1); `strtr` cascade-safe detokenise + `false` guard (Task 2); shared Messages-API helpers (Task 4).

## Sprint 3b — OpenAI + Gemini providers (2026-05-30, complete)

Branch: `feat/ai-analysis-providers`. Spec: `docs/superpowers/specs/2026-05-30-ai-analysis-providers-design.md`. Plan: `docs/superpowers/plans/2026-05-30-ai-analysis-providers.md`. Executed inline (per user preference after the 3a session-limit interruption).

Makes the AI provider pluggable — admin can choose Claude, OpenAI, or Gemini from settings, no other behaviour change. Ollama deferred.

### New classes / refactor
- `classes/ai/base_http_ai_client.php` — abstract template-method base: `final generate_sql()`/`format_result()` own the shared flow (POST, status check, `extract_text`, fence-strip, SQL-shape parse); subclasses implement `endpoint()`/`auth_headers()`/`build_sql_payload()`/`build_format_payload()`/`extract_text()`. `post()` throws PARSE_FAILED on a non-JSON body (preserves claude_client's prior behaviour, incl. `format_result` unparseable-throw). `model()` resolves empty config → `DEFAULT_MODEL`.
- `claude_client` — refactored onto the base (15 tests unchanged = safety net).
- `openai_client` — Chat Completions; `Authorization: Bearer`; `response_format:{type:json_object}` for SQL only; `extract_text` = `choices[0].message.content`.
- `gemini_client` — generateContent; model in URL path; `x-goog-api-key` header; `responseMimeType:application/json` for SQL only; `extract_text` = `candidates[0].content.parts[0].text`.
- `ai_client_factory` — `openai`/`gemini` match cases; passes per-provider model; unknown → coding_exception; `set_override` seam untouched.

### Settings / config / DB
- Provider dropdown gains OpenAI + Google Gemini. New free-text model fields (`claude_model`/`openai_model`/`gemini_model`, defaults `claude-sonnet-4-20250514`/`gpt-4o`/`gemini-2.0-flash`) + `openai_api_key`/`gemini_api_key`. No DB schema change. version.php → 2026053001.

### Tests (118 total plugin-wide, +20)
openai_client 8 (new), gemini_client 8 (new), ai_client_factory 4 (new); claude_client 15 unchanged. No interface/validator/scrubber/gateway/audit changes.

### Deviations from plan
- `base::post()` was tightened to throw PARSE_FAILED on a non-array decoded body (the plan's first draft returned `[]`), required so `claude_client_test::test_format_result_unparseable_throws` stays green after the refactor.

## Sprint 4 — Frontend chat widget (2026-05-31, complete)

Branch: `feat/ai-analysis-pipeline-claude`. Spec: `docs/superpowers/specs/2026-05-30-ai-analysis-frontend-chat-widget-design.md`. Plan: `docs/superpowers/plans/2026-05-30-frontend-chat-widget.md`. Executed inline (subagent dispatch hit the session limit; finished inline per user preference).

Adds a floating natural-language chat widget surfaced on every page (for users holding `local/ai_analysis:query` in the page context). Consumes the existing `local_ai_analysis_query` external function; no new external functions, no DB change.

### New / changed files
- `lib.php` — `local_ai_analysis_before_footer()` legacy callback. Returns widget HTML (Moodle 4.5 captures the return value via `before_footer_html_generation::process_legacy_callbacks()`); `''` when the user lacks the capability in `$PAGE->context`. Loads the AMD module with `js_call_amd('local_ai_analysis/chat_widget', 'init', [$courseid])`.
- `templates/chat_widget.mustache` — widget skeleton: FAB + shared panel (drawer/fullscreen) with header (＋ ⤢/⤡ ✕), history sidebar, welcome view, results thread, bottom input. UI strings via `{{#str}}`; JS-needed strings exposed as `data-str-*` on the root.
- `styles.css` — all rules scoped to `.local-ai-analysis-widget`; state driven by `data-state` (collapsed/drawer/fullscreen) and `data-view` (welcome/thread).
- `amd/src/chat_widget.js` + `amd/build/chat_widget.min.js` — state machine, `core/ajax` call (`format:true`), JSON-string row parsing, table render, `core/chartjs` bar chart (first all-numeric column, ≥2 rows), answer + format_note, in-memory single-shot session history (sidebar, click-to-revisit). All result text set via `textContent` (XSS-safe).
- `lang/en/local_ai_analysis.php` — `widget_*` UI strings.
- `version.php` → 2026053002, release `0.4.0`.

### Tests (120 total plugin-wide, +2)
`tests/lib_test.php`: widget rendered for an enrolled editingteacher (course context); empty string for a student lacking the capability. Both acknowledge environment theme `debugging()` via `resetDebugging()`.

### Deviations from plan
- Spec said check `context_system::instance()` and `echo`; corrected to `$PAGE->context` (the capability is CONTEXT_COURSE — system check would hide it from teachers) and to returning the string (core concatenates the return value, not echo).
- `empty($PAGE->context)` guard was buggy (magic `__get` property + `empty()` → always "empty"); replaced with reading the context into a variable first.
- AMD could not be built with grunt here (Moodle grunt requires node ≥22; host has node 20, container has no node). `amd/build/chat_widget.min.js` was hand-authored as an equivalent named AMD `define()` module and node-syntax-checked. Moodle ESLint (grunt) was therefore NOT run — re-run `npx grunt amd --root=local/ai_analysis` on a node-22 host before release to lint + regenerate the build + source map.

### Post-merge fix — AMD source map (commit adc6f8c4)
The hand-authored `amd/build/chat_widget.min.js` rendered the FAB but the JS was dead on click. Cause: with `$CFG->cachejs=0` (dev), `lib/requirejs.php` (≈line 184) serves the built `.min.js` only when a `.min.js.map` sits beside it; with no map it falls back to serving `amd/src/*.js` — our ES6 source has no `define()` → "define() not found" → module never loads. Fix: added a minimal valid v3 `amd/build/chat_widget.min.js.map`. Verified `curl .../lib/requirejs.php/-1/local_ai_analysis/chat_widget.js` now returns the `define(...)` build. Grunt (node ≥22) will regenerate both files later.

### Deployment + live verification (2026-05-31, ops — not committed; config.php is outside the repo)
One-time install per INSTALL.md was completed on this instance and the full pipeline was verified live end-to-end with Gemini:
- Settings: `provider=gemini`; `gemini_model` switched `gemini-2.0-flash` → **`gemini-2.5-flash`** (the 2.0-flash free-tier quota on this key is `limit: 0` → HTTP 429 RESOURCE_EXHAUSTED; 2.5-flash / flash-latest / 2.5-flash-lite return 200 for this key).
- Read-only DB user `moodle_ai_ro` created via `db/readonly_grants.sql` (4 SELECT grants: user, grade_grades, course_modules, logstore_standard_log; writes denied — verified).
- `config.php` (instance, not repo): `ai_analysis_dbuser` / `ai_analysis_dbpass` / `ai_analysis_audit_key` set; backup at `moodle/config.php.bak.aianalysis`.
- Live result: prompt "How many users are registered?" → SQL `SELECT COUNT(id) FROM mdl_user LIMIT 1000` → `answer: "There are 398 users registered on the site."` status SUCCESS.

### Manifest widening + widget UX (2026-05-31, commit 883e6016)
- **mdl_course added to the manifest** (`id, fullname, shortname, summary, startdate, visible`) with a course `_scope_note` for non-admin (filter `WHERE id = <courseid>`). RO user granted `SELECT ON mdl_course` (db/readonly_grants.sql updated + applied). manifest_builder_test updated (now 5 tables; +course scope-note assertion). Verified live: "what is this course" → SUCCESS. sql_validator needs no change (manifest is its allow-list).
- **Friendly widget error messages** — the drawer showed the raw status string (e.g. `out_of_scope`). Added `widget_msg_scope/rate/blocked/failed` lang strings, emitted as `data-msg-*` on the widget root; AMD `friendlyMessage()` maps OUT_OF_SCOPE/RATE_LIMITED/BLOCKED_INJECTION (+ generic fallback) to readable text. Updated both `amd/src` and the hand-authored `amd/build` (kept in sync). 120 tests still pass.

### Manifest expansion 2 — grades-per-course + enrolment (2026-05-31, commit 1bff9d36)
User requested basic questions ("top student in this course", "who is enrolled") that were OUT_OF_SCOPE. Root cause: `mdl_grade_grades` has no `courseid` (links to a course only via `mdl_grade_items`), and no enrolment tables were exposed. Added three tables to the manifest with per-course scope notes, granted RO SELECT on each (db/readonly_grants.sql updated + applied):
- `mdl_grade_items` (id, courseid, itemname, itemtype, grademax) — scope note: filter WHERE courseid; itemtype='course' is the total.
- `mdl_enrol` (id, courseid, enrol, status) — scope note: filter WHERE courseid.
- `mdl_user_enrolments` (id, userid, enrolid, status) — scope note: join via enrolid; status 0=active,1=suspended.
manifest_builder_test updated (8 tables; +grade_items/enrol scope-note asserts). 120 tests pass.
**Verification:** enrolment count works live (30 students, SUCCESS). Top-students capability proven via direct `sql_validator` PASS + RO execution (0 rows only because course 23 has no grades). Teacher/roles deliberately left OUT_OF_SCOPE (user declined role/context exposure).
**Model note:** switched live model gemini-2.5-flash → gemini-2.5-flash-lite (flash's 20/day free quota exhausted). flash-lite has more quota but weaker reasoning (gave `cannot_answer` on the 3-join grade query). See 04-current-state.

## Sprint 5 Task 5 — decrypt_prompt AJAX external function (2026-05-31, complete)

Branch: `sprint5-admin-management`. Commit: `70431370`.

Adds a capability-gated external function that decrypts a stored audit prompt and writes its own self-audit trail.

### New / changed files
- `classes/external/decrypt_prompt.php` — new `external_api` subclass. Validates params, checks `local/ai_analysis:decryptprompt` in system context, fetches audit row, calls `audit_crypto::decrypt()`, writes a `PROMPT_REVEALED` audit row via `audit_writer::write()`, returns `{status, prompt}`. Status ∈ {SUCCESS, NOT_FOUND, DECRYPT_FAILED}.
- `db/services.php` — registered `local_ai_analysis_decrypt_prompt` (classname, methodname, type=read, ajax=true, loginrequired=true, capabilities=decryptprompt).
- `tests/decrypt_prompt_test.php` — 3 tests: admin reveals + self-audit row created; missing ciphertext → NOT_FOUND; non-admin user → `required_capability_exception`. Theme-debugging noise from `create_user()` suppressed with `$this->resetDebugging()`.

### Tests
3/3 pass (6 assertions). 123 total plugin-wide.

## Sprint 5 — Admin / Management & Compliance (2026-05-31, complete, branch sprint5-admin-management)

Full admin/compliance layer. version.php → `2026053100` / `0.5.0`. 142 plugin tests pass. Spec: docs/superpowers/specs/2026-05-31-sprint5-admin-management-design.md; plan: docs/superpowers/plans/2026-05-31-sprint5-admin-management.md.

### T1 — shared `audit_crypto` (commit 9a8e7d5a, e5e59abb)
- New `classes/audit/audit_crypto.php`: `encrypt()`/`decrypt()`/`normalize_key()` — single AES-256-CBC impl (format `base64(iv)::base64(ct)`). `audit_writer` refactored to call it; its private `normalize_aes_key()` deleted. tests/audit_crypto_test.php (5 tests: hex+raw key round-trip, no-key, garbage, bad-length warns).

### T2 — HTTP 429/5xx → transport_exception (commit 1485e7f5, 39ed554c)
- `base_http_ai_client::post()` now throws `transport_exception` for 429 and ≥500 (→ gateway maps to AI_TRANSPORT_ERROR / retry-able), keeps `ai_client_exception` for other 4xx. Body excerpt capped at 500 chars. Fixes the prior 429→AI_INVALID_JSON mis-map. tests/base_http_ai_client_test.php (3); 3 stale claude_client_test cases updated (429/503/500 now transport).

### T3 — retention scheduled task (commit 53886567)
- New `classes/task/purge_audit_task.php` + `db/tasks.php` (daily 03:00). Reads `retentiondays` config; >0 deletes audit rows older than cutoff, 0 = keep forever (no-op). tests/purge_audit_task_test.php (2).

### T4 — GDPR Privacy API (commit 296bb147, 884ac2ad)
- New `classes/privacy/provider.php`: metadata + plugin + core_userlist providers over `local_ai_analysis_audit` (system context). Export = the user's rows; erasure = DELETE (not anonymise). All 13 stored columns declared incl. `block_reason` (added after review caught the gap). 14 privacy lang strings. tests/privacy_provider_test.php (7 — all provider methods).

### T5 — decrypt_prompt AJAX fn (commit 70431370)
- `classes/external/decrypt_prompt.php` + `db/services.php` registration `local_ai_analysis_decrypt_prompt` (ajax, cap `decryptprompt`). Cap+sesskey gated; decrypts via audit_crypto; writes a `PROMPT_REVEALED` self-audit row (who revealed which id); returns {status, prompt}. tests/decrypt_prompt_test.php (3).

### T6 — audit log report page + reveal JS (commit a62c620b)
- New `classes/report/audit_table.php` (`table_sql`: sortable/paginated/CSV-downloadable; static `build_filter()`; actions column with Reveal button only when caller has `decryptprompt` & not downloading; `s()`+shorten_text on SQL, textContent in JS = XSS-safe). New `audit.php` page under Site admin → Reports (cap `viewaudit`, externalpage `localaianalysisaudit`). New `amd/src/audit_reveal.js` + hand-authored `amd/build/audit_reveal.min.js` + `.map` (dev-mode requirement, same as Sprint 4). 11 report lang strings. tests/audit_table_test.php (2).

### T7 — settings polish (commit 512d7543)
- settings.php grouped under headings (Provider / API keys & models / Rate limiting / Audit & retention); added `retentiondays` configtext (default 365) + audit-log link. Reports externalpage + all prior settings preserved.

### Pending / caveats
- AMD `audit_reveal` not browser-verified here (no node-22 grunt) — hand-authored build+map mirror Sprint-4 pattern; rebuild via `npx grunt amd --root=local/ai_analysis` on a node-22 host before release.
- New scheduled task + service + report page require run upgrade + purge_caches on deploy (version bumped → upgrade runs automatically).

## Sprint 3c — Ollama provider (2026-06-01, complete)

Self-hosted, no-API-key provider. Removes Gemini daily-quota pain.

### New classes
- `classes/ai/ollama_client.php` — extends `openai_client`. Ollama's `/v1/chat/completions` is OpenAI wire-compatible, so SQL/format payloads, `extract_text`, JSON parsing and 429/5xx handling all inherit unchanged. Overrides only: constructor `(transport, base_url, model)` (base_url replaces the unused api_key slot; defaults `http://localhost:11434`, trailing slash stripped), `endpoint()` (base_url + `/v1/chat/completions`), `auth_headers()` (drops Bearer — no auth), `DEFAULT_MODEL = 'qwen2.5-coder'`.

### Wiring
- `ai_client_factory`: added `'ollama'` match case → reads `ollama_base_url` + `ollama_model`.
- `settings.php`: `ollama` added to provider dropdown; `ollama_base_url` (PARAM_URL, default `http://localhost:11434`) + `ollama_model` (PARAM_TEXT, default `qwen2.5-coder`) fields before the rate-limit heading.
- 4 lang strings (`setting_ollama_base_url[_desc]`, `setting_ollama_model[_desc]`).

### Bonus: AMD rebuild (resolved long-standing caveat)
- Ran real `grunt amd --root=local/ai_analysis` via a `node:22-slim` Docker container (host has node-20; grunt hard-gates ≥22.11). Container run as `-u $(id -u):33` (www-data gid) so it can write the group-writable `.eslintignore`/`.stylelintignore`.
- Fixed an ESLint `no-bitwise` error in `amd/src/chat_widget.js` UUID fallback (`Math.random()*16|0` → `Math.floor(...)`; `r&0x3|0x8` → `r%4+8`; same result).
- Regenerated `chat_widget` + `audit_reveal` `.min.js` **and real source maps** (were 123/125-byte hand-authored stubs; now 21KB/1.6KB rollup maps). AMD builds are no longer hand-authored.

### Cleanup
- Deleted throwaway `test_validation_exception.php` (instance root, Sprint-1 manual script superseded by PHPUnit). Added `config.php.bak.aianalysis` to `moodle/.gitignore` (config backup with live secrets — kept, just untracked).

### DB changes
- None. version.php → 2026060100 / 0.6.0.

### Tests (149 total across plugin, +7)
- `tests/ollama_client_test.php` (6): default base_url+model & no-auth-header, custom base_url trailing-slash strip, custom model, inherited happy-path/out-of-scope/format_result.
- `tests/ai_client_factory_test.php` (+1): `test_ollama_provider` dispatch.

### Live verification
- OpenAI-compat path proven against the host's running Ollama (`qwen2.5:7b`): the exact payload `ollama_client` sends (model + `response_format: json_object` + messages) returned a parseable `{sql, params, explanation}` object. Wire compatibility + JSON mode + parseability confirmed.

### Pending / caveats
- **Container→Ollama networking**: Moodle runs inside `moodle-web-8092`; host Ollama binds `127.0.0.1` only, so `localhost:11434` (the default) is unreachable from the container, and the docker gateway (`172.26.0.1:11434`) times out. For the live in-app pipeline, run Ollama with `OLLAMA_HOST=0.0.0.0` and set `ollama_base_url` to the docker gateway IP (or `host.docker.internal` if added to the container). Default works only when Moodle and Ollama share a host.
- Host has `qwen2.5:7b` + `qwen2.5:14b` pulled, not the `-coder` default — `ollama pull qwen2.5-coder` or set the model field accordingly.

## Sprint 3c addendum — configurable request timeout + live Ollama bring-up (2026-06-01)

Live-testing Ollama in the actual pipeline surfaced a chain of infra blockers (all now resolved) and one needed code change.

### Code: configurable AI request timeout
- `base_http_ai_client.__construct` gained a 4th param `int $timeout = 30` (stored), and `post()` now passes it to `transport->post(...)` (previously used the transport's hard-coded 30s default).
- `ollama_client.__construct` threads `$timeout` to `parent::__construct`.
- `ai_client_factory::make()` reads a new global `request_timeout` config (`(int) … ?: 30`) and passes it to **all** providers (claude/openai/gemini/ollama). claude/openai/gemini inherit the base constructor unchanged.
- `settings.php`: new `request_timeout` configtext (PARAM_INT, default 30) under the Rate limiting heading; 2 lang strings.
- Tests: `ollama_client_test` +2 (`test_timeout_threaded_to_transport`, `test_default_timeout_is_30`; fake transport now records `last_timeout`). **151 plugin tests pass.** version.php → 2026060101 / 0.6.1.

### Deployment chain for live Ollama (this instance, dockerised Moodle + host Ollama)
Moodle runs in container `moodle-web-8092`; Ollama runs on the host. To make the in-app pipeline reach it, ALL of the following were required:
1. **Ollama bind**: host Ollama must listen on all interfaces (`OLLAMA_HOST=0.0.0.0`; confirmed `ss` shows `*:11434`), not just `127.0.0.1`.
2. **`ollama_base_url`** set to the docker bridge gateway `http://172.26.0.1:11434` (container's `localhost` is itself, not the host).
3. **Host firewall**: nftables/iptables (Debian 13, `iptables` is the nft shim) dropped container→host packets → 30s timeout with 0 bytes. Fixed with `sudo /usr/sbin/iptables -I INPUT -i br-213e02bb1a10 -p tcp --dport 11434 -j ACCEPT` (br-213e02bb1a10 = this network's bridge). NOT yet persisted (no `/etc/iptables/` dir) — re-add on host reboot, or `iptables-save` to a saved path.
4. **Moodle cURL security**: Moodle's `\curl` blocks private IPs once any host/port security rule exists. Added to `config.php`: `$CFG->curlsecurityblockedhosts = '';` and `$CFG->curlsecurityallowedport = "80\n443\n11434";`. (config.php is gitignored — instance-only; replicate per deployment.)
5. **Latency / timeout**: no GPU here (`size_vram:0`) → CPU inference. qwen2.5:7b ≈ 64s/query → exceeded the old 30s timeout. Pulled `qwen2.5:3b`; warm ≈ 10.6s, cold (model load) ≈ 42s. Instance now set to `ollama_model=qwen2.5:3b`, `request_timeout=90`.

### Notes
- Both 3b and 7b tend to append `WHERE courseid = 0` to `mdl_user` (no such column) for global/admin queries — they over-apply the "Course ID: 0" context line. Pre-existing prompt-design quirk (also seen with 7b), caught downstream by `sql_validator`. Not Ollama-specific.
- Ollama unloads idle models after ~5 min → next query pays the cold-load again. Set `keep_alive` (Ollama side) to keep it resident for snappier widget UX.
