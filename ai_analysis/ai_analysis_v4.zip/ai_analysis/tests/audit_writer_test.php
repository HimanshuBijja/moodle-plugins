<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\audit\audit_writer
 */
class audit_writer_test extends \advanced_testcase {

    public function test_writes_hash_without_key(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        unset($CFG->ai_analysis_audit_key);

        \local_ai_analysis\audit\audit_writer::write(
            userid: 42,
            courseid: 7,
            prompt: 'hello world',
            sql: 'SELECT id FROM mdl_user',
            status: 'SUCCESS',
            reason: '',
            provider: 'claude'
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 42]);
        $this->assertNotFalse($row);
        $this->assertSame(hash('sha256', 'hello world'), $row->prompt_hash);
        $this->assertSame(11, (int)$row->prompt_length);
        $this->assertNull($row->prompt_encrypted);
        $this->assertSame('SUCCESS', $row->status);
        $this->assertSame('claude', $row->provider);
    }

    public function test_writes_encrypted_prompt_when_key_set(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('k', 32);

        \local_ai_analysis\audit\audit_writer::write(
            userid: 100, courseid: 0, prompt: 'secret prompt text',
            sql: null, status: 'BLOCKED_INJECTION', reason: 'ignore previous', provider: ''
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 100]);
        $this->assertNotNull($row->prompt_encrypted);
        $this->assertStringContainsString('::', $row->prompt_encrypted);

        // Round-trip decrypt.
        [$iv_b64, $ct_b64] = explode('::', $row->prompt_encrypted);
        $plain = openssl_decrypt(base64_decode($ct_b64), 'AES-256-CBC', $CFG->ai_analysis_audit_key, OPENSSL_RAW_DATA, base64_decode($iv_b64));
        $this->assertSame('secret prompt text', $plain);
    }

    public function test_truncates_useragent_and_sql(): void {
        global $DB;
        $this->resetAfterTest();
        $_SERVER['HTTP_USER_AGENT'] = str_repeat('A', 400);
        $long_sql = 'SELECT ' . str_repeat('x', 3000);

        \local_ai_analysis\audit\audit_writer::write(
            userid: 1, courseid: 0, prompt: 'p', sql: $long_sql,
            status: 'SUCCESS', reason: '', provider: ''
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 1]);
        $this->assertLessThanOrEqual(255, strlen($row->useragent));
        $this->assertLessThanOrEqual(2000, strlen($row->sql_executed));
    }

    public function test_wrong_key_length_skips_encryption_without_throwing(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = 'too-short';  // 9 bytes, not 32.

        \local_ai_analysis\audit\audit_writer::write(
            userid: 200, courseid: 0, prompt: 'should not be encrypted with weak key',
            sql: null, status: 'SUCCESS', reason: '', provider: ''
        );

        $this->assertDebuggingCalled();

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 200]);
        $this->assertNotFalse($row);
        $this->assertNull($row->prompt_encrypted, 'Weak key must not produce ciphertext');
        $this->assertSame(hash('sha256', 'should not be encrypted with weak key'), $row->prompt_hash);
    }

    public function test_hex_encoded_key_is_decoded_and_used(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        // INSTALL.md tells admins to run `openssl rand -hex 32`, which yields a
        // 64-char hex string. audit_writer must accept that form (auto-decode).
        $raw_key = random_bytes(32);
        $CFG->ai_analysis_audit_key = bin2hex($raw_key);  // 64 hex chars.

        \local_ai_analysis\audit\audit_writer::write(
            userid: 300, courseid: 0, prompt: 'hex key prompt',
            sql: null, status: 'SUCCESS', reason: '', provider: ''
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 300]);
        $this->assertNotNull($row->prompt_encrypted, 'Hex-encoded key must still produce ciphertext');
        [$iv_b64, $ct_b64] = explode('::', $row->prompt_encrypted);
        $plain = openssl_decrypt(base64_decode($ct_b64), 'AES-256-CBC', $raw_key, OPENSSL_RAW_DATA, base64_decode($iv_b64));
        $this->assertSame('hex key prompt', $plain);
    }

    public function test_never_throws_when_db_fails(): void {
        // Pass a deliberately oversized status (column is char(40)) to provoke a DB error.
        $this->resetAfterTest();
        $oversize_status = str_repeat('X', 200);

        // Must not throw.
        \local_ai_analysis\audit\audit_writer::write(
            userid: 1, courseid: 0, prompt: 'p', sql: null,
            status: $oversize_status, reason: '', provider: ''
        );
        $this->assertTrue(true); // Reached this line = no exception escaped.
    }
}
