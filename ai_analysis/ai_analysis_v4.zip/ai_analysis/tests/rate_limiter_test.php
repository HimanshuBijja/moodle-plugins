<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\security\rate_limiter
 */
class rate_limiter_test extends \advanced_testcase {

    public function test_fresh_user_has_full_bucket(): void {
        $this->resetAfterTest();
        $rl = new \local_ai_analysis\security\rate_limiter();
        for ($i = 0; $i < 10; $i++) {
            $this->assertTrue($rl->consume(42, false), "consume #$i should succeed");
        }
    }

    public function test_bucket_empties_after_capacity(): void {
        $this->resetAfterTest();
        $rl = new \local_ai_analysis\security\rate_limiter();
        for ($i = 0; $i < 10; $i++) {
            $rl->consume(100, false);
        }
        $this->assertFalse($rl->consume(100, false), '11th consume should return false');
    }

    public function test_admin_bypasses_limit(): void {
        $this->resetAfterTest();
        $rl = new \local_ai_analysis\security\rate_limiter();
        for ($i = 0; $i < 50; $i++) {
            $this->assertTrue($rl->consume(1, true), "admin consume #$i should bypass");
        }
    }

    public function test_buckets_isolated_per_user(): void {
        $this->resetAfterTest();
        $rl = new \local_ai_analysis\security\rate_limiter();
        for ($i = 0; $i < 10; $i++) {
            $rl->consume(200, false);
        }
        $this->assertFalse($rl->consume(200, false));
        $this->assertTrue($rl->consume(201, false), 'different user has own bucket');
    }

    public function test_refill_after_simulated_time_passes(): void {
        $this->resetAfterTest();
        global $DB;
        // Drain.
        $rl = new \local_ai_analysis\security\rate_limiter();
        for ($i = 0; $i < 10; $i++) {
            $rl->consume(300, false);
        }
        $this->assertFalse($rl->consume(300, false));
        // Rewind the bucket's last-refill timestamp by 120 seconds via the cache.
        $cache = \cache::make('local_ai_analysis', 'ratelimit');
        $bucket = $cache->get('user_300');
        $bucket['last'] -= 120;
        $cache->set('user_300', $bucket);
        // 120s elapsed at 1/min should refill 2 tokens.
        $this->assertTrue($rl->consume(300, false), 'should refill after 120s elapsed');
        $this->assertTrue($rl->consume(300, false), 'second refill token also usable');
        $this->assertFalse($rl->consume(300, false), 'but only 2 refilled');
    }
}
