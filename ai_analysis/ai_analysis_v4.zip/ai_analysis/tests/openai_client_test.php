<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * Fake transport recording the last request and replaying a canned response.
 */
class openai_fake_transport implements http_transport_interface {
    public ?string $last_url = null;
    public ?array $last_headers = null;
    public ?string $last_body = null;
    public array $next_response = ['status' => 200, 'headers' => [], 'body' => ''];

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        $this->last_url = $url;
        $this->last_headers = $headers;
        $this->last_body = $body;
        return $this->next_response;
    }
}

/**
 * @covers \local_ai_analysis\ai\openai_client
 */
class openai_client_test extends \advanced_testcase {

    private function chat_response(string $content): array {
        return ['status' => 200, 'headers' => [], 'body' => json_encode([
            'choices' => [['message' => ['role' => 'assistant', 'content' => $content]]],
        ])];
    }

    public function test_sql_request_targets_chat_endpoint_with_bearer_and_json_mode(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'sk-test');
        $c->generate_sql('SYS', 'USR');
        $this->assertSame('https://api.openai.com/v1/chat/completions', $t->last_url);
        $this->assertContains('Authorization: Bearer sk-test', $t->last_headers);
        $body = json_decode($t->last_body, true);
        $this->assertSame('gpt-4o', $body['model']);
        $this->assertSame(['type' => 'json_object'], $body['response_format']);
        $this->assertSame('system', $body['messages'][0]['role']);
        $this->assertSame('SYS', $body['messages'][0]['content']);
        $this->assertSame('USR', $body['messages'][1]['content']);
    }

    public function test_happy_path_returns_sql_array(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user WHERE id = ? LIMIT 10","params":[5],"explanation":"by id"}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('sql', $r['type']);
        $this->assertSame([5], $r['params']);
    }

    public function test_code_fence_stripped(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response("```json\n{\"sql\":\"SELECT id FROM mdl_user LIMIT 1\",\"params\":[],\"explanation\":\"\"}\n```");
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $this->assertSame('sql', $c->generate_sql('s', 'u')['type']);
    }

    public function test_out_of_scope(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"error":"out_of_scope"}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('out_of_scope', $r['type']);
        $this->assertSame('out_of_scope', $r['message']);
    }

    public function test_http_error_throws(): void {
        $t = new openai_fake_transport();
        $t->next_response = ['status' => 401, 'headers' => [], 'body' => '{"error":"bad key"}'];
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_malformed_throws(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('not json');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_custom_model_used(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k', 'gpt-4o-mini');
        $c->generate_sql('s', 'u');
        $this->assertSame('gpt-4o-mini', json_decode($t->last_body, true)['model']);
    }

    public function test_format_result_returns_prose_without_json_mode(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('PERSON_1 has the top grade.');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $answer = $c->format_result('who scored highest', [['firstname' => 'PERSON_1']]);
        $this->assertSame('PERSON_1 has the top grade.', $answer);
        $body = json_decode($t->last_body, true);
        $this->assertArrayNotHasKey('response_format', $body);
        $this->assertSame(1024, $body['max_tokens']);
        $this->assertStringContainsString('PERSON_1', $body['messages'][1]['content']);
    }
}
