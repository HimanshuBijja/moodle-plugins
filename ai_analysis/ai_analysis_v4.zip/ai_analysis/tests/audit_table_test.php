<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\report\audit_table;

/**
 * @covers \local_ai_analysis\report\audit_table
 */
class audit_table_test extends \advanced_testcase {

    public function test_empty_filters_match_all(): void {
        [$where, $params] = audit_table::build_filter([]);
        $this->assertEquals('1=1', $where);
        $this->assertEquals([], $params);
    }

    public function test_filters_build_constraints(): void {
        [$where, $params] = audit_table::build_filter([
            'userid' => 7, 'courseid' => 3, 'status' => 'SUCCESS',
            'datefrom' => 100, 'dateto' => 200,
        ]);
        $this->assertStringContainsString('userid = :userid', $where);
        $this->assertStringContainsString('courseid = :courseid', $where);
        $this->assertStringContainsString('status = :status', $where);
        $this->assertStringContainsString('timecreated >= :datefrom', $where);
        $this->assertStringContainsString('timecreated <= :dateto', $where);
        $this->assertEquals(7, $params['userid']);
        $this->assertEquals('SUCCESS', $params['status']);
        $this->assertEquals(200, $params['dateto']);
    }
}
