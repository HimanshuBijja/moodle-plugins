<?php
namespace local_ai_analysis;

use local_ai_analysis\exception\query_execution_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\query_executor
 */
class query_executor_test extends \advanced_testcase {

    public function test_runs_select_against_injected_db(): void {
        global $DB;
        $this->resetAfterTest();
        $u1 = $this->getDataGenerator()->create_user(['firstname' => 'Alice']);
        $u2 = $this->getDataGenerator()->create_user(['firstname' => 'Bob']);
        // Clear any spurious debugging messages from the environment (e.g. missing themes).
        $this->resetDebugging();

        $exec = new \local_ai_analysis\db\query_executor($DB);
        $rows = $exec->run('SELECT id, firstname FROM {user} WHERE id IN (?, ?) ORDER BY id', [$u1->id, $u2->id]);

        $this->assertCount(2, $rows);
        $this->assertSame('Alice', $rows[0]->firstname);
        $this->assertSame('Bob', $rows[1]->firstname);
    }

    public function test_returns_array_values_not_keyed_by_id(): void {
        global $DB;
        $this->resetAfterTest();
        $u = $this->getDataGenerator()->create_user();
        // Clear any spurious debugging messages from the environment (e.g. missing themes).
        $this->resetDebugging();
        $exec = new \local_ai_analysis\db\query_executor($DB);
        $rows = $exec->run('SELECT id FROM {user} WHERE id = ?', [$u->id]);
        // Plain numeric keys, not Moodle's typical id-keyed shape.
        $this->assertSame([0], array_keys($rows));
    }

    public function test_syntax_error_throws_query_execution_exception(): void {
        global $DB;
        $this->resetAfterTest();
        $exec = new \local_ai_analysis\db\query_executor($DB);
        $this->expectException(query_execution_exception::class);
        $exec->run('SELECT bogus_column FROM {user} WHERE 1', []);
    }
}
