<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\request\approved_contextlist;
use local_ai_analysis\privacy\provider;

/**
 * @covers \local_ai_analysis\privacy\provider
 */
class privacy_provider_test extends \core_privacy\tests\provider_testcase {

    private function seed(int $userid): void {
        global $DB;
        $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => $userid, 'courseid' => 0, 'timecreated' => time(),
            'prompt_hash' => 'h', 'prompt_length' => 5, 'status' => 'SUCCESS',
        ]);
    }

    public function test_metadata_not_empty(): void {
        $this->resetAfterTest();
        $collection = new \core_privacy\local\metadata\collection('local_ai_analysis');
        $collection = provider::get_metadata($collection);
        $this->assertNotEmpty($collection->get_collection());
    }

    public function test_get_contexts_for_userid(): void {
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $user->id);
        $contextlist = provider::get_contexts_for_userid((int) $user->id);
        $this->assertCount(1, $contextlist);
        $this->assertEquals(
            \context_system::instance()->id,
            $contextlist->current()->id
        );
    }

    public function test_delete_data_for_user(): void {
        global $DB;
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $user->id);
        $this->seed((int) $user->id);
        $other = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $other->id);

        $ctxlist = new approved_contextlist($user, 'local_ai_analysis',
            [\context_system::instance()->id]);
        provider::delete_data_for_user($ctxlist);

        $this->assertEquals(0, $DB->count_records('local_ai_analysis_audit', ['userid' => $user->id]));
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit', ['userid' => $other->id]));
    }

    public function test_get_users_in_context(): void {
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $user->id);
        $userlist = new \core_privacy\local\request\userlist(\context_system::instance(), 'local_ai_analysis');
        provider::get_users_in_context($userlist);
        $this->assertTrue(in_array($user->id, $userlist->get_userids()));
    }

    public function test_export_user_data(): void {
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $user->id);
        $ctxlist = new approved_contextlist($user, 'local_ai_analysis',
            [\context_system::instance()->id]);
        provider::export_user_data($ctxlist);
        $writer = \core_privacy\local\request\writer::with_context(\context_system::instance());
        $this->assertTrue($writer->has_any_data());
    }

    public function test_delete_data_for_all_users_in_context(): void {
        global $DB;
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $user->id);
        $this->seed((int) $user->id);
        provider::delete_data_for_all_users_in_context(\context_system::instance());
        $this->assertEquals(0, $DB->count_records('local_ai_analysis_audit'));
    }

    public function test_delete_data_for_users(): void {
        global $DB;
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $other = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->seed((int) $user->id);
        $this->seed((int) $other->id);
        $userlist = new \core_privacy\local\request\approved_userlist(
            \context_system::instance(), 'local_ai_analysis', [$user->id]);
        provider::delete_data_for_users($userlist);
        $this->assertEquals(0, $DB->count_records('local_ai_analysis_audit', ['userid' => $user->id]));
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit', ['userid' => $other->id]));
    }
}
