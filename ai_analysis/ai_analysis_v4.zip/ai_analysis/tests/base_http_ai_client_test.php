<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;
use local_ai_analysis\exception\transport_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\ai\base_http_ai_client
 */
class base_http_ai_client_test extends \advanced_testcase {

    private function make_transport(int $status, string $body): http_transport_interface {
        return new class($status, $body) implements http_transport_interface {
            public function __construct(private int $status, private string $body) {}
            public function post(string $url, array $headers, string $body, int $timeout = 30): array {
                return ['status' => $this->status, 'headers' => [], 'body' => $this->body];
            }
        };
    }

    private function make_client(http_transport_interface $transport): \local_ai_analysis\ai\claude_client {
        return new \local_ai_analysis\ai\claude_client($transport, 'test-key');
    }

    public function test_http_429_throws_transport_exception(): void {
        $transport = $this->make_transport(429, '{"error":"rate_limit_exceeded"}');
        $client = $this->make_client($transport);
        $this->expectException(transport_exception::class);
        $client->generate_sql('sys', 'usr');
    }

    public function test_http_503_throws_transport_exception(): void {
        $transport = $this->make_transport(503, 'Service Unavailable');
        $client = $this->make_client($transport);
        $this->expectException(transport_exception::class);
        $client->generate_sql('sys', 'usr');
    }

    public function test_http_400_throws_ai_client_exception(): void {
        $transport = $this->make_transport(400, '{"error":"bad_request"}');
        $client = $this->make_client($transport);
        $this->expectException(ai_client_exception::class);
        $client->generate_sql('sys', 'usr');
    }
}
