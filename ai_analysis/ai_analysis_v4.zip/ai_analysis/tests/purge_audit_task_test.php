<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\task\purge_audit_task;

/**
 * @covers \local_ai_analysis\task\purge_audit_task
 */
class purge_audit_task_test extends \advanced_testcase {

    private function seed(int $timecreated): void {
        global $DB;
        $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => 1, 'courseid' => 0, 'timecreated' => $timecreated,
            'prompt_hash' => 'h', 'prompt_length' => 1, 'status' => 'SUCCESS',
        ]);
    }

    public function test_deletes_rows_older_than_retention(): void {
        global $DB;
        $this->resetAfterTest();
        set_config('retentiondays', 30, 'local_ai_analysis');
        $now = time();
        $this->seed($now - 40 * DAYSECS); // older -> delete
        $this->seed($now - 10 * DAYSECS); // newer -> keep
        (new purge_audit_task())->execute();
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit'));
    }

    public function test_zero_retention_keeps_everything(): void {
        global $DB;
        $this->resetAfterTest();
        set_config('retentiondays', 0, 'local_ai_analysis');
        $this->seed(time() - 9999 * DAYSECS);
        (new purge_audit_task())->execute();
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit'));
    }
}
