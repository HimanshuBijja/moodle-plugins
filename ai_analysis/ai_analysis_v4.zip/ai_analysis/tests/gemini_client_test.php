<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

class gemini_fake_transport implements http_transport_interface {
    public ?string $last_url = null;
    public ?array $last_headers = null;
    public ?string $last_body = null;
    public array $next_response = ['status' => 200, 'headers' => [], 'body' => ''];

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        $this->last_url = $url;
        $this->last_headers = $headers;
        $this->last_body = $body;
        return $this->next_response;
    }
}

/**
 * @covers \local_ai_analysis\ai\gemini_client
 */
class gemini_client_test extends \advanced_testcase {

    private function gen_response(string $text): array {
        return ['status' => 200, 'headers' => [], 'body' => json_encode([
            'candidates' => [['content' => ['parts' => [['text' => $text]]]]],
        ])];
    }

    public function test_sql_request_targets_model_url_with_key_header_and_json_mime(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'gkey');
        $c->generate_sql('SYS', 'USR');
        $this->assertSame(
            'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
            $t->last_url
        );
        $this->assertContains('x-goog-api-key: gkey', $t->last_headers);
        $body = json_decode($t->last_body, true);
        $this->assertSame('SYS', $body['systemInstruction']['parts'][0]['text']);
        $this->assertSame('USR', $body['contents'][0]['parts'][0]['text']);
        $this->assertSame('application/json', $body['generationConfig']['responseMimeType']);
        $this->assertSame(800, $body['generationConfig']['maxOutputTokens']);
    }

    public function test_happy_path_returns_sql_array(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"sql":"SELECT id FROM mdl_user WHERE id = ? LIMIT 10","params":[7],"explanation":""}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('sql', $r['type']);
        $this->assertSame([7], $r['params']);
    }

    public function test_code_fence_stripped(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response("```json\n{\"sql\":\"SELECT id FROM mdl_user LIMIT 1\",\"params\":[],\"explanation\":\"\"}\n```");
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->assertSame('sql', $c->generate_sql('s', 'u')['type']);
    }

    public function test_out_of_scope(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"error":"out_of_scope"}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->assertSame('out_of_scope', $c->generate_sql('s', 'u')['type']);
    }

    public function test_http_error_throws(): void {
        $t = new gemini_fake_transport();
        $t->next_response = ['status' => 400, 'headers' => [], 'body' => '{"error":"bad"}'];
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_malformed_throws(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('not json');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_custom_model_in_url(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k', 'gemini-1.5-pro');
        $c->generate_sql('s', 'u');
        $this->assertStringContainsString('/models/gemini-1.5-pro:generateContent', $t->last_url);
    }

    public function test_format_result_returns_prose_without_json_mime(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('PERSON_1 leads.');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $answer = $c->format_result('who leads', [['firstname' => 'PERSON_1']]);
        $this->assertSame('PERSON_1 leads.', $answer);
        $body = json_decode($t->last_body, true);
        $this->assertArrayNotHasKey('responseMimeType', $body['generationConfig']);
        $this->assertSame(1024, $body['generationConfig']['maxOutputTokens']);
    }
}
