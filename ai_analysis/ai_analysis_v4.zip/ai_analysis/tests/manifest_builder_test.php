<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\manifest\manifest_builder
 */
class manifest_builder_test extends \advanced_testcase {

    public function test_admin_returns_full_manifest(): void {
        $m = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertEqualsCanonicalizing(
            [
                'mdl_user', 'mdl_course', 'mdl_grade_grades', 'mdl_grade_items',
                'mdl_course_modules', 'mdl_enrol', 'mdl_user_enrolments', 'mdl_logstore_standard_log',
            ],
            array_keys($m)
        );
        $this->assertArrayNotHasKey('_scope_note', $m['mdl_user']);
        $this->assertArrayNotHasKey('_scope_note', $m['mdl_course']);
    }

    public function test_teacher_attaches_scope_note(): void {
        $m = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 42);
        $this->assertArrayHasKey('_scope_note', $m['mdl_user']);
        $this->assertStringContainsString('42', $m['mdl_user']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_logstore_standard_log']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_course']);
        $this->assertStringContainsString('42', $m['mdl_course']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_grade_items']);
        $this->assertStringContainsString('42', $m['mdl_grade_items']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_enrol']);
    }

    /**
     * @dataProvider role_provider
     */
    public function test_no_forbidden_columns_ever_appear(string $role, int $courseid): void {
        // Sensitive columns that must NEVER appear in any manifest variant.
        $forbidden = ['password', 'secret', 'sesskey', 'token', 'apikey', 'hash', 'salt', 'privatekey'];
        $m = \local_ai_analysis\manifest\manifest_builder::build($role, $courseid);
        foreach ($m as $table => $cols) {
            if (!is_array($cols)) continue;
            foreach ($cols as $key => $col) {
                if ($key === '_scope_note') continue;
                $this->assertNotContains($col, $forbidden, "Forbidden column '$col' appeared in $table for role=$role");
            }
        }
    }

    public static function role_provider(): array {
        return [
            ['admin', 0],
            ['manager', 0],
            ['editingteacher', 0],
            ['editingteacher', 42],
            ['teacher', 99],
        ];
    }
}
