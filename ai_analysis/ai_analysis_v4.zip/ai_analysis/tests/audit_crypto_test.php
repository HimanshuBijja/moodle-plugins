<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\audit\audit_crypto;

/**
 * @covers \local_ai_analysis\audit\audit_crypto
 */
class audit_crypto_test extends \advanced_testcase {

    public function test_round_trip_with_hex_key(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('ab', 32); // 64 hex chars.
        $stored = audit_crypto::encrypt('who failed quiz 3');
        $this->assertNotNull($stored);
        $this->assertStringContainsString('::', $stored);
        $this->assertSame('who failed quiz 3', audit_crypto::decrypt($stored));
    }

    public function test_no_key_returns_null(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = '';
        $this->assertNull(audit_crypto::encrypt('x'));
        $this->assertNull(audit_crypto::decrypt('aaaa::bbbb'));
    }

    public function test_decrypt_garbage_returns_null(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('ab', 32);
        $this->assertNull(audit_crypto::decrypt('not-valid-format'));
        $this->assertNull(audit_crypto::decrypt('!!!::!!!'));
    }

    public function test_round_trip_with_raw_32byte_key(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('k', 32); // 32 raw bytes.
        $stored = audit_crypto::encrypt('top students');
        $this->assertNotNull($stored);
        $this->assertSame('top students', audit_crypto::decrypt($stored));
    }

    public function test_bad_length_key_warns_and_returns_null(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = 'too-short';
        $this->assertNull(audit_crypto::encrypt('x'));
        $this->assertDebuggingCalled();
    }
}
