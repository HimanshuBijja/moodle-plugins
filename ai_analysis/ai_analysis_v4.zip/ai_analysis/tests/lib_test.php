<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot . '/local/ai_analysis/lib.php');

/**
 * @covers ::local_ai_analysis_before_footer
 */
class lib_test extends \advanced_testcase {

    public function test_widget_rendered_for_capable_user(): void {
        global $PAGE;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $teacher = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($teacher->id, $course->id, 'editingteacher');
        $this->setUser($teacher);

        $PAGE->set_course($course);
        $PAGE->set_context(\context_course::instance($course->id));

        $html = \local_ai_analysis_before_footer();
        // Acknowledge environment-specific theme debugging from rendering.
        $this->resetDebugging();
        $this->assertStringContainsString('data-region="ai-widget"', $html);
    }

    public function test_widget_not_rendered_for_incapable_user(): void {
        global $PAGE;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $student = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($student->id, $course->id, 'student');
        $this->setUser($student);

        $PAGE->set_course($course);
        $PAGE->set_context(\context_course::instance($course->id));

        $html = \local_ai_analysis_before_footer();
        // Acknowledge environment-specific theme debugging from create_user.
        $this->resetDebugging();
        $this->assertSame('', $html);
    }
}
