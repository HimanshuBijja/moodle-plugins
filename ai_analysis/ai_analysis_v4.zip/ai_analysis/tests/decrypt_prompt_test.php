<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\external\decrypt_prompt;
use local_ai_analysis\audit\audit_crypto;

/**
 * @covers \local_ai_analysis\external\decrypt_prompt
 */
class decrypt_prompt_test extends \advanced_testcase {

    private function seed_encrypted(string $plain): int {
        global $DB;
        return (int) $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => 2, 'courseid' => 0, 'timecreated' => time(),
            'prompt_hash' => hash('sha256', $plain), 'prompt_length' => strlen($plain),
            'prompt_encrypted' => audit_crypto::encrypt($plain), 'status' => 'SUCCESS',
        ]);
    }

    public function test_admin_reveals_and_self_audits(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('cd', 32);
        $this->setAdminUser();
        $id = $this->seed_encrypted('list failing students');

        $result = decrypt_prompt::execute($id);
        $this->assertEquals('SUCCESS', $result['status']);
        $this->assertEquals('list failing students', $result['prompt']);
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit', ['status' => 'PROMPT_REVEALED']));
    }

    public function test_missing_ciphertext_returns_not_found(): void {
        global $DB;
        $this->resetAfterTest();
        $this->setAdminUser();
        $id = (int) $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => 2, 'courseid' => 0, 'timecreated' => time(),
            'prompt_hash' => 'h', 'prompt_length' => 0, 'prompt_encrypted' => null,
            'status' => 'BLOCKED_INJECTION',
        ]);
        $result = decrypt_prompt::execute($id);
        $this->assertEquals('NOT_FOUND', $result['status']);
        $this->assertEquals('', $result['prompt']);
    }

    public function test_without_capability_throws(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('cd', 32);
        $user = $this->getDataGenerator()->create_user();
        $this->resetDebugging();
        $this->setUser($user); // no decryptprompt cap
        $id = $this->seed_encrypted('x');
        $this->expectException(\required_capability_exception::class);
        decrypt_prompt::execute($id);
    }
}
