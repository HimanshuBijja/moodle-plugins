<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\security\pii_scrubber;

/**
 * @covers \local_ai_analysis\security\pii_scrubber
 */
class pii_scrubber_test extends \advanced_testcase {

    public function test_is_pii_known_and_unknown(): void {
        $this->assertTrue(pii_scrubber::is_pii('mdl_user.firstname'));
        $this->assertTrue(pii_scrubber::is_pii('mdl_user.email'));
        $this->assertFalse(pii_scrubber::is_pii('mdl_user.id'));
        $this->assertFalse(pii_scrubber::is_pii('mdl_grade_grades.finalgrade'));
    }

    public function test_classify_columns_plain_pii_and_nonpii(): void {
        $source = ['id' => 'mdl_user.id', 'firstname' => 'mdl_user.firstname'];
        $refs   = ['id' => ['mdl_user.id'], 'firstname' => ['mdl_user.firstname']];
        $this->assertSame([
            'id'        => null,
            'firstname' => 'mdl_user.firstname',
        ], pii_scrubber::classify_columns($source, $refs));
    }

    public function test_classify_columns_derived_referencing_pii_is_redacted(): void {
        $source = ['n' => null, 'full' => null];
        $refs   = ['n' => [], 'full' => ['mdl_user.firstname', 'mdl_user.lastname']];
        $this->assertSame([
            'n'    => null,
            'full' => '__REDACT__',
        ], pii_scrubber::classify_columns($source, $refs));
    }

    public function test_tokenize_masks_pii_column(): void {
        $s = new pii_scrubber();
        $rows = [
            (object) ['id' => 1, 'firstname' => 'Alice'],
            (object) ['id' => 2, 'firstname' => 'Bob'],
        ];
        $map = ['id' => null, 'firstname' => 'mdl_user.firstname'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame(1, $out[0]['id']);
        $this->assertSame('PERSON_1', $out[0]['firstname']);
        $this->assertSame('PERSON_2', $out[1]['firstname']);
    }

    public function test_tokenize_is_stable_per_value(): void {
        $s = new pii_scrubber();
        $rows = [
            (object) ['firstname' => 'Alice'],
            (object) ['firstname' => 'Alice'],
            (object) ['firstname' => 'Bob'],
        ];
        $map = ['firstname' => 'mdl_user.firstname'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame('PERSON_1', $out[0]['firstname']);
        $this->assertSame('PERSON_1', $out[1]['firstname']);
        $this->assertSame('PERSON_2', $out[2]['firstname']);
    }

    public function test_tokenize_redacts_derived_column(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['full' => 'Alice Smith']];
        $map = ['full' => pii_scrubber::REDACT];
        $out = $s->tokenize($rows, $map);
        $this->assertSame('REDACTED_1', $out[0]['full']);
    }

    public function test_tokenize_passes_through_nonpii_and_empty(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['id' => 5, 'firstname' => '', 'email' => null]];
        $map = ['id' => null, 'firstname' => 'mdl_user.firstname', 'email' => 'mdl_user.email'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame(5, $out[0]['id']);
        $this->assertSame('', $out[0]['firstname']);
        $this->assertNull($out[0]['email']);
    }

    public function test_detokenize_round_trip(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['firstname' => 'Alice'], (object) ['firstname' => 'Bob']];
        $s->tokenize($rows, ['firstname' => 'mdl_user.firstname']);
        $answer = 'PERSON_1 scored higher than PERSON_2.';
        $this->assertSame('Alice scored higher than Bob.', $s->detokenize($answer));
    }

    public function test_detokenize_longest_token_first(): void {
        $s = new pii_scrubber();
        $rows = [];
        for ($i = 1; $i <= 11; $i++) {
            $rows[] = (object) ['firstname' => 'Name' . $i];
        }
        $s->tokenize($rows, ['firstname' => 'mdl_user.firstname']);
        $this->assertSame('Name11 and Name1', $s->detokenize('PERSON_11 and PERSON_1'));
    }

    public function test_detokenize_noop_when_nothing_tokenised(): void {
        $s = new pii_scrubber();
        $this->assertSame('plain text', $s->detokenize('plain text'));
    }

    public function test_detokenize_no_cascade_when_value_equals_token(): void {
        $s = new pii_scrubber();
        // First real value literally spells the token that the second value will receive.
        $rows = [(object) ['firstname' => 'PERSON_2'], (object) ['firstname' => 'Bob']];
        $out = $s->tokenize($rows, ['firstname' => 'mdl_user.firstname']);
        $this->assertSame('PERSON_1', $out[0]['firstname']);
        $this->assertSame('PERSON_2', $out[1]['firstname']);
        // Simultaneous replacement: PERSON_1 -> "PERSON_2" (literal), PERSON_2 -> "Bob".
        $this->assertSame('PERSON_2 and Bob', $s->detokenize('PERSON_1 and PERSON_2'));
    }

    public function test_tokenize_handles_integer_pii_value(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['idnumber' => 12345]];
        $out = $s->tokenize($rows, ['idnumber' => 'mdl_user.idnumber']);
        $this->assertSame('ID_1', $out[0]['idnumber']);
    }
}
