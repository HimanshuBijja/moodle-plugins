<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Inject the AI analysis chat widget into the page footer.
 *
 * Legacy `before_footer` callback. Moodle 4.5 captures the returned string
 * (via \core\hook\output\before_footer_html_generation::process_legacy_callbacks())
 * and appends it to the footer before JS is finalised.
 *
 * Returns an empty string when the user lacks the `local/ai_analysis:query`
 * capability in the current page context. The capability is CONTEXT_COURSE
 * level, so it is checked against $PAGE->context (a teacher holds it inside
 * their course, not system-wide). This is a display gate only; the
 * local_ai_analysis_query external function re-checks the capability.
 *
 * @return string HTML appended to the footer, or '' if the widget is hidden.
 */
function local_ai_analysis_before_footer(): string {
    global $PAGE, $OUTPUT;

    if (!isloggedin() || isguestuser()) {
        return '';
    }

    // Read the magic context property into a variable: empty($PAGE->context)
    // is unreliable because moodle_page exposes context via __get.
    $context = $PAGE->context;
    if (!$context) {
        return '';
    }
    if (!has_capability('local/ai_analysis:query', $context)) {
        return '';
    }

    $courseid = (int) ($PAGE->course->id ?? SITEID);
    $PAGE->requires->js_call_amd('local_ai_analysis/chat_widget', 'init', [$courseid]);

    return $OUTPUT->render_from_template('local_ai_analysis/chat_widget', [
        'courseid' => $courseid,
    ]);
}
