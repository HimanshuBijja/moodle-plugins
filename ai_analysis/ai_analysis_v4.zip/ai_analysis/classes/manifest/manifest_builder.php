<?php
namespace local_ai_analysis\manifest;

defined('MOODLE_INTERNAL') || die();

/**
 * Builds the allow-list manifest of tables and columns the AI may reference.
 *
 * The same manifest array is fed to (a) the AI prompt builder so the model
 * knows what it may reference, and (b) the SQL validator so it can reject
 * any SQL that strays outside the allow-list. Single source of truth.
 */
class manifest_builder {

    /** @var array<string, string[]> Hardcoded — never derived from the live DB. */
    private static array $FULL_MANIFEST = [
        'mdl_user'                  => ['id', 'firstname', 'lastname', 'city', 'department', 'timecreated'],
        'mdl_course'                => ['id', 'fullname', 'shortname', 'summary', 'startdate', 'visible'],
        'mdl_grade_grades'          => ['userid', 'itemid', 'finalgrade', 'timemodified'],
        'mdl_grade_items'           => ['id', 'courseid', 'itemname', 'itemtype', 'grademax'],
        'mdl_course_modules'        => ['id', 'course', 'module', 'completion'],
        'mdl_enrol'                 => ['id', 'courseid', 'enrol', 'status'],
        'mdl_user_enrolments'       => ['id', 'userid', 'enrolid', 'status'],
        'mdl_logstore_standard_log' => ['userid', 'courseid', 'eventname', 'timecreated'],
    ];

    /**
     * Returns a manifest array. For non-admin roles with courseid > 0, the
     * returned mdl_user and mdl_logstore_standard_log entries gain a
     * string-valued '_scope_note' key alongside their column list. The static
     * $FULL_MANIFEST itself is never mutated (PHP copies the array by value).
     *
     * @return array<string, mixed>
     */
    public static function build(string $role, int $courseid): array {
        $manifest = self::$FULL_MANIFEST;

        if ($role !== 'admin' && $courseid > 0) {
            $manifest['mdl_user']['_scope_note'] =
                'Only users enrolled in course ' . $courseid;
            $manifest['mdl_logstore_standard_log']['_scope_note'] =
                'Always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_course']['_scope_note'] =
                'The current course is id ' . $courseid . '; filter WHERE id = ' . $courseid;
            $manifest['mdl_grade_items']['_scope_note'] =
                'Grades link to a course only through this table; always filter WHERE courseid = ' . $courseid
                . ' (itemtype = \'course\' is the course total)';
            $manifest['mdl_enrol']['_scope_note'] =
                'Always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_user_enrolments']['_scope_note'] =
                'Join to mdl_enrol via enrolid to scope to course ' . $courseid
                . '; status 0 = active, 1 = suspended';
        }
        return $manifest;
    }
}
