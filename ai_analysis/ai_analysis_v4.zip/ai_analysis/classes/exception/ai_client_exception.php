<?php
namespace local_ai_analysis\exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Thrown by ai_client implementations when the AI returns an unparseable
 * response or a non-2xx HTTP status. Carries a machine-readable reason and
 * a truncated body excerpt for audit logging.
 */
class ai_client_exception extends \moodle_exception {

    /** @var string Machine-readable reason code (e.g. "HTTP_429", "PARSE_FAILED"). */
    public string $reason;

    /** @var string First 500 chars of the AI response body. */
    public string $body_excerpt;

    public function __construct(string $reason, string $body = '') {
        $this->reason = $reason;
        $this->body_excerpt = substr($body, 0, 500);
        parent::__construct('aiclienterror', 'local_ai_analysis', '', $reason);
    }
}
