<?php
namespace local_ai_analysis\exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Thrown by sql_validator when a SQL string fails any validation rule.
 * Carries a machine-readable reason code (e.g. "TABLE_NOT_ALLOWED:mdl_config")
 * plus a truncated excerpt of the offending SQL for audit logging.
 */
class validation_exception extends \moodle_exception {

    /** @var string Machine-readable reason code. */
    public string $reason;

    /** @var string First 500 chars of the SQL that was rejected. */
    public string $sql_excerpt;

    public function __construct(string $reason, string $sql) {
        $this->reason      = $reason;
        $this->sql_excerpt = substr($sql, 0, 500);
        parent::__construct('validation_failed', 'local_ai_analysis', '', $reason);
    }
}
