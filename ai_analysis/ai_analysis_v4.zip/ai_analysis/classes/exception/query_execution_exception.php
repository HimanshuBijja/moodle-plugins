<?php
namespace local_ai_analysis\exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Thrown by query_executor when the read-only DB connection rejects a
 * validated query (rare — should only happen on permission misconfiguration
 * or transient DB failure, since the SQL has already passed validation).
 */
class query_execution_exception extends \moodle_exception {

    public function __construct(string $reason) {
        parent::__construct('queryfailed', 'local_ai_analysis', '', $reason);
    }
}
