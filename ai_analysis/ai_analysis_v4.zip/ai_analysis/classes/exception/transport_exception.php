<?php
namespace local_ai_analysis\exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Thrown by http_transport implementations on connection failure, DNS error,
 * SSL error, or timeout. Wraps the underlying message for audit logging.
 */
class transport_exception extends \moodle_exception {

    public function __construct(string $reason) {
        parent::__construct('aitransporterror', 'local_ai_analysis', '', $reason);
    }
}
