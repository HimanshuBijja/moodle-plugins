<?php
namespace local_ai_analysis\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use context;
use context_system;

class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_ai_analysis_audit', [
            'userid'           => 'privacy:metadata:audit:userid',
            'courseid'         => 'privacy:metadata:audit:courseid',
            'timecreated'      => 'privacy:metadata:audit:timecreated',
            'prompt_hash'      => 'privacy:metadata:audit:prompt_hash',
            'prompt_length'    => 'privacy:metadata:audit:prompt_length',
            'prompt_encrypted' => 'privacy:metadata:audit:prompt_encrypted',
            'sql_executed'     => 'privacy:metadata:audit:sql_executed',
            'row_count'        => 'privacy:metadata:audit:row_count',
            'status'           => 'privacy:metadata:audit:status',
            'provider'         => 'privacy:metadata:audit:provider',
            'duration_ms'      => 'privacy:metadata:audit:duration_ms',
            'useragent'        => 'privacy:metadata:audit:useragent',
            'block_reason'     => 'privacy:metadata:audit:block_reason',
        ], 'privacy:metadata:audit');
        return $collection;
    }

    public static function get_contexts_for_userid(int $userid): contextlist {
        global $DB;
        $contextlist = new contextlist();
        if ($DB->record_exists('local_ai_analysis_audit', ['userid' => $userid])) {
            $contextlist->add_system_context();
        }
        return $contextlist;
    }

    public static function get_users_in_context(userlist $userlist): void {
        if (!$userlist->get_context() instanceof context_system) {
            return;
        }
        $userlist->add_from_sql('userid', 'SELECT userid FROM {local_ai_analysis_audit}', []);
    }

    public static function export_user_data(approved_contextlist $contextlist): void {
        global $DB;
        foreach ($contextlist->get_contexts() as $context) {
            if (!$context instanceof context_system) {
                continue;
            }
            $rows = $DB->get_records('local_ai_analysis_audit',
                ['userid' => $contextlist->get_user()->id], 'timecreated ASC');
            $data = array_map(static function($r) {
                return [
                    'timecreated'   => userdate($r->timecreated),
                    'courseid'      => $r->courseid,
                    'status'        => $r->status,
                    'provider'      => $r->provider,
                    'prompt_length' => $r->prompt_length,
                    'row_count'     => $r->row_count,
                    'sql_executed'  => $r->sql_executed,
                    'block_reason'  => $r->block_reason,
                ];
            }, array_values($rows));
            if ($data) {
                writer::with_context($context)->export_data(
                    [get_string('privacy:path:audit', 'local_ai_analysis')],
                    (object) ['records' => $data]
                );
            }
        }
    }

    public static function delete_data_for_all_users_in_context(context $context): void {
        global $DB;
        if ($context instanceof context_system) {
            $DB->delete_records('local_ai_analysis_audit');
        }
    }

    public static function delete_data_for_user(approved_contextlist $contextlist): void {
        global $DB;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context instanceof context_system) {
                $DB->delete_records('local_ai_analysis_audit',
                    ['userid' => $contextlist->get_user()->id]);
            }
        }
    }

    public static function delete_data_for_users(approved_userlist $userlist): void {
        global $DB;
        if (!$userlist->get_context() instanceof context_system) {
            return;
        }
        [$insql, $params] = $DB->get_in_or_equal($userlist->get_userids(), SQL_PARAMS_NAMED);
        $DB->delete_records_select('local_ai_analysis_audit', "userid $insql", $params);
    }
}
