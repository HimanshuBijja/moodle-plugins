<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Ollama client (self-hosted, no API key).
 *
 * Ollama exposes an OpenAI-compatible Chat Completions API at
 * {base_url}/v1/chat/completions, so this reuses openai_client's payload
 * building, text extraction, JSON parsing and HTTP error handling wholesale.
 * Only three things differ: the base URL is configurable (the server is
 * self-hosted, location varies), no Authorization header is sent (Ollama has
 * no auth), and the default model is a local one.
 */
class ollama_client extends openai_client {

    protected const DEFAULT_MODEL = 'qwen2.5-coder';
    private const DEFAULT_BASE_URL = 'http://localhost:11434';

    private string $base_url;

    public function __construct(
        http_transport_interface $transport,
        string $base_url = '',
        string $model = '',
        int $timeout = 30,
    ) {
        parent::__construct($transport, '', $model, $timeout);
        $this->base_url = $base_url !== '' ? rtrim($base_url, '/') : self::DEFAULT_BASE_URL;
    }

    protected function endpoint(): string {
        return $this->base_url . '/v1/chat/completions';
    }

    protected function auth_headers(): array {
        return ['content-type: application/json'];
    }
}
