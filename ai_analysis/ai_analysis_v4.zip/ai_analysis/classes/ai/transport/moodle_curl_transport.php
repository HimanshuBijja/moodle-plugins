<?php
namespace local_ai_analysis\ai\transport;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\transport_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Wraps Moodle's \curl class (lib/filelib.php) so we respect site proxy
 * configuration and Moodle's SSL defaults.
 */
class moodle_curl_transport implements http_transport_interface {

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl();
        $curl->setHeader($headers);
        $curl->setopt([
            'CURLOPT_TIMEOUT'        => $timeout,
            'CURLOPT_CONNECTTIMEOUT' => min($timeout, 10),
            'CURLOPT_FOLLOWLOCATION' => false,
            'CURLOPT_RETURNTRANSFER' => true,
        ]);

        $response_body = $curl->post($url, $body);
        $info          = $curl->get_info();
        $errno         = $curl->get_errno();

        if ($errno !== 0 || $response_body === false) {
            throw new transport_exception(sprintf(
                'curl errno=%d, error=%s',
                $errno,
                $curl->error ?? 'unknown'
            ));
        }

        return [
            'status'  => (int) ($info['http_code'] ?? 0),
            'headers' => [], // Moodle's \curl does not expose response headers by default; not needed by claude_client.
            'body'    => (string) $response_body,
        ];
    }
}
