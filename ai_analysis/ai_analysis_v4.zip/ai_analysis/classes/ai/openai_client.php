<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * OpenAI Chat Completions client. Uses response_format json_object for SQL
 * generation (forces valid JSON); prose mode for formatting.
 */
class openai_client extends base_http_ai_client {

    protected const DEFAULT_MODEL = 'gpt-4o';
    private const ENDPOINT = 'https://api.openai.com/v1/chat/completions';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::ENDPOINT;
    }

    protected function auth_headers(): array {
        return [
            'Authorization: Bearer ' . $this->api_key,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'model'           => $this->model(),
            'max_tokens'      => self::MAX_TOKENS_SQL,
            'response_format' => ['type' => 'json_object'],
            'messages'        => [
                ['role' => 'system', 'content' => $system_prompt],
                ['role' => 'user',   'content' => $user_prompt],
            ],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_FORMAT,
            'messages'   => [
                ['role' => 'system', 'content' => prompt_builder::build_format_system()],
                ['role' => 'user',   'content' => json_encode(['question' => $user_prompt, 'rows' => $safe_rows])],
            ],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['choices'][0]['message']['content'] ?? null;
        return is_string($t) ? $t : '';
    }
}
