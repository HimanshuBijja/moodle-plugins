<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Contract for AI providers (Claude in Sprint 2; OpenAI/Gemini/Ollama in
 * Sprint 3). Sprint 3 will add a second method format_result(); adding a
 * method to an interface implemented only inside this plugin is a contained
 * change.
 */
interface ai_client_interface {

    /**
     * Ask the AI to translate a natural-language prompt into validated SQL.
     *
     * @return array Either
     *   ['type' => 'sql', 'sql' => string, 'params' => array, 'explanation' => string]
     *   ['type' => 'out_of_scope', 'message' => string]
     * @throws \local_ai_analysis\exception\ai_client_exception on transport or parse failure.
     */
    public function generate_sql(string $system_prompt, string $user_prompt): array;

    /**
     * Summarise already-PII-scrubbed result rows into a plain-language answer.
     *
     * @param string $user_prompt The educator's original question (for intent).
     * @param array  $safe_rows   Tokenised rows — contains no real PII.
     * @return string             Plain-text answer that may contain tokens verbatim.
     * @throws \local_ai_analysis\exception\ai_client_exception
     */
    public function format_result(string $user_prompt, array $safe_rows): string;
}
