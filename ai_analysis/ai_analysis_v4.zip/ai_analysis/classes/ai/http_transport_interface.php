<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Narrow contract for AI client HTTP calls. Implementations wrap whatever
 * HTTP client the environment provides; tests inject a fake that returns
 * canned responses without touching the network.
 */
interface http_transport_interface {

    /**
     * Send a POST request and return the raw response.
     *
     * @param string $url
     * @param array  $headers Indexed list of "Name: Value" strings.
     * @param string $body    Request body, already serialised (e.g. JSON).
     * @param int    $timeout Seconds. Default 30.
     * @return array ['status' => int, 'headers' => array, 'body' => string]
     * @throws \local_ai_analysis\exception\transport_exception
     */
    public function post(string $url, array $headers, string $body, int $timeout = 30): array;
}
