<?php
namespace local_ai_analysis\db;

use local_ai_analysis\exception\query_execution_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Executes validated SELECT statements against a separate, read-only
 * moodle_database connection. Tests inject the global $DB; production
 * leaves the constructor argument null so the executor lazily opens a
 * readonly driver instance using $CFG->ai_analysis_db{user,pass}.
 */
class query_executor {

    private ?\moodle_database $db;

    public function __construct(?\moodle_database $db = null) {
        $this->db = $db;
    }

    public function run(string $validated_sql, array $params): array {
        $db = $this->db ?? $this->open_readonly_connection();
        try {
            $records = $db->get_records_sql($validated_sql, $params);
        } catch (\dml_exception $e) {
            throw new query_execution_exception($e->getMessage());
        }
        return array_values((array) $records);
    }

    private function open_readonly_connection(): \moodle_database {
        global $CFG;
        $user = $CFG->ai_analysis_dbuser ?? null;
        $pass = $CFG->ai_analysis_dbpass ?? null;
        if (!$user || $pass === null) {
            throw new query_execution_exception(
                'ai_analysis_dbuser / ai_analysis_dbpass not configured (see INSTALL.md)'
            );
        }
        $driver = \moodle_database::get_driver_instance($CFG->dbtype, 'native');
        $driver->connect($CFG->dbhost, $user, $pass, $CFG->dbname, $CFG->prefix);
        return $driver;
    }
}
