<?php
namespace local_ai_analysis\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Deletes audit rows older than the configured retention window.
 * retentiondays <= 0 disables purging (keep forever).
 */
class purge_audit_task extends \core\task\scheduled_task {

    public function get_name(): string {
        return get_string('task_purge_audit', 'local_ai_analysis');
    }

    public function execute(): void {
        global $DB;
        $days = (int) get_config('local_ai_analysis', 'retentiondays');
        if ($days <= 0) {
            mtrace('local_ai_analysis: audit retention disabled (retentiondays <= 0).');
            return;
        }
        $cutoff = time() - ($days * DAYSECS);
        $before = $DB->count_records_select('local_ai_analysis_audit', 'timecreated < ?', [$cutoff]);
        $DB->delete_records_select('local_ai_analysis_audit', 'timecreated < ?', [$cutoff]);
        mtrace("local_ai_analysis: purged {$before} audit rows older than {$days} days.");
    }
}
