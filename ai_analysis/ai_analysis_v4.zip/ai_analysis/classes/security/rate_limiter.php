<?php
namespace local_ai_analysis\security;

defined('MOODLE_INTERNAL') || die();

/**
 * Per-user token bucket. Stored in cache_application so it survives logout
 * and is shared across PHP workers. Admins (passed $is_admin=true by the
 * gateway after a moodle/site:config capability check) bypass entirely.
 */
class rate_limiter {

    public function consume(int $userid, bool $is_admin): bool {
        if ($is_admin) {
            return true;
        }
        $capacity = self::capacity();
        $cache = \cache::make('local_ai_analysis', 'ratelimit');
        $key = 'user_' . $userid;
        $bucket = $cache->get($key);
        if ($bucket === false || !is_array($bucket)) {
            $bucket = ['tokens' => $capacity, 'last' => time()];
        }
        // Refill: 1 token per 60s, up to capacity.
        $elapsed = time() - (int) $bucket['last'];
        if ($elapsed > 0) {
            $refill = intdiv($elapsed, 60);
            $bucket['tokens'] = min($capacity, (int) $bucket['tokens'] + $refill);
            $bucket['last']   = (int) $bucket['last'] + ($refill * 60);
        }
        if ((int) $bucket['tokens'] < 1) {
            $cache->set($key, $bucket);
            return false;
        }
        $bucket['tokens'] = (int) $bucket['tokens'] - 1;
        $cache->set($key, $bucket);
        return true;
    }

    private static function capacity(): int {
        $configured = (int) get_config('local_ai_analysis', 'rate_limit_per_min');
        return $configured > 0 ? $configured : 10;
    }
}
