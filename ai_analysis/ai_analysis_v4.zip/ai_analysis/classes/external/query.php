<?php
namespace local_ai_analysis\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;

use local_ai_analysis\ai\ai_client_factory;
use local_ai_analysis\ai\prompt_builder;
use local_ai_analysis\audit\audit_writer;
use local_ai_analysis\db\query_executor;
use local_ai_analysis\exception\ai_client_exception;
use local_ai_analysis\exception\query_execution_exception;
use local_ai_analysis\exception\transport_exception;
use local_ai_analysis\exception\validation_exception;
use local_ai_analysis\manifest\manifest_builder;
use local_ai_analysis\security\rate_limiter;
use local_ai_analysis\security\sql_validator;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../vendor/autoload.php');

/**
 * AJAX gateway: orchestrates the full pipeline from sanitised prompt to
 * validated query result. Writes an audit row on every code path including
 * the catch-all. Returns a well-typed envelope to the AJAX layer rather
 * than throwing, except for capability denials (Moodle's external API
 * translates required_capability_exception to a structured error itself).
 */
class query extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'prompt'     => new external_value(PARAM_TEXT, 'User prompt', VALUE_REQUIRED),
            'courseid'   => new external_value(PARAM_INT, 'Course context (0 = system)', VALUE_DEFAULT, 0),
            'request_id' => new external_value(PARAM_ALPHANUMEXT, 'Client-supplied request id for race tracking', VALUE_REQUIRED),
            'format'     => new external_value(PARAM_BOOL, 'Run the AI formatting pass (layer 7)', VALUE_DEFAULT, false),
        ]);
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'request_id' => new external_value(PARAM_ALPHANUMEXT, 'Echoed back from request'),
            'userid'     => new external_value(PARAM_INT, 'Acting user id'),
            'courseid'   => new external_value(PARAM_INT, 'Course context'),
            'status'     => new external_value(PARAM_ALPHANUMEXT, 'SUCCESS or an error code'),
            'sql'        => new external_value(PARAM_RAW, 'Validated SQL when SUCCESS', VALUE_DEFAULT, ''),
            'params'     => new external_multiple_structure(
                new external_value(PARAM_RAW, 'Bound parameter value'),
                'Bound parameters',
                VALUE_DEFAULT,
                []
            ),
            'row_count'  => new external_value(PARAM_INT, 'Number of rows', VALUE_DEFAULT, 0),
            'rows'       => new external_multiple_structure(
                new external_value(PARAM_RAW, 'Row as JSON-encoded string'),
                'Result rows (each row JSON-encoded to keep external_api happy)',
                VALUE_DEFAULT,
                []
            ),
            'answer'     => new external_value(PARAM_RAW, 'Natural-language answer when format=true', VALUE_DEFAULT, ''),
            'format_note' => new external_value(PARAM_TEXT, 'Soft note when formatting falls back', VALUE_DEFAULT, ''),
            'error'      => new external_value(PARAM_TEXT, 'Human-readable error message; empty on SUCCESS', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(string $prompt, int $courseid, string $request_id, bool $format = false): array {
        global $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'prompt' => $prompt, 'courseid' => $courseid, 'request_id' => $request_id, 'format' => $format,
        ]);
        $prompt     = $params['prompt'];
        $courseid   = (int) $params['courseid'];
        $request_id = $params['request_id'];
        $format     = (bool) $params['format'];

        $start = microtime(true);

        // L2: auth + caps + courseid validation.
        if ($courseid > 0) {
            $course = get_course($courseid);
            $context = \context_course::instance($course->id);
        } else {
            $context = \context_system::instance();
        }
        self::validate_context($context);
        require_capability('local/ai_analysis:query', $context);
        if ($courseid === 0) {
            require_capability('local/ai_analysis:queryglobal', $context);
        }

        $is_admin = has_capability('moodle/site:config', \context_system::instance());
        $role = $is_admin ? 'admin' : 'editingteacher';

        // L2: input sanitisation. Catch + audit + return envelope (do not throw to the AJAX layer).
        try {
            $prompt = prompt_builder::sanitise_user_prompt($prompt);
        } catch (\moodle_exception $e) {
            $reason = $e->a ? (string) $e->a : $e->errorcode;
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'BLOCKED_INJECTION', reason: $reason,
                provider: '', row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'BLOCKED_INJECTION', $reason);
        }

        // L2: rate limit.
        $rl = new rate_limiter();
        if (!$rl->consume((int) $USER->id, $is_admin)) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'RATE_LIMITED', reason: '', provider: '',
                row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'RATE_LIMITED', get_string('ratelimited', 'local_ai_analysis'));
        }

        // L3: manifest + system prompt.
        $manifest = manifest_builder::build($role, $courseid);
        $system   = prompt_builder::build_system($manifest, $role, $courseid, time());

        // L4: AI call.
        $provider = get_config('local_ai_analysis', 'provider') ?: 'claude';
        try {
            $ai = ai_client_factory::make()->generate_sql($system, $prompt);
        } catch (ai_client_exception $e) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'AI_INVALID_JSON', reason: $e->reason,
                provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'AI_INVALID_JSON', $e->reason);
        } catch (transport_exception $e) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'AI_TRANSPORT_ERROR', reason: $e->getMessage(),
                provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'AI_TRANSPORT_ERROR', $e->getMessage());
        }

        if ($ai['type'] === 'out_of_scope') {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'OUT_OF_SCOPE', reason: $ai['message'] ?? '',
                provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'OUT_OF_SCOPE', $ai['message'] ?? '');
        }

        $sql = (string) $ai['sql'];
        $bound_params = (array) $ai['params'];

        // L5: validate.
        $validator = new sql_validator($manifest);
        try {
            $validator->validate($sql, $bound_params);
        } catch (validation_exception $e) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: $sql, status: 'SQL_INVALID', reason: $e->reason,
                provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'SQL_INVALID', $e->reason);
        }

        // L6: execute. In tests we have no $CFG->ai_analysis_db* — fall back to global $DB.
        // Translate the canonical mdl_ prefix to the runtime prefix (differs in PHPUnit test runs).
        $exec_sql = self::translate_prefix($sql);
        global $DB;
        $executor = self::build_executor($DB);
        try {
            $rows = $executor->run($exec_sql, $bound_params);
        } catch (query_execution_exception $e) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: $sql, status: 'QUERY_FAILED', reason: $e->getMessage(),
                provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'QUERY_FAILED', $e->getMessage());
        }

        $row_count = count($rows);

        $answer = '';
        $format_note = '';
        if ($format) {
            try {
                $classified = \local_ai_analysis\security\pii_scrubber::classify_columns(
                    $validator->get_column_source_map(),
                    $validator->get_column_references()
                );
                $scrubber  = new \local_ai_analysis\security\pii_scrubber();
                $safe_rows = $scrubber->tokenize($rows, $classified);
                $tokanswer = ai_client_factory::make()->format_result($prompt, $safe_rows);
                $answer    = $scrubber->detokenize($tokanswer);
            } catch (ai_client_exception | transport_exception $e) {
                $answer = '';
                $format_note = get_string('formatunavailable', 'local_ai_analysis');
                debugging('format_result failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            }
        }

        audit_writer::write(
            userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
            sql: $sql, status: 'SUCCESS', reason: '',
            provider: $provider, row_count: $row_count, duration_ms: self::elapsed_ms($start),
        );

        return [
            'request_id' => $request_id,
            'userid'     => (int) $USER->id,
            'courseid'   => $courseid,
            'status'     => 'SUCCESS',
            'sql'        => $sql,
            'params'     => array_map(fn($p) => (string) $p, $bound_params),
            'row_count'  => $row_count,
            'rows'       => array_map(fn($r) => json_encode($r), $rows),
            'answer'      => $answer,
            'format_note' => $format_note,
            'error'      => '',
        ];
    }

    /**
     * Translates the canonical mdl_ table prefix to the runtime DB prefix.
     * This is a no-op in production (where $CFG->prefix === 'mdl_') but is
     * essential during PHPUnit runs where the prefix is 'phpu_'.
     */
    private static function translate_prefix(string $sql): string {
        global $CFG;
        $runtime_prefix = $CFG->prefix ?? 'mdl_';
        if ($runtime_prefix === 'mdl_') {
            return $sql;
        }
        return str_replace('mdl_', $runtime_prefix, $sql);
    }

    private static function build_executor(\moodle_database $db_for_tests): query_executor {
        global $CFG;
        if (empty($CFG->ai_analysis_dbuser) || empty($CFG->ai_analysis_dbpass)) {
            return new query_executor($db_for_tests);
        }
        return new query_executor();
    }

    private static function elapsed_ms(float $start): int {
        return (int) round((microtime(true) - $start) * 1000);
    }

    private static function error_envelope(string $request_id, int $userid, int $courseid, string $status, string $error): array {
        return [
            'request_id' => $request_id,
            'userid'     => $userid,
            'courseid'   => $courseid,
            'status'     => $status,
            'sql'        => '',
            'params'     => [],
            'row_count'  => 0,
            'rows'       => [],
            'answer'      => '',
            'format_note' => '',
            'error'      => $error,
        ];
    }
}
