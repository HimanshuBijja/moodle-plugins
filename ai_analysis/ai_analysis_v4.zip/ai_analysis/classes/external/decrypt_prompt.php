<?php
namespace local_ai_analysis\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

use local_ai_analysis\audit\audit_crypto;
use local_ai_analysis\audit\audit_writer;

defined('MOODLE_INTERNAL') || die();

/**
 * Reveal (decrypt) a stored audit prompt. Capability + sesskey gated by the
 * AJAX layer. Every successful reveal writes its own PROMPT_REVEALED audit row.
 */
class decrypt_prompt extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'id' => new external_value(PARAM_INT, 'Audit row id to reveal'),
        ]);
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'status' => new external_value(PARAM_ALPHANUMEXT, 'SUCCESS, NOT_FOUND or DECRYPT_FAILED'),
            'prompt' => new external_value(PARAM_RAW, 'Decrypted prompt, empty unless SUCCESS'),
        ]);
    }

    public static function execute(int $id): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), ['id' => $id]);
        $context = \context_system::instance();
        self::validate_context($context);
        require_capability('local/ai_analysis:decryptprompt', $context);

        $row = $DB->get_record('local_ai_analysis_audit', ['id' => $params['id']]);
        if (!$row || $row->prompt_encrypted === null || $row->prompt_encrypted === '') {
            return ['status' => 'NOT_FOUND', 'prompt' => ''];
        }

        $plain = audit_crypto::decrypt($row->prompt_encrypted);
        if ($plain === null) {
            return ['status' => 'DECRYPT_FAILED', 'prompt' => ''];
        }

        audit_writer::write(
            (int) $USER->id, 0, 'reveal', null,
            'PROMPT_REVEALED', 'revealed audit id ' . $params['id']
        );

        return ['status' => 'SUCCESS', 'prompt' => $plain];
    }
}
