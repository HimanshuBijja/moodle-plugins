<?php
namespace local_ai_analysis\audit;

defined('MOODLE_INTERNAL') || die();

/**
 * Always-on audit writer. Catches all its own exceptions so any caller —
 * including error paths — can audit without nested try/catch.
 */
class audit_writer {

    public static function write(
        int $userid,
        int $courseid,
        string $prompt,
        ?string $sql,
        string $status,
        string $reason = '',
        string $provider = '',
        ?int $row_count = null,
        ?int $duration_ms = null
    ): void {
        global $DB;

        try {
            $encrypted = audit_crypto::encrypt($prompt);

            $DB->insert_record('local_ai_analysis_audit', (object)[
                'userid'            => $userid,
                'courseid'          => $courseid,
                'timecreated'       => time(),
                'prompt_hash'       => hash('sha256', $prompt),
                'prompt_length'     => strlen($prompt),
                'prompt_encrypted'  => $encrypted,
                'sql_executed'      => $sql !== null ? substr($sql, 0, 2000) : null,
                'row_count'         => $row_count,
                'status'            => substr($status, 0, 40),
                'block_reason'      => substr($reason, 0, 120),
                'provider'          => substr($provider, 0, 20),
                'duration_ms'       => $duration_ms,
                'useragent'         => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            ]);
        } catch (\Throwable $e) {
            debugging(
                'local_ai_analysis audit write failed: ' . $e->getMessage(),
                DEBUG_DEVELOPER
            );
        }
    }

}
