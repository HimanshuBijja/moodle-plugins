<?php
namespace local_ai_analysis\audit;

defined('MOODLE_INTERNAL') || die();

/**
 * Shared AES-256-CBC helper for audit prompts. Single source of the cipher so
 * audit_writer (encrypt) and decrypt_prompt (decrypt) cannot drift. Storage
 * format: base64(iv) . '::' . base64(ciphertext). Never throws.
 */
class audit_crypto {

    /** Encrypt a prompt for storage, or null if no usable key / failure. */
    public static function encrypt(string $plain): ?string {
        global $CFG;
        $key = self::normalize_key($CFG->ai_analysis_audit_key ?? '');
        if ($key === null) {
            return null;
        }
        $iv = openssl_random_pseudo_bytes(16);
        $ct = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($ct === false) {
            return null;
        }
        return base64_encode($iv) . '::' . base64_encode($ct);
    }

    /** Decrypt stored ciphertext back to plaintext, or null on any problem. */
    public static function decrypt(string $stored): ?string {
        global $CFG;
        $key = self::normalize_key($CFG->ai_analysis_audit_key ?? '');
        if ($key === null) {
            return null;
        }
        $parts = explode('::', $stored, 2);
        if (count($parts) !== 2) {
            return null;
        }
        $iv = base64_decode($parts[0], true);
        $ct = base64_decode($parts[1], true);
        if ($iv === false || $ct === false || strlen($iv) !== 16) {
            return null;
        }
        $pt = openssl_decrypt($ct, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        return $pt === false ? null : $pt;
    }

    /**
     * Accept the key as 32 raw bytes or 64 hex digits; return 32 raw bytes or
     * null (logged via debugging) if empty / wrong size / wrong format.
     */
    public static function normalize_key(string $raw): ?string {
        if ($raw === '') {
            return null;
        }
        if (strlen($raw) === 32) {
            return $raw;
        }
        if (strlen($raw) === 64 && ctype_xdigit($raw)) {
            return hex2bin($raw);
        }
        debugging(
            'local_ai_analysis_audit_key must be 32 raw bytes or 64 hex digits; '
            . 'got ' . strlen($raw) . ' chars. Prompt will not be encrypted.',
            DEBUG_DEVELOPER
        );
        return null;
    }
}
