<?php
namespace local_ai_analysis\report;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/tablelib.php');

/**
 * Audit log report table. Sortable, paginated, downloadable. The reveal action
 * column appears only for users with the decryptprompt capability.
 */
class audit_table extends \table_sql {

    public function __construct(string $uniqueid, array $filters = []) {
        parent::__construct($uniqueid);

        $columns = ['timecreated', 'userid', 'courseid', 'status', 'provider',
            'prompt_length', 'row_count', 'duration_ms', 'sql_executed'];
        $headers = [
            get_string('col_time', 'local_ai_analysis'),
            get_string('col_user', 'local_ai_analysis'),
            get_string('col_course', 'local_ai_analysis'),
            get_string('col_status', 'local_ai_analysis'),
            get_string('col_provider', 'local_ai_analysis'),
            get_string('col_promptlen', 'local_ai_analysis'),
            get_string('col_rows', 'local_ai_analysis'),
            get_string('col_duration', 'local_ai_analysis'),
            get_string('col_sql', 'local_ai_analysis'),
        ];

        $candecrypt = has_capability('local/ai_analysis:decryptprompt',
            \context_system::instance());
        if ($candecrypt && !$this->is_downloading()) {
            $columns[] = 'actions';
            $headers[] = get_string('col_actions', 'local_ai_analysis');
        }

        $this->define_columns($columns);
        $this->define_headers($headers);
        $this->sortable(true, 'timecreated', SORT_DESC);
        $this->no_sorting('actions');
        $this->no_sorting('sql_executed');
        $this->collapsible(false);

        [$where, $params] = self::build_filter($filters);
        $this->set_sql('id, userid, courseid, timecreated, status, provider, '
            . 'prompt_length, row_count, duration_ms, sql_executed, prompt_encrypted',
            '{local_ai_analysis_audit}', $where, $params);
    }

    /** Build WHERE + named params from optional filters. */
    public static function build_filter(array $filters): array {
        $clauses = [];
        $params = [];
        if (!empty($filters['userid'])) {
            $clauses[] = 'userid = :userid';
            $params['userid'] = (int) $filters['userid'];
        }
        if (!empty($filters['courseid'])) {
            $clauses[] = 'courseid = :courseid';
            $params['courseid'] = (int) $filters['courseid'];
        }
        if (!empty($filters['status'])) {
            $clauses[] = 'status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['datefrom'])) {
            $clauses[] = 'timecreated >= :datefrom';
            $params['datefrom'] = (int) $filters['datefrom'];
        }
        if (!empty($filters['dateto'])) {
            $clauses[] = 'timecreated <= :dateto';
            $params['dateto'] = (int) $filters['dateto'];
        }
        return [$clauses ? implode(' AND ', $clauses) : '1=1', $params];
    }

    public function col_timecreated($row) {
        return userdate($row->timecreated);
    }

    public function col_userid($row) {
        if ($this->is_downloading()) {
            return $row->userid;
        }
        $user = \core_user::get_user($row->userid);
        $name = $user ? fullname($user) : ('user ' . $row->userid);
        $url = new \moodle_url('/user/profile.php', ['id' => $row->userid]);
        return \html_writer::link($url, $name);
    }

    public function col_courseid($row) {
        return $row->courseid ? $row->courseid : '-';
    }

    public function col_sql_executed($row) {
        return $row->sql_executed ? shorten_text(s($row->sql_executed), 120) : '';
    }

    public function col_actions($row) {
        if (empty($row->prompt_encrypted)) {
            return '';
        }
        return \html_writer::tag('button', get_string('reveal_prompt', 'local_ai_analysis'), [
            'type' => 'button',
            'class' => 'btn btn-link btn-sm local-ai-reveal',
            'data-audit-id' => $row->id,
        ]);
    }
}
