-- Run as root against the Moodle database.
-- Idempotent: safe to re-run.

CREATE USER IF NOT EXISTS 'moodle_ai_ro'@'%' IDENTIFIED BY 'REPLACE_WITH_STRONG_PASSWORD';

GRANT SELECT ON moodle.mdl_user                  TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_course                TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_grade_grades          TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_grade_items           TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_course_modules        TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_enrol                 TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_user_enrolments       TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_logstore_standard_log TO 'moodle_ai_ro'@'%';

-- Explicitly NO grants on mdl_config, mdl_user_password_resets, mdl_sessions.
-- Add new allow-listed tables here as later sprints expand the manifest.

FLUSH PRIVILEGES;
