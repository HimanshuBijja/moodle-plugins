<?php
defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_ai_analysis_query' => [
        'classname'   => 'local_ai_analysis\\external\\query',
        'methodname'  => 'execute',
        'description' => 'Translate a natural-language prompt to validated SQL and return the result rows.',
        'type'        => 'read',
        'ajax'        => true,
        'loginrequired' => true,
    ],
    'local_ai_analysis_decrypt_prompt' => [
        'classname'     => 'local_ai_analysis\\external\\decrypt_prompt',
        'methodname'    => 'execute',
        'description'   => 'Decrypt and return a stored audit prompt (admin only).',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/ai_analysis:decryptprompt',
    ],
];
