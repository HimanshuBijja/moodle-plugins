<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_ai_analysis_upgrade(int $oldversion): bool {
    // No upgrades yet — install.xml is the source of truth in Sprint 1.
    return true;
}
