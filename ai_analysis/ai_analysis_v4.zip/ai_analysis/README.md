# local_ai_analysis

Moodle 4.5 local plugin that embeds an AI chatbot for natural-language queries against student data.

## Status

**Sprint 1 — Security Foundation (in progress).** No AI calls, no chatbot UI yet. This sprint ships the SQL validator, schema manifest builder, audit log, and capabilities. See `docs/superpowers/specs/` for the full design.

## Installation

After cloning into `moodle/local/ai_analysis/`:

1. Visit *Site administration → Notifications* to install the plugin database schema.
2. Follow `INSTALL.md` to create the read-only DB user and add encryption keys to `config.php`.
3. Verify capabilities under *Site administration → Users → Permissions → Define roles*.
