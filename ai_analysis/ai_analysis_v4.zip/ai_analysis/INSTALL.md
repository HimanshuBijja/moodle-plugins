# local_ai_analysis — Installation

A natural-language-to-SQL chatbot for Moodle 4.5+ / PHP 8.1+ / MariaDB 10.11.

Beyond the standard plugin install, this plugin needs: a read-only DB user, three
`config.php` entries, and an AI provider key. Full checklist below.

> **Conventions.** Commands below use this repo's docker naming (`moodle-web-8092`,
> `moodle-db-8092`, DB `moodle`, prefix `mdl_`, root password `rootpass`). Replace
> them with the target instance's container names, DB name, prefix, and credentials.

## Requirements at a glance

| # | Step | Purpose |
|---|------|---------|
| 1 | Copy plugin code | dependency (`php-sql-parser`) is bundled in `vendor/` — no composer |
| 2 | Notifications upgrade | audit table, capabilities, services, cache, cron task |
| 3 | Read-only DB user | DML/DDL fails at the server even if PHP validation is bypassed |
| 4 | `config.php` entries | RO DB credentials + audit encryption key |
| 5 | AI provider settings | the actual AI call (provider + key + model) |
| 6 | Capabilities | who may use the widget (defaults usually fine) |
| 7 | Moodle cron | audit retention purge task |
| 8 | Purge caches | serve new AMD / templates / CSS |

---

## 1. Install the plugin code

Place this directory at `moodle/local/ai_analysis/`.

The SQL-validation dependency (`greenlion/php-sql-parser`) is committed in-tree under
`vendor/`, so **no `composer install` is required** — copying the directory is enough.

Requirements: Moodle **4.5+** (`$plugin->requires = 2024100700`), **PHP 8.1+**, **MariaDB 10.11**.

## 2. Run the install/upgrade

Visit *Site administration → Notifications* and complete the upgrade (or run
`php admin/cli/upgrade.php --non-interactive`).

This creates the `mdl_local_ai_analysis_audit` table and registers:
- 5 capabilities (`query`, `queryglobal`, `viewaudit`, `decryptprompt`, `managepresets`)
- 2 external services (`local_ai_analysis_query`, `local_ai_analysis_decrypt_prompt`)
- the `ratelimit` application cache
- the daily `purge_audit_task` scheduled task

## 3. Read-only DB user

The query executor connects with a **read-only** MariaDB user — never the main Moodle
user — using `$CFG->ai_analysis_dbuser/dbpass` against the same `$CFG->dbhost`, `dbname`,
and `prefix`. Even if every PHP-layer validation is bypassed, `INSERT`/`UPDATE`/`DELETE`/
`DROP` fail at the server.

Generate a strong password:

```bash
openssl rand -base64 32
```

Edit `db/readonly_grants.sql` and replace `REPLACE_WITH_STRONG_PASSWORD` with it.

> ⚠️ **`db/readonly_grants.sql` hardcodes the DB name `moodle` and prefix `mdl_`.**
> If the target instance uses a different database name or table prefix, edit the
> `GRANT SELECT ON <db>.<prefix>table` lines to match before applying.

Apply it (idempotent — safe to re-run):

```bash
docker exec -i moodle-db-8092 mariadb -uroot -prootpass moodle < moodle/local/ai_analysis/db/readonly_grants.sql
```

Verify — expect exactly **8** `GRANT SELECT` lines and nothing else:

```bash
docker exec moodle-db-8092 mariadb -umoodle_ai_ro -p<password> moodle -e "SHOW GRANTS FOR CURRENT_USER();"
```

The 8 allow-listed tables: `mdl_user`, `mdl_course`, `mdl_grade_grades`,
`mdl_grade_items`, `mdl_course_modules`, `mdl_enrol`, `mdl_user_enrolments`,
`mdl_logstore_standard_log`. As the manifest grows, add grants here and keep this file
as the source of truth.

## 4. Audit encryption key + config.php entries

Stored prompts are SHA-256 hashed and AES-256-CBC encrypted. Generate a 32-byte key:

```bash
openssl rand -hex 32
```

(64 hex chars is recognised and decoded to 32 raw bytes automatically. Any other length
is rejected at runtime: prompts are still hashed, but `prompt_encrypted` stays NULL and a
`debugging()` warning is logged.)

Append to `moodle/config.php` **before** the final `require_once(__DIR__ . '/lib/setup.php');`:

```php
$CFG->ai_analysis_dbuser    = 'moodle_ai_ro';
$CFG->ai_analysis_dbpass    = '<password from step 3>';
$CFG->ai_analysis_audit_key = '<key from this step>';
```

## 5. Configure an AI provider

*Site administration → Plugins → Local plugins → AI Analysis.*

Pick a provider and fill in its key + model:

| Provider | What to set |
|----------|-------------|
| **Claude (Anthropic)** | `claude_api_key` (console.anthropic.com) + `claude_model` (e.g. `claude-sonnet-4-20250514`) |
| **OpenAI** | `openai_api_key` (platform.openai.com) + `openai_model` (e.g. `gpt-4o`) |
| **Google Gemini** | `gemini_api_key` (aistudio.google.com) + `gemini_model` (e.g. `gemini-2.0-flash`) |
| **Ollama (self-hosted)** | no key; `ollama_base_url` + `ollama_model` — see the Ollama appendix |

Other settings on this page:
- **AI request timeout** (seconds, default 30) — raise for slow self-hosted models.
- **Per-user rate limit** (requests/min, default 10) — admins bypass.
- **Audit retention** (days, default 365; 0 = keep forever).

## 6. Capabilities

Defaults (in `db/access.php`) are usually sufficient:

| Capability | Default holders |
|------------|-----------------|
| `query` (use widget in a course) | editingteacher, teacher, manager |
| `queryglobal` (system-wide query) | manager |
| `viewaudit` (audit log report) | site admins only |
| `decryptprompt` (reveal stored prompts) | site admins only |
| `managepresets` | editingteacher, manager |

Change only if you want, e.g., non-admins to view the audit log.

## 7. Cron

Moodle cron must be running so the daily `purge_audit_task` enforces audit retention.
(In this repo, the `moodle-cron-<id>` container already runs `cron.php` on a loop.)

## 8. Purge caches

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php
```

So the chat widget's AMD module, template, and CSS load on first request.

## 9. Verify

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite
```

> Use the `--testsuite` (or explicit file-path) form, **not `--filter`** — unrelated
> half-installed plugins in some environments disrupt filter-based discovery.

Then smoke-test in a browser: open a course as a teacher, click the AI Data Assistant
FAB, ask a question, confirm a table/chart/answer comes back.

---

## Appendix: Ollama (self-hosted, no API key)

Use only if you want local inference. If Moodle runs in a container and Ollama runs on
the **host**, all of the following are required (each was a real blocker during bring-up):

1. **Ollama bind** — start Ollama with `OLLAMA_HOST=0.0.0.0` so it listens on all
   interfaces, not just `127.0.0.1`. Verify: `ss -tlnp | grep 11434` shows `*:11434`.
2. **Base URL** — set `ollama_base_url` to the **docker bridge gateway**, e.g.
   `http://172.26.0.1:11434` (find it with
   `docker inspect <web-container> --format '{{range .NetworkSettings.Networks}}{{.Gateway}}{{end}}'`).
   The container's `localhost` is itself, not the host.
3. **Host firewall** — the host may drop container→host packets. Allow the bridge:
   ```bash
   sudo iptables -I INPUT -i <bridge-iface> -p tcp --dport 11434 -j ACCEPT
   ```
   (`<bridge-iface>` = `br-<first 12 chars of the network ID>`.) Persist with
   `iptables-save` / `netfilter-persistent`, or it must be re-added after a host reboot.
4. **Moodle cURL security** — Moodle's `\curl` blocks private IPs once any host/port
   security rule exists. Add to `config.php`:
   ```php
   $CFG->curlsecurityblockedhosts = '';
   $CFG->curlsecurityallowedport  = "80\n443\n11434";
   ```
5. **Model + timeout** — on a CPU-only host, a 7B model can take ~60s/query. Pull a
   smaller model (`ollama pull qwen2.5:3b`, ~10s warm) and raise **AI request timeout**
   (e.g. 90). Set Ollama `keep_alive` to keep the model resident and avoid cold-load
   latency (~40s) on the first query after idle.
