import Ajax from 'core/ajax';
import Notification from 'core/notification';

export const init = () => {
    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.local-ai-reveal');
        if (!btn) {
            return;
        }
        e.preventDefault();
        const id = parseInt(btn.getAttribute('data-audit-id'), 10);
        btn.disabled = true;
        Ajax.call([{
            methodname: 'local_ai_analysis_decrypt_prompt',
            args: {id: id},
        }])[0].then((res) => {
            const cell = btn.parentNode;
            if (res.status === 'SUCCESS') {
                cell.textContent = res.prompt;
            } else {
                cell.textContent = '[' + res.status + ']';
            }
            return res;
        }).catch((err) => {
            btn.disabled = false;
            Notification.exception(err);
        });
    });
};
