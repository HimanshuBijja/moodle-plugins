<?php
require(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();
$context = context_system::instance();
require_capability('local/ai_analysis:viewaudit', $context);

admin_externalpage_setup('localaianalysisaudit');

$download = optional_param('download', '', PARAM_ALPHA);
$filters = [
    'userid'   => optional_param('userid', 0, PARAM_INT),
    'courseid' => optional_param('courseid', 0, PARAM_INT),
    'status'   => optional_param('status', '', PARAM_ALPHANUMEXT),
    'datefrom' => optional_param('datefrom', 0, PARAM_INT),
    'dateto'   => optional_param('dateto', 0, PARAM_INT),
];

$table = new \local_ai_analysis\report\audit_table('local_ai_analysis_audit', $filters);
$baseurl = new moodle_url('/local/ai_analysis/audit.php', array_filter($filters));
$table->define_baseurl($baseurl);
$table->is_downloadable(true);
$table->show_download_buttons_at([TABLE_P_BOTTOM]);

if ($download) {
    $table->is_downloading($download, 'ai_analysis_audit', 'audit');
}

if (!$table->is_downloading()) {
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('audit_report', 'local_ai_analysis'));
    $PAGE->requires->js_call_amd('local_ai_analysis/audit_reveal', 'init');
}

$table->out(50, true);

if (!$table->is_downloading()) {
    echo $OUTPUT->footer();
}
