<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_ai_analysis', get_string('pluginname', 'local_ai_analysis'));
    $ADMIN->add('localplugins', $settings);

    $ADMIN->add('reports', new admin_externalpage(
        'localaianalysisaudit',
        get_string('audit_report', 'local_ai_analysis'),
        new moodle_url('/local/ai_analysis/audit.php'),
        'local/ai_analysis:viewaudit'
    ));

    $settings->add(new admin_setting_heading('local_ai_analysis/h_provider',
        get_string('h_provider', 'local_ai_analysis'), ''));

    $settings->add(new admin_setting_configselect(
        'local_ai_analysis/provider',
        get_string('setting_provider', 'local_ai_analysis'),
        get_string('setting_provider_desc', 'local_ai_analysis'),
        'claude',
        ['claude' => 'Claude (Anthropic)', 'openai' => 'OpenAI', 'gemini' => 'Google Gemini', 'ollama' => 'Ollama (self-hosted)']
    ));

    $settings->add(new admin_setting_heading('local_ai_analysis/h_keys',
        get_string('h_keys', 'local_ai_analysis'), ''));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/claude_api_key',
        get_string('setting_claude_api_key', 'local_ai_analysis'),
        get_string('setting_claude_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/claude_model',
        get_string('setting_claude_model', 'local_ai_analysis'),
        get_string('setting_claude_model_desc', 'local_ai_analysis'),
        'claude-sonnet-4-20250514',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/openai_api_key',
        get_string('setting_openai_api_key', 'local_ai_analysis'),
        get_string('setting_openai_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/openai_model',
        get_string('setting_openai_model', 'local_ai_analysis'),
        get_string('setting_openai_model_desc', 'local_ai_analysis'),
        'gpt-4o',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/gemini_api_key',
        get_string('setting_gemini_api_key', 'local_ai_analysis'),
        get_string('setting_gemini_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/gemini_model',
        get_string('setting_gemini_model', 'local_ai_analysis'),
        get_string('setting_gemini_model_desc', 'local_ai_analysis'),
        'gemini-2.0-flash',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/ollama_base_url',
        get_string('setting_ollama_base_url', 'local_ai_analysis'),
        get_string('setting_ollama_base_url_desc', 'local_ai_analysis'),
        'http://localhost:11434',
        PARAM_URL
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/ollama_model',
        get_string('setting_ollama_model', 'local_ai_analysis'),
        get_string('setting_ollama_model_desc', 'local_ai_analysis'),
        'qwen2.5-coder',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_heading('local_ai_analysis/h_limits',
        get_string('h_limits', 'local_ai_analysis'), ''));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/rate_limit_per_min',
        get_string('setting_rate_limit', 'local_ai_analysis'),
        get_string('setting_rate_limit_desc', 'local_ai_analysis'),
        '10',
        PARAM_INT,
        5
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/request_timeout',
        get_string('setting_request_timeout', 'local_ai_analysis'),
        get_string('setting_request_timeout_desc', 'local_ai_analysis'),
        '30',
        PARAM_INT,
        5
    ));

    $settings->add(new admin_setting_heading('local_ai_analysis/h_audit',
        get_string('h_audit', 'local_ai_analysis'), ''));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/retentiondays',
        get_string('setting_retentiondays', 'local_ai_analysis'),
        get_string('setting_retentiondays_desc', 'local_ai_analysis'),
        '365',
        PARAM_INT
    ));

    $settings->add(new admin_setting_description(
        'local_ai_analysis/auditlink',
        get_string('audit_report', 'local_ai_analysis'),
        \html_writer::link(
            new moodle_url('/local/ai_analysis/audit.php'),
            get_string('audit_report', 'local_ai_analysis')
        )
    ));
}
