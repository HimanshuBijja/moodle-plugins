<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'AI Analysis';

// Capability strings.
$string['ai_analysis:query']          = 'Query the AI analysis chatbot in a course context';
$string['ai_analysis:queryglobal']    = 'Query the AI analysis chatbot in the system context';
$string['ai_analysis:viewaudit']      = 'View the AI analysis audit log';
$string['ai_analysis:decryptprompt']  = 'Decrypt stored AI analysis prompts (requires re-authentication)';
$string['ai_analysis:managepresets']  = 'Manage AI analysis query presets';

// Audit status strings (used by Sprint 5 audit viewer UI; declared now to keep langfile stable).
$string['status_success']            = 'Success';
$string['status_blocked_injection']  = 'Blocked: prompt injection';
$string['status_rate_limited']       = 'Rate limited';
$string['status_sql_invalid']        = 'SQL invalid';
$string['status_parse_failed']       = 'Parse failed';
$string['status_ai_invalid_json']    = 'AI returned invalid JSON';
$string['status_out_of_scope']       = 'Out of scope';

// Validator exception messages.
$string['validation_failed']         = 'SQL validation failed: {$a}';

// Pipeline exception messages.
$string['aitransporterror']  = 'AI provider transport error: {$a}';
$string['aiclienterror']     = 'AI provider response error: {$a}';
$string['queryfailed']       = 'Query execution failed: {$a}';
$string['promptblocked']     = 'Prompt blocked: contains forbidden phrase ({$a})';
$string['ratelimited']       = 'Rate limit exceeded. Please wait before retrying.';

// Settings page strings.
$string['setting_provider']            = 'AI provider';
$string['setting_provider_desc']       = 'Which AI provider to use for SQL generation. More options arrive in Sprint 3.';
$string['setting_claude_api_key']      = 'Claude API key';
$string['setting_claude_api_key_desc'] = 'Anthropic API key. Generate one at https://console.anthropic.com/. Required when provider is Claude.';
$string['setting_rate_limit']          = 'Per-user rate limit (requests/min)';
$string['setting_rate_limit_desc']     = 'Maximum AI requests per minute per non-admin user. Admins are unlimited.';

$string['formatunavailable'] = 'Answer formatting is unavailable; showing raw results.';

// Per-provider model + key strings.
$string['setting_claude_model']        = 'Claude model';
$string['setting_claude_model_desc']   = 'Anthropic model id, e.g. claude-sonnet-4-20250514.';
$string['setting_openai_api_key']      = 'OpenAI API key';
$string['setting_openai_api_key_desc'] = 'API key from https://platform.openai.com/. Required when provider is OpenAI.';
$string['setting_openai_model']        = 'OpenAI model';
$string['setting_openai_model_desc']   = 'OpenAI model id, e.g. gpt-4o or gpt-4o-mini.';
$string['setting_gemini_api_key']      = 'Gemini API key';
$string['setting_gemini_api_key_desc'] = 'API key from https://aistudio.google.com/. Required when provider is Gemini.';
$string['setting_gemini_model']        = 'Gemini model';
$string['setting_gemini_model_desc']   = 'Gemini model id, e.g. gemini-2.0-flash or gemini-1.5-pro.';

// Sprint 4: chat widget UI strings.
$string['widget_title']        = 'AI Data Assistant';
$string['widget_open']         = 'Open AI Data Assistant';
$string['widget_newchat']      = 'New chat';
$string['widget_expand']       = 'Expand to full screen';
$string['widget_collapse']     = 'Collapse to drawer';
$string['widget_close']        = 'Close';
$string['widget_placeholder']  = 'Ask about your student data…';
$string['widget_ask']          = 'Ask';
$string['widget_welcome']      = 'What should we analyse today?';
$string['widget_welcome_sub']  = 'Ask a question about your student data';
$string['widget_loading']      = 'Analysing…';
$string['widget_history']      = 'History';
$string['widget_nohistory']    = 'No queries yet';
$string['widget_suggestion1']  = 'Top 10 students by grade';
$string['widget_suggestion2']  = 'Students at risk of failing';
$string['widget_suggestion3']  = 'Average grade per course';
$string['widget_error']        = 'Something went wrong';
$string['widget_msg_scope']    = 'I can only answer questions about the data I am allowed to query: courses, users, grades, activity completion, and access logs. Try rephrasing around those.';
$string['widget_msg_rate']     = 'You are sending requests too quickly. Please wait a moment and try again.';
$string['widget_msg_blocked']  = 'That request was blocked for security reasons. Please rephrase and try again.';
$string['widget_msg_failed']   = 'I could not complete that request. Please try rephrasing your question.';
