# local_ai_analysis — Installation

This plugin requires a one-time setup step beyond the standard Moodle plugin install: a read-only DB user and two `config.php` entries.

## 1. Plugin install

Place this directory at `moodle/local/ai_analysis/` and visit *Site administration → Notifications*. Moodle will create the `mdl_local_ai_analysis_audit` table and register the plugin's capabilities.

## 2. Read-only DB user

The plugin's Sprint-2 query executor will connect with a read-only MariaDB user — never the main Moodle user. Even if every PHP-layer validation is bypassed, `INSERT`/`UPDATE`/`DELETE`/`DROP` will fail at the DB server.

Generate a strong password:

```bash
openssl rand -base64 32
```

Edit `db/readonly_grants.sql` and replace `REPLACE_WITH_STRONG_PASSWORD` with the generated value, then apply it:

```bash
docker exec -i moodle-db-8092 mariadb -uroot -prootpass moodle < moodle/local/ai_analysis/db/readonly_grants.sql
```

Verify:

```bash
docker exec moodle-db-8092 mariadb -umoodle_ai_ro -p<password> moodle -e "SHOW GRANTS FOR CURRENT_USER();"
```

Expected: four `GRANT SELECT` lines and nothing else.

## 3. Audit prompt encryption key

Encrypted prompt storage uses AES-256-CBC. Generate a 32-byte key:

```bash
openssl rand -hex 32
```

(Note: AES-256 requires exactly 32 bytes. `openssl rand -hex 32` produces 64 hex characters — the audit writer recognises this form and decodes it back to 32 raw bytes automatically. You can also store 32 raw bytes directly if your `config.php` is generated programmatically. Any other length is rejected at runtime: prompts are still hashed, but the `prompt_encrypted` column stays NULL and a `debugging()` warning is logged.)

## 4. Add to `config.php`

Append to `moodle/config.php` *before* the final `require_once(...)`:

```php
$CFG->ai_analysis_dbuser    = 'moodle_ai_ro';
$CFG->ai_analysis_dbpass    = '<password from step 2>';
$CFG->ai_analysis_audit_key = '<key from step 3>';
```

Sprint 1 reads only `ai_analysis_audit_key`. The two DB credentials are consumed by Sprint 2's query executor; setting them now means no `config.php` edits later.

## 5. Verify

Run the PHPUnit suite from the Moodle root. Note: use the explicit test-file path approach below rather than `--filter`, because unrelated half-installed plugins in this environment can disrupt PHPUnit's filter-based discovery:

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/audit_writer_test.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_validator_test.php
```

Expected: each command ends with `OK (N tests, ...)`.
