<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;
use local_ai_analysis\exception\transport_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Fake transport that records what was sent and replays a canned response.
 */
class fake_http_transport implements http_transport_interface {
    public ?string $last_url = null;
    public ?array $last_headers = null;
    public ?string $last_body = null;
    public array $next_response = ['status' => 200, 'headers' => [], 'body' => ''];
    public ?\Throwable $throw_on_next = null;

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        $this->last_url = $url;
        $this->last_headers = $headers;
        $this->last_body = $body;
        if ($this->throw_on_next !== null) {
            $t = $this->throw_on_next;
            $this->throw_on_next = null;
            throw $t;
        }
        return $this->next_response;
    }
}

/**
 * @covers \local_ai_analysis\ai\claude_client
 */
class claude_client_test extends \advanced_testcase {

    private function build_claude_response(string $inner_json): array {
        $api_payload = [
            'content' => [['type' => 'text', 'text' => $inner_json]],
        ];
        return ['status' => 200, 'headers' => [], 'body' => json_encode($api_payload)];
    }

    public function test_request_targets_anthropic_messages_endpoint(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\claude_client($t, 'test-key');
        $c->generate_sql('sys', 'usr');
        $this->assertSame('https://api.anthropic.com/v1/messages', $t->last_url);
    }

    public function test_request_sets_anthropic_headers(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\claude_client($t, 'my-key');
        $c->generate_sql('sys', 'usr');
        $this->assertContains('x-api-key: my-key', $t->last_headers);
        $this->assertContains('anthropic-version: 2023-06-01', $t->last_headers);
        $this->assertContains('content-type: application/json', $t->last_headers);
    }

    public function test_request_body_contains_system_and_user(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $c->generate_sql('THE_SYSTEM_PROMPT', 'THE_USER_PROMPT');
        $body = json_decode($t->last_body, true);
        $this->assertSame('claude-sonnet-4-20250514', $body['model']);
        $this->assertSame(800, $body['max_tokens']);
        $this->assertSame('THE_SYSTEM_PROMPT', $body['system']);
        $this->assertCount(1, $body['messages']);
        $this->assertSame('user', $body['messages'][0]['role']);
        $this->assertSame('THE_USER_PROMPT', $body['messages'][0]['content']);
    }

    public function test_happy_path_returns_sql_array(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response(
            '{"sql":"SELECT id FROM mdl_user WHERE id = ? LIMIT 10","params":[42],"explanation":"by id"}'
        );
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $result = $c->generate_sql('sys', 'usr');
        $this->assertSame('sql', $result['type']);
        $this->assertSame('SELECT id FROM mdl_user WHERE id = ? LIMIT 10', $result['sql']);
        $this->assertSame([42], $result['params']);
        $this->assertSame('by id', $result['explanation']);
    }

    public function test_code_fence_wrapped_json_is_stripped(): void {
        $fenced = "```json\n" . '{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}' . "\n```";
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response($fenced);
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $result = $c->generate_sql('sys', 'usr');
        $this->assertSame('sql', $result['type']);
        $this->assertSame('SELECT id FROM mdl_user LIMIT 1', $result['sql']);
    }

    public function test_out_of_scope_response(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response('{"error":"out_of_scope"}');
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $result = $c->generate_sql('sys', 'usr');
        $this->assertSame('out_of_scope', $result['type']);
        $this->assertSame('out_of_scope', $result['message']);
    }

    public function test_http_4xx_throws_ai_client_exception(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 429, 'headers' => [], 'body' => '{"error":"rate_limit"}'];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        try {
            $c->generate_sql('sys', 'usr');
            $this->fail('expected ai_client_exception');
        } catch (ai_client_exception $e) {
            $this->assertSame('HTTP_429', $e->reason);
            $this->assertStringContainsString('rate_limit', $e->body_excerpt);
        }
    }

    public function test_http_5xx_throws_ai_client_exception(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 503, 'headers' => [], 'body' => 'Service Unavailable'];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('sys', 'usr');
    }

    public function test_malformed_inner_json_throws_ai_client_exception(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response('not valid json at all');
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        try {
            $c->generate_sql('sys', 'usr');
            $this->fail('expected ai_client_exception');
        } catch (ai_client_exception $e) {
            $this->assertSame('PARSE_FAILED', $e->reason);
        }
    }

    public function test_missing_sql_or_params_throws(): void {
        $t = new fake_http_transport();
        $t->next_response = $this->build_claude_response('{"explanation":"no sql here"}');
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('sys', 'usr');
    }

    public function test_transport_exception_propagates(): void {
        $t = new fake_http_transport();
        $t->throw_on_next = new transport_exception('curl errno=28');
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(transport_exception::class);
        $c->generate_sql('sys', 'usr');
    }

    public function test_format_result_targets_messages_endpoint_with_format_system(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 200, 'headers' => [], 'body' => json_encode([
            'content' => [['type' => 'text', 'text' => 'PERSON_1 has the top grade.']],
        ])];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $answer = $c->format_result('who scored highest', [['firstname' => 'PERSON_1', 'g' => 90]]);
        $this->assertSame('https://api.anthropic.com/v1/messages', $t->last_url);
        $this->assertSame('PERSON_1 has the top grade.', $answer);
        $body = json_decode($t->last_body, true);
        $this->assertSame(1024, $body['max_tokens']);
        $this->assertStringContainsString('summarise', strtolower($body['system']));
        $this->assertStringContainsString('PERSON_1', $body['messages'][0]['content']);
        $this->assertStringContainsString('who scored highest', $body['messages'][0]['content']);
    }

    public function test_format_result_strips_code_fences(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 200, 'headers' => [], 'body' => json_encode([
            'content' => [['type' => 'text', 'text' => "```\nPlain answer.\n```"]],
        ])];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->assertSame('Plain answer.', $c->format_result('q', []));
    }

    public function test_format_result_http_error_throws(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 500, 'headers' => [], 'body' => 'boom'];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(\local_ai_analysis\exception\ai_client_exception::class);
        $c->format_result('q', []);
    }

    public function test_format_result_unparseable_throws(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 200, 'headers' => [], 'body' => 'not json'];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(\local_ai_analysis\exception\ai_client_exception::class);
        $c->format_result('q', []);
    }
}
