<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\ai_client_factory;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * @covers \local_ai_analysis\ai\ai_client_factory
 */
class ai_client_factory_test extends \advanced_testcase {

    public function test_claude_is_default(): void {
        $this->resetAfterTest();
        set_config('provider', '', 'local_ai_analysis');
        $this->assertInstanceOf(\local_ai_analysis\ai\claude_client::class, ai_client_factory::make());
    }

    public function test_openai_provider(): void {
        $this->resetAfterTest();
        set_config('provider', 'openai', 'local_ai_analysis');
        $this->assertInstanceOf(\local_ai_analysis\ai\openai_client::class, ai_client_factory::make());
    }

    public function test_gemini_provider(): void {
        $this->resetAfterTest();
        set_config('provider', 'gemini', 'local_ai_analysis');
        $this->assertInstanceOf(\local_ai_analysis\ai\gemini_client::class, ai_client_factory::make());
    }

    public function test_unknown_provider_throws(): void {
        $this->resetAfterTest();
        set_config('provider', 'bogus', 'local_ai_analysis');
        $this->expectException(\coding_exception::class);
        ai_client_factory::make();
    }
}
