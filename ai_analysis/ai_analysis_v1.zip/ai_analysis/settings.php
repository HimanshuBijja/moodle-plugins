<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_ai_analysis', get_string('pluginname', 'local_ai_analysis'));
    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_configselect(
        'local_ai_analysis/provider',
        get_string('setting_provider', 'local_ai_analysis'),
        get_string('setting_provider_desc', 'local_ai_analysis'),
        'claude',
        ['claude' => 'Claude (Anthropic)', 'openai' => 'OpenAI', 'gemini' => 'Google Gemini']
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/claude_api_key',
        get_string('setting_claude_api_key', 'local_ai_analysis'),
        get_string('setting_claude_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/claude_model',
        get_string('setting_claude_model', 'local_ai_analysis'),
        get_string('setting_claude_model_desc', 'local_ai_analysis'),
        'claude-sonnet-4-20250514',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/openai_api_key',
        get_string('setting_openai_api_key', 'local_ai_analysis'),
        get_string('setting_openai_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/openai_model',
        get_string('setting_openai_model', 'local_ai_analysis'),
        get_string('setting_openai_model_desc', 'local_ai_analysis'),
        'gpt-4o',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/gemini_api_key',
        get_string('setting_gemini_api_key', 'local_ai_analysis'),
        get_string('setting_gemini_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/gemini_model',
        get_string('setting_gemini_model', 'local_ai_analysis'),
        get_string('setting_gemini_model_desc', 'local_ai_analysis'),
        'gemini-2.0-flash',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/rate_limit_per_min',
        get_string('setting_rate_limit', 'local_ai_analysis'),
        get_string('setting_rate_limit_desc', 'local_ai_analysis'),
        '10',
        PARAM_INT,
        5
    ));
}
