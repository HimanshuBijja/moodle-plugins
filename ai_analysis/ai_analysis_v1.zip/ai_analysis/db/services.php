<?php
defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_ai_analysis_query' => [
        'classname'   => 'local_ai_analysis\\external\\query',
        'methodname'  => 'execute',
        'description' => 'Translate a natural-language prompt to validated SQL and return the result rows.',
        'type'        => 'read',
        'ajax'        => true,
        'loginrequired' => true,
    ],
];
