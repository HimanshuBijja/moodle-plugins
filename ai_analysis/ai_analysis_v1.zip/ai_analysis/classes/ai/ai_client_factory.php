<?php
namespace local_ai_analysis\ai;

use local_ai_analysis\ai\transport\moodle_curl_transport;

defined('MOODLE_INTERNAL') || die();

/**
 * Returns the configured AI client. Reads get_config('local_ai_analysis',
 * 'provider'); defaults to 'claude'.
 *
 * Test seam: PHPUnit runs set defined('PHPUNIT_TEST'), in which case tests
 * may call set_override() to inject a stub. The override is reset between
 * tests by reset_override(), typically called from tearDown.
 */
class ai_client_factory {

    /** @var ai_client_interface|null */
    private static ?ai_client_interface $override = null;

    public static function make(): ai_client_interface {
        if (self::$override !== null) {
            return self::$override;
        }
        $provider  = get_config('local_ai_analysis', 'provider') ?: 'claude';
        $transport = new moodle_curl_transport();
        return match ($provider) {
            'claude' => new claude_client(
                $transport,
                (string) get_config('local_ai_analysis', 'claude_api_key'),
                (string) get_config('local_ai_analysis', 'claude_model'),
            ),
            'openai' => new openai_client(
                $transport,
                (string) get_config('local_ai_analysis', 'openai_api_key'),
                (string) get_config('local_ai_analysis', 'openai_model'),
            ),
            'gemini' => new gemini_client(
                $transport,
                (string) get_config('local_ai_analysis', 'gemini_api_key'),
                (string) get_config('local_ai_analysis', 'gemini_model'),
            ),
            default => throw new \coding_exception('Unsupported AI provider: ' . $provider),
        };
    }

    public static function set_override(ai_client_interface $client): void {
        if (!defined('PHPUNIT_TEST') || !PHPUNIT_TEST) {
            throw new \coding_exception('set_override is only available under PHPUNIT_TEST');
        }
        self::$override = $client;
    }

    public static function reset_override(): void {
        self::$override = null;
    }
}
