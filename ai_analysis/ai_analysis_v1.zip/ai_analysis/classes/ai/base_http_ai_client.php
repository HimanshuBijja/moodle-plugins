<?php
namespace local_ai_analysis\ai;

use local_ai_analysis\exception\ai_client_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Template-method base for JSON-over-HTTP AI providers. Owns the entire
 * provider-independent flow; concrete providers implement five small hooks.
 * generate_sql()/format_result() are final so the SQL-output parsing cannot
 * drift between providers.
 */
abstract class base_http_ai_client implements ai_client_interface {

    public function __construct(
        protected http_transport_interface $transport,
        protected string $api_key,
        protected string $model = '',
    ) {}

    final public function generate_sql(string $system_prompt, string $user_prompt): array {
        $response = $this->post($this->build_sql_payload($system_prompt, $user_prompt));
        $text     = $this->extract_text($response);
        $stripped = $this->strip_fences($text);
        $decoded  = json_decode($stripped, true);
        if (!is_array($decoded)) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        if (isset($decoded['error']) && is_string($decoded['error'])) {
            return ['type' => 'out_of_scope', 'message' => $decoded['error']];
        }
        if (!isset($decoded['sql']) || !isset($decoded['params']) || !is_array($decoded['params'])) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        return [
            'type'        => 'sql',
            'sql'         => (string) $decoded['sql'],
            'params'      => $decoded['params'],
            'explanation' => (string) ($decoded['explanation'] ?? ''),
        ];
    }

    final public function format_result(string $user_prompt, array $safe_rows): string {
        $response = $this->post($this->build_format_payload($user_prompt, $safe_rows));
        return trim($this->strip_fences($this->extract_text($response)));
    }

    /** POST the JSON-encoded payload; return the decoded response envelope. */
    protected function post(array $payload): array {
        $response = $this->transport->post($this->endpoint(), $this->auth_headers(), json_encode($payload));
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new ai_client_exception('HTTP_' . $response['status'], $response['body']);
        }
        $decoded = json_decode($response['body'], true);
        if (!is_array($decoded)) {
            throw new ai_client_exception('PARSE_FAILED', $response['body']);
        }
        return $decoded;
    }

    protected function strip_fences(string $text): string {
        $stripped = trim($text);
        $stripped = preg_replace('/^```\w*\s*/i', '', $stripped);
        $stripped = preg_replace('/\s*```\s*$/', '', $stripped);
        return $stripped;
    }

    /** Effective model: explicit config else provider default. */
    protected function model(): string {
        return $this->model !== '' ? $this->model : static::DEFAULT_MODEL;
    }

    abstract protected function endpoint(): string;
    abstract protected function auth_headers(): array;
    abstract protected function build_sql_payload(string $system_prompt, string $user_prompt): array;
    abstract protected function build_format_payload(string $user_prompt, array $safe_rows): array;

    /** Extract assistant text from the decoded response, or '' if the path is absent. */
    abstract protected function extract_text(array $response): string;
}
