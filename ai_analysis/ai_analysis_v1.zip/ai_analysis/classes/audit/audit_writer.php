<?php
namespace local_ai_analysis\audit;

defined('MOODLE_INTERNAL') || die();

/**
 * Always-on audit writer. Catches all its own exceptions so any caller —
 * including error paths — can audit without nested try/catch.
 */
class audit_writer {

    public static function write(
        int $userid,
        int $courseid,
        string $prompt,
        ?string $sql,
        string $status,
        string $reason = '',
        string $provider = '',
        ?int $row_count = null,
        ?int $duration_ms = null
    ): void {
        global $DB, $CFG;

        try {
            $encrypted = null;
            $key = self::normalize_aes_key($CFG->ai_analysis_audit_key ?? '');
            if ($key !== null) {
                $iv = openssl_random_pseudo_bytes(16);
                $ct = openssl_encrypt($prompt, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
                if ($ct !== false) {
                    $encrypted = base64_encode($iv) . '::' . base64_encode($ct);
                }
            }

            $DB->insert_record('local_ai_analysis_audit', (object)[
                'userid'            => $userid,
                'courseid'          => $courseid,
                'timecreated'       => time(),
                'prompt_hash'       => hash('sha256', $prompt),
                'prompt_length'     => strlen($prompt),
                'prompt_encrypted'  => $encrypted,
                'sql_executed'      => $sql !== null ? substr($sql, 0, 2000) : null,
                'row_count'         => $row_count,
                'status'            => substr($status, 0, 40),
                'block_reason'      => substr($reason, 0, 120),
                'provider'          => substr($provider, 0, 20),
                'duration_ms'       => $duration_ms,
                'useragent'         => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            ]);
        } catch (\Throwable $e) {
            debugging(
                'local_ai_analysis audit write failed: ' . $e->getMessage(),
                DEBUG_DEVELOPER
            );
        }
    }

    /**
     * Accept the audit encryption key in either of two forms:
     *  - 32 raw bytes (e.g. produced by `openssl rand -base64 24` then base64_decoded into config).
     *  - 64 hex digits (e.g. produced by `openssl rand -hex 32`, the form documented in INSTALL.md).
     * Returns the 32-byte raw key on success, or null if the input is empty / wrong size / wrong
     * format. A null return is logged via debugging() so misconfiguration is visible in dev mode
     * without the writer ever throwing.
     */
    private static function normalize_aes_key(string $raw): ?string {
        if ($raw === '') {
            return null;
        }
        if (strlen($raw) === 32) {
            return $raw;
        }
        if (strlen($raw) === 64 && ctype_xdigit($raw)) {
            return hex2bin($raw);
        }
        debugging(
            'local_ai_analysis_audit_key must be 32 raw bytes or 64 hex digits; '
            . 'got ' . strlen($raw) . ' chars. Prompt will not be encrypted.',
            DEBUG_DEVELOPER
        );
        return null;
    }
}
