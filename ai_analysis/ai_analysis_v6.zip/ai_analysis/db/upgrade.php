<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_ai_analysis_upgrade(int $oldversion): bool {
    global $DB;

    if ($oldversion < 2026061201) {
        // Sub-project C: create the read-only course-staff view.
        \local_ai_analysis\db\course_staff_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061201, 'local', 'ai_analysis');
    }

    if ($oldversion < 2026061202) {
        // Sub-project B1: create the read-only student-engagement view.
        \local_ai_analysis\db\student_engagement_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061202, 'local', 'ai_analysis');
    }

    if ($oldversion < 2026061203) {
        // Sub-project B2: create the read-only course-performance view.
        \local_ai_analysis\db\course_performance_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061203, 'local', 'ai_analysis');
    }

    if ($oldversion < 2026061301) {
        // Sub-project B3: create the read-only custom-feedback rating views.
        \local_ai_analysis\db\course_feedback_view::create($DB);
        \local_ai_analysis\db\feedback_activity_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061301, 'local', 'ai_analysis');
    }

    return true;
}
