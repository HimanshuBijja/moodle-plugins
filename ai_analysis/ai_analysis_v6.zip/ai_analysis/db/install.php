<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Install-time hook: create the read-only ai_course_staff view. Runs on fresh
 * installs and during PHPUnit init (which reinstalls plugins).
 */
function xmldb_local_ai_analysis_install(): bool {
    global $DB;
    // Skip view creation during PHPUnit install: the snapshot (tabledata.ser) includes
    // all tables returned by SHOW TABLES (views too), and reset_database() tries DELETE
    // on every snapshotted table — which fails on a non-updatable join view and breaks
    // the test environment. Tests create the view themselves in setUp().
    if (!defined('PHPUNIT_TEST') || !PHPUNIT_TEST) {
        \local_ai_analysis\db\course_staff_view::create($DB);
        \local_ai_analysis\db\student_engagement_view::create($DB);
        \local_ai_analysis\db\course_performance_view::create($DB);
        \local_ai_analysis\db\course_feedback_view::create($DB);
        \local_ai_analysis\db\feedback_activity_view::create($DB);
    }
    return true;
}
