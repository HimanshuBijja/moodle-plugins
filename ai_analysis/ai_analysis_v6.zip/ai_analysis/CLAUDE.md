# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

`local_ai_analysis` is a Moodle 4.5 local plugin that provides a natural-language-to-SQL chatbot for querying student data. It targets PHP 8.1+ / MariaDB 10.11. The plugin is structured as five sprints; Sprints 1 (security foundation) and 2 (pipeline + Claude provider) are complete/in-progress. See `docs/superpowers/specs/` for detailed design documents.

## Running Tests

All PHPUnit tests run inside the Docker container. **Always use the file-path form, not `--filter`** (unrelated plugins in this instance disrupt filter-based discovery):

```bash
# One-time setup (run after any schema/config change):
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php

# Run a single test file:
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/<name>_test.php

# Run all plugin tests:
docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite
```

Test files live in `tests/` with the suffix `_test.php`. The testsuite is defined in `phpunit.xml`.

## Architecture — Request Pipeline

The AJAX gateway (`classes/external/query.php`) is the main orchestrator. A single `execute()` call flows through these layers in order:

1. **Auth + capabilities** — `require_capability('local/ai_analysis:query')`. Global queries additionally require `queryglobal`.
2. **Input sanitisation** — `prompt_builder::sanitise_user_prompt()` enforces 3–800 char length and a blocklist of prompt-injection phrases.
3. **Rate limiting** — `rate_limiter::consume()` uses a per-user token bucket in `cache_application` (1 token/60s, capacity from plugin config; admins bypass).
4. **Manifest + system prompt** — `manifest_builder::build()` produces the schema snapshot; `prompt_builder::build_system()` embeds it in the AI system role.
5. **AI call** — `ai_client_factory::make()` returns the active provider (only `claude` today). `claude_client::generate_sql()` calls the Anthropic Messages API via an injected `http_transport_interface`.
6. **SQL validation** — `sql_validator::validate()` (AST-based, using `greenlion/php-sql-parser`) enforces: SELECT only, no DDL/DML, no wildcards, no subqueries, manifest-scoped tables/columns, scalar params, LIMIT ≤ 1000.
7. **Query execution** — `query_executor::run()` opens a separate read-only `moodle_database` connection using `$CFG->ai_analysis_dbuser/dbpass`. Tests inject the global `$DB` instead.
8. **Audit** — `audit_writer::write()` is called on every code path including errors. Prompts are stored as SHA-256 hash + AES-256-CBC ciphertext (`$CFG->ai_analysis_audit_key`).

Every layer that fails returns a structured error envelope (never throws to the AJAX layer), and writes an audit row with a `status` code.

## Key Design Patterns

**Test seams via injection** — components never hard-wire their dependencies:
- `claude_client` accepts an `http_transport_interface` constructor arg; tests pass a fake transport.
- `ai_client_factory` exposes `set_override()` / `reset_override()` (guarded by `PHPUNIT_TEST`) so tests can inject a stub AI client.
- `query_executor` accepts an optional `moodle_database` arg; null triggers the real read-only connection.

**No exceptions to the AJAX layer** — `external/query.php` catches every domain exception and converts it to an envelope with `status` ∈ `{BLOCKED_INJECTION, RATE_LIMITED, AI_INVALID_JSON, AI_TRANSPORT_ERROR, OUT_OF_SCOPE, SQL_INVALID, QUERY_FAILED, SUCCESS}`.

**Manifest is the single source of truth for SQL validation** — `sql_validator` receives the exact same manifest array that was sent to the AI, so the allow-list cannot drift.

**Table prefix translation** — the gateway calls `translate_prefix()` to swap `mdl_` → the runtime prefix (`phpu_` in PHPUnit). The AI and validator always work with `mdl_` names.

## Configuration (`config.php`)

```php
$CFG->ai_analysis_dbuser    = 'moodle_ai_ro';   // read-only DB user
$CFG->ai_analysis_dbpass    = '...';
$CFG->ai_analysis_audit_key = '...';             // 32 raw bytes or 64 hex chars
```

Plugin settings (provider, Claude API key, rate limit) are stored via Moodle's `get_config`/`set_config` under component `local_ai_analysis`.



# Model Selection

Select the model according to task complexity and expected reasoning depth.

* Architecture, system design, migrations, complex debugging, root-cause analysis, and high-impact decisions → Opus
* Feature implementation, code review, refactoring, testing, and general development tasks → Sonnet
* Search, grep, lint verification, log inspection, simple analysis, and lightweight review tasks → Haiku

### Guidelines:

* Escalate only when additional reasoning is required.
* De-escalate after the complex task is complete.
* Use cost-efficient models whenever quality is expected to be equivalent.

### Subagents:

* Planning/Architecture agent → Opus
* Search/Review/Test agents → Haiku or Sonnet
* Select the model according to the task's relevance and complexity.



# Rules
- task completion - proceed with next task, no permission required, just inform; unless its a deciding change 
- Use subagents for medium/large tasks, multi-file changes, research, reviews, or parallel work. Small changes may be done directly.
- do not output: code changes,read, write, bash, edit  (to save tokens) 
- commit message should have only my signature , dont use anthropic/claude signatures
- ask questions with options with taking big/breaking decisions
- (superpowers): always proceed after generating spec, continue with subagent driven for execution  
- Report only failures 
- Merge back to master locally after Implementation completes, (for superpowers implementation only)



## Git Rules:
### always allow commands: 
- show
- log
- diff
- commit
- add
- checkout

### ask permissions

## Test Rules:
- always allow to run all tests

## Terminal rules
### always allow
- grep
- npx eslint
- lint checks commands
- mkdir
- cd /home/himanshu/moodle-instances/moodle-instance-8092


## Output Suppression

Do not output:

* Read operations
* Edit operations
* Bash commands
* Command results
* Test logs
* Lint output
* Typecheck output
* File diffs
* Tool traces
* Subagent transcripts

Run them silently.

Only output:

* Current task status
* Blocking issues
* Important decisions requiring user input
* Final git commit message
* Final completion summary

For tests, lint, typecheck, and verification:

* Run automatically.
* Do not print logs.
* Report only failures with a concise error summary.
* If all checks pass, simply state: "Verification passed."

For file edits:

* Do not show diffs or edited code unless explicitly requested.

For command execution:

* Execute approved commands silently.
* Do not echo commands before or after execution.



# Guardrails


# Project Rules

Before coding, read:
- docs/ai-memory/00-project-overview.md
- docs/ai-memory/01-architecture.md
- docs/ai-memory/04-current-state.md

After every feature update:
1. Update docs/ai-memory/02-features-log.md
2. Update docs/ai-memory/04-current-state.md
3. Add major decisions to docs/ai-memory/03-decisions.md
4. Mention changed files, new APIs, DB changes, and pending bugs

create files/folders inside docs if it dosent exists

# Load Skills

* use superpowers and caveman skills 