# Sub-project B1 — Student Engagement & Risk View Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let the chatbot answer engagement/at-risk questions ("students at risk in this course") via a pre-computed read-only view exposing per-student metrics + a transparent risk_band, plus one fast-path template.

**Architecture:** A plugin-owned MariaDB view `mdl_ai_student_engagement` (grain: one row per active-enrolled non-staff student per course, `courseid > 0` only) aggregates logstore activity, assignment submissions, and grades into flat metric columns + a derived `risk_band`. It reuses sub-project C's view-ownership pattern (install/upgrade create it, PHPUNIT-skip, per-test create/drop) and the sub-project A intent framework (a `at_risk_students` template).

**Tech Stack:** PHP 8.1, Moodle 4.5, MariaDB 10.11 (view via `$DB->execute`), PHPUnit (Docker), greenlion/php-sql-parser (via `sql_validator`).

**Spec:** `docs/superpowers/specs/2026-06-12-sprintB1-student-engagement-risk-design.md`

**Prerequisite:** sub-project C is merged (this view references `mdl_ai_course_staff`).

---

## File Structure

| File | Responsibility |
|---|---|
| `classes/db/student_engagement_view.php` (new) | DDL holder: `definition_sql($prefix)` + `create($db)`. |
| `db/install.php` (modify) | Also create the engagement view (after the staff view), PHPUNIT-skip. |
| `db/upgrade.php` (modify) | New version-guarded step creates the engagement view. |
| `db/readonly_grants.sql` (modify) | Grant SELECT on the engagement view. |
| `classes/manifest/manifest_builder.php` (modify) | Allow-list the view + course scope-note. |
| `classes/security/pii_scrubber.php` (modify) | View name columns → PERSON. |
| `classes/intent/synonym_dictionary.php` (modify) | risk-term family. |
| `classes/intent/intent_registry.php` (modify) | `at_risk_students` intent. |
| `classes/intent/sql_template.php` (modify) | `at_risk_students` template case. |
| `version.php` (modify) | Bump to `2026061202` / `0.10.0`. |
| `tests/student_engagement_view_test.php` (new) | Metrics, risk_band, staff + courseid=0 exclusion, column shape. |
| `tests/{intent_classifier,sql_template,external_query,manifest_builder,pii_scrubber}_test.php` (modify) | Extend. |
| `INSTALL.md`, `docs/ai-memory/02,03,04` (modify) | Record. |

---

## Task 1: The engagement view (DDL holder + install + upgrade + grant + version)

**Files:**
- Create: `classes/db/student_engagement_view.php`, `tests/student_engagement_view_test.php`
- Modify: `db/install.php`, `db/upgrade.php`, `db/readonly_grants.sql`, `version.php`

- [ ] **Step 1: Write the failing test**

Create `local/ai_analysis/tests/student_engagement_view_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\db\course_staff_view;
use local_ai_analysis\db\student_engagement_view;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\student_engagement_view
 */
class student_engagement_view_test extends \advanced_testcase {

    /** Both views must exist; engagement references the staff view. Create staff first. */
    protected function setUp(): void {
        global $DB;
        parent::setUp();
        course_staff_view::create($DB);
        student_engagement_view::create($DB);
    }

    protected function tearDown(): void {
        global $DB;
        // Drop dependent view first, then the staff view, before the framework reset.
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . student_engagement_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . course_staff_view::VIEW);
        parent::tearDown();
    }

    /** Active manual enrolment, no role (so the user is a "student", not staff). */
    private function enrol(int $userid, int $courseid): void {
        global $DB;
        $inst = $DB->get_record('enrol', ['courseid' => $courseid, 'enrol' => 'manual'], '*', MUST_EXIST);
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $inst->id, 'userid' => $userid, 'status' => 0,
            'timestart' => 0, 'timeend' => 0, 'modifierid' => 0,
            'timecreated' => time(), 'timemodified' => time(),
        ]);
    }

    /** Minimal valid logstore row. */
    private function log(int $userid, int $courseid, int $time): void {
        global $DB;
        $DB->insert_record('logstore_standard_log', (object) [
            'eventname' => '\\core\\event\\course_viewed', 'component' => 'core',
            'action' => 'viewed', 'target' => 'course', 'crud' => 'r', 'edulevel' => 0,
            'contextid' => 1, 'contextlevel' => 50, 'contextinstanceid' => $courseid,
            'userid' => $userid, 'courseid' => $courseid, 'anonymous' => 0,
            'timecreated' => $time, 'origin' => 'web', 'ip' => '0.0.0.0',
        ]);
    }

    public function test_metrics_risk_band_and_exclusions(): void {
        global $DB;
        $this->resetAfterTest();
        $now = time();

        $course = $this->getDataGenerator()->create_course();
        $coursectx = \context_course::instance($course->id);

        // One assignment in the course (drives missing_submissions).
        $assign = $this->getDataGenerator()->get_plugin_generator('mod_assign')
            ->create_instance(['course' => $course->id]);

        // High-risk student: old activity (>14d), few events (<5), no submission, no grade.
        $high = $this->getDataGenerator()->create_user();
        $this->enrol($high->id, $course->id);
        $this->log($high->id, $course->id, $now - 30 * DAYSECS);
        $this->log($high->id, $course->id, $now - 31 * DAYSECS);
        // A course-0 log for the same user — must never surface in the view.
        $this->log($high->id, 0, $now);

        // Low-risk student: recent + many events, submitted the assignment, good grade.
        $low = $this->getDataGenerator()->create_user();
        $this->enrol($low->id, $course->id);
        for ($i = 0; $i < 6; $i++) {
            $this->log($low->id, $course->id, $now - $i * 60);
        }
        $DB->insert_record('assign_submission', (object) [
            'assignment' => $assign->id, 'userid' => $low->id, 'status' => 'submitted',
            'groupid' => 0, 'attemptnumber' => 0, 'latest' => 1,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        $gi = $DB->insert_record('grade_items', (object) [
            'courseid' => $course->id, 'itemtype' => 'course', 'grademax' => 100,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        $DB->insert_record('grade_grades', (object) [
            'itemid' => $gi, 'userid' => $low->id, 'finalgrade' => 85,
            'timecreated' => $now, 'timemodified' => $now,
        ]);

        // A teacher (staff) on the course — must be excluded from the student view.
        $teacher = $this->getDataGenerator()->create_user();
        $this->enrol($teacher->id, $course->id);
        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher'], '*', MUST_EXIST);
        $DB->insert_record('role_assignments', (object) [
            'roleid' => $teacherrole->id, 'contextid' => $coursectx->id, 'userid' => $teacher->id,
            'timemodified' => $now, 'modifierid' => 0, 'component' => '', 'itemid' => 0, 'sortorder' => 0,
        ]);

        $rows = $DB->get_records('ai_student_engagement', ['courseid' => $course->id]);
        $byuser = [];
        foreach ($rows as $r) {
            $byuser[(int) $r->userid] = $r;
        }

        // Staff excluded.
        $this->assertArrayNotHasKey((int) $teacher->id, $byuser);

        // High-risk student.
        $this->assertArrayHasKey((int) $high->id, $byuser);
        $h = $byuser[(int) $high->id];
        $this->assertSame('high', $h->risk_band);
        $this->assertSame(2, (int) $h->activity_count);
        $this->assertSame(1, (int) $h->missing_submissions);
        $this->assertGreaterThanOrEqual(29, (int) $h->last_activity_days);
        $this->assertNull($h->avg_grade);

        // Low-risk student.
        $l = $byuser[(int) $low->id];
        $this->assertSame('low', $l->risk_band);
        $this->assertSame(6, (int) $l->activity_count);
        $this->assertSame(0, (int) $l->missing_submissions);
        $this->assertEquals(85.0, (float) $l->avg_grade);

        // courseid = 0 never appears, even unscoped.
        $this->assertSame(0, $DB->count_records('ai_student_engagement', ['courseid' => 0]));

        // Only safe identity columns exist.
        $this->assertTrue(property_exists($h, 'firstname'));
        $this->assertTrue(property_exists($h, 'lastname'));
        $this->assertFalse(property_exists($h, 'username'));
        $this->assertFalse(property_exists($h, 'email'));
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/student_engagement_view_test.php`
Expected: FAIL — class `student_engagement_view` not found.

- [ ] **Step 3: Write the view DDL holder**

Create `local/ai_analysis/classes/db/student_engagement_view.php`:

```php
<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_student_engagement` view. Grain: one row
 * per (course, student) where student = active enrolment that is NOT course
 * staff (excluded via mdl_ai_course_staff). courseid = 0 (system context) is
 * unconditionally excluded — never appears, even in a site-wide query. The
 * view aggregates logstore activity, assignment submissions, and course grades
 * into flat metrics + a transparent risk_band, all internal to the view so the
 * AI/validator only see flat columns. Created by db/install.php (real installs)
 * and db/upgrade.php; skipped under PHPUNIT (a non-updatable aggregate view
 * breaks reset_database()) — tests create/drop it per-class.
 */
class student_engagement_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_student_engagement';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_student_engagement AS
SELECT m.courseid, m.userid, m.firstname, m.lastname,
       m.last_activity_days, m.activity_count, m.missing_submissions, m.avg_grade,
       CASE WHEN m.badcount >= 3 THEN 'high'
            WHEN m.badcount >= 1 THEN 'medium'
            ELSE 'low' END AS risk_band
FROM (
    SELECT e.courseid AS courseid,
           u.id AS userid,
           u.firstname AS firstname,
           u.lastname AS lastname,
           CASE WHEN act.last_activity IS NULL THEN NULL
                ELSE DATEDIFF(NOW(), FROM_UNIXTIME(act.last_activity)) END AS last_activity_days,
           COALESCE(act.activity_count, 0) AS activity_count,
           COALESCE(asg.total_assigns, 0) - COALESCE(sub.submitted, 0) AS missing_submissions,
           grd.avg_grade AS avg_grade,
           ( CASE WHEN act.last_activity IS NULL
                       OR DATEDIFF(NOW(), FROM_UNIXTIME(act.last_activity)) > 14 THEN 1 ELSE 0 END
           + CASE WHEN COALESCE(asg.total_assigns, 0) - COALESCE(sub.submitted, 0) > 0 THEN 1 ELSE 0 END
           + CASE WHEN grd.avg_grade IS NOT NULL AND grd.avg_grade < 40 THEN 1 ELSE 0 END
           + CASE WHEN COALESCE(act.activity_count, 0) < 5 THEN 1 ELSE 0 END ) AS badcount
    FROM {$p}user_enrolments ue
    JOIN {$p}enrol e ON e.id = ue.enrolid AND e.status = 0
    JOIN {$p}user u ON u.id = ue.userid
    LEFT JOIN (
        SELECT userid, courseid, COUNT(*) AS activity_count, MAX(timecreated) AS last_activity
        FROM {$p}logstore_standard_log
        WHERE courseid > 0
        GROUP BY userid, courseid
    ) act ON act.userid = u.id AND act.courseid = e.courseid
    LEFT JOIN (
        SELECT course, COUNT(*) AS total_assigns FROM {$p}assign GROUP BY course
    ) asg ON asg.course = e.courseid
    LEFT JOIN (
        SELECT a.course AS course, s.userid AS userid, COUNT(*) AS submitted
        FROM {$p}assign a
        JOIN {$p}assign_submission s ON s.assignment = a.id AND s.status = 'submitted'
        GROUP BY a.course, s.userid
    ) sub ON sub.course = e.courseid AND sub.userid = u.id
    LEFT JOIN (
        SELECT gi.courseid AS courseid, gg.userid AS userid, AVG(gg.finalgrade) AS avg_grade
        FROM {$p}grade_items gi
        JOIN {$p}grade_grades gg ON gg.itemid = gi.id
        WHERE gi.itemtype = 'course'
        GROUP BY gi.courseid, gg.userid
    ) grd ON grd.courseid = e.courseid AND grd.userid = u.id
    WHERE ue.status = 0
      AND e.courseid > 0
      AND NOT EXISTS (
          SELECT 1 FROM {$p}ai_course_staff cs
          WHERE cs.courseid = e.courseid AND cs.userid = u.id
      )
) m";
    }

    /** Create (or replace) the view. Requires mdl_ai_course_staff to already exist. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
```

- [ ] **Step 4: Wire into install.php (after the staff view)**

In `local/ai_analysis/db/install.php`, inside the existing `if (!defined('PHPUNIT_TEST') || !PHPUNIT_TEST) { ... }` block, add the engagement view creation immediately AFTER the existing `course_staff_view::create($DB);` line (order matters — engagement references the staff view):

```php
        \local_ai_analysis\db\course_staff_view::create($DB);
        \local_ai_analysis\db\student_engagement_view::create($DB);
```

- [ ] **Step 5: Add the upgrade step + bump version**

In `local/ai_analysis/db/upgrade.php`, add a new block before `return true;`:

```php
    if ($oldversion < 2026061202) {
        // Sub-project B1: create the read-only student-engagement view.
        \local_ai_analysis\db\student_engagement_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061202, 'local', 'ai_analysis');
    }
```

In `local/ai_analysis/version.php`, set `$plugin->version = 2026061202;` and `$plugin->release = '0.10.0';`.

- [ ] **Step 6: Add the RO grant**

In `local/ai_analysis/db/readonly_grants.sql`, add after the `mdl_ai_course_staff` GRANT line:

```sql
GRANT SELECT ON moodle.mdl_ai_student_engagement TO 'moodle_ai_ro'@'%';
```

- [ ] **Step 7: Apply to the test DB, then run the test**

Run: `docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php`
(regenerates the shared phpunit cache + reinstalls plugins — expected; this verifies install/upgrade wiring even though the test creates the view itself)
Then: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/student_engagement_view_test.php`
Expected: PASS.

IMPORTANT: do NOT weaken assertions or fake the view. If `risk_band`/metric values are off, fix the view DDL (the aggregation or the badcount CASE arithmetic), not the test. If the view creation errors because `mdl_ai_course_staff` is missing, confirm `course_staff_view::create()` runs in setUp BEFORE `student_engagement_view::create()`. If a metric like `last_activity_days` is off-by-one due to DATEDIFF/clock, the test already allows `>= 29`; keep assertions tolerant only where genuinely clock-dependent, never for risk_band/counts. Report any DDL change you make.

- [ ] **Step 8: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/db/student_engagement_view.php local/ai_analysis/db/install.php local/ai_analysis/db/upgrade.php local/ai_analysis/db/readonly_grants.sql local/ai_analysis/version.php local/ai_analysis/tests/student_engagement_view_test.php
git commit -m "feat(ai_analysis): read-only student-engagement view (metrics + risk_band)"
```

Commit rule: NO Co-Authored-By / Claude / Anthropic signature lines. Plain message only.

---

## Task 2: Expose the view in the manifest

**Files:** Modify `classes/manifest/manifest_builder.php`; Test `tests/manifest_builder_test.php` (append).

- [ ] **Step 1: Append the failing test**

Add inside `class manifest_builder_test`:

```php
    public function test_manifest_includes_student_engagement_view(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_student_engagement', $manifest);
        $this->assertSame(
            ['courseid', 'userid', 'firstname', 'lastname', 'last_activity_days',
             'activity_count', 'missing_submissions', 'avg_grade', 'risk_band'],
            $manifest['mdl_ai_student_engagement']
        );
    }

    public function test_engagement_view_gets_scope_note_for_scoped_teacher(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 88);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_student_engagement']);
        $this->assertStringContainsString('88', $manifest['mdl_ai_student_engagement']['_scope_note']);
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: FAIL — key missing. (If `test_admin_returns_full_manifest` lists expected keys, it will also fail — update it in Step 3.)

- [ ] **Step 3: Implement**

In `classes/manifest/manifest_builder.php`, add to `$FULL_MANIFEST` after the `mdl_ai_course_staff` line:

```php
        'mdl_ai_student_engagement' => ['courseid', 'userid', 'firstname', 'lastname', 'last_activity_days', 'activity_count', 'missing_submissions', 'avg_grade', 'risk_band'],
```

Inside the `if ($role !== 'admin' && $courseid > 0)` block, after the `mdl_ai_course_staff` scope-note:

```php
            $manifest['mdl_ai_student_engagement']['_scope_note'] =
                'Per-student engagement metrics + risk_band (high/medium/low) for a course; always filter WHERE courseid = ' . $courseid;
```

If `test_admin_returns_full_manifest` (or similar) asserts an exact key list, add `'mdl_ai_student_engagement'` to its expected list too.

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/manifest/manifest_builder.php local/ai_analysis/tests/manifest_builder_test.php
git commit -m "feat(ai_analysis): allow-list student-engagement view in manifest"
```

Commit rule: plain message, no signatures.

---

## Task 3: PII classification for the view's name columns

**Files:** Modify `classes/security/pii_scrubber.php`; Test `tests/pii_scrubber_test.php` (append).

- [ ] **Step 1: Append the failing test**

```php
    public function test_student_engagement_view_names_are_pii(): void {
        $this->assertTrue(
            \local_ai_analysis\security\pii_scrubber::is_pii('mdl_ai_student_engagement.firstname')
        );
        $this->assertTrue(
            \local_ai_analysis\security\pii_scrubber::is_pii('mdl_ai_student_engagement.lastname')
        );
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/pii_scrubber_test.php`
Expected: FAIL.

- [ ] **Step 3: Implement**

In `classes/security/pii_scrubber.php` `PII_MAP`, after the `mdl_ai_course_staff.*` entries:

```php
        'mdl_ai_student_engagement.firstname' => 'PERSON',
        'mdl_ai_student_engagement.lastname'  => 'PERSON',
```

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/pii_scrubber_test.php`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/security/pii_scrubber.php local/ai_analysis/tests/pii_scrubber_test.php
git commit -m "feat(ai_analysis): treat student-engagement view names as PII"
```

Commit rule: plain message, no signatures.

---

## Task 4: at_risk_students intent (classifier + synonyms)

**Files:** Modify `classes/intent/synonym_dictionary.php`, `classes/intent/intent_registry.php`; Test `tests/intent_classifier_test.php` (append).

- [ ] **Step 1: Append the failing tests**

```php
    /**
     * @dataProvider risk_phrasings
     */
    public function test_risk_phrasings_classify_as_at_risk_students(string $prompt): void {
        $this->assertSame('at_risk_students', intent_classifier::classify($prompt));
    }

    public static function risk_phrasings(): array {
        return [
            ['students at risk'],
            ['at risk students'],
            ['who is at risk'],
            ['struggling students'],
            ['show at risk students'],
        ];
    }

    public function test_risk_does_not_collide_with_listing_or_staff(): void {
        $this->assertSame('student_listing', intent_classifier::classify('list students'));
        $this->assertSame('course_staff', intent_classifier::classify('who teaches this course'));
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: FAIL — risk phrasings return null.

- [ ] **Step 3a: Extend the synonym dictionary**

In `classes/intent/synonym_dictionary.php` `MAP`, add (before the closing `];`):

```php
        // risk family
        'risk'        => 'risk',
        'struggling'  => 'risk',
        'disengaged'  => 'risk',
        'failing'     => 'risk',
```

- [ ] **Step 3b: Add the at_risk_students registry entry**

In `classes/intent/intent_registry.php`, add a third entry to the array returned by `all()` (after `course_staff`):

```php
            [
                'id'       => 'at_risk_students',
                'requires' => ['risk'],
                'any_of'   => ['students', 'list', 'enrolled'],
                'none_of'  => ['staff'],
            ],
```

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: PASS. Note: `risk` was already a `none_of` disqualifier for `student_listing` and `course_staff`, so "students at risk" correctly stops matching those and matches `at_risk_students`. If an existing student/staff data-provider case breaks, the logic is wrong — fix code, not tests. ('failing' now maps to 'risk'; if an existing test asserted a 'failing'/'failed' phrasing returns null, that still holds for student_listing since 'risk' is its disqualifier — verify and report any change.)

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/intent/synonym_dictionary.php local/ai_analysis/classes/intent/intent_registry.php local/ai_analysis/tests/intent_classifier_test.php
git commit -m "feat(ai_analysis): at_risk_students intent + risk synonym family"
```

Commit rule: plain message, no signatures.

---

## Task 5: at_risk_students SQL template

**Files:** Modify `classes/intent/sql_template.php`; Test `tests/sql_template_test.php` (append).

- [ ] **Step 1: Append the failing tests**

```php
    public function test_at_risk_builds_sql_with_bound_courseid(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('at_risk_students', 66);
        $this->assertStringContainsStringIgnoringCase('from mdl_ai_student_engagement', $sql);
        $this->assertStringContainsStringIgnoringCase("risk_band = 'high'", $sql);
        $this->assertSame([66], $params);
    }

    public function test_at_risk_sql_passes_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 66);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('at_risk_students', 66);
        $this->assertTrue($validator->validate($sql, $params));
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: FAIL — coding_exception "Unknown intent template: at_risk_students".

- [ ] **Step 3: Implement**

In `classes/intent/sql_template.php`, add a constant alongside the others:

```php
    /** High-risk students for a course, from the engagement view. */
    private const AT_RISK_SQL =
        'SELECT s.userid, s.firstname, s.lastname, s.last_activity_days, '
        . 's.missing_submissions, s.avg_grade, s.risk_band '
        . 'FROM mdl_ai_student_engagement s '
        . "WHERE s.courseid = ? AND s.risk_band = 'high' "
        . 'ORDER BY s.last_activity_days DESC '
        . 'LIMIT 1000';
```

And add a `case` before `default`:

```php
            case 'at_risk_students':
                return [self::AT_RISK_SQL, [$courseid]];
```

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: PASS, including `test_at_risk_sql_passes_validator`.

IMPORTANT: if the validator rejects it, fix the template SQL to be manifest-legal against `mdl_ai_student_engagement` (columns: courseid, userid, firstname, lastname, last_activity_days, activity_count, missing_submissions, avg_grade, risk_band) — do NOT weaken the test/validator. Note `risk_band = 'high'` is a literal string comparison, and `ORDER BY ... DESC` on an allow-listed column; both are validator-legal (the student_listing/course_staff templates use the same shapes). Report any change.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/intent/sql_template.php local/ai_analysis/tests/sql_template_test.php
git commit -m "feat(ai_analysis): at_risk_students SQL template over engagement view"
```

Commit rule: plain message, no signatures.

---

## Task 6: End-to-end at-risk fast-path (gateway test)

**Files:** Modify `tests/external_query_test.php`. No production code change (the gateway already routes matched intents).

- [ ] **Step 1: Augment the view lifecycle in setUp/tearDown**

`external_query_test` already creates/drops `mdl_ai_course_staff` in setUp/tearDown (from sub-project C). Add the engagement view alongside it.

In `setUp()`, immediately AFTER the existing `course_staff_view::create($DB);` line, add:
```php
        \local_ai_analysis\db\student_engagement_view::create($DB);
```
(If setUp references the class by FQN inline, use `\local_ai_analysis\db\student_engagement_view::create($DB);`.)

In `tearDown()`, BEFORE the existing staff-view DROP, add (drop dependent view first):
```php
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . \local_ai_analysis\db\student_engagement_view::VIEW);
```

- [ ] **Step 2: Append the failing/confirming test**

```php
    public function test_at_risk_fast_path_serves_without_calling_ai(): void {
        global $DB;
        // Seed one clearly high-risk student: enrolled, no activity, no submissions, no grade.
        $inst = $DB->get_record('enrol', ['courseid' => $this->course->id, 'enrol' => 'manual'], '*', MUST_EXIST);
        $student = $this->getDataGenerator()->create_user();
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $inst->id, 'userid' => $student->id, 'status' => 0,
            'timestart' => 0, 'timeend' => 0, 'modifierid' => 0,
            'timecreated' => time(), 'timemodified' => time(),
        ]);
        // An assignment so missing_submissions > 0 (pushes risk to high).
        $this->getDataGenerator()->get_plugin_generator('mod_assign')
            ->create_instance(['course' => $this->course->id]);

        $resp = $this->call('students at risk');

        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertGreaterThanOrEqual(1, $resp['row_count']);
        $this->assertSame(0, $this->stub->call_count); // no LLM call

        $audit = $DB->get_record('local_ai_analysis_audit', ['userid' => $this->teacher->id], '*', MUST_EXIST);
        $this->assertSame('template', $audit->provider);
    }
```

- [ ] **Step 3: Run the gateway test file**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: PASS — all tests, including the new at-risk one (the seeded student has no activity + a missing submission → risk_band 'high' → returned). If empty, confirm the engagement view is created in setUp AFTER the staff view, and that the seeded student is genuinely high-risk (no logs, missing submission). Do NOT modify production code.

- [ ] **Step 4: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/tests/external_query_test.php
git commit -m "test(ai_analysis): end-to-end at_risk_students fast-path through the gateway"
```

Commit rule: plain message, no signatures.

---

## Task 7: Docs + INSTALL + full suite

**Files:** Modify `INSTALL.md`, `docs/ai-memory/02,03,04`.

- [ ] **Step 1: Full suite**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite`
Expected: OK — all tests pass (the 2 pre-existing risky print-output warnings in `purge_audit_task_test` are fine). Report only real FAILures. Record the total count.

- [ ] **Step 2: INSTALL.md**

Add a note that `db/readonly_grants.sql` now also grants SELECT on `mdl_ai_student_engagement`; the view is auto-created by install/upgrade, only the GRANT is manual.

- [ ] **Step 3: ai-memory docs**

- `02-features-log.md`: add "Sub-project B1 — Student Engagement & Risk View": the `mdl_ai_student_engagement` view (grain = enrolled non-staff students, courseid>0 only; metrics last_activity_days/activity_count/missing_submissions/avg_grade; transparent risk_band high/medium/low with thresholds >14d / >0 missing / <40 grade / <5 events, 3+ bad = high); reuses C's staff view to exclude teachers; `classes/db/student_engagement_view.php`; install/upgrade (2026061202) + RO grant; manifest + scope-note; `at_risk_students` template + risk synonyms; pii_scrubber covers names; live-view now, metric-table-later scale path; tests create both views per-class; version 2026061202 / 0.10.0; full suite count.
- `04-current-state.md`: under Done add B1; version 2026061202 / 0.10.0; test count; manifest section now "14 tables + 2 views"; note the documented scale path (materialized metric table + scheduled task) for when logstore aggregation gets slow; remaining roadmap: B2 (course performance), B3 (feedback), D (memory).
- `03-decisions.md`: record B1 decisions (4 signals raw + transparent risk_band; student = enrolled minus staff; courseid=0 unconditionally excluded; live view in v1, metric table later; $DB->execute for DDL; per-test create/drop, install PHPUNIT-skip).

- [ ] **Step 4: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/INSTALL.md local/ai_analysis/docs/ai-memory/
git commit -m "docs(ai_analysis): record sub-project B1 (engagement view); bump to 0.10.0"
```

Commit rule: plain message, no signatures.

---

## Self-Review

- **Spec coverage:** view with 4 metrics + risk_band (T1) ✓; student = enrolled minus staff via C's view (T1) ✓; courseid=0 unconditionally excluded + tested (T1 `WHERE e.courseid > 0` + count_records assertion) ✓; transparent risk_band thresholds (T1 badcount CASE) ✓; only firstname/lastname exposed + tested (T1) ✓; view ownership + PHPUNIT-skip + per-test create/drop + dependency order staff-before-engagement (T1, T6) ✓; RO grant (T1) ✓; manifest + scope-note (T2) ✓; PII (T3) ✓; at_risk_students intent + risk synonyms, composes with existing disqualifier (T4) ✓; template passes validator (T5) ✓; gateway e2e no-AI provider=template (T6) ✓; live-view/metric-table decision documented (T7) ✓; docs/INSTALL (T7) ✓.
- **Placeholders:** none — full code in every step.
- **Type consistency:** `student_engagement_view::definition_sql(string): string`, `::create(\moodle_database): void`, `::VIEW = 'ai_student_engagement'`; manifest key `mdl_ai_student_engagement` with the 9-column list used identically in T2 + T5; intent id `at_risk_students`; template positional `?`; PII keys `mdl_ai_student_engagement.firstname/lastname`; version `2026061202` identical in upgrade guard + version.php. Engagement view depends on `course_staff_view` (created first in install + every test setUp).
