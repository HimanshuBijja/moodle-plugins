# Sprint 8 (A) — Intent → SQL Templates Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a deterministic, zero-LLM fast-path that serves the `student_listing` intent from a hand-written parameterized SQL template, falling through to the existing AI pipeline for everything else.

**Architecture:** A new `classes/intent/` package (synonym dictionary → normalizer → declarative intent registry → classifier → SQL template). `classes/external/query.php` consults the classifier after rate-limiting; a confident match builds template SQL that still passes through the existing `sql_validator` → `query_executor` → `audit_writer`. Route is recorded by reusing the audit `provider` column (`'template'`). Unknown questions are routed to the unchanged AI path.

**Tech Stack:** PHP 8.1, Moodle 4.5 external API, PHPUnit (Docker), greenlion/php-sql-parser (via existing `sql_validator`).

**Spec:** `docs/superpowers/specs/2026-06-11-sprint8-intent-sql-templates-design.md`

---

## File Structure

| File | Responsibility |
|---|---|
| `classes/intent/synonym_dictionary.php` (new) | Surface term → canonical token map; `canonicalize()` one token. |
| `classes/intent/query_normalizer.php` (new) | Lowercase/strip/split a prompt → array of canonical tokens (uses dictionary). |
| `classes/intent/intent_registry.php` (new) | Declarative intent definitions (`requires`/`any_of`/`none_of`). Data only. |
| `classes/intent/intent_classifier.php` (new) | Normalize a prompt, match against registry, return intent id or `null`. Never throws. |
| `classes/intent/sql_template.php` (new) | Map an intent id + courseid → `[sql, params]`. |
| `classes/external/query.php` (modify) | Insert fast-path branch after manifest build; set `provider='template'`. |
| `tests/intent_classifier_test.php` (new) | Normalizer + dictionary + classifier behavior. |
| `tests/sql_template_test.php` (new) | Template SQL/params correctness + passes `sql_validator`. |
| `tests/external_query_test.php` (modify) | Fast-path serves without AI; unknown falls through; audit `provider='template'`. |
| `version.php` (modify) | Version bump. |
| `docs/ai-memory/02-features-log.md`, `04-current-state.md`, `03-decisions.md` (modify) | Record the feature. |

---

## Task 1: Synonym dictionary + query normalizer

**Files:**
- Create: `classes/intent/synonym_dictionary.php`
- Create: `classes/intent/query_normalizer.php`
- Test: `tests/intent_classifier_test.php`

- [ ] **Step 1: Write the failing test**

Create `tests/intent_classifier_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\intent\query_normalizer;
use local_ai_analysis\intent\intent_classifier;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\intent\query_normalizer
 * @covers \local_ai_analysis\intent\synonym_dictionary
 * @covers \local_ai_analysis\intent\intent_classifier
 */
class intent_classifier_test extends \advanced_testcase {

    public function test_normalizer_lowercases_strips_and_maps_synonyms(): void {
        // "Show" -> list, "pupils" -> students, punctuation stripped.
        $tokens = query_normalizer::normalize('Show me the Pupils!');
        $this->assertContains('list', $tokens);
        $this->assertContains('students', $tokens);
    }

    public function test_normalizer_maps_context_words(): void {
        // "current" and "course" both canonicalize to the context token "enrolled".
        $tokens = query_normalizer::normalize('current course students');
        $this->assertContains('students', $tokens);
        $this->assertContains('enrolled', $tokens);
    }

    public function test_normalizer_leaves_unknown_tokens_intact(): void {
        $tokens = query_normalizer::normalize('students in DBMS');
        $this->assertContains('students', $tokens);
        $this->assertContains('dbms', $tokens);
        // No list-verb and no context word present.
        $this->assertNotContains('list', $tokens);
        $this->assertNotContains('enrolled', $tokens);
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: FAIL — class `query_normalizer` not found.

- [ ] **Step 3: Write the synonym dictionary**

Create `classes/intent/synonym_dictionary.php`:

```php
<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Surface-term → canonical-token map for deterministic intent matching.
 * Same hardcoded-array pattern as manifest_builder: a single source of truth,
 * never derived from live data.
 */
class synonym_dictionary {

    /** @var array<string,string> surface token => canonical token */
    private const MAP = [
        // students-noun family
        'student'   => 'students',
        'students'  => 'students',
        'pupil'     => 'students',
        'pupils'    => 'students',
        'learner'   => 'students',
        'learners'  => 'students',
        // list-verb family
        'list'      => 'list',
        'show'      => 'list',
        'get'       => 'list',
        'display'   => 'list',
        'give'      => 'list',
        'view'      => 'list',
        'see'       => 'list',
        'all'       => 'list',
        // course-context family
        'enrolled'  => 'enrolled',
        'enrol'     => 'enrolled',
        'enrolment' => 'enrolled',
        'course'    => 'enrolled',
        'class'     => 'enrolled',
        'current'   => 'enrolled',
        'this'      => 'enrolled',
        'here'      => 'enrolled',
    ];

    /** Canonicalize a single lowercase token; unknown tokens pass through unchanged. */
    public static function canonicalize(string $token): string {
        return self::MAP[$token] ?? $token;
    }
}
```

- [ ] **Step 4: Write the query normalizer**

Create `classes/intent/query_normalizer.php`:

```php
<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Turns a free-text prompt into a list of canonical tokens for classification.
 * Used ONLY for intent matching — the AI fallback still receives the original
 * sanitised prompt, so this can never change AI-path behaviour.
 */
class query_normalizer {

    /**
     * @param string $prompt sanitised user prompt
     * @return string[] canonical tokens (order preserved, may contain duplicates)
     */
    public static function normalize(string $prompt): array {
        $lower = \core_text::strtolower($prompt);
        // Replace any non-alphanumeric run with a single space, then split.
        $clean = preg_replace('/[^a-z0-9]+/', ' ', $lower);
        $raw = preg_split('/\s+/', trim($clean), -1, PREG_SPLIT_NO_EMPTY);
        $tokens = [];
        foreach ($raw as $t) {
            $tokens[] = synonym_dictionary::canonicalize($t);
        }
        return $tokens;
    }
}
```

- [ ] **Step 5: Run the normalizer tests**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: the three `test_normalizer_*` tests PASS (the classifier tests added in Task 2 do not exist yet).

- [ ] **Step 6: Commit**

```bash
git add local/ai_analysis/classes/intent/synonym_dictionary.php local/ai_analysis/classes/intent/query_normalizer.php local/ai_analysis/tests/intent_classifier_test.php
git commit -m "feat(ai_analysis): synonym dictionary + query normalizer for intent matching"
```

---

## Task 2: Intent registry + classifier

**Files:**
- Create: `classes/intent/intent_registry.php`
- Create: `classes/intent/intent_classifier.php`
- Test: `tests/intent_classifier_test.php` (append)

- [ ] **Step 1: Write the failing tests**

Append these methods inside `class intent_classifier_test` in `tests/intent_classifier_test.php`:

```php
    /**
     * @dataProvider listing_phrasings
     */
    public function test_listing_phrasings_classify_as_student_listing(string $prompt): void {
        $this->assertSame('student_listing', intent_classifier::classify($prompt));
    }

    public static function listing_phrasings(): array {
        return [
            ['list students'],
            ['students list'],
            ['show students'],
            ['show me the students'],
            ['current course students'],
            ['all students'],
            ['list enrolled students'],
        ];
    }

    /**
     * @dataProvider non_matching_phrasings
     */
    public function test_non_matching_prompts_return_null(string $prompt): void {
        $this->assertNull(intent_classifier::classify($prompt));
    }

    public static function non_matching_phrasings(): array {
        return [
            ['failed students'],          // grade qualifier disqualifies
            ['students who failed'],
            ['top students by marks'],
            ['who submitted assignment 3'], // submission terms, no students-noun
            ['students in DBMS'],          // named course: no list-verb, no context word
            ['what is the meaning of life'],
            ['what is this course'],       // no students-noun
        ];
    }
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: FAIL — class `intent_classifier` not found.

- [ ] **Step 3: Write the intent registry**

Create `classes/intent/intent_registry.php`:

```php
<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Declarative catalogue of known intents. Data only — the matching algorithm
 * lives in intent_classifier. Each entry is matched against the canonical token
 * SET produced by query_normalizer:
 *   - requires : every token must be present
 *   - any_of   : at least one token must be present
 *   - none_of  : no token may be present (disqualifiers)
 * Adding an intent later = one new entry here + one branch in sql_template.
 */
class intent_registry {

    /** @return array<int,array{id:string,requires:string[],any_of:string[],none_of:string[]}> */
    public static function all(): array {
        return [
            [
                'id'       => 'student_listing',
                'requires' => ['students'],
                'any_of'   => ['list', 'enrolled'],
                'none_of'  => [
                    // grade qualifiers
                    'failed', 'fail', 'passed', 'pass', 'grade', 'grades',
                    'mark', 'marks', 'score', 'scores', 'below', 'above',
                    'top', 'best', 'worst', 'lowest', 'highest', 'risk',
                    // submission/activity qualifiers
                    'submitted', 'submission', 'submissions',
                    'assignment', 'assignments', 'quiz', 'quizzes',
                ],
            ],
        ];
    }
}
```

- [ ] **Step 4: Write the classifier**

Create `classes/intent/intent_classifier.php`:

```php
<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Deterministic keyword/synonym intent classifier. Returns a known intent id
 * for a confident match, or null to signal "fall through to the AI pipeline".
 * Never throws — any internal anomaly resolves to null (no exceptions to AJAX).
 */
class intent_classifier {

    /** @return string|null intent id, or null when no intent confidently matches */
    public static function classify(string $prompt): ?string {
        try {
            $tokens = array_flip(query_normalizer::normalize($prompt));
            foreach (intent_registry::all() as $intent) {
                if (self::matches($tokens, $intent)) {
                    return $intent['id'];
                }
            }
        } catch (\Throwable $e) {
            debugging('intent classify failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
        return null;
    }

    /** @param array<string,int> $tokens canonical token => any value (set membership) */
    private static function matches(array $tokens, array $intent): bool {
        foreach ($intent['requires'] as $t) {
            if (!isset($tokens[$t])) {
                return false;
            }
        }
        foreach ($intent['none_of'] as $t) {
            if (isset($tokens[$t])) {
                return false;
            }
        }
        if (empty($intent['any_of'])) {
            return true;
        }
        foreach ($intent['any_of'] as $t) {
            if (isset($tokens[$t])) {
                return true;
            }
        }
        return false;
    }
}
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: PASS — all normalizer + classifier tests green.

- [ ] **Step 6: Commit**

```bash
git add local/ai_analysis/classes/intent/intent_registry.php local/ai_analysis/classes/intent/intent_classifier.php local/ai_analysis/tests/intent_classifier_test.php
git commit -m "feat(ai_analysis): declarative intent registry + deterministic classifier"
```

---

## Task 3: SQL template builder

**Files:**
- Create: `classes/intent/sql_template.php`
- Test: `tests/sql_template_test.php`

- [ ] **Step 1: Write the failing test**

Create `tests/sql_template_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\intent\sql_template;
use local_ai_analysis\manifest\manifest_builder;
use local_ai_analysis\security\sql_validator;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\intent\sql_template
 */
class sql_template_test extends \advanced_testcase {

    public function test_student_listing_builds_sql_with_bound_courseid(): void {
        [$sql, $params] = sql_template::build('student_listing', 42);
        $this->assertStringContainsStringIgnoringCase('from mdl_user', $sql);
        $this->assertStringContainsStringIgnoringCase('mdl_user_enrolments', $sql);
        $this->assertStringContainsStringIgnoringCase('mdl_enrol', $sql);
        $this->assertSame([42], $params);
    }

    public function test_student_listing_sql_passes_validator(): void {
        // The manifest the validator uses is the same one the gateway builds.
        $manifest  = manifest_builder::build('editingteacher', 42);
        $validator = new sql_validator($manifest);
        [$sql, $params] = sql_template::build('student_listing', 42);
        // validate() takes $sql by reference and throws on any policy breach.
        $this->assertTrue($validator->validate($sql, $params));
    }

    public function test_unknown_intent_throws(): void {
        $this->expectException(\coding_exception::class);
        sql_template::build('no_such_intent', 1);
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: FAIL — class `sql_template` not found.

- [ ] **Step 3: Write the template builder**

Create `classes/intent/sql_template.php`:

```php
<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Maps a matched intent id (+ slots) to a hand-written, parameterized SELECT.
 * SQL uses the canonical mdl_ prefix (translated to the runtime prefix by the
 * gateway, exactly as for AI SQL) and positional ? params (matching the AI
 * path). Every template is unit-tested to pass sql_validator.
 */
class sql_template {

    /** Active enrolled users for a course. status=0 means an active enrolment. */
    private const STUDENT_LISTING_SQL =
        'SELECT u.id, u.firstname, u.lastname '
        . 'FROM mdl_user u '
        . 'JOIN mdl_user_enrolments ue ON ue.userid = u.id '
        . 'JOIN mdl_enrol e ON e.id = ue.enrolid '
        . 'WHERE e.courseid = ? AND ue.status = 0 AND e.status = 0 '
        . 'ORDER BY u.lastname '
        . 'LIMIT 1000';

    /**
     * @param string $intentid a known intent id from intent_registry
     * @param int $courseid current course context
     * @return array{0:string,1:array} [sql, positional params]
     */
    public static function build(string $intentid, int $courseid): array {
        switch ($intentid) {
            case 'student_listing':
                return [self::STUDENT_LISTING_SQL, [$courseid]];
            default:
                throw new \coding_exception('Unknown intent template: ' . $intentid);
        }
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: PASS — including `test_student_listing_sql_passes_validator` (proves the template is manifest-legal).

- [ ] **Step 5: Commit**

```bash
git add local/ai_analysis/classes/intent/sql_template.php local/ai_analysis/tests/sql_template_test.php
git commit -m "feat(ai_analysis): student_listing SQL template (validator-clean)"
```

---

## Task 4: Wire the fast-path into the gateway

**Files:**
- Modify: `classes/external/query.php`
- Test: `tests/external_query_test.php` (append)

- [ ] **Step 1: Write the failing tests**

Append these methods inside `class external_query_test` in `tests/external_query_test.php`:

```php
    public function test_template_fast_path_serves_without_calling_ai(): void {
        global $DB;
        // Enrol two extra students; the teacher (from setUp) is also enrolled,
        // so the enrolment-based listing returns 3 rows (documented v1 caveat:
        // "students" = active enrolled users, incl. the teacher).
        $s1 = $this->getDataGenerator()->create_user();
        $s2 = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($s1->id, $this->course->id, 'student');
        $this->getDataGenerator()->enrol_user($s2->id, $this->course->id, 'student');

        $resp = $this->call('list students');

        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertSame(3, $resp['row_count']);
        // The whole point: no LLM call happened.
        $this->assertSame(0, $this->stub->call_count);

        $audit = $DB->get_record('local_ai_analysis_audit', ['userid' => $this->teacher->id], '*', MUST_EXIST);
        $this->assertSame('SUCCESS', $audit->status);
        $this->assertSame('template', $audit->provider);
    }

    public function test_unknown_prompt_falls_through_to_ai(): void {
        $this->stub->next_result = ['type' => 'out_of_scope', 'message' => 'not in schema'];
        $resp = $this->call('what is the meaning of life');
        $this->assertSame('OUT_OF_SCOPE', $resp['status']);
        // Fallback path was used: the AI client WAS called exactly once.
        $this->assertSame(1, $this->stub->call_count);
    }
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: FAIL — `test_template_fast_path_*` fails (AI stub is still called / provider is not `template`).

- [ ] **Step 3: Add the imports**

In `classes/external/query.php`, add to the `use` block (after the other `local_ai_analysis\...` imports near line 20):

```php
use local_ai_analysis\intent\intent_classifier;
use local_ai_analysis\intent\sql_template;
```

- [ ] **Step 4: Insert the fast-path branch**

In `classes/external/query.php`, replace this existing block (the manifest build through the AI loop preamble, currently lines ~145–176):

```php
        // L3: manifest + system prompt.
        $manifest = manifest_builder::build($role, $courseid);
        $system   = prompt_builder::build_system($manifest, $role, $courseid, time());

        // Build multi-turn context: keep the last N turns, re-sanitise each prior
        // prompt, and silently drop any that fail (history is best-effort context,
        // never fatal). Every generated SQL is still validated downstream, so a
        // forged history cannot widen access.
        $clean_history = [];
        foreach (array_slice($history, -self::MAX_HISTORY_TURNS) as $turn) {
            try {
                $hp = prompt_builder::sanitise_user_prompt((string) ($turn['prompt'] ?? ''));
            } catch (\moodle_exception $e) {
                continue;
            }
            $clean_history[] = ['prompt' => $hp, 'sql' => (string) ($turn['sql'] ?? '')];
        }

        // L4 + L5: generate then validate, with one self-correction retry. Weak
        // models sometimes reference a table/column outside the manifest (e.g. an
        // invented mdl_enrolment_status). Feeding the validator's rejection reason
        // back as a corrective turn usually recovers a valid query without a
        // user-visible failure. Every attempt is still validated, so this never
        // weakens the allow-list.
        $provider      = get_config('local_ai_analysis', 'provider') ?: 'claude';
        $cur_prompt    = $prompt;
        $retry_history = $clean_history;
        $sql           = '';
        $bound_params  = [];
        $validator     = new sql_validator($manifest);
        $attempt       = 0;
        while (true) {
```

with the following. The validator is built before the branch; a deterministic fast-path runs first and, on a match, skips the AI loop entirely; the AI loop is nested under `else`; `$ai` is initialised to `null`:

```php
        // L3: manifest.
        $manifest  = manifest_builder::build($role, $courseid);
        $validator = new sql_validator($manifest);

        // L4a: deterministic intent fast-path. A known intent is served by a
        // hand-written template with NO AI call; unknown questions fall through
        // to the AI pipeline below. Template SQL still passes through the same
        // validator + executor + audit, so no security guarantee is bypassed.
        $ai       = null;
        $provider = get_config('local_ai_analysis', 'provider') ?: 'claude';
        $sql          = '';
        $bound_params = [];

        $intent = intent_classifier::classify($prompt);
        if ($intent !== null) {
            $provider = 'template';
            [$sql, $bound_params] = sql_template::build($intent, $courseid);
            try {
                $validator->validate($sql, $bound_params);
            } catch (validation_exception $e) {
                // A template that fails validation is a bug, not a user error;
                // surface it with the normal envelope rather than masking it.
                audit_writer::write(
                    userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                    sql: $sql, status: 'SQL_INVALID', reason: $e->reason,
                    provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
                );
                return self::error_envelope($request_id, (int) $USER->id, $courseid, 'SQL_INVALID', $e->reason);
            }
        } else {
            // L4 + L5: generate then validate, with one self-correction retry. Weak
            // models sometimes reference a table/column outside the manifest (e.g. an
            // invented mdl_enrolment_status). Feeding the validator's rejection reason
            // back as a corrective turn usually recovers a valid query. Every attempt
            // is still validated, so this never weakens the allow-list.
            $system = prompt_builder::build_system($manifest, $role, $courseid, time());

            // Build multi-turn context: keep the last N turns, re-sanitise each
            // prior prompt, and silently drop any that fail (best-effort context).
            $clean_history = [];
            foreach (array_slice($history, -self::MAX_HISTORY_TURNS) as $turn) {
                try {
                    $hp = prompt_builder::sanitise_user_prompt((string) ($turn['prompt'] ?? ''));
                } catch (\moodle_exception $e) {
                    continue;
                }
                $clean_history[] = ['prompt' => $hp, 'sql' => (string) ($turn['sql'] ?? '')];
            }

            $cur_prompt    = $prompt;
            $retry_history = $clean_history;
            $attempt       = 0;
            while (true) {
```

> **Note for the implementer:** this replacement MOVES the manifest build, the validator construction, the `$provider` lookup, the `$clean_history` foreach, and the `$cur_prompt`/`$retry_history`/`$attempt` setup. Do not leave duplicate copies of any of those lines. The `while (true) {` is now the LAST line of the inserted block and opens the AI loop; the existing loop body (`$attempt++; ...`) that follows is unchanged in logic but is now nested one level deeper inside the `else` — re-indent it (and its closing `}`) by four spaces.

- [ ] **Step 5: Close the else block and guard the chart line**

The AI loop's existing closing `}` (currently ~line 227, just before the chart comment `// Validate the AI-proposed chart spec...`) now needs the `else` block's closing brace too. Add one more `}` immediately after the loop's closing `}` to close the `else`.

Then the chart line must tolerate the template path where `$ai` is `null`. Replace (current ~line 231):

```php
        $chart_spec = self::validate_chart($ai['chart'] ?? null, array_keys($source_map));
```

with:

```php
        $chart_spec = self::validate_chart(($ai !== null ? ($ai['chart'] ?? null) : null), array_keys($source_map));
```

Everything from `$source_map = $validator->get_column_source_map();` onward (execution, links, format, success audit, return) is shared by both paths and needs no further change — the success-path audit already writes `provider: $provider`, which is now `'template'` for fast-path rows.

- [ ] **Step 6: Run the full gateway test file**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: PASS — new fast-path + fallback tests green AND all pre-existing gateway tests still green (the AI path is behaviourally unchanged).

- [ ] **Step 7: Commit**

```bash
git add local/ai_analysis/classes/external/query.php local/ai_analysis/tests/external_query_test.php
git commit -m "feat(ai_analysis): route known intents through deterministic template fast-path"
```

---

## Task 5: Version bump + docs

**Files:**
- Modify: `version.php`
- Modify: `docs/ai-memory/02-features-log.md`, `docs/ai-memory/04-current-state.md`, `docs/ai-memory/03-decisions.md`

- [ ] **Step 1: Bump the version**

In `version.php`, increment `$plugin->version` to `2026061101` and set `$plugin->release` to `'0.8.0'`. (Read the file first; match the existing property style.)

- [ ] **Step 2: Run the whole plugin test suite**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite`
Expected: PASS — all pre-existing tests plus the new `intent_classifier_test`, `sql_template_test`, and the two new gateway tests. Report only failures.

- [ ] **Step 3: Update the ai-memory docs**

- `02-features-log.md`: add a "Sprint 8 (A) — Intent → SQL Templates" entry: new `classes/intent/` package (synonym_dictionary, query_normalizer, intent_registry, intent_classifier, sql_template); fast-path wired into `query.php`; one intent `student_listing` (active-enrolment definition, incl. teacher — caveat); route recorded via audit `provider='template'`; no schema change; new test count.
- `04-current-state.md`: under "Done", add Sprint 8 (A); note version `2026061101 / 0.8.0`; update total test count; note the deferred A-v1 non-goals (grade-filter/submissions/counts/named-course/follow-ups) and that B/C/D follow.
- `03-decisions.md`: record the four locked decisions (deterministic fast-path + AI fallback; keyword/synonym classification, no LLM classifier; current-course slot only; reuse `provider` audit column for route — no migration).

- [ ] **Step 4: Commit**

```bash
git add local/ai_analysis/version.php local/ai_analysis/docs/ai-memory/
git commit -m "docs(ai_analysis): record Sprint 8 (A) intent templates; bump to 0.8.0"
```

---

## Self-Review

- **Spec coverage:** fast-path placement (T4) ✓; new `classes/intent/` components (T1–T3) ✓; `student_listing` template + active-enrolment definition (T3) ✓; current-course slot only (T3/T4) ✓; semantic caveat asserted in a test (T4 `row_count===3`) ✓; audit `provider='template'`, no migration (T4) ✓; never-throws classifier (T2) ✓; template still validated (T3 + T4) ✓; out-of-scope non-goals fall through (T2 negative cases + T4 fallback) ✓; testing matrix (T1–T4) ✓; version + docs (T5) ✓.
- **Placeholders:** none — every code step shows complete code.
- **Type consistency:** `intent_classifier::classify(string): ?string`, `sql_template::build(string,int): array`, `query_normalizer::normalize(string): array`, `synonym_dictionary::canonicalize(string): string`, `intent_registry::all(): array` — used consistently across tasks and the gateway edit. Template uses positional `?` params matching the AI path and `validate(string &$sql, array $params): bool`.
