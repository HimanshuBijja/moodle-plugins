# AI Analysis — OpenAI + Gemini Providers Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the AI provider pluggable — add OpenAI and Google Gemini behind `ai_client_interface` so an admin can switch providers from settings with no other behaviour change.

**Architecture:** Introduce an abstract `base_http_ai_client` (template-method) owning the provider-independent request/parse flow (`generate_sql`, `format_result`, fence-strip, POST, SQL-shape parsing). Refactor `claude_client` onto it (its 15 existing tests are the behaviour-preservation net), then add `openai_client` and `gemini_client` as thin subclasses implementing five hooks each. Extend the factory and settings.

**Tech Stack:** PHP 8.1, Moodle 4.5 (`core_external`, `\curl`), PHPUnit, Anthropic / OpenAI Chat Completions / Google Gemini generateContent APIs.

**Spec:** `docs/superpowers/specs/2026-05-30-ai-analysis-providers-design.md`

**Working directory:** `/home/himanshu/moodle-instances/moodle-instance-8092/moodle/local/ai_analysis/`. Paths are relative to this dir unless prefixed `moodle/`. Git runs from repo root `/home/himanshu/moodle-instances/moodle-instance-8092/`.

**Branch:** create off `main` before starting:
```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git checkout main
git checkout -b feat/ai-analysis-providers
```

**Commit signature:** plain `feat(...)`/`refactor(...)` messages — NO Co-Authored-By / Claude / Anthropic trailer (project rule).

**PHPUnit:** always by file path, never `--filter`. Re-init after the version bump in Task 5:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
```

## File structure

New files **bold**; modified plain. Each client has one responsibility: build its provider's request and extract its response text. All shared flow lives in the base.

```
classes/ai/
├── **base_http_ai_client.php**   abstract: generate_sql/format_result/post/strip_fences/model + 5 abstract hooks
├── claude_client.php             refactor: extends base, keep Anthropic hooks only
├── **openai_client.php**          extends base, OpenAI Chat Completions hooks
├── **gemini_client.php**          extends base, Gemini generateContent hooks
└── ai_client_factory.php         add openai + gemini match cases, pass model
settings.php                      provider dropdown options + per-provider key/model
lang/en/local_ai_analysis.php     new setting strings
version.php                       bump
tests/
├── claude_client_test.php        UNCHANGED — must stay green (refactor safety net)
├── **openai_client_test.php**
├── **gemini_client_test.php**
└── **ai_client_factory_test.php**
```

**Shared contracts (consistent across all tasks):**
- `base_http_ai_client` constructor: `(http_transport_interface $transport, string $api_key, string $model = '')`.
- Hooks: `endpoint(): string`, `auth_headers(): array`, `build_sql_payload(string $system, string $user): array`, `build_format_payload(string $user_prompt, array $safe_rows): array`, `extract_text(array $response): string`.
- Each subclass: `protected const DEFAULT_MODEL`; resolve via `$this->model()`.

---

## Task 1: base_http_ai_client + refactor claude_client

**Files:**
- Create: `classes/ai/base_http_ai_client.php`
- Modify: `classes/ai/claude_client.php`
- Test: `tests/claude_client_test.php` (run unchanged)

The strategy: create the base, then rewrite `claude_client` to extend it. The existing 15 `claude_client_test` tests are the contract — they must pass with NO edits. Do not write new tests in this task; the refactor is validated by the existing suite.

- [ ] **Step 1: Create the abstract base** — `classes/ai/base_http_ai_client.php`:

```php
<?php
namespace local_ai_analysis\ai;

use local_ai_analysis\exception\ai_client_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Template-method base for JSON-over-HTTP AI providers. Owns the entire
 * provider-independent flow; concrete providers implement five small hooks.
 * generate_sql()/format_result() are final so the SQL-output parsing cannot
 * drift between providers.
 */
abstract class base_http_ai_client implements ai_client_interface {

    public function __construct(
        protected http_transport_interface $transport,
        protected string $api_key,
        protected string $model = '',
    ) {}

    final public function generate_sql(string $system_prompt, string $user_prompt): array {
        $response = $this->post($this->build_sql_payload($system_prompt, $user_prompt));
        $text     = $this->extract_text($response);
        $stripped = $this->strip_fences($text);
        $decoded  = json_decode($stripped, true);
        if (!is_array($decoded)) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        if (isset($decoded['error']) && is_string($decoded['error'])) {
            return ['type' => 'out_of_scope', 'message' => $decoded['error']];
        }
        if (!isset($decoded['sql']) || !isset($decoded['params']) || !is_array($decoded['params'])) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        return [
            'type'        => 'sql',
            'sql'         => (string) $decoded['sql'],
            'params'      => $decoded['params'],
            'explanation' => (string) ($decoded['explanation'] ?? ''),
        ];
    }

    final public function format_result(string $user_prompt, array $safe_rows): string {
        $response = $this->post($this->build_format_payload($user_prompt, $safe_rows));
        return trim($this->strip_fences($this->extract_text($response)));
    }

    /** POST the JSON-encoded payload; return the decoded response envelope. */
    protected function post(array $payload): array {
        $response = $this->transport->post($this->endpoint(), $this->auth_headers(), json_encode($payload));
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new ai_client_exception('HTTP_' . $response['status'], $response['body']);
        }
        $decoded = json_decode($response['body'], true);
        return is_array($decoded) ? $decoded : [];
    }

    protected function strip_fences(string $text): string {
        $stripped = trim($text);
        $stripped = preg_replace('/^```\w*\s*/i', '', $stripped);
        $stripped = preg_replace('/\s*```\s*$/', '', $stripped);
        return $stripped;
    }

    /** Effective model: explicit config else provider default. */
    protected function model(): string {
        return $this->model !== '' ? $this->model : static::DEFAULT_MODEL;
    }

    abstract protected function endpoint(): string;
    abstract protected function auth_headers(): array;
    abstract protected function build_sql_payload(string $system_prompt, string $user_prompt): array;
    abstract protected function build_format_payload(string $user_prompt, array $safe_rows): array;

    /** Extract assistant text from the decoded response, or '' if the path is absent. */
    abstract protected function extract_text(array $response): string;
}
```

- [ ] **Step 2: Rewrite claude_client to extend the base** — replace the entire body of `classes/ai/claude_client.php` (keep the `<?php`, namespace, `use ai_client_exception`, and `defined('MOODLE_INTERNAL')` guard) with:

```php
<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Anthropic Messages API client. Provider-specific hooks only; all shared
 * request/parse flow lives in base_http_ai_client.
 */
class claude_client extends base_http_ai_client {

    protected const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
    private const ENDPOINT = 'https://api.anthropic.com/v1/messages';
    private const ANTHROPIC_VERSION = '2023-06-01';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::ENDPOINT;
    }

    protected function auth_headers(): array {
        return [
            'x-api-key: ' . $this->api_key,
            'anthropic-version: ' . self::ANTHROPIC_VERSION,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_SQL,
            'system'     => $system_prompt,
            'messages'   => [['role' => 'user', 'content' => $user_prompt]],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_FORMAT,
            'system'     => prompt_builder::build_format_system(),
            'messages'   => [['role' => 'user', 'content' => json_encode([
                'question' => $user_prompt,
                'rows'     => $safe_rows,
            ])]],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['content'][0]['text'] ?? null;
        return is_string($t) ? $t : '';
    }
}
```

- [ ] **Step 3: Run the existing claude tests — must pass unchanged**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/claude_client_test.php`
Expected: `OK (15 tests, ...)`. If any fail, the refactor changed behaviour — fix the base/subclass until green; do NOT edit the tests.

Note on the model assertion: `claude_client_test` constructs `new claude_client($t, 'k')` (no model arg → `''`), and `test_request_body_contains_system_and_user` asserts `model === 'claude-sonnet-4-20250514'`. `model()` returns `DEFAULT_MODEL` for the empty string, so this holds.

- [ ] **Step 4: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git add moodle/local/ai_analysis/classes/ai/base_http_ai_client.php moodle/local/ai_analysis/classes/ai/claude_client.php
git commit -m "refactor(ai_analysis): extract base_http_ai_client; claude_client extends it"
```

---

## Task 2: openai_client (TDD)

**Files:**
- Create: `tests/openai_client_test.php`
- Create: `classes/ai/openai_client.php`

- [ ] **Step 1: Write the failing tests** — `tests/openai_client_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * Fake transport recording the last request and replaying a canned response.
 */
class openai_fake_transport implements http_transport_interface {
    public ?string $last_url = null;
    public ?array $last_headers = null;
    public ?string $last_body = null;
    public array $next_response = ['status' => 200, 'headers' => [], 'body' => ''];

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        $this->last_url = $url;
        $this->last_headers = $headers;
        $this->last_body = $body;
        return $this->next_response;
    }
}

/**
 * @covers \local_ai_analysis\ai\openai_client
 */
class openai_client_test extends \advanced_testcase {

    private function chat_response(string $content): array {
        return ['status' => 200, 'headers' => [], 'body' => json_encode([
            'choices' => [['message' => ['role' => 'assistant', 'content' => $content]]],
        ])];
    }

    public function test_sql_request_targets_chat_endpoint_with_bearer_and_json_mode(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'sk-test');
        $c->generate_sql('SYS', 'USR');
        $this->assertSame('https://api.openai.com/v1/chat/completions', $t->last_url);
        $this->assertContains('Authorization: Bearer sk-test', $t->last_headers);
        $body = json_decode($t->last_body, true);
        $this->assertSame('gpt-4o', $body['model']);
        $this->assertSame(['type' => 'json_object'], $body['response_format']);
        $this->assertSame('system', $body['messages'][0]['role']);
        $this->assertSame('SYS', $body['messages'][0]['content']);
        $this->assertSame('USR', $body['messages'][1]['content']);
    }

    public function test_happy_path_returns_sql_array(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user WHERE id = ? LIMIT 10","params":[5],"explanation":"by id"}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('sql', $r['type']);
        $this->assertSame([5], $r['params']);
    }

    public function test_code_fence_stripped(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response("```json\n{\"sql\":\"SELECT id FROM mdl_user LIMIT 1\",\"params\":[],\"explanation\":\"\"}\n```");
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $this->assertSame('sql', $c->generate_sql('s', 'u')['type']);
    }

    public function test_out_of_scope(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"error":"out_of_scope"}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('out_of_scope', $r['type']);
        $this->assertSame('out_of_scope', $r['message']);
    }

    public function test_http_error_throws(): void {
        $t = new openai_fake_transport();
        $t->next_response = ['status' => 401, 'headers' => [], 'body' => '{"error":"bad key"}'];
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_malformed_throws(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('not json');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_custom_model_used(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k', 'gpt-4o-mini');
        $c->generate_sql('s', 'u');
        $this->assertSame('gpt-4o-mini', json_decode($t->last_body, true)['model']);
    }

    public function test_format_result_returns_prose_without_json_mode(): void {
        $t = new openai_fake_transport();
        $t->next_response = $this->chat_response('PERSON_1 has the top grade.');
        $c = new \local_ai_analysis\ai\openai_client($t, 'k');
        $answer = $c->format_result('who scored highest', [['firstname' => 'PERSON_1']]);
        $this->assertSame('PERSON_1 has the top grade.', $answer);
        $body = json_decode($t->last_body, true);
        $this->assertArrayNotHasKey('response_format', $body);
        $this->assertSame(1024, $body['max_tokens']);
        $this->assertStringContainsString('PERSON_1', $body['messages'][1]['content']);
    }
}
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/openai_client_test.php`
Expected: `Class "local_ai_analysis\ai\openai_client" not found`.

- [ ] **Step 3: Implement** — `classes/ai/openai_client.php`:

```php
<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * OpenAI Chat Completions client. Uses response_format json_object for SQL
 * generation (forces valid JSON); prose mode for formatting.
 */
class openai_client extends base_http_ai_client {

    protected const DEFAULT_MODEL = 'gpt-4o';
    private const ENDPOINT = 'https://api.openai.com/v1/chat/completions';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::ENDPOINT;
    }

    protected function auth_headers(): array {
        return [
            'Authorization: Bearer ' . $this->api_key,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'model'           => $this->model(),
            'max_tokens'      => self::MAX_TOKENS_SQL,
            'response_format' => ['type' => 'json_object'],
            'messages'        => [
                ['role' => 'system', 'content' => $system_prompt],
                ['role' => 'user',   'content' => $user_prompt],
            ],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_FORMAT,
            'messages'   => [
                ['role' => 'system', 'content' => prompt_builder::build_format_system()],
                ['role' => 'user',   'content' => json_encode(['question' => $user_prompt, 'rows' => $safe_rows])],
            ],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['choices'][0]['message']['content'] ?? null;
        return is_string($t) ? $t : '';
    }
}
```

- [ ] **Step 4: Run, verify all pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/openai_client_test.php`
Expected: `OK (8 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git add moodle/local/ai_analysis/classes/ai/openai_client.php moodle/local/ai_analysis/tests/openai_client_test.php
git commit -m "feat(ai_analysis): add openai_client provider"
```

---

## Task 3: gemini_client (TDD)

**Files:**
- Create: `tests/gemini_client_test.php`
- Create: `classes/ai/gemini_client.php`

- [ ] **Step 1: Write the failing tests** — `tests/gemini_client_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

class gemini_fake_transport implements http_transport_interface {
    public ?string $last_url = null;
    public ?array $last_headers = null;
    public ?string $last_body = null;
    public array $next_response = ['status' => 200, 'headers' => [], 'body' => ''];

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        $this->last_url = $url;
        $this->last_headers = $headers;
        $this->last_body = $body;
        return $this->next_response;
    }
}

/**
 * @covers \local_ai_analysis\ai\gemini_client
 */
class gemini_client_test extends \advanced_testcase {

    private function gen_response(string $text): array {
        return ['status' => 200, 'headers' => [], 'body' => json_encode([
            'candidates' => [['content' => ['parts' => [['text' => $text]]]]],
        ])];
    }

    public function test_sql_request_targets_model_url_with_key_header_and_json_mime(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'gkey');
        $c->generate_sql('SYS', 'USR');
        $this->assertSame(
            'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
            $t->last_url
        );
        $this->assertContains('x-goog-api-key: gkey', $t->last_headers);
        $body = json_decode($t->last_body, true);
        $this->assertSame('SYS', $body['systemInstruction']['parts'][0]['text']);
        $this->assertSame('USR', $body['contents'][0]['parts'][0]['text']);
        $this->assertSame('application/json', $body['generationConfig']['responseMimeType']);
        $this->assertSame(800, $body['generationConfig']['maxOutputTokens']);
    }

    public function test_happy_path_returns_sql_array(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"sql":"SELECT id FROM mdl_user WHERE id = ? LIMIT 10","params":[7],"explanation":""}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('sql', $r['type']);
        $this->assertSame([7], $r['params']);
    }

    public function test_code_fence_stripped(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response("```json\n{\"sql\":\"SELECT id FROM mdl_user LIMIT 1\",\"params\":[],\"explanation\":\"\"}\n```");
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->assertSame('sql', $c->generate_sql('s', 'u')['type']);
    }

    public function test_out_of_scope(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"error":"out_of_scope"}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->assertSame('out_of_scope', $c->generate_sql('s', 'u')['type']);
    }

    public function test_http_error_throws(): void {
        $t = new gemini_fake_transport();
        $t->next_response = ['status' => 400, 'headers' => [], 'body' => '{"error":"bad"}'];
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_malformed_throws(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('not json');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $this->expectException(ai_client_exception::class);
        $c->generate_sql('s', 'u');
    }

    public function test_custom_model_in_url(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k', 'gemini-1.5-pro');
        $c->generate_sql('s', 'u');
        $this->assertStringContainsString('/models/gemini-1.5-pro:generateContent', $t->last_url);
    }

    public function test_format_result_returns_prose_without_json_mime(): void {
        $t = new gemini_fake_transport();
        $t->next_response = $this->gen_response('PERSON_1 leads.');
        $c = new \local_ai_analysis\ai\gemini_client($t, 'k');
        $answer = $c->format_result('who leads', [['firstname' => 'PERSON_1']]);
        $this->assertSame('PERSON_1 leads.', $answer);
        $body = json_decode($t->last_body, true);
        $this->assertArrayNotHasKey('responseMimeType', $body['generationConfig']);
        $this->assertSame(1024, $body['generationConfig']['maxOutputTokens']);
    }
}
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/gemini_client_test.php`
Expected: `Class "local_ai_analysis\ai\gemini_client" not found`.

- [ ] **Step 3: Implement** — `classes/ai/gemini_client.php`:

```php
<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Google Gemini generateContent client. The model is part of the URL path;
 * the API key travels as the x-goog-api-key header (kept out of URL logs).
 */
class gemini_client extends base_http_ai_client {

    protected const DEFAULT_MODEL = 'gemini-2.0-flash';
    private const BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::BASE . $this->model() . ':generateContent';
    }

    protected function auth_headers(): array {
        return [
            'x-goog-api-key: ' . $this->api_key,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'systemInstruction' => ['parts' => [['text' => $system_prompt]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => $user_prompt]]]],
            'generationConfig'  => [
                'maxOutputTokens'  => self::MAX_TOKENS_SQL,
                'responseMimeType' => 'application/json',
            ],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'systemInstruction' => ['parts' => [['text' => prompt_builder::build_format_system()]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => json_encode([
                'question' => $user_prompt,
                'rows'     => $safe_rows,
            ])]]]],
            'generationConfig'  => ['maxOutputTokens' => self::MAX_TOKENS_FORMAT],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['candidates'][0]['content']['parts'][0]['text'] ?? null;
        return is_string($t) ? $t : '';
    }
}
```

- [ ] **Step 4: Run, verify all pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/gemini_client_test.php`
Expected: `OK (8 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git add moodle/local/ai_analysis/classes/ai/gemini_client.php moodle/local/ai_analysis/tests/gemini_client_test.php
git commit -m "feat(ai_analysis): add gemini_client provider"
```

---

## Task 4: factory dispatch (TDD)

**Files:**
- Modify: `classes/ai/ai_client_factory.php`
- Create: `tests/ai_client_factory_test.php`

- [ ] **Step 1: Write the failing tests** — `tests/ai_client_factory_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\ai_client_factory;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * @covers \local_ai_analysis\ai\ai_client_factory
 */
class ai_client_factory_test extends \advanced_testcase {

    public function test_claude_is_default(): void {
        $this->resetAfterTest();
        set_config('provider', '', 'local_ai_analysis');
        $this->assertInstanceOf(\local_ai_analysis\ai\claude_client::class, ai_client_factory::make());
    }

    public function test_openai_provider(): void {
        $this->resetAfterTest();
        set_config('provider', 'openai', 'local_ai_analysis');
        $this->assertInstanceOf(\local_ai_analysis\ai\openai_client::class, ai_client_factory::make());
    }

    public function test_gemini_provider(): void {
        $this->resetAfterTest();
        set_config('provider', 'gemini', 'local_ai_analysis');
        $this->assertInstanceOf(\local_ai_analysis\ai\gemini_client::class, ai_client_factory::make());
    }

    public function test_unknown_provider_throws(): void {
        $this->resetAfterTest();
        set_config('provider', 'bogus', 'local_ai_analysis');
        $this->expectException(\coding_exception::class);
        ai_client_factory::make();
    }
}
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/ai_client_factory_test.php`
Expected: failures — `openai`/`gemini` currently hit the `default` and throw (so `test_openai_provider`/`test_gemini_provider` fail with coding_exception).

- [ ] **Step 3: Extend the factory** — in `classes/ai/ai_client_factory.php`, replace the `make()` body's provider resolution so it reads (keeping the existing `$override` check and the `set_override`/`reset_override` methods untouched):

```php
    public static function make(): ai_client_interface {
        if (self::$override !== null) {
            return self::$override;
        }
        $provider  = get_config('local_ai_analysis', 'provider') ?: 'claude';
        $transport = new moodle_curl_transport();
        return match ($provider) {
            'claude' => new claude_client(
                $transport,
                (string) get_config('local_ai_analysis', 'claude_api_key'),
                (string) get_config('local_ai_analysis', 'claude_model'),
            ),
            'openai' => new openai_client(
                $transport,
                (string) get_config('local_ai_analysis', 'openai_api_key'),
                (string) get_config('local_ai_analysis', 'openai_model'),
            ),
            'gemini' => new gemini_client(
                $transport,
                (string) get_config('local_ai_analysis', 'gemini_api_key'),
                (string) get_config('local_ai_analysis', 'gemini_model'),
            ),
            default => throw new \coding_exception('Unsupported AI provider: ' . $provider),
        };
    }
```

The file already has `use local_ai_analysis\ai\transport\moodle_curl_transport;` at the top (from Sprint 2). `claude_client` previously took only `($transport, $api_key)`; passing a third `claude_model` arg is compatible because the base constructor defaults `$model = ''`. No new `use` needed — `openai_client`/`gemini_client` are in the same namespace.

- [ ] **Step 4: Run, verify all pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/ai_client_factory_test.php`
Expected: `OK (4 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git add moodle/local/ai_analysis/classes/ai/ai_client_factory.php moodle/local/ai_analysis/tests/ai_client_factory_test.php
git commit -m "feat(ai_analysis): factory dispatch for openai and gemini providers"
```

---

## Task 5: settings + lang + version bump

**Files:**
- Modify: `settings.php`
- Modify: `lang/en/local_ai_analysis.php`
- Modify: `version.php`

- [ ] **Step 1: Expand the provider dropdown and add per-provider settings** — in `settings.php`, change the provider `admin_setting_configselect` options array from `['claude' => 'Claude (Anthropic)']` to:

```php
        ['claude' => 'Claude (Anthropic)', 'openai' => 'OpenAI', 'gemini' => 'Google Gemini']
```

Then, after the existing `claude_api_key` setting block and before the `rate_limit_per_min` block, add:

```php
    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/claude_model',
        get_string('setting_claude_model', 'local_ai_analysis'),
        get_string('setting_claude_model_desc', 'local_ai_analysis'),
        'claude-sonnet-4-20250514',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/openai_api_key',
        get_string('setting_openai_api_key', 'local_ai_analysis'),
        get_string('setting_openai_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/openai_model',
        get_string('setting_openai_model', 'local_ai_analysis'),
        get_string('setting_openai_model_desc', 'local_ai_analysis'),
        'gpt-4o',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_ai_analysis/gemini_api_key',
        get_string('setting_gemini_api_key', 'local_ai_analysis'),
        get_string('setting_gemini_api_key_desc', 'local_ai_analysis'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/gemini_model',
        get_string('setting_gemini_model', 'local_ai_analysis'),
        get_string('setting_gemini_model_desc', 'local_ai_analysis'),
        'gemini-2.0-flash',
        PARAM_TEXT
    ));
```

- [ ] **Step 2: Add the lang strings** — append to `lang/en/local_ai_analysis.php`:

```php
$string['setting_claude_model']        = 'Claude model';
$string['setting_claude_model_desc']   = 'Anthropic model id, e.g. claude-sonnet-4-20250514.';
$string['setting_openai_api_key']      = 'OpenAI API key';
$string['setting_openai_api_key_desc'] = 'API key from https://platform.openai.com/. Required when provider is OpenAI.';
$string['setting_openai_model']        = 'OpenAI model';
$string['setting_openai_model_desc']   = 'OpenAI model id, e.g. gpt-4o or gpt-4o-mini.';
$string['setting_gemini_api_key']      = 'Gemini API key';
$string['setting_gemini_api_key_desc'] = 'API key from https://aistudio.google.com/. Required when provider is Gemini.';
$string['setting_gemini_model']        = 'Gemini model';
$string['setting_gemini_model_desc']   = 'Gemini model id, e.g. gemini-2.0-flash or gemini-1.5-pro.';
```

- [ ] **Step 3: Bump version** — in `version.php`, change `$plugin->version   = 2026053000;` to:

```php
$plugin->version   = 2026053001;
```

- [ ] **Step 4: Apply upgrade + verify settings parse**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/upgrade.php --non-interactive 2>&1 | tail -2
docker exec moodle-web-8092 php -l /var/www/html/local/ai_analysis/settings.php
```
Expected: upgrade completes successfully; `No syntax errors detected`.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git add moodle/local/ai_analysis/settings.php moodle/local/ai_analysis/lang moodle/local/ai_analysis/version.php
git commit -m "feat(ai_analysis): add OpenAI/Gemini provider settings and model fields"
```

---

## Task 6: Final verification

**Files:** none — verification only.

- [ ] **Step 1: Re-init and run the full plugin suite by file path**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
for t in manifest_builder audit_writer sql_validator prompt_builder claude_client rate_limiter query_executor pii_scrubber external_query openai_client gemini_client ai_client_factory; do
  echo -n "$t: "; docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/${t}_test.php 2>&1 | grep -E "^(OK|FAILURES|ERRORS|Tests:)" | tail -1
done
```
Expected: 12 lines, each `OK (...)`. New: openai_client 8, gemini_client 8, ai_client_factory 4. Unchanged: claude_client 15, plus Sprint 1/2/3a files. Combined ≥ 118 tests.

- [ ] **Step 2: Done — manual gate**

No commit. If anything fails, return to the relevant task. Otherwise the branch is ready for merge (per project rule: merge to `main` locally after implementation completes).

---

## Self-review

### Spec coverage
- **base_http_ai_client (template-method, final flow, 5 hooks)** → Task 1. ✓
- **claude_client refactor onto base, 15 tests stay green** → Task 1 (steps 2–3). ✓
- **openai_client (Chat Completions, json_object mode, bearer, extract choices[0].message.content)** → Task 2. ✓
- **gemini_client (generateContent, model-in-URL, x-goog-api-key, responseMimeType, extract candidates[0].content.parts[0].text)** → Task 3. ✓
- **Factory openai/gemini cases + default guard** → Task 4. ✓
- **Settings: dropdown options, per-provider key + free-text model, claude_model parity** → Task 5. ✓
- **No change to interface/validator/scrubber/gateway/audit** → confirmed; no task touches them. ✓
- **Error contract unchanged (HTTP_*/PARSE_FAILED/out_of_scope)** → base `post()`+`generate_sql` in Task 1; asserted by client tests in Tasks 2–3. ✓
- **JSON mode only for SQL, prose for format** → asserted by `test_format_result_*` in Tasks 2–3. ✓

### Placeholder scan
No TBD/TODO/"handle edge cases". Every code step shows complete code. Commit messages carry no Claude/Anthropic trailer.

### Type consistency
- Base hooks `endpoint()/auth_headers()/build_sql_payload()/build_format_payload()/extract_text()` — identical signatures in base (Task 1) and all three subclasses (Tasks 1–3). ✓
- Constructor `($transport, $api_key, $model='')` — base (Task 1); factory passes 3 args for every provider (Task 4); compatible with claude’s prior 2-arg construction. ✓
- `DEFAULT_MODEL` const + `model()` resolution — defined per subclass, used in payload/endpoint. ✓
- `response_format`/`responseMimeType` present for SQL, absent for format — consistent between impl (Tasks 2–3) and assertions. ✓
- Config keys `claude_model`/`openai_api_key`/`openai_model`/`gemini_api_key`/`gemini_model` — same names in factory (Task 4) and settings (Task 5). ✓
