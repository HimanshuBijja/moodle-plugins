# Sub-project B2 — Course Performance View Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let the chatbot answer course-performance questions ("underperforming courses", "how is this course doing") via a read-only view that rolls up the B1 engagement view per course, plus one scope-aware fast-path template.

**Architecture:** A plugin-owned MariaDB view `mdl_ai_course_performance` (one row per course) aggregates `mdl_ai_student_engagement` (B1) by courseid, joined to `mdl_course` for the name, exposing at-risk counts/pct, avg grade, and completion metrics. It reuses the established view-ownership pattern (install/upgrade create it, PHPUNIT-skip, per-test create/drop) and the sub-project A intent framework (a scope-aware `course_performance` template).

**Tech Stack:** PHP 8.1, Moodle 4.5, MariaDB 10.11 (view via `$DB->execute`), PHPUnit (Docker), greenlion/php-sql-parser (via `sql_validator`).

**Spec:** `docs/superpowers/specs/2026-06-12-sprintB2-course-performance-design.md`

**Prerequisite:** sub-projects C + B1 merged (this view selects from `mdl_ai_student_engagement`, which selects from `mdl_ai_course_staff`). Dependency chain: **staff → engagement → performance**.

---

## File Structure

| File | Responsibility |
|---|---|
| `classes/db/course_performance_view.php` (new) | DDL holder: `definition_sql($prefix)` + `create($db)`. |
| `db/install.php` (modify) | Also create the performance view (after engagement), PHPUNIT-skip. |
| `db/upgrade.php` (modify) | New version-guarded step (2026061203) creates the performance view. |
| `db/readonly_grants.sql` (modify) | Grant SELECT on the performance view. |
| `classes/manifest/manifest_builder.php` (modify) | Allow-list the view + course scope-note. |
| `classes/intent/synonym_dictionary.php` (modify) | performance-term family. |
| `classes/intent/intent_registry.php` (modify) | `course_performance` intent. |
| `classes/intent/sql_template.php` (modify) | Scope-aware `course_performance` case. |
| `version.php` (modify) | Bump to `2026061203` / `0.11.0`. |
| `tests/course_performance_view_test.php` (new) | Rollup correctness, exclusions. |
| `tests/{intent_classifier,sql_template,external_query,manifest_builder}_test.php` (modify) | Extend. |
| `INSTALL.md`, `docs/ai-memory/02,03,04` (modify) | Record. |
| **NOT** `classes/security/pii_scrubber.php` | No identity columns — unchanged. |

---

## Task 1: The course-performance view (DDL holder + install + upgrade + grant + version)

**Files:**
- Create: `classes/db/course_performance_view.php`, `tests/course_performance_view_test.php`
- Modify: `db/install.php`, `db/upgrade.php`, `db/readonly_grants.sql`, `version.php`

- [ ] **Step 1: Write the failing test**

Create `local/ai_analysis/tests/course_performance_view_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\db\course_staff_view;
use local_ai_analysis\db\student_engagement_view;
use local_ai_analysis\db\course_performance_view;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\course_performance_view
 */
class course_performance_view_test extends \advanced_testcase {

    /** Create the 3-view chain: staff -> engagement -> performance. */
    protected function setUp(): void {
        global $DB;
        parent::setUp();
        course_staff_view::create($DB);
        student_engagement_view::create($DB);
        course_performance_view::create($DB);
    }

    /** Drop in reverse order before the framework reset. */
    protected function tearDown(): void {
        global $DB;
        $p = $DB->get_prefix();
        $DB->execute('DROP VIEW IF EXISTS ' . $p . course_performance_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $p . student_engagement_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $p . course_staff_view::VIEW);
        parent::tearDown();
    }

    private function enrol(int $userid, int $courseid): void {
        global $DB;
        $inst = $DB->get_record('enrol', ['courseid' => $courseid, 'enrol' => 'manual'], '*', MUST_EXIST);
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $inst->id, 'userid' => $userid, 'status' => 0,
            'timestart' => 0, 'timeend' => 0, 'modifierid' => 0,
            'timecreated' => time(), 'timemodified' => time(),
        ]);
    }

    private function log(int $userid, int $courseid, int $time): void {
        global $DB;
        $DB->insert_record('logstore_standard_log', (object) [
            'eventname' => '\\core\\event\\course_viewed', 'component' => 'core',
            'action' => 'viewed', 'target' => 'course', 'crud' => 'r', 'edulevel' => 0,
            'contextid' => 1, 'contextlevel' => 50, 'contextinstanceid' => $courseid,
            'userid' => $userid, 'courseid' => $courseid, 'anonymous' => 0,
            'timecreated' => $time, 'origin' => 'web', 'ip' => '0.0.0.0',
        ]);
    }

    public function test_rollup_metrics_and_exclusions(): void {
        global $DB;
        $this->resetAfterTest();
        $now = time();

        // Course A: 2 high-risk students (no activity, missing submission).
        $ca = $this->getDataGenerator()->create_course(['fullname' => 'Alpha']);
        $this->getDataGenerator()->get_plugin_generator('mod_assign')->create_instance(['course' => $ca->id]);
        foreach ([0, 1] as $i) {
            $s = $this->getDataGenerator()->create_user();
            $this->enrol($s->id, $ca->id);
        }

        // Course B: 2 low-risk students (active + submitted).
        $cb = $this->getDataGenerator()->create_course(['fullname' => 'Beta']);
        $asgB = $this->getDataGenerator()->get_plugin_generator('mod_assign')->create_instance(['course' => $cb->id]);
        foreach ([0, 1] as $i) {
            $s = $this->getDataGenerator()->create_user();
            $this->enrol($s->id, $cb->id);
            for ($k = 0; $k < 6; $k++) {
                $this->log($s->id, $cb->id, $now - $k * 60);
            }
            $DB->insert_record('assign_submission', (object) [
                'assignment' => $asgB->id, 'userid' => $s->id, 'status' => 'submitted',
                'groupid' => 0, 'attemptnumber' => 0, 'latest' => 1,
                'timecreated' => $now, 'timemodified' => $now,
            ]);
        }

        // Course C: only a teacher (staff), no students -> must not appear.
        $cc = $this->getDataGenerator()->create_course(['fullname' => 'Gamma']);
        $ccctx = \context_course::instance($cc->id);
        $teacher = $this->getDataGenerator()->create_user();
        $this->enrol($teacher->id, $cc->id);
        $trole = $DB->get_record('role', ['shortname' => 'editingteacher'], '*', MUST_EXIST);
        $DB->insert_record('role_assignments', (object) [
            'roleid' => $trole->id, 'contextid' => $ccctx->id, 'userid' => $teacher->id,
            'timemodified' => $now, 'modifierid' => 0, 'component' => '', 'itemid' => 0, 'sortorder' => 0,
        ]);

        $a = $DB->get_record('ai_course_performance', ['courseid' => $ca->id], '*', MUST_EXIST);
        $this->assertSame('Alpha', $a->coursename);
        $this->assertSame(2, (int) $a->student_count);
        $this->assertSame(2, (int) $a->at_risk_high);
        $this->assertEquals(100.0, (float) $a->at_risk_pct);
        $this->assertEquals(0.0, (float) $a->pct_no_missing);

        $b = $DB->get_record('ai_course_performance', ['courseid' => $cb->id], '*', MUST_EXIST);
        $this->assertSame(2, (int) $b->student_count);
        $this->assertSame(0, (int) $b->at_risk_high);
        $this->assertEquals(0.0, (float) $b->at_risk_pct);
        $this->assertEquals(100.0, (float) $b->pct_no_missing);

        // Course C (staff only) absent; courseid=0 absent.
        $this->assertFalse($DB->record_exists('ai_course_performance', ['courseid' => $cc->id]));
        $this->assertSame(0, $DB->count_records('ai_course_performance', ['courseid' => 0]));
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/course_performance_view_test.php`
Expected: FAIL — class `course_performance_view` not found.

- [ ] **Step 3: Write the view DDL holder**

Create `local/ai_analysis/classes/db/course_performance_view.php`:

```php
<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_course_performance` view: one row per
 * course, rolling up mdl_ai_student_engagement (B1) by courseid and joining
 * mdl_course for the name. Inherits the engagement view's enrolled-minus-staff
 * population and courseid > 0 exclusion. Exposes at-risk counts/pct, avg grade,
 * and completion metrics — no student identity, so no PII. Created by
 * install/upgrade; skipped under PHPUNIT — tests create/drop the 3-view chain
 * per-class. Requires mdl_ai_student_engagement (and thus mdl_ai_course_staff)
 * to exist first.
 */
class course_performance_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_course_performance';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_course_performance AS
SELECT se.courseid AS courseid,
       c.fullname AS coursename,
       COUNT(*) AS student_count,
       SUM(CASE WHEN se.risk_band = 'high' THEN 1 ELSE 0 END) AS at_risk_high,
       SUM(CASE WHEN se.risk_band = 'medium' THEN 1 ELSE 0 END) AS at_risk_medium,
       SUM(CASE WHEN se.risk_band = 'low' THEN 1 ELSE 0 END) AS at_risk_low,
       ROUND(100 * SUM(CASE WHEN se.risk_band = 'high' THEN 1 ELSE 0 END) / COUNT(*), 1) AS at_risk_pct,
       AVG(se.avg_grade) AS avg_grade,
       AVG(se.missing_submissions) AS avg_missing_submissions,
       ROUND(100 * SUM(CASE WHEN se.missing_submissions = 0 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_no_missing
FROM {$p}ai_student_engagement se
JOIN {$p}course c ON c.id = se.courseid
GROUP BY se.courseid, c.fullname";
    }

    /** Create (or replace) the view. Requires mdl_ai_student_engagement to exist. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
```

- [ ] **Step 4: Wire into install.php (after the engagement view)**

In `local/ai_analysis/db/install.php`, inside the existing `if (!defined('PHPUNIT_TEST') || !PHPUNIT_TEST) { ... }` block, add the performance view creation immediately AFTER the existing `student_engagement_view::create($DB);` line (order matters — performance reads engagement):

```php
        \local_ai_analysis\db\student_engagement_view::create($DB);
        \local_ai_analysis\db\course_performance_view::create($DB);
```

- [ ] **Step 5: Add the upgrade step + bump version**

In `local/ai_analysis/db/upgrade.php`, add a new block before `return true;`:

```php
    if ($oldversion < 2026061203) {
        // Sub-project B2: create the read-only course-performance view.
        \local_ai_analysis\db\course_performance_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061203, 'local', 'ai_analysis');
    }
```

In `local/ai_analysis/version.php`, set `$plugin->version = 2026061203;` and `$plugin->release = '0.11.0';`.

- [ ] **Step 6: Add the RO grant**

In `local/ai_analysis/db/readonly_grants.sql`, add after the `mdl_ai_student_engagement` GRANT line:

```sql
GRANT SELECT ON moodle.mdl_ai_course_performance TO 'moodle_ai_ro'@'%';
```

- [ ] **Step 7: Apply to the test DB, then run the test**

Run: `docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php`  (~30-60s)
Then: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/course_performance_view_test.php`
Expected: PASS.

IMPORTANT: do NOT weaken assertions or fake the view. If a rollup value is wrong, fix the view DDL (the SUM/AVG/ROUND expressions), not the test. If view creation errors because `mdl_ai_student_engagement` is missing, ensure the 3 views are created in setUp in order staff → engagement → performance. Report any DDL change. Edit ONLY files under `local/ai_analysis/`; if init.php surfaces an unrelated half-installed sibling-plugin error, report it, do not touch that plugin.

- [ ] **Step 8: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/db/course_performance_view.php local/ai_analysis/db/install.php local/ai_analysis/db/upgrade.php local/ai_analysis/db/readonly_grants.sql local/ai_analysis/version.php local/ai_analysis/tests/course_performance_view_test.php
git commit -m "feat(ai_analysis): read-only course-performance view (rollup of engagement)"
```

Commit rule: NO Co-Authored-By / Claude / Anthropic signature lines. Plain message only.

---

## Task 2: Expose the view in the manifest

**Files:** Modify `classes/manifest/manifest_builder.php`; Test `tests/manifest_builder_test.php` (append).

- [ ] **Step 1: Append the failing test**

```php
    public function test_manifest_includes_course_performance_view(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_course_performance', $manifest);
        $this->assertSame(
            ['courseid', 'coursename', 'student_count', 'at_risk_high', 'at_risk_medium',
             'at_risk_low', 'at_risk_pct', 'avg_grade', 'avg_missing_submissions', 'pct_no_missing'],
            $manifest['mdl_ai_course_performance']
        );
    }

    public function test_course_performance_view_gets_scope_note_for_scoped_teacher(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 99);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_course_performance']);
        $this->assertStringContainsString('99', $manifest['mdl_ai_course_performance']['_scope_note']);
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: FAIL — key missing. (If `test_admin_returns_full_manifest` asserts the full key set canonically, it will also fail — fix it in Step 3.)

- [ ] **Step 3: Implement**

In `classes/manifest/manifest_builder.php`, add to `$FULL_MANIFEST` after the `mdl_ai_student_engagement` line:

```php
        'mdl_ai_course_performance' => ['courseid', 'coursename', 'student_count', 'at_risk_high', 'at_risk_medium', 'at_risk_low', 'at_risk_pct', 'avg_grade', 'avg_missing_submissions', 'pct_no_missing'],
```

Inside the `if ($role !== 'admin' && $courseid > 0)` block, after the `mdl_ai_student_engagement` scope-note:

```php
            $manifest['mdl_ai_course_performance']['_scope_note'] =
                'Course-level performance rollup (at-risk counts, avg grade, completion); always filter WHERE courseid = ' . $courseid;
```

If `test_admin_returns_full_manifest` (or similar) asserts an exact/canonical key list, add `'mdl_ai_course_performance'` to its expected list.

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/manifest/manifest_builder.php local/ai_analysis/tests/manifest_builder_test.php
git commit -m "feat(ai_analysis): allow-list course-performance view in manifest"
```

Commit rule: plain message, no signatures.

---

## Task 3: course_performance intent (classifier + synonyms)

**Files:** Modify `classes/intent/synonym_dictionary.php`, `classes/intent/intent_registry.php`; Test `tests/intent_classifier_test.php` (append).

- [ ] **Step 1: Append the failing tests**

```php
    /**
     * @dataProvider performance_phrasings
     */
    public function test_performance_phrasings_classify_as_course_performance(string $prompt): void {
        $this->assertSame('course_performance', intent_classifier::classify($prompt));
    }

    public static function performance_phrasings(): array {
        return [
            ['underperforming courses'],
            ['course performance'],
            ['how is this course performing'],
            ['course health'],
        ];
    }

    public function test_performance_distinct_from_other_intents(): void {
        $this->assertSame('at_risk_students', intent_classifier::classify('students at risk'));
        $this->assertSame('student_listing', intent_classifier::classify('list students'));
        $this->assertSame('course_staff', intent_classifier::classify('who teaches this course'));
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: FAIL — performance phrasings return null.

- [ ] **Step 3a: Extend the synonym dictionary**

In `classes/intent/synonym_dictionary.php` `MAP`, add (before the closing `];`):

```php
        // course-performance family
        'performance'     => 'performance',
        'performing'      => 'performance',
        'underperforming' => 'performance',
        'health'          => 'performance',
```

- [ ] **Step 3b: Add the course_performance registry entry**

In `classes/intent/intent_registry.php`, add a fourth entry to the array returned by `all()` (after `at_risk_students`):

```php
            [
                'id'       => 'course_performance',
                'requires' => ['performance'],
                'any_of'   => ['enrolled'],
                'none_of'  => ['students', 'staff', 'risk'],
            ],
```

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: PASS. `performance` is a unique required token, so it does not collide with the student/staff/risk intents. (`course`/`courses` already canonicalize to `enrolled`, satisfying `any_of`.) If an existing case breaks, fix the registry logic, not the test.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/intent/synonym_dictionary.php local/ai_analysis/classes/intent/intent_registry.php local/ai_analysis/tests/intent_classifier_test.php
git commit -m "feat(ai_analysis): course_performance intent + performance synonym family"
```

Commit rule: plain message, no signatures.

---

## Task 4: Scope-aware course_performance SQL template

**Files:** Modify `classes/intent/sql_template.php`; Test `tests/sql_template_test.php` (append).

- [ ] **Step 1: Append the failing tests**

```php
    public function test_course_performance_scoped_binds_courseid(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_performance', 55);
        $this->assertStringContainsStringIgnoringCase('where p.courseid = ?', $sql);
        $this->assertSame([55], $params);
    }

    public function test_course_performance_global_ranks_no_params(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_performance', 0);
        $this->assertStringContainsStringIgnoringCase('order by p.at_risk_pct desc', $sql);
        $this->assertStringNotContainsStringIgnoringCase('where', $sql);
        $this->assertSame([], $params);
    }

    public function test_course_performance_both_shapes_pass_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$scoped, $sp] = \local_ai_analysis\intent\sql_template::build('course_performance', 55);
        [$global, $gp] = \local_ai_analysis\intent\sql_template::build('course_performance', 0);
        $this->assertTrue($validator->validate($scoped, $sp));
        $this->assertTrue($validator->validate($global, $gp));
    }
```

- [ ] **Step 2: Run → fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: FAIL — coding_exception "Unknown intent template: course_performance".

- [ ] **Step 3: Implement**

In `classes/intent/sql_template.php`, add a column-list constant alongside the others:

```php
    /** Output columns for the course-performance template (both shapes). */
    private const COURSE_PERFORMANCE_COLS =
        'p.courseid, p.coursename, p.student_count, p.at_risk_high, p.at_risk_pct, '
        . 'p.avg_grade, p.avg_missing_submissions, p.pct_no_missing';
```

And add a `case` before `default` in `build()`. Note this case returns TWO shapes depending on `$courseid` (scope-aware):

```php
            case 'course_performance':
                if ($courseid > 0) {
                    return ['SELECT ' . self::COURSE_PERFORMANCE_COLS
                        . ' FROM mdl_ai_course_performance p WHERE p.courseid = ? LIMIT 1000', [$courseid]];
                }
                return ['SELECT ' . self::COURSE_PERFORMANCE_COLS
                    . ' FROM mdl_ai_course_performance p ORDER BY p.at_risk_pct DESC LIMIT 1000', []];
```

- [ ] **Step 4: Run → pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: PASS, including `test_course_performance_both_shapes_pass_validator`. The global shape has no WHERE/params — that is validator-legal (SELECT-only, allow-listed columns, no subquery, LIMIT ≤ 1000; there is no WHERE-required rule). If the validator rejects either shape, fix the template SQL to be manifest-legal against `mdl_ai_course_performance`; do NOT weaken the test/validator. Report any change.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/intent/sql_template.php local/ai_analysis/tests/sql_template_test.php
git commit -m "feat(ai_analysis): scope-aware course_performance SQL template"
```

Commit rule: plain message, no signatures.

---

## Task 5: End-to-end course-performance fast-path (gateway test)

**Files:** Modify `tests/external_query_test.php`. No production code change.

`external_query_test` already creates/drops `mdl_ai_course_staff` + `mdl_ai_student_engagement` in setUp/tearDown (C + B1). Add the performance view alongside them (created last, dropped first).

- [ ] **Step 1: Augment the view lifecycle**

In `setUp()`, immediately AFTER the existing `student_engagement_view::create($DB);` line, add:
```php
        \local_ai_analysis\db\course_performance_view::create($DB);
```

In `tearDown()`, immediately BEFORE the existing `student_engagement_view` DROP line, add (drop dependent view first):
```php
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . \local_ai_analysis\db\course_performance_view::VIEW);
```

- [ ] **Step 2: Append the test**

```php
    public function test_course_performance_fast_path_serves_without_calling_ai(): void {
        global $DB;
        // Seed one student so the course appears in the performance rollup.
        $inst = $DB->get_record('enrol', ['courseid' => $this->course->id, 'enrol' => 'manual'], '*', MUST_EXIST);
        $student = $this->getDataGenerator()->create_user();
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $inst->id, 'userid' => $student->id, 'status' => 0,
            'timestart' => 0, 'timeend' => 0, 'modifierid' => 0,
            'timecreated' => time(), 'timemodified' => time(),
        ]);

        // Scoped teacher (courseid > 0) -> their course's performance row.
        $resp = $this->call('course performance');

        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertSame(1, $resp['row_count']);
        $this->assertSame(0, $this->stub->call_count); // no LLM call

        $audit = $DB->get_record('local_ai_analysis_audit', ['userid' => $this->teacher->id], '*', MUST_EXIST);
        $this->assertSame('template', $audit->provider);
    }
```

- [ ] **Step 3: Run the gateway test file**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: PASS — all tests including the new one (the seeded student makes the course appear; the scoped template returns exactly that one course row). If 0 rows, confirm all three views are created in setUp in order, and the student is enrolled. Do NOT modify production code.

- [ ] **Step 4: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/tests/external_query_test.php
git commit -m "test(ai_analysis): end-to-end course_performance fast-path through the gateway"
```

Commit rule: plain message, no signatures.

---

## Task 6: Docs + INSTALL + full suite

**Files:** Modify `INSTALL.md`, `docs/ai-memory/02,03,04`.

- [ ] **Step 1: Full suite**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite`
Expected: OK — all pass (the 2 pre-existing risky print-output warnings in `purge_audit_task_test` are fine). Report only real FAILures. Record the total count.

- [ ] **Step 2: INSTALL.md**

Add a note that `db/readonly_grants.sql` now also grants SELECT on `mdl_ai_course_performance`; the view is auto-created by install/upgrade, only the GRANT is manual.

- [ ] **Step 3: ai-memory docs**

- `02-features-log.md`: add "Sub-project B2 — Course Performance View": the `mdl_ai_course_performance` view (one row per course, rolls up the engagement view by courseid + joins mdl_course for name; metrics student_count, at_risk_high/medium/low, at_risk_pct, avg_grade, avg_missing_submissions, pct_no_missing; inherits enrolled-minus-staff + courseid>0 exclusion; courses with no students absent); 3-view dependency chain staff→engagement→performance; `classes/db/course_performance_view.php` + install/upgrade (2026061203) + RO grant; manifest + scope-note; scope-aware `course_performance` template (courseid>0 → that course's row; courseid=0 → global ranking by at_risk_pct, gated by queryglobal) + performance synonyms; NO PII change (no identity columns); version 2026061203 / 0.11.0; full suite count.
- `04-current-state.md`: under Done add B2; version 2026061203 / 0.11.0; test count; manifest section now "14 tables + 3 views (course_staff, student_engagement, course_performance)"; reiterate the materialized-metric-table scale path (global course ranking is the heaviest path); remaining roadmap: B3 (feedback), D (memory).
- `03-decisions.md`: record B2 decisions (rolls up B1 view — view-on-view DRY; metrics = at-risk counts/pct + avg_grade + completion, no activity rollup, no course band; "underperforming" = rank by at_risk_pct; scope-aware template, global branch gated by queryglobal; no PII; 3-view create-order).

- [ ] **Step 4: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/INSTALL.md local/ai_analysis/docs/ai-memory/
git commit -m "docs(ai_analysis): record sub-project B2 (course-performance view); bump to 0.11.0"
```

Commit rule: plain message, no signatures.

---

## Self-Review

- **Spec coverage:** view rolls up engagement by course + joins mdl_course (T1) ✓; metrics at-risk counts/pct + avg_grade + avg_missing + pct_no_missing (T1) ✓; courseid=0 + staff-only-course exclusions inherited + tested (T1) ✓; no PII change (no pii task; noted) ✓; 3-view ownership + create-order + PHPUNIT-skip + per-test create/drop (T1, T5) ✓; RO grant (T1) ✓; manifest + scope-note (T2) ✓; course_performance intent + performance synonyms, distinct token (T3) ✓; scope-aware template both shapes + both pass validator (T4) ✓; gateway e2e scoped branch, no-AI, provider=template (T5) ✓; global branch covered at template-unit level (T4) ✓; docs/INSTALL + scale-path note (T6) ✓.
- **Placeholders:** none — full code in every step.
- **Type consistency:** `course_performance_view::definition_sql(string): string`, `::create(\moodle_database): void`, `::VIEW = 'ai_course_performance'`; manifest key `mdl_ai_course_performance` with the 10-column list used identically in T2; intent id `course_performance`; template alias `p`, scoped uses `?`+`[courseid]`, global uses `[]`; version `2026061203` identical in upgrade guard + version.php. Depends on `student_engagement_view` + `course_staff_view` (created first, in order, in install + every test setUp).
