# Sub-project C — Role/People Queries Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let the chatbot safely answer course-staff questions ("who teaches this course") by exposing a pre-filtered, read-only DB view of teaching staff — never the raw role tables — plus one deterministic fast-path template.

**Architecture:** A plugin-owned MariaDB view `mdl_ai_course_staff` joins role_assignments+context+role+user, restricted to the 4 staff roles at course context, excluding configured site-admins, projecting only `courseid,userid,firstname,lastname,role`. It is created by `db/install.php` (fresh + PHPUnit DB) and `db/upgrade.php` (existing prod), granted to the RO user, added to the manifest, and given a `course_staff` intent template extending sub-project A.

**Tech Stack:** PHP 8.1, Moodle 4.5, MariaDB 10.11 (view via `$DB->change_database_structure`), PHPUnit (Docker), greenlion/php-sql-parser (via `sql_validator`).

**Spec:** `docs/superpowers/specs/2026-06-12-sprintC-role-people-queries-design.md`

---

## File Structure

| File | Responsibility |
|---|---|
| `classes/db/course_staff_view.php` (new) | Holds the view's DDL (`definition_sql($prefix)`) + `create($db)`. Single source of the view SQL (DRY across install/upgrade/tests). |
| `db/install.php` (new) | `xmldb_local_ai_analysis_install()` creates the view on fresh installs + PHPUnit init. |
| `db/upgrade.php` (modify) | New version-guarded step creates the view on existing installs. |
| `db/readonly_grants.sql` (modify) | Add `GRANT SELECT` on the view. |
| `classes/manifest/manifest_builder.php` (modify) | Allow-list the view + course scope-note. |
| `classes/security/pii_scrubber.php` (modify) | Tokenize the view's name columns. |
| `classes/intent/synonym_dictionary.php` (modify) | Staff-term family + `who`→`list`. |
| `classes/intent/intent_registry.php` (modify) | `course_staff` intent entry. |
| `classes/intent/sql_template.php` (modify) | `course_staff` template case. |
| `version.php` (modify) | Bump to `2026061201` / `0.9.0`. |
| `tests/course_staff_view_test.php` (new) | View existence, shape, site-admin exclusion, course-context only. |
| `tests/intent_classifier_test.php` (modify) | Staff-phrasing classification + updated who-phrasings. |
| `tests/sql_template_test.php` (modify) | `course_staff` template passes validator. |
| `tests/external_query_test.php` (modify) | Staff fast-path end-to-end (no AI call, provider='template'). |
| `tests/manifest_builder_test.php` (modify) | View present + scope-note. |
| `tests/pii_scrubber_test.php` (modify) | View name columns classified PERSON. |
| `INSTALL.md`, `docs/ai-memory/02,03,04` (modify) | Record view grant + feature. |

---

## Task 1: The staff view (DDL holder + install + upgrade + grant + version)

**Files:**
- Create: `classes/db/course_staff_view.php`
- Create: `db/install.php`
- Modify: `db/upgrade.php`, `db/readonly_grants.sql`, `version.php`
- Test: `tests/course_staff_view_test.php`

- [ ] **Step 1: Write the failing test**

Create `tests/course_staff_view_test.php`:

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\course_staff_view
 */
class course_staff_view_test extends \advanced_testcase {

    /** Seed a course-context role assignment directly (no enrol/role hooks). */
    private function assign(int $roleid, int $contextid, int $userid): void {
        global $DB;
        $DB->insert_record('role_assignments', (object) [
            'roleid'       => $roleid,
            'contextid'    => $contextid,
            'userid'       => $userid,
            'timemodified' => time(),
            'modifierid'   => 0,
            'component'    => '',
            'itemid'       => 0,
            'sortorder'    => 0,
        ]);
    }

    public function test_view_lists_course_teacher_but_excludes_siteadmin_manager(): void {
        global $DB;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $coursectx = \context_course::instance($course->id);

        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher'], '*', MUST_EXIST);
        $managerrole = $DB->get_record('role', ['shortname' => 'manager'], '*', MUST_EXIST);

        $teacher = $this->getDataGenerator()->create_user();
        $adminmanager = $this->getDataGenerator()->create_user();

        // A normal course teacher: must appear.
        $this->assign((int) $teacherrole->id, (int) $coursectx->id, (int) $teacher->id);
        // A manager on the course who is ALSO a configured site admin: must NOT appear.
        $this->assign((int) $managerrole->id, (int) $coursectx->id, (int) $adminmanager->id);
        set_config('siteadmins', (string) $adminmanager->id);

        $rows = $DB->get_records('ai_course_staff', ['courseid' => $course->id]);
        $userids = array_map(static fn($r) => (int) $r->userid, $rows);

        $this->assertContains((int) $teacher->id, $userids, 'course teacher should be visible');
        $this->assertNotContains((int) $adminmanager->id, $userids, 'site-admin manager must be hidden');

        // Identity columns present; no username/email column exists on the view.
        $row = $DB->get_record('ai_course_staff', ['userid' => $teacher->id]);
        $this->assertTrue(property_exists($row, 'firstname'));
        $this->assertTrue(property_exists($row, 'lastname'));
        $this->assertTrue(property_exists($row, 'role'));
        $this->assertFalse(property_exists($row, 'username'));
        $this->assertFalse(property_exists($row, 'email'));
    }

    public function test_view_excludes_non_course_context_assignments(): void {
        global $DB;
        $this->resetAfterTest();

        $managerrole = $DB->get_record('role', ['shortname' => 'manager'], '*', MUST_EXIST);
        $sysmanager = $this->getDataGenerator()->create_user();
        // Manager assigned at SYSTEM context (contextlevel 10) — not a course, must be absent.
        $this->assign((int) $managerrole->id, (int) \context_system::instance()->id, (int) $sysmanager->id);

        $rows = $DB->get_records('ai_course_staff');
        $userids = array_map(static fn($r) => (int) $r->userid, $rows);
        $this->assertNotContains((int) $sysmanager->id, $userids);
    }
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/course_staff_view_test.php`
Expected: FAIL — table/view `phpu_ai_course_staff` does not exist (or class not found).

- [ ] **Step 3: Write the view DDL holder**

Create `classes/db/course_staff_view.php`:

```php
<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_course_staff` view — the single, safe
 * gateway to course-staff identity. Used by db/install.php (fresh installs +
 * the PHPUnit test DB) and db/upgrade.php (existing installs) so the view
 * exists everywhere the plugin runs. The view bakes in the privacy policy:
 * only the 4 staff roles at course context, site-admins excluded dynamically,
 * and only firstname/lastname/role projected (no username/email/idnumber).
 */
class course_staff_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_course_staff';

    /** @param string $prefix runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $prefix): string {
        return "CREATE OR REPLACE VIEW {$prefix}ai_course_staff AS
SELECT ra.id, ctx.instanceid AS courseid, u.id AS userid,
       u.firstname, u.lastname, r.shortname AS role
FROM {$prefix}role_assignments ra
JOIN {$prefix}context ctx ON ctx.id = ra.contextid AND ctx.contextlevel = 50
JOIN {$prefix}role r ON r.id = ra.roleid
JOIN {$prefix}user u ON u.id = ra.userid
WHERE r.shortname IN ('manager','coursecreator','editingteacher','teacher')
  AND NOT EXISTS (SELECT 1 FROM {$prefix}config c
                  WHERE c.name = 'siteadmins' AND FIND_IN_SET(u.id, c.value))";
    }

    /** Create (or replace) the view in the given database. */
    public static function create(\moodle_database $db): void {
        $db->change_database_structure(self::definition_sql($db->get_prefix()));
    }
}
```

- [ ] **Step 4: Create db/install.php**

Create `db/install.php`:

```php
<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Install-time hook: create the read-only ai_course_staff view. Runs on fresh
 * installs and during PHPUnit init (which reinstalls plugins).
 */
function xmldb_local_ai_analysis_install(): bool {
    global $DB;
    \local_ai_analysis\db\course_staff_view::create($DB);
    return true;
}
```

- [ ] **Step 5: Add the upgrade step + bump version**

In `db/upgrade.php`, replace the body of `xmldb_local_ai_analysis_upgrade`:

```php
function xmldb_local_ai_analysis_upgrade(int $oldversion): bool {
    global $DB;

    if ($oldversion < 2026061201) {
        // Sub-project C: create the read-only course-staff view.
        \local_ai_analysis\db\course_staff_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061201, 'local', 'ai_analysis');
    }

    return true;
}
```

In `version.php`, set `$plugin->version = 2026061201;` and `$plugin->release = '0.9.0';`.

- [ ] **Step 6: Add the RO grant**

In `db/readonly_grants.sql`, add after the `mdl_groups_members` grant line:

```sql
GRANT SELECT ON moodle.mdl_ai_course_staff      TO 'moodle_ai_ro'@'%';
```

- [ ] **Step 7: Apply to the test DB, then run the test**

The view is created by install/upgrade, so the PHPUnit DB must be re-initialised to pick it up:

Run: `docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php`
Then: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/course_staff_view_test.php`
Expected: PASS — both tests green (teacher visible, site-admin manager hidden, system-context manager absent).

- [ ] **Step 8: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/db/course_staff_view.php local/ai_analysis/db/install.php local/ai_analysis/db/upgrade.php local/ai_analysis/db/readonly_grants.sql local/ai_analysis/version.php local/ai_analysis/tests/course_staff_view_test.php
git commit -m "feat(ai_analysis): read-only course-staff view (privacy-filtered) + install/upgrade/grant"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines. Plain message only.

---

## Task 2: Expose the view in the manifest

**Files:**
- Modify: `classes/manifest/manifest_builder.php`
- Test: `tests/manifest_builder_test.php` (append)

- [ ] **Step 1: Write the failing test**

Append to `class manifest_builder_test` in `tests/manifest_builder_test.php`:

```php
    public function test_manifest_includes_course_staff_view(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_course_staff', $manifest);
        $this->assertSame(
            ['courseid', 'userid', 'firstname', 'lastname', 'role'],
            $manifest['mdl_ai_course_staff']
        );
    }

    public function test_course_staff_view_gets_scope_note_for_scoped_teacher(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 77);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_course_staff']);
        $this->assertStringContainsString('77', $manifest['mdl_ai_course_staff']['_scope_note']);
    }
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: FAIL — key `mdl_ai_course_staff` missing.

- [ ] **Step 3: Add the view to the manifest**

In `classes/manifest/manifest_builder.php`, add to the `$FULL_MANIFEST` array (after the `mdl_groups_members` line):

```php
        'mdl_ai_course_staff'       => ['courseid', 'userid', 'firstname', 'lastname', 'role'],
```

And inside the `if ($role !== 'admin' && $courseid > 0)` block, add (after the `mdl_groups_members` scope-note):

```php
            $manifest['mdl_ai_course_staff']['_scope_note'] =
                'Teaching staff (teacher/manager roles) for a course; always filter WHERE courseid = ' . $courseid;
```

- [ ] **Step 4: Run test to verify it passes**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/manifest/manifest_builder.php local/ai_analysis/tests/manifest_builder_test.php
git commit -m "feat(ai_analysis): allow-list course-staff view in manifest with course scope-note"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines.

---

## Task 3: PII classification for the view's name columns

**Files:**
- Modify: `classes/security/pii_scrubber.php`
- Test: `tests/pii_scrubber_test.php` (append)

- [ ] **Step 1: Write the failing test**

Append to `class pii_scrubber_test` in `tests/pii_scrubber_test.php`:

```php
    public function test_course_staff_view_names_are_pii(): void {
        $this->assertTrue(
            \local_ai_analysis\security\pii_scrubber::is_pii('mdl_ai_course_staff.firstname')
        );
        $this->assertTrue(
            \local_ai_analysis\security\pii_scrubber::is_pii('mdl_ai_course_staff.lastname')
        );
    }
```

(Note: `is_pii()` is the existing public predicate at `pii_scrubber.php` that checks `PII_MAP` membership. If the existing test class uses a different accessor, mirror whatever the neighbouring PII tests already call.)

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/pii_scrubber_test.php`
Expected: FAIL — these table.column keys are not in `PII_MAP`.

- [ ] **Step 3: Add the view name columns to PII_MAP**

In `classes/security/pii_scrubber.php`, add to the `PII_MAP` const (after the `mdl_user.*` entries):

```php
        'mdl_ai_course_staff.firstname' => 'PERSON',
        'mdl_ai_course_staff.lastname'  => 'PERSON',
```

- [ ] **Step 4: Run test to verify it passes**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/pii_scrubber_test.php`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/security/pii_scrubber.php local/ai_analysis/tests/pii_scrubber_test.php
git commit -m "feat(ai_analysis): treat course-staff view names as PII in format pass"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines.

---

## Task 4: Classifier extension (staff family + course_staff intent)

**Files:**
- Modify: `classes/intent/synonym_dictionary.php`, `classes/intent/intent_registry.php`
- Test: `tests/intent_classifier_test.php` (append + update)

- [ ] **Step 1: Write the failing tests**

Append to `class intent_classifier_test` in `tests/intent_classifier_test.php`:

```php
    /**
     * @dataProvider staff_phrasings
     */
    public function test_staff_phrasings_classify_as_course_staff(string $prompt): void {
        $this->assertSame('course_staff', intent_classifier::classify($prompt));
    }

    public static function staff_phrasings(): array {
        return [
            ['who teaches this course'],
            ['who is the lecturer'],
            ['list teachers'],
            ['show lecturers'],
            ['faculty of this course'],
            ['list the instructors'],
        ];
    }

    public function test_student_and_staff_stay_distinct(): void {
        // Student phrasings must still resolve to student_listing, not course_staff.
        $this->assertSame('student_listing', intent_classifier::classify('list students'));
        $this->assertSame('student_listing', intent_classifier::classify('who are the students'));
        // Grade/submission staff phrasings fall through to the AI (null).
        $this->assertNull(intent_classifier::classify('top teachers by grade'));
    }
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: FAIL — staff phrasings return null (no `course_staff` intent yet).

- [ ] **Step 3: Extend the synonym dictionary**

In `classes/intent/synonym_dictionary.php`, add to the `MAP` const a staff family and the `who`→`list` mapping. Add these entries:

```php
        // staff-noun family
        'teacher'     => 'staff',
        'teachers'    => 'staff',
        'lecturer'    => 'staff',
        'lecturers'   => 'staff',
        'faculty'     => 'staff',
        'instructor'  => 'staff',
        'instructors' => 'staff',
        'professor'   => 'staff',
        'professors'  => 'staff',
        'tutor'       => 'staff',
        'tutors'      => 'staff',
        'staff'       => 'staff',
        // teaching verbs canonicalize to the staff noun for matching
        'teach'       => 'staff',
        'teaches'     => 'staff',
        'teaching'    => 'staff',
        // interrogative implies a listing intent
        'who'         => 'list',
```

- [ ] **Step 4: Add the course_staff registry entry**

In `classes/intent/intent_registry.php`, add a second entry to the array returned by `all()` (after the `student_listing` entry):

```php
            [
                'id'       => 'course_staff',
                'requires' => ['staff'],
                'any_of'   => ['list', 'enrolled'],
                'none_of'  => [
                    // student listing belongs to student_listing
                    'students',
                    // grade qualifiers
                    'failed', 'fail', 'passed', 'pass', 'grade', 'grades',
                    'mark', 'marks', 'score', 'scores', 'below', 'above',
                    'top', 'best', 'worst', 'lowest', 'highest', 'risk',
                    // submission/activity qualifiers
                    'submitted', 'submission', 'submissions',
                    'assignment', 'assignments', 'quiz', 'quizzes',
                ],
            ],
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: PASS — staff phrasings → `course_staff`; student phrasings still → `student_listing`; grade staff → null.

If any PRE-EXISTING `student_listing` data-provider case now fails because `who`→`list` changed its result, that is expected only for who-phrasings; the listed student cases (`'list students'`, `'students list'`, `'show students'`, `'show me the students'`, `'current course students'`, `'all students'`, `'list enrolled students'`) must all still pass unchanged — if one breaks, the registry `none_of`/`requires` logic is wrong, fix the code (not the test).

- [ ] **Step 6: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/intent/synonym_dictionary.php local/ai_analysis/classes/intent/intent_registry.php local/ai_analysis/tests/intent_classifier_test.php
git commit -m "feat(ai_analysis): course_staff intent + staff synonym family"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines.

---

## Task 5: course_staff SQL template

**Files:**
- Modify: `classes/intent/sql_template.php`
- Test: `tests/sql_template_test.php` (append)

- [ ] **Step 1: Write the failing test**

Append to `class sql_template_test` in `tests/sql_template_test.php`:

```php
    public function test_course_staff_builds_sql_with_bound_courseid(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_staff', 55);
        $this->assertStringContainsStringIgnoringCase('from mdl_ai_course_staff', $sql);
        $this->assertSame([55], $params);
    }

    public function test_course_staff_sql_passes_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 55);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_staff', 55);
        $this->assertTrue($validator->validate($sql, $params));
    }
```

- [ ] **Step 2: Run test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: FAIL — `coding_exception` "Unknown intent template: course_staff".

- [ ] **Step 3: Add the template case**

In `classes/intent/sql_template.php`, add a constant alongside `STUDENT_LISTING_SQL`:

```php
    /** Teaching staff for a course, from the privacy-filtered view. */
    private const COURSE_STAFF_SQL =
        'SELECT s.userid, s.firstname, s.lastname, s.role '
        . 'FROM mdl_ai_course_staff s '
        . 'WHERE s.courseid = ? '
        . 'ORDER BY s.lastname '
        . 'LIMIT 1000';
```

And add a `case` to the `switch` in `build()` (before `default`):

```php
            case 'course_staff':
                return [self::COURSE_STAFF_SQL, [$courseid]];
```

- [ ] **Step 4: Run test to verify it passes**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: PASS — including `test_course_staff_sql_passes_validator` (template is manifest-legal against the view).

- [ ] **Step 5: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/classes/intent/sql_template.php local/ai_analysis/tests/sql_template_test.php
git commit -m "feat(ai_analysis): course_staff SQL template over the staff view (validator-clean)"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines.

---

## Task 6: End-to-end staff fast-path (gateway test only — no gateway code change)

**Files:**
- Test: `tests/external_query_test.php` (append)

The gateway already routes any matched intent through the template fast-path (sub-project A). `course_staff` is a new registry entry + template, so NO `query.php` change is needed — this task proves the framework generalises.

- [ ] **Step 1: Write the failing/confirming test**

Append to `class external_query_test` in `tests/external_query_test.php`:

```php
    public function test_course_staff_fast_path_serves_without_calling_ai(): void {
        global $DB;
        // Seed a course-context teacher directly (no enrol/role hooks — keeps the
        // test hermetic against unrelated half-installed plugins in this instance).
        $coursectx = \context_course::instance($this->course->id);
        $teacherrole = $DB->get_record('role', ['shortname' => 'teacher'], '*', MUST_EXIST);
        $staff = $this->getDataGenerator()->create_user();
        $DB->insert_record('role_assignments', (object) [
            'roleid'       => $teacherrole->id,
            'contextid'    => $coursectx->id,
            'userid'       => $staff->id,
            'timemodified' => time(),
            'modifierid'   => 0,
            'component'    => '',
            'itemid'       => 0,
            'sortorder'    => 0,
        ]);

        $resp = $this->call('who teaches this course');

        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertGreaterThanOrEqual(1, $resp['row_count']);
        $this->assertSame(0, $this->stub->call_count); // no LLM call

        $audit = $DB->get_record('local_ai_analysis_audit', ['userid' => $this->teacher->id], '*', MUST_EXIST);
        $this->assertSame('template', $audit->provider);
    }
```

- [ ] **Step 2: Run the gateway test file**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: PASS — all gateway tests including the new staff fast-path (rows returned, AI never called, audit provider 'template'). If it fails because the view is empty/missing in the test DB, confirm Task 1 Step 7 (`init.php`) was run.

- [ ] **Step 3: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/tests/external_query_test.php
git commit -m "test(ai_analysis): end-to-end course_staff fast-path through the gateway"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines.

---

## Task 7: Docs + INSTALL + full suite

**Files:**
- Modify: `INSTALL.md`, `docs/ai-memory/02-features-log.md`, `04-current-state.md`, `03-decisions.md`

- [ ] **Step 1: Full suite**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite`
Expected: OK — all pre-existing + new tests pass (the 2 pre-existing "risky" print-output warnings in `purge_audit_task_test` are fine). Report only actual FAILures.

- [ ] **Step 2: INSTALL.md — note the new RO grant**

In `INSTALL.md`, where the read-only grants are described, add a line that `db/readonly_grants.sql` now also grants SELECT on `mdl_ai_course_staff` (the staff view), and that the view itself is created automatically by plugin install/upgrade — only the GRANT is manual.

- [ ] **Step 3: Update ai-memory docs**

- `02-features-log.md`: add "Sub-project C — Role/People Queries": plugin-owned `mdl_ai_course_staff` view (4 staff roles, course context, site-admins excluded via FIND_IN_SET, only firstname/lastname/role); `classes/db/course_staff_view.php` + `db/install.php` + upgrade step + RO grant; manifest exposure + scope-note; `course_staff` intent template + staff synonym family + `who`→`list`; pii_scrubber covers the view names; new/updated tests; version `2026061201 / 0.9.0`.
- `04-current-state.md`: under Done, add Sub-project C; bump version/test count; update the manifest section (now 14 tables + 1 view); note the privacy decision is now implemented (staff visible, site-admins + usernames hidden); note category-level staff limitation; next = B (analytics views), D (memory).
- `03-decisions.md`: record C's locked decisions (staff = manager+coursecreator+editingteacher+teacher, course context only; site-admins excluded dynamically even with a staff role; exposure via pre-filtered RO view not raw role tables; plugin owns the view via install/upgrade; only firstname/lastname/role projected).

- [ ] **Step 4: Commit**

```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092/moodle
git add local/ai_analysis/INSTALL.md local/ai_analysis/docs/ai-memory/
git commit -m "docs(ai_analysis): record sub-project C (course-staff view); bump to 0.9.0"
```

IMPORTANT commit rule: NO Co-Authored-By / Claude / Anthropic signature lines.

---

## Self-Review

- **Spec coverage:** view definition + dynamic site-admin exclusion (T1) ✓; plugin owns view via install+upgrade so it exists in PHPUnit DB (T1) ✓; RO grant (T1) ✓; manifest exposure + scope-note (T2) ✓; PII for view names (T3) ✓; staff synonym family + who→list + course_staff intent (T4) ✓; course_staff template passes validator (T5) ✓; end-to-end fast-path, no AI, provider='template' (T6) ✓; only firstname/lastname/role projected — asserted by the view-shape test (T1) and no other columns in template/manifest ✓; course-context-only limitation tested (T1) ✓; docs/INSTALL (T7) ✓.
- **Placeholder scan:** none — every code step shows complete code.
- **Type consistency:** `course_staff_view::definition_sql(string): string`, `::create(\moodle_database): void`, `::VIEW`; manifest key `mdl_ai_course_staff` with columns `[courseid,userid,firstname,lastname,role]`; intent id `course_staff`; template uses positional `?`; PII keys `mdl_ai_course_staff.firstname/lastname`. All consistent across tasks. Version `2026061201` used identically in upgrade guard + version.php.
