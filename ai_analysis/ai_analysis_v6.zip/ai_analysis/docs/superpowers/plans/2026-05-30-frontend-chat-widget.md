# Frontend Chat Widget Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a floating natural-language chat widget to `local_ai_analysis` that lets capable users query student data from any Moodle page and see a table, an auto-detected bar chart, and an AI-formatted answer.

**Architecture:** A legacy `before_footer` callback in `lib.php` renders a Mustache widget skeleton (FAB + drawer + fullscreen overlay) for users holding `local/ai_analysis:query` in the current page context, and loads an AMD module. The AMD module (`amd/src/chat_widget.js`) owns all state, calls the existing `local_ai_analysis_query` external function via `core/ajax`, and renders results (table + `core/chartjs` bar chart + prose). No new PHP classes, no DB changes.

**Tech Stack:** PHP 8.1, Moodle 4.5 output/template API, Mustache, AMD/ES6, `core/ajax`, `core/chartjs`, grunt (AMD build), PHPUnit.

**Spec:** `docs/superpowers/specs/2026-05-30-ai-analysis-frontend-chat-widget-design.md`

---

## File Structure

| File | Action | Responsibility |
|---|---|---|
| `lang/en/local_ai_analysis.php` | Modify | Add widget UI strings |
| `templates/chat_widget.mustache` | Create | Widget DOM skeleton (FAB + drawer + fullscreen) |
| `lib.php` | Modify | `local_ai_analysis_before_footer()` — capability gate + render + AMD load |
| `tests/lib_test.php` | Create | PHPUnit: capability gate + render |
| `styles.css` | Create | Widget styles (scoped `.local-ai-analysis-widget`) |
| `amd/src/chat_widget.js` | Create | State machine, AJAX, table/chart/answer rendering, session history |
| `amd/build/chat_widget.min.js` | Generated | Built by grunt (committed) |
| `version.php` | Modify | Bump to `2026053002` |

**Task order rationale:** The lang strings and template (Task 1) must exist before the `lib.php` PHPUnit test (Task 2), because that test renders the template — so the test doubles as template validation.

---

### Task 1: Lang strings + Mustache template

**Files:**
- Modify: `lang/en/local_ai_analysis.php` (append before closing — file has no `?>`)
- Create: `templates/chat_widget.mustache`

- [ ] **Step 1: Append widget UI strings to the lang file**

Add these lines at the end of `lang/en/local_ai_analysis.php`:

```php

// Sprint 4: chat widget UI strings.
$string['widget_title']        = 'AI Data Assistant';
$string['widget_open']         = 'Open AI Data Assistant';
$string['widget_newchat']      = 'New chat';
$string['widget_expand']       = 'Expand to full screen';
$string['widget_collapse']     = 'Collapse to drawer';
$string['widget_close']        = 'Close';
$string['widget_placeholder']  = 'Ask about your student data…';
$string['widget_ask']          = 'Ask';
$string['widget_welcome']      = 'What should we analyse today?';
$string['widget_welcome_sub']  = 'Ask a question about your student data';
$string['widget_loading']      = 'Analysing…';
$string['widget_history']      = 'History';
$string['widget_nohistory']    = 'No queries yet';
$string['widget_suggestion1']  = 'Top 10 students by grade';
$string['widget_suggestion2']  = 'Students at risk of failing';
$string['widget_suggestion3']  = 'Average grade per course';
$string['widget_error']        = 'Something went wrong';
```

- [ ] **Step 2: Create the Mustache template**

Create `templates/chat_widget.mustache` with this exact content:

```mustache
{{!
    @template local_ai_analysis/chat_widget

    AI Analysis floating chat widget.

    Context variables required for this template:
    * courseid - int, the current course id (0 if none)

    Example context (json):
    {
        "courseid": 2
    }
}}
<div class="local-ai-analysis-widget" data-region="ai-widget" data-state="collapsed" data-view="welcome"
     data-courseid="{{courseid}}"
     data-str-loading="{{#str}}widget_loading, local_ai_analysis{{/str}}"
     data-str-ask="{{#str}}widget_ask, local_ai_analysis{{/str}}"
     data-str-error="{{#str}}widget_error, local_ai_analysis{{/str}}">

    <button type="button" class="lai-fab" data-action="open"
            aria-label="{{#str}}widget_open, local_ai_analysis{{/str}}">
        <span aria-hidden="true">&#129302;</span>
    </button>

    <div class="lai-panel" data-region="panel" role="dialog"
         aria-label="{{#str}}widget_title, local_ai_analysis{{/str}}">

        <div class="lai-header">
            <span class="lai-title"><span aria-hidden="true">&#129302;</span> {{#str}}widget_title, local_ai_analysis{{/str}}</span>
            <div class="lai-header-actions">
                <button type="button" class="lai-btn" data-action="new"
                        title="{{#str}}widget_newchat, local_ai_analysis{{/str}}"
                        aria-label="{{#str}}widget_newchat, local_ai_analysis{{/str}}">&#43;</button>
                <button type="button" class="lai-btn" data-action="expand"
                        title="{{#str}}widget_expand, local_ai_analysis{{/str}}"
                        aria-label="{{#str}}widget_expand, local_ai_analysis{{/str}}">&#10530;</button>
                <button type="button" class="lai-btn" data-action="collapse"
                        title="{{#str}}widget_collapse, local_ai_analysis{{/str}}"
                        aria-label="{{#str}}widget_collapse, local_ai_analysis{{/str}}">&#10531;</button>
                <button type="button" class="lai-btn" data-action="close"
                        title="{{#str}}widget_close, local_ai_analysis{{/str}}"
                        aria-label="{{#str}}widget_close, local_ai_analysis{{/str}}">&#10005;</button>
            </div>
        </div>

        <div class="lai-body">
            <aside class="lai-sidebar" data-region="sidebar">
                <button type="button" class="lai-sidebar-new" data-action="new">&#43; {{#str}}widget_newchat, local_ai_analysis{{/str}}</button>
                <div class="lai-history-label">{{#str}}widget_history, local_ai_analysis{{/str}}</div>
                <ul class="lai-history" data-region="history"></ul>
            </aside>

            <div class="lai-main">
                <div class="lai-welcome" data-region="welcome">
                    <h2 class="lai-welcome-title">{{#str}}widget_welcome, local_ai_analysis{{/str}}</h2>
                    <p class="lai-welcome-sub">{{#str}}widget_welcome_sub, local_ai_analysis{{/str}}</p>
                    <div class="lai-suggestions">
                        <button type="button" class="lai-chip" data-action="suggest">{{#str}}widget_suggestion1, local_ai_analysis{{/str}}</button>
                        <button type="button" class="lai-chip" data-action="suggest">{{#str}}widget_suggestion2, local_ai_analysis{{/str}}</button>
                        <button type="button" class="lai-chip" data-action="suggest">{{#str}}widget_suggestion3, local_ai_analysis{{/str}}</button>
                    </div>
                </div>
                <div class="lai-thread" data-region="thread"></div>
            </div>
        </div>

        <div class="lai-input-bar">
            <div class="lai-input-wrap">
                <input type="text" class="lai-input" data-region="input"
                       placeholder="{{#str}}widget_placeholder, local_ai_analysis{{/str}}" autocomplete="off">
                <button type="button" class="lai-send" data-action="send">{{#str}}widget_ask, local_ai_analysis{{/str}}</button>
            </div>
        </div>
    </div>
</div>
```

- [ ] **Step 3: Lint the template (optional but recommended)**

Run from the Moodle root:
```bash
docker exec moodle-web-8092 sh -c 'cd /var/www/html && npx grunt mustache --root=local/ai_analysis' 2>&1 | tail -5
```
Expected: no mustache errors (or command unavailable — skip if so; Task 2's PHPUnit test validates rendering).

- [ ] **Step 4: Commit**

```bash
git add lang/en/local_ai_analysis.php templates/chat_widget.mustache
git commit -m "feat(ai_analysis): add chat widget lang strings and Mustache template"
```

---

### Task 2: lib.php before_footer callback + PHPUnit tests

**Files:**
- Modify: `lib.php`
- Create: `tests/lib_test.php`

- [ ] **Step 1: Write the failing test**

Create `tests/lib_test.php`:

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot . '/local/ai_analysis/lib.php');

/**
 * @covers ::local_ai_analysis_before_footer
 */
class lib_test extends \advanced_testcase {

    public function test_widget_rendered_for_capable_user(): void {
        global $PAGE;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $teacher = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($teacher->id, $course->id, 'editingteacher');
        $this->setUser($teacher);

        $PAGE->set_course($course);
        $PAGE->set_context(\context_course::instance($course->id));

        $html = \local_ai_analysis_before_footer();
        $this->assertStringContainsString('data-region="ai-widget"', $html);
    }

    public function test_widget_not_rendered_for_incapable_user(): void {
        global $PAGE;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $student = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($student->id, $course->id, 'student');
        $this->setUser($student);

        $PAGE->set_course($course);
        $PAGE->set_context(\context_course::instance($course->id));

        $html = \local_ai_analysis_before_footer();
        $this->assertSame('', $html);
    }
}
```

- [ ] **Step 2: Run the test to verify it fails**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/lib_test.php
```
Expected: FAIL with `Error: Call to undefined function local_ai_analysis_before_footer()`.

- [ ] **Step 3: Implement the callback**

Replace the entire contents of `lib.php` with:

```php
<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Inject the AI analysis chat widget into the page footer.
 *
 * Legacy `before_footer` callback. Moodle 4.5 captures the returned string
 * (via \core\hook\output\before_footer_html_generation::process_legacy_callbacks())
 * and appends it to the footer before JS is finalised.
 *
 * Returns an empty string when the user lacks the `local/ai_analysis:query`
 * capability in the current page context. The capability is CONTEXT_COURSE
 * level, so it is checked against $PAGE->context (a teacher holds it inside
 * their course, not system-wide). This is a display gate only; the
 * local_ai_analysis_query external function re-checks the capability.
 *
 * @return string HTML appended to the footer, or '' if the widget is hidden.
 */
function local_ai_analysis_before_footer(): string {
    global $PAGE, $OUTPUT;

    if (!isloggedin() || isguestuser() || empty($PAGE->context)) {
        return '';
    }
    if (!has_capability('local/ai_analysis:query', $PAGE->context)) {
        return '';
    }

    $courseid = (int) ($PAGE->course->id ?? SITEID);
    $PAGE->requires->js_call_amd('local_ai_analysis/chat_widget', 'init', [$courseid]);

    return $OUTPUT->render_from_template('local_ai_analysis/chat_widget', [
        'courseid' => $courseid,
    ]);
}
```

- [ ] **Step 4: Run the test to verify it passes**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/lib_test.php
```
Expected: PASS (2 tests). If a "Unexpected debugging() call" error appears from theme rendering, add `$this->resetDebugging();` as the last line of each test method and re-run.

- [ ] **Step 5: Commit**

```bash
git add lib.php tests/lib_test.php
git commit -m "feat(ai_analysis): add before_footer hook rendering the chat widget"
```

---

### Task 3: Widget styles

**Files:**
- Create: `styles.css`

- [ ] **Step 1: Create the stylesheet**

Create `styles.css` with this exact content:

```css
/* AI Analysis chat widget. All rules scoped to .local-ai-analysis-widget. */

.local-ai-analysis-widget {
    --lai-blue: #0F6CBF;
    --lai-border: #d9dee3;
}

/* Floating action button (collapsed state). */
.local-ai-analysis-widget .lai-fab {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 56px;
    height: 56px;
    border: none;
    border-radius: 50%;
    background: var(--lai-blue);
    color: #fff;
    font-size: 24px;
    line-height: 1;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    z-index: 1050;
}
.local-ai-analysis-widget[data-state="drawer"] .lai-fab,
.local-ai-analysis-widget[data-state="fullscreen"] .lai-fab {
    display: none;
}

/* Panel: shared by drawer + fullscreen, hidden when collapsed. */
.local-ai-analysis-widget .lai-panel {
    display: none;
    flex-direction: column;
    background: #fff;
    color: #1d2125;
}
.local-ai-analysis-widget[data-state="drawer"] .lai-panel,
.local-ai-analysis-widget[data-state="fullscreen"] .lai-panel {
    display: flex;
}

/* Drawer geometry. */
.local-ai-analysis-widget[data-state="drawer"] .lai-panel {
    position: fixed;
    bottom: 0;
    right: 0;
    width: 360px;
    height: 70vh;
    max-height: 600px;
    border: 1px solid var(--lai-border);
    border-radius: 10px 0 0 0;
    box-shadow: -2px -2px 16px rgba(0, 0, 0, 0.15);
    z-index: 1060;
}

/* Fullscreen geometry. */
.local-ai-analysis-widget[data-state="fullscreen"] .lai-panel {
    position: fixed;
    inset: 0;
    width: 100%;
    height: 100%;
    border: none;
    border-radius: 0;
    z-index: 9999;
}

/* Header. */
.local-ai-analysis-widget .lai-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;
    background: var(--lai-blue);
    color: #fff;
    flex-shrink: 0;
}
.local-ai-analysis-widget[data-state="drawer"] .lai-header {
    border-radius: 10px 0 0 0;
}
.local-ai-analysis-widget .lai-title {
    font-weight: 600;
    font-size: 14px;
}
.local-ai-analysis-widget .lai-header-actions {
    display: flex;
    gap: 6px;
}
.local-ai-analysis-widget .lai-btn {
    background: transparent;
    border: none;
    color: #fff;
    font-size: 15px;
    line-height: 1;
    cursor: pointer;
    padding: 4px 6px;
    border-radius: 4px;
    opacity: 0.9;
}
.local-ai-analysis-widget .lai-btn:hover {
    background: rgba(255, 255, 255, 0.18);
    opacity: 1;
}
/* Show only the relevant resize control per state. */
.local-ai-analysis-widget[data-state="drawer"] [data-action="collapse"],
.local-ai-analysis-widget[data-state="fullscreen"] [data-action="expand"] {
    display: none;
}

/* Body: sidebar + main. */
.local-ai-analysis-widget .lai-body {
    display: flex;
    flex: 1 1 auto;
    min-height: 0;
}
.local-ai-analysis-widget .lai-sidebar {
    display: none;
    flex-direction: column;
    width: 200px;
    border-right: 1px solid var(--lai-border);
    background: #f8f9fa;
    padding: 12px;
    overflow-y: auto;
    flex-shrink: 0;
}
.local-ai-analysis-widget[data-state="fullscreen"] .lai-sidebar {
    display: flex;
}
.local-ai-analysis-widget .lai-sidebar-new {
    background: transparent;
    border: 1px solid var(--lai-border);
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 13px;
    cursor: pointer;
    color: var(--lai-blue);
    margin-bottom: 12px;
}
.local-ai-analysis-widget .lai-history-label {
    font-size: 11px;
    text-transform: uppercase;
    color: #6c757d;
    font-weight: 700;
    margin-bottom: 6px;
}
.local-ai-analysis-widget .lai-history {
    list-style: none;
    margin: 0;
    padding: 0;
}
.local-ai-analysis-widget .lai-history-item {
    padding: 5px 8px;
    border-radius: 5px;
    font-size: 12px;
    color: #495057;
    cursor: pointer;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.local-ai-analysis-widget .lai-history-item:hover {
    background: #e8f0fe;
    color: var(--lai-blue);
}

/* Main area. */
.local-ai-analysis-widget .lai-main {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
}

/* Welcome view: shown only in fullscreen + welcome view. */
.local-ai-analysis-widget .lai-welcome {
    display: none;
    flex: 1 1 auto;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 24px;
}
.local-ai-analysis-widget[data-state="fullscreen"][data-view="welcome"] .lai-welcome {
    display: flex;
}
.local-ai-analysis-widget .lai-welcome-title {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 6px;
}
.local-ai-analysis-widget .lai-welcome-sub {
    color: #6c757d;
    margin: 0 0 16px;
}
.local-ai-analysis-widget .lai-suggestions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: center;
}
.local-ai-analysis-widget .lai-chip {
    border: 1px solid var(--lai-border);
    border-radius: 20px;
    padding: 6px 14px;
    font-size: 13px;
    background: #fff;
    color: #495057;
    cursor: pointer;
}
.local-ai-analysis-widget .lai-chip:hover {
    border-color: var(--lai-blue);
    color: var(--lai-blue);
}

/* Thread / results. */
.local-ai-analysis-widget .lai-thread {
    flex: 1 1 auto;
    overflow-y: auto;
    padding: 12px 16px;
    min-height: 0;
}
.local-ai-analysis-widget[data-view="welcome"] .lai-thread {
    display: none;
}
.local-ai-analysis-widget[data-state="fullscreen"][data-view="thread"] .lai-welcome {
    display: none;
}
.local-ai-analysis-widget .lai-msg-user {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 10px;
}
.local-ai-analysis-widget .lai-bubble {
    background: #f1f3f5;
    border-radius: 14px 14px 2px 14px;
    padding: 8px 12px;
    font-size: 13px;
    max-width: 80%;
}
.local-ai-analysis-widget .lai-table-wrap {
    overflow-x: auto;
    margin-bottom: 10px;
}
.local-ai-analysis-widget .lai-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}
.local-ai-analysis-widget .lai-table th,
.local-ai-analysis-widget .lai-table td {
    padding: 4px 8px;
    text-align: left;
    border-bottom: 1px solid #eef0f2;
}
.local-ai-analysis-widget .lai-table th {
    background: #f0f4fa;
    font-weight: 600;
}
.local-ai-analysis-widget .lai-table tbody tr:nth-child(even) {
    background: #fafbfc;
}
.local-ai-analysis-widget .lai-chart-wrap {
    position: relative;
    height: 220px;
    margin-bottom: 10px;
}
.local-ai-analysis-widget .lai-answer {
    font-size: 13px;
    color: #333;
    background: #f5f7fb;
    border-left: 3px solid var(--lai-blue);
    padding: 8px 12px;
    border-radius: 0 4px 4px 0;
    white-space: pre-wrap;
}
.local-ai-analysis-widget .lai-caption {
    font-size: 11px;
    color: #6c757d;
    margin-top: 6px;
}
.local-ai-analysis-widget .lai-error {
    font-size: 13px;
    color: #842029;
    background: #f8d7da;
    border-left: 3px solid #dc3545;
    padding: 8px 12px;
    border-radius: 0 4px 4px 0;
}

/* Input bar. */
.local-ai-analysis-widget .lai-input-bar {
    flex-shrink: 0;
    border-top: 1px solid var(--lai-border);
    background: #fafbfc;
    padding: 10px 16px;
}
.local-ai-analysis-widget .lai-input-wrap {
    display: flex;
    gap: 8px;
    align-items: center;
    max-width: 600px;
    margin: 0 auto;
}
.local-ai-analysis-widget .lai-input {
    flex: 1 1 auto;
    border: 1px solid var(--lai-border);
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 13px;
}
.local-ai-analysis-widget .lai-input:focus {
    outline: none;
    border-color: var(--lai-blue);
    box-shadow: 0 0 0 2px rgba(15, 108, 191, 0.2);
}
.local-ai-analysis-widget .lai-send {
    background: var(--lai-blue);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
}
.local-ai-analysis-widget .lai-send:disabled,
.local-ai-analysis-widget .lai-input:disabled {
    opacity: 0.6;
    cursor: default;
}
```

- [ ] **Step 2: Commit**

```bash
git add styles.css
git commit -m "feat(ai_analysis): add chat widget styles"
```

---

### Task 4: AMD module

**Files:**
- Create: `amd/src/chat_widget.js`

- [ ] **Step 1: Create the ES6 module**

Create `amd/src/chat_widget.js` with this exact content:

```javascript
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AI Analysis floating chat widget.
 *
 * @module     local_ai_analysis/chat_widget
 * @copyright  2026 Himanshu Bijja
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {call as fetchMany} from 'core/ajax';
import ChartJS from 'core/chartjs';
import Notification from 'core/notification';

const SELECTORS = {
    ROOT: '[data-region="ai-widget"]',
    INPUT: '[data-region="input"]',
    THREAD: '[data-region="thread"]',
    HISTORY: '[data-region="history"]',
    SEND: '[data-action="send"]',
};

const STATE = {COLLAPSED: 'collapsed', DRAWER: 'drawer', FULLSCREEN: 'fullscreen'};

let courseId = 0;
const sessionHistory = [];
const resultCache = {};
let charts = [];

/**
 * Initialise the widget.
 *
 * @param {Number} courseid The current course id.
 */
export const init = (courseid) => {
    courseId = parseInt(courseid, 10) || 0;
    const root = document.querySelector(SELECTORS.ROOT);
    if (!root || root.dataset.initialised) {
        return;
    }
    root.dataset.initialised = '1';
    registerListeners(root);
};

/**
 * Wire up delegated click + keydown listeners.
 *
 * @param {HTMLElement} root The widget root element.
 */
const registerListeners = (root) => {
    root.addEventListener('click', (e) => {
        const actionEl = e.target.closest('[data-action]');
        if (actionEl) {
            handleAction(root, actionEl.dataset.action, actionEl);
            return;
        }
        const histEl = e.target.closest('[data-history-id]');
        if (histEl) {
            showCached(root, histEl.dataset.historyId);
        }
    });
    const input = root.querySelector(SELECTORS.INPUT);
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            submitQuery(root, input.value);
        }
    });
};

/**
 * Dispatch a data-action click.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} action The action name.
 * @param {HTMLElement} el The clicked element.
 */
const handleAction = (root, action, el) => {
    switch (action) {
        case 'open':
            setState(root, STATE.DRAWER);
            focusInput(root);
            break;
        case 'expand':
            setState(root, STATE.FULLSCREEN);
            focusInput(root);
            break;
        case 'collapse':
            setState(root, STATE.DRAWER);
            focusInput(root);
            break;
        case 'close':
            setState(root, STATE.COLLAPSED);
            break;
        case 'new':
            clearThread(root);
            root.dataset.view = 'welcome';
            focusInput(root);
            break;
        case 'send':
            submitQuery(root, root.querySelector(SELECTORS.INPUT).value);
            break;
        case 'suggest':
            submitQuery(root, el.textContent.trim());
            break;
        default:
            break;
    }
};

/**
 * Set the widget state attribute.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} state One of STATE.*.
 */
const setState = (root, state) => {
    root.dataset.state = state;
};

/**
 * Focus the prompt input shortly after a state change.
 *
 * @param {HTMLElement} root The widget root element.
 */
const focusInput = (root) => {
    const input = root.querySelector(SELECTORS.INPUT);
    if (input) {
        setTimeout(() => input.focus(), 50);
    }
};

/**
 * Toggle the loading state of the input + send button.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {Boolean} loading Whether a request is in flight.
 */
const setLoading = (root, loading) => {
    const input = root.querySelector(SELECTORS.INPUT);
    const send = root.querySelector(SELECTORS.SEND);
    input.disabled = loading;
    send.disabled = loading;
    send.textContent = loading ? root.dataset.strLoading : root.dataset.strAsk;
};

/**
 * Generate a RFC4122-ish unique id, falling back when crypto is unavailable.
 *
 * @return {String} A unique request id.
 */
const generateRequestId = () => {
    if (window.crypto && window.crypto.randomUUID) {
        return window.crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

/**
 * Submit a prompt to the external function and render the result.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} rawPrompt The user's prompt.
 */
const submitQuery = (root, rawPrompt) => {
    const prompt = (rawPrompt || '').trim();
    if (!prompt) {
        return;
    }
    const requestId = generateRequestId();
    root.querySelector(SELECTORS.INPUT).value = '';
    root.dataset.view = 'thread';
    setLoading(root, true);

    fetchMany([{
        methodname: 'local_ai_analysis_query',
        args: {prompt: prompt, courseid: courseId, request_id: requestId, format: true},
    }])[0]
        .then((response) => {
            cacheAndRender(root, prompt, requestId, response);
            return response;
        })
        .catch((error) => {
            renderError(root, prompt, error.message || root.dataset.strError);
            Notification.exception(error);
        })
        .always(() => {
            setLoading(root, false);
            focusInput(root);
        });
};

/**
 * Cache a successful exchange, push to history, and render it.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} prompt The user's prompt.
 * @param {String} requestId The request id.
 * @param {Object} response The external function response envelope.
 */
const cacheAndRender = (root, prompt, requestId, response) => {
    resultCache[requestId] = {prompt: prompt, response: response};
    sessionHistory.push({requestId: requestId, prompt: prompt});
    renderHistory(root);
    renderRecord(root, resultCache[requestId]);
};

/**
 * Re-display a cached exchange from history.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} requestId The request id key.
 */
const showCached = (root, requestId) => {
    const record = resultCache[requestId];
    if (!record) {
        return;
    }
    root.dataset.view = 'thread';
    renderRecord(root, record);
};

/**
 * Destroy any live charts and empty the thread.
 *
 * @param {HTMLElement} root The widget root element.
 */
const clearThread = (root) => {
    charts.forEach((c) => c.destroy());
    charts = [];
    root.querySelector(SELECTORS.THREAD).innerHTML = '';
};

/**
 * Render a cached exchange (prompt bubble + result) into the thread.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {Object} record A {prompt, response} record.
 */
const renderRecord = (root, record) => {
    clearThread(root);
    const thread = root.querySelector(SELECTORS.THREAD);
    thread.appendChild(buildUserBubble(record.prompt));

    const response = record.response;
    if (!response || response.status !== 'SUCCESS') {
        const msg = (response && response.error) ? response.error : root.dataset.strError;
        thread.appendChild(buildErrorBlock(msg));
        return;
    }

    const rows = parseRows(response.rows);
    if (rows.length) {
        thread.appendChild(buildTable(rows));
        const chart = maybeBuildChart(rows);
        if (chart) {
            thread.appendChild(chart.wrapper);
            charts.push(new ChartJS(chart.canvas.getContext('2d'), chart.config));
        }
    }
    if (response.answer) {
        thread.appendChild(buildAnswer(response.answer));
    }
    if (response.format_note) {
        thread.appendChild(buildCaption(response.format_note));
    }
    thread.scrollTop = thread.scrollHeight;
};

/**
 * Render an error exchange (prompt bubble + error block).
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} prompt The user's prompt.
 * @param {String} message The error message.
 */
const renderError = (root, prompt, message) => {
    clearThread(root);
    const thread = root.querySelector(SELECTORS.THREAD);
    thread.appendChild(buildUserBubble(prompt));
    thread.appendChild(buildErrorBlock(message));
};

/**
 * Parse the response rows (array of JSON strings) into objects.
 *
 * @param {Array} rows The raw rows from the response.
 * @return {Array} Parsed row objects.
 */
const parseRows = (rows) => {
    if (!Array.isArray(rows)) {
        return [];
    }
    const out = [];
    rows.forEach((r) => {
        try {
            out.push(typeof r === 'string' ? JSON.parse(r) : r);
        } catch (e) {
            // Skip an unparseable row.
        }
    });
    return out;
};

/**
 * Create an element with optional class and text (text set safely).
 *
 * @param {String} tag The tag name.
 * @param {String|null} className The class name, or null.
 * @param {String|Number|null} text The text content, or null/undefined.
 * @return {HTMLElement} The created element.
 */
const el = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) {
        node.className = className;
    }
    if (text !== undefined && text !== null) {
        node.textContent = String(text);
    }
    return node;
};

/**
 * Build the right-aligned user prompt bubble.
 *
 * @param {String} prompt The user's prompt.
 * @return {HTMLElement} The bubble wrapper.
 */
const buildUserBubble = (prompt) => {
    const wrap = el('div', 'lai-msg lai-msg-user');
    wrap.appendChild(el('div', 'lai-bubble', prompt));
    return wrap;
};

/**
 * Build an error block.
 *
 * @param {String} message The error message.
 * @return {HTMLElement} The error element.
 */
const buildErrorBlock = (message) => el('div', 'lai-error', message);

/**
 * Build the AI answer prose block.
 *
 * @param {String} answer The formatted answer.
 * @return {HTMLElement} The answer element.
 */
const buildAnswer = (answer) => el('div', 'lai-answer', answer);

/**
 * Build a small caption (e.g. format note).
 *
 * @param {String} note The caption text.
 * @return {HTMLElement} The caption element.
 */
const buildCaption = (note) => el('div', 'lai-caption', note);

/**
 * Build a data table from row objects.
 *
 * @param {Array} rows Parsed row objects (non-empty).
 * @return {HTMLElement} The table wrapper.
 */
const buildTable = (rows) => {
    const cols = Object.keys(rows[0]);
    const wrap = el('div', 'lai-table-wrap');
    const table = el('table', 'lai-table');

    const thead = el('thead');
    const htr = el('tr');
    cols.forEach((c) => htr.appendChild(el('th', null, c)));
    thead.appendChild(htr);
    table.appendChild(thead);

    const tbody = el('tbody');
    rows.forEach((row) => {
        const tr = el('tr');
        cols.forEach((c) => tr.appendChild(el('td', null, row[c])));
        tbody.appendChild(tr);
    });
    table.appendChild(tbody);

    wrap.appendChild(table);
    return wrap;
};

/**
 * Test whether a value is finite-numeric.
 *
 * @param {*} v The value.
 * @return {Boolean} True if numeric.
 */
const isNumeric = (v) => v !== null && v !== '' && !isNaN(parseFloat(v)) && isFinite(v);

/**
 * Build a bar-chart config if the rows contain a numeric column.
 *
 * @param {Array} rows Parsed row objects.
 * @return {Object|null} {wrapper, canvas, config} or null when no chart applies.
 */
const maybeBuildChart = (rows) => {
    if (rows.length < 2) {
        return null;
    }
    const cols = Object.keys(rows[0]);
    let valueKey = null;
    for (let i = 0; i < cols.length; i++) {
        if (rows.every((r) => isNumeric(r[cols[i]]))) {
            valueKey = cols[i];
            break;
        }
    }
    if (!valueKey) {
        return null;
    }
    const labelKey = cols.find((c) => c !== valueKey) || cols[0];
    const labels = rows.map((r) => String(r[labelKey]));
    const values = rows.map((r) => parseFloat(r[valueKey]));

    const wrapper = el('div', 'lai-chart-wrap');
    const canvas = document.createElement('canvas');
    wrapper.appendChild(canvas);

    const config = {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{label: valueKey, data: values, backgroundColor: '#0F6CBF'}],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {legend: {display: false}},
            scales: {y: {beginAtZero: true}},
        },
    };
    return {wrapper: wrapper, canvas: canvas, config: config};
};

/**
 * Re-render the session history list (newest first).
 *
 * @param {HTMLElement} root The widget root element.
 */
const renderHistory = (root) => {
    const list = root.querySelector(SELECTORS.HISTORY);
    list.innerHTML = '';
    sessionHistory.slice().reverse().forEach((item) => {
        const li = el('li', 'lai-history-item', item.prompt);
        li.dataset.historyId = item.requestId;
        list.appendChild(li);
    });
};
```

- [ ] **Step 2: Commit the source**

```bash
git add amd/src/chat_widget.js
git commit -m "feat(ai_analysis): add chat widget AMD source module"
```

---

### Task 5: Build AMD, lint, version bump, full verification

**Files:**
- Generated: `amd/build/chat_widget.min.js` (+ `.map`)
- Modify: `version.php`

- [ ] **Step 1: Build the AMD module with grunt**

Run from the Moodle root inside the container:
```bash
docker exec moodle-web-8092 sh -c 'cd /var/www/html && npx grunt amd --root=local/ai_analysis' 2>&1 | tail -20
```
Expected: `Done.` with no ESLint errors, and `amd/build/chat_widget.min.js` created.

If ESLint reports errors, fix them in `amd/src/chat_widget.js` and re-run until clean. If the `--root` flag is unsupported by this Moodle's Gruntfile, run `docker exec moodle-web-8092 sh -c 'cd /var/www/html && npx grunt amd'` instead (builds all AMD; slower but equivalent).

- [ ] **Step 2: Verify the build artifact exists**

```bash
ls -la local/ai_analysis/amd/build/chat_widget.min.js
```
Expected: file exists and is non-empty.

- [ ] **Step 3: Bump the plugin version**

Edit `version.php` — change the version line and release string:

```php
$plugin->version   = 2026053002;
```
```php
$plugin->release   = '0.4.0 (Sprint 4: frontend chat widget)';
```

- [ ] **Step 4: Run the full plugin test suite**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite
```
Expected: all tests pass (the prior 118 + 2 new lib tests = 120), 0 failures.

- [ ] **Step 5: Commit**

```bash
git add amd/build/chat_widget.min.js amd/build/chat_widget.min.js.map version.php
git commit -m "build(ai_analysis): build chat widget AMD and bump version for Sprint 4"
```

---

## Post-Implementation: ai-memory docs

After all tasks pass, update (per CLAUDE.md project rules):
- `docs/ai-memory/02-features-log.md` — add the Sprint 4 widget entry (files, the `before_footer` hook, AMD module, Chart.js usage).
- `docs/ai-memory/04-current-state.md` — mark Sprint 4 complete; note the widget is wired to `local_ai_analysis_query`.
- `docs/ai-memory/03-decisions.md` — record: (1) legacy `before_footer` callback returning a string (not the hook class) for simplicity + testability; (2) capability checked against `$PAGE->context` not `context_system` because the cap is course-level; (3) chart auto-detection heuristic (first all-numeric column, ≥2 rows); (4) in-memory single-shot history, never sent to the AI.

Commit the doc updates separately.

## Manual Smoke-Test Checklist (run in a browser after deploy)

- FAB appears bottom-right on a course page when logged in as an editing teacher.
- FAB absent for a student (no `local/ai_analysis:query`).
- FAB → drawer; type a valid prompt → table + chart + answer render.
- Out-of-scope prompt → red error block inline (no table/chart).
- ⤢ → fullscreen (welcome heading + chips before first query); ⤡ → drawer; ✕ → FAB.
- ＋ clears the thread back to welcome.
- After queries, fullscreen sidebar lists past prompts; clicking one re-shows its result.
