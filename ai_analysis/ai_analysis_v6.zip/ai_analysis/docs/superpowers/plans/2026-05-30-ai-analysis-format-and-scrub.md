# AI Analysis — PII Scrubber + format_result Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a per-request AI formatting pass (layer 7) that turns query rows into a plain-language answer, guarded by a reversible-token PII scrubber so real student data never reaches the external AI provider.

**Architecture:** Two focused units. `pii_scrubber` (security namespace) tokenises PII columns in result rows and de-tokenises the AI's answer, using a curated `table.column → PII type` map and an alias-safe column-source map surfaced from `sql_validator`. `claude_client` gains `format_result()` (the second `ai_client_interface` method Sprint 2 anticipated), reusing the same HTTP transport seam. The gateway runs scrub → AI #2 → de-tokenise after L6 only when `format=true`, with graceful fallback to raw rows on any AI #2 failure.

**Tech Stack:** PHP 8.1, Moodle 4.5 (`core_external\external_api`, `cache`, `moodle_database`), PHPUnit, Anthropic Messages API, `greenlion/php-sql-parser`.

**Spec:** `docs/superpowers/specs/2026-05-30-ai-analysis-format-and-scrub-design.md`

**Working directory:** `/home/himanshu/moodle-instances/moodle-instance-8092/moodle/local/ai_analysis/`. Paths in this plan are relative to this dir unless prefixed with `moodle/`. Git commands run from repo root `/home/himanshu/moodle-instances/moodle-instance-8092/`.

**Branch:** create a fresh feature branch off `main` before starting:
```bash
cd /home/himanshu/moodle-instances/moodle-instance-8092
git checkout main
git checkout -b feat/ai-analysis-format-scrub
```

**Commit signature:** plain `feat(...)`/`test(...)` messages only — **no** Co-Authored-By / Claude / Anthropic trailer (project rule).

**PHPUnit invocation:** always by file path, never `--filter`. Unrelated broken plugin dirs in this Moodle install emit version.php warnings that disrupt filter-based discovery but do not affect file-path-based runs.

```bash
# One-time (re-run after the version bump in Task 5):
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
```

## File structure

New files in **bold**; existing modified files in plain. Each unit has one responsibility.

```
classes/
├── ai/
│   ├── ai_client_interface.php   (add format_result signature)
│   ├── claude_client.php         (implement format_result; add FORMAT_MAX_TOKENS)
│   └── prompt_builder.php        (add static build_format_system)
├── security/
│   ├── sql_validator.php         (add get_column_source_map + get_column_references, populated during validate)
│   └── **pii_scrubber.php**       (curated PII map, classify_columns, tokenize, detokenize)
└── external/
    └── query.php                 (format param, keep validator instance, L6.5/L7/L7.5, two envelope fields)
lang/en/local_ai_analysis.php     (add formatunavailable)
tests/
├── **pii_scrubber_test.php**
├── sql_validator_test.php        (extend: source/reference accessors)
├── prompt_builder_test.php       (extend: format system prompt)
├── claude_client_test.php        (extend: format_result)
└── external_query_test.php       (extend: format flag + leak guard)
version.php                       (bump)
```

**Data contract shared across tasks:**
- `sql_validator::get_column_source_map(): array` → `output column name => "table.column" | null` (null = derived/not a single plain column).
- `sql_validator::get_column_references(): array` → `output column name => string[]` (every underlying `table.column` the output references; one entry for a plain column, many for a derived expression, none for constants/`COUNT(*)`).
- `pii_scrubber::classify_columns(array $source_map, array $references): array` → `output column name => "table.column" | null | "__REDACT__"`.
- `pii_scrubber::tokenize(array $rows, array $column_map): array` (column_map = the classify_columns output).
- `pii_scrubber::detokenize(string $text): string`.
- `pii_scrubber::is_pii(string $tablecolumn): bool`.
- `ai_client_interface::format_result(string $user_prompt, array $safe_rows): string`.

---

## Task 1: sql_validator column-source accessors (TDD)

**Files:**
- Modify: `classes/security/sql_validator.php`
- Test: `tests/sql_validator_test.php`

- [ ] **Step 1: Add the failing tests** — append these methods inside the existing `sql_validator_test` class in `tests/sql_validator_test.php`:

```php
    public function test_column_source_map_plain_columns(): void {
        $manifest = ['mdl_user' => ['id', 'firstname', 'email']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT id, firstname, email FROM mdl_user LIMIT 10';
        $v->validate($sql, []);
        $this->assertSame([
            'id'        => 'mdl_user.id',
            'firstname' => 'mdl_user.firstname',
            'email'     => 'mdl_user.email',
        ], $v->get_column_source_map());
    }

    public function test_column_source_map_resolves_alias_qualified(): void {
        $manifest = ['mdl_user' => ['id', 'firstname']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        // Column aliased AS fn — output key is the alias, source resolves to the real column.
        $sql = 'SELECT u.id, u.firstname AS fn FROM mdl_user u LIMIT 10';
        $v->validate($sql, []);
        $map = $v->get_column_source_map();
        $this->assertSame('mdl_user.id', $map['id']);
        $this->assertSame('mdl_user.firstname', $map['fn']);
    }

    public function test_column_source_map_derived_is_null_with_references(): void {
        $manifest = ['mdl_user' => ['id', 'firstname', 'lastname']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT COUNT(id) AS n, CONCAT(firstname, lastname) AS full FROM mdl_user LIMIT 10';
        $v->validate($sql, []);
        $map = $v->get_column_source_map();
        $refs = $v->get_column_references();
        $this->assertNull($map['n']);
        $this->assertNull($map['full']);
        $this->assertSame([], $refs['n']);
        $this->assertSame(['mdl_user.firstname', 'mdl_user.lastname'], $refs['full']);
    }
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_validator_test.php`
Expected: errors — `Call to undefined method ... get_column_source_map()`.

- [ ] **Step 3: Add the properties + accessors** — in `classes/security/sql_validator.php`, add after the `$manifest` property declaration:

```php
    /** @var array<string, string|null> output column name => "table.column" | null */
    private array $column_source_map = [];

    /** @var array<string, string[]> output column name => underlying "table.column" list */
    private array $column_references = [];

    public function get_column_source_map(): array {
        return $this->column_source_map;
    }

    public function get_column_references(): array {
        return $this->column_references;
    }
```

- [ ] **Step 4: Populate the maps during validate()** — in `validate()`, replace the existing top-selects loop:

```php
        foreach ($this->iter_top_selects($ast) as $select_ast) {
            $alias_to_table = $this->collect_tables($select_ast, $sql);
            $this->check_columns($select_ast, $alias_to_table, $sql);
        }
```

with:

```php
        $first = true;
        foreach ($this->iter_top_selects($ast) as $select_ast) {
            $alias_to_table = $this->collect_tables($select_ast, $sql);
            $this->check_columns($select_ast, $alias_to_table, $sql);
            if ($first) {
                $this->build_output_map($select_ast, $alias_to_table);
                $first = false;
            }
        }
```

- [ ] **Step 5: Add the helper methods** — add these private methods to `sql_validator`:

```php
    /**
     * Records the output-column → source map for the first top-level SELECT.
     * Plain column references resolve to "table.column"; derived expressions
     * (functions/operators/constants) map to null but record their underlying
     * column references for the PII scrubber's redaction rule.
     */
    private function build_output_map(array $select_ast, array $aliases): void {
        $this->column_source_map = [];
        $this->column_references = [];
        foreach ($select_ast['SELECT'] ?? [] as $col) {
            $etype = $col['expr_type'] ?? '';
            if ($etype === 'comment') {
                continue;
            }
            $alias = null;
            if (is_array($col['alias'] ?? null)) {
                $alias = trim($col['alias']['name'] ?? '', '`" ');
            }
            if ($etype === 'colref') {
                $src  = $this->resolve_colref($col['base_expr'] ?? '', $aliases);
                $name = $alias ?? $this->output_name_for_colref($col['base_expr'] ?? '');
                $this->column_source_map[$name] = $src;
                $this->column_references[$name] = $src !== null ? [$src] : [];
            } else {
                $name = $alias ?? trim($col['base_expr'] ?? '', '`" ');
                $refs = [];
                $this->collect_colref_sources($col['sub_tree'] ?? null, $aliases, $refs);
                $this->column_source_map[$name] = null;
                $this->column_references[$name] = array_values(array_unique($refs));
            }
        }
    }

    /** Resolve a colref base_expr to "table.column" or null if unresolvable. */
    private function resolve_colref(string $base, array $aliases): ?string {
        $base = trim($base);
        if ($base === '' || $base === '*' || str_ends_with($base, '.*')) {
            return null;
        }
        $parts = explode('.', $base);
        if (count($parts) === 2) {
            $alias = trim($parts[0], '`"');
            $colnm = trim($parts[1], '`"');
            return isset($aliases[$alias]) ? $aliases[$alias] . '.' . $colnm : null;
        }
        $colnm  = trim($parts[0], '`"');
        $tables = array_unique(array_values($aliases));
        $match  = null;
        foreach ($tables as $t) {
            if (in_array($colnm, $this->manifest[$t] ?? [], true)) {
                if ($match !== null) {
                    return null; // Ambiguous; validation would already have rejected.
                }
                $match = $t;
            }
        }
        return $match !== null ? $match . '.' . $colnm : null;
    }

    /** Output column name for a colref base_expr (table qualifier stripped). */
    private function output_name_for_colref(string $base): string {
        $parts = explode('.', trim($base));
        return trim(end($parts), '`"');
    }

    /** Recursively collect resolved "table.column" sources from an expression sub_tree. */
    private function collect_colref_sources($node, array $aliases, array &$out): void {
        if (!is_array($node)) {
            return;
        }
        if (isset($node['expr_type'])) {
            if ($node['expr_type'] === 'colref') {
                $src = $this->resolve_colref($node['base_expr'] ?? '', $aliases);
                if ($src !== null) {
                    $out[] = $src;
                }
            }
            if (isset($node['sub_tree']) && is_array($node['sub_tree'])) {
                $this->collect_colref_sources($node['sub_tree'], $aliases, $out);
            }
            return;
        }
        foreach ($node as $child) {
            $this->collect_colref_sources($child, $aliases, $out);
        }
    }
```

- [ ] **Step 6: Run, verify all pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_validator_test.php`
Expected: `OK (19 tests, ...)` (16 existing + 3 new).

- [ ] **Step 7: Commit**

```bash
git add moodle/local/ai_analysis/classes/security/sql_validator.php moodle/local/ai_analysis/tests/sql_validator_test.php
git commit -m "feat(ai_analysis): surface alias-safe column-source map from sql_validator"
```

---

## Task 2: pii_scrubber (TDD)

**Files:**
- Create: `classes/security/pii_scrubber.php`
- Test: `tests/pii_scrubber_test.php`

- [ ] **Step 1: Write the failing tests** — create `tests/pii_scrubber_test.php`:

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\security\pii_scrubber;

/**
 * @covers \local_ai_analysis\security\pii_scrubber
 */
class pii_scrubber_test extends \advanced_testcase {

    public function test_is_pii_known_and_unknown(): void {
        $this->assertTrue(pii_scrubber::is_pii('mdl_user.firstname'));
        $this->assertTrue(pii_scrubber::is_pii('mdl_user.email'));
        $this->assertFalse(pii_scrubber::is_pii('mdl_user.id'));
        $this->assertFalse(pii_scrubber::is_pii('mdl_grade_grades.finalgrade'));
    }

    public function test_classify_columns_plain_pii_and_nonpii(): void {
        $source = ['id' => 'mdl_user.id', 'firstname' => 'mdl_user.firstname'];
        $refs   = ['id' => ['mdl_user.id'], 'firstname' => ['mdl_user.firstname']];
        $this->assertSame([
            'id'        => null,
            'firstname' => 'mdl_user.firstname',
        ], pii_scrubber::classify_columns($source, $refs));
    }

    public function test_classify_columns_derived_referencing_pii_is_redacted(): void {
        $source = ['n' => null, 'full' => null];
        $refs   = ['n' => [], 'full' => ['mdl_user.firstname', 'mdl_user.lastname']];
        $this->assertSame([
            'n'    => null,
            'full' => '__REDACT__',
        ], pii_scrubber::classify_columns($source, $refs));
    }

    public function test_tokenize_masks_pii_column(): void {
        $s = new pii_scrubber();
        $rows = [
            (object) ['id' => 1, 'firstname' => 'Alice'],
            (object) ['id' => 2, 'firstname' => 'Bob'],
        ];
        $map = ['id' => null, 'firstname' => 'mdl_user.firstname'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame(1, $out[0]['id']);
        $this->assertSame('PERSON_1', $out[0]['firstname']);
        $this->assertSame('PERSON_2', $out[1]['firstname']);
    }

    public function test_tokenize_is_stable_per_value(): void {
        $s = new pii_scrubber();
        $rows = [
            (object) ['firstname' => 'Alice'],
            (object) ['firstname' => 'Alice'],
            (object) ['firstname' => 'Bob'],
        ];
        $map = ['firstname' => 'mdl_user.firstname'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame('PERSON_1', $out[0]['firstname']);
        $this->assertSame('PERSON_1', $out[1]['firstname']);
        $this->assertSame('PERSON_2', $out[2]['firstname']);
    }

    public function test_tokenize_redacts_derived_column(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['full' => 'Alice Smith']];
        $map = ['full' => '__REDACT__'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame('REDACTED_1', $out[0]['full']);
    }

    public function test_tokenize_passes_through_nonpii_and_empty(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['id' => 5, 'firstname' => '', 'email' => null]];
        $map = ['id' => null, 'firstname' => 'mdl_user.firstname', 'email' => 'mdl_user.email'];
        $out = $s->tokenize($rows, $map);
        $this->assertSame(5, $out[0]['id']);
        $this->assertSame('', $out[0]['firstname']); // empty not tokenised
        $this->assertNull($out[0]['email']);          // null not tokenised
    }

    public function test_detokenize_round_trip(): void {
        $s = new pii_scrubber();
        $rows = [(object) ['firstname' => 'Alice'], (object) ['firstname' => 'Bob']];
        $s->tokenize($rows, ['firstname' => 'mdl_user.firstname']);
        $answer = 'PERSON_1 scored higher than PERSON_2.';
        $this->assertSame('Alice scored higher than Bob.', $s->detokenize($answer));
    }

    public function test_detokenize_longest_token_first(): void {
        $s = new pii_scrubber();
        // Force 11 distinct values so PERSON_1 and PERSON_11 both exist.
        $rows = [];
        for ($i = 1; $i <= 11; $i++) {
            $rows[] = (object) ['firstname' => 'Name' . $i];
        }
        $s->tokenize($rows, ['firstname' => 'mdl_user.firstname']);
        // PERSON_11 must restore to Name11, not "Name1" + "1".
        $this->assertSame('Name11 and Name1', $s->detokenize('PERSON_11 and PERSON_1'));
    }

    public function test_detokenize_noop_when_nothing_tokenised(): void {
        $s = new pii_scrubber();
        $this->assertSame('plain text', $s->detokenize('plain text'));
    }
}
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/pii_scrubber_test.php`
Expected: errors — `Class "local_ai_analysis\security\pii_scrubber" not found`.

- [ ] **Step 3: Implement `pii_scrubber`** — create `classes/security/pii_scrubber.php`:

```php
<?php
namespace local_ai_analysis\security;

defined('MOODLE_INTERNAL') || die();

/**
 * Reversible, column-classified PII tokeniser. One instance per request; the
 * token map lives as instance state and is never persisted. tokenize() masks
 * PII column values with stable tokens (PERSON_1, EMAIL_2, …) before rows are
 * sent to the formatting AI; detokenize() restores the real values in the AI's
 * answer before it is shown to the authorised educator.
 */
class pii_scrubber {

    /** Curated source-of-truth: "table.column" => token prefix. */
    private const PII_MAP = [
        'mdl_user.firstname'         => 'PERSON',
        'mdl_user.lastname'          => 'PERSON',
        'mdl_user.firstnamephonetic' => 'PERSON',
        'mdl_user.lastnamephonetic'  => 'PERSON',
        'mdl_user.middlename'        => 'PERSON',
        'mdl_user.alternatename'     => 'PERSON',
        'mdl_user.email'             => 'EMAIL',
        'mdl_user.username'          => 'USERNAME',
        'mdl_user.idnumber'          => 'ID',
        'mdl_user.phone1'            => 'PHONE',
        'mdl_user.phone2'            => 'PHONE',
        'mdl_user.address'           => 'ADDRESS',
        'mdl_user.city'              => 'LOCATION',
        'mdl_user.country'           => 'LOCATION',
        'mdl_user.institution'       => 'ORG',
        'mdl_user.department'        => 'ORG',
        'mdl_user.lastip'            => 'IP',
    ];

    /** Sentinel classification for derived expressions that reference PII. */
    public const REDACT = '__REDACT__';

    /** @var array<string, string> token => real value */
    private array $map = [];
    /** @var array<string, string> "prefix\0value" => token (stable assignment) */
    private array $reverse = [];
    /** @var array<string, int> prefix => last counter */
    private array $counters = [];

    public static function is_pii(string $tablecolumn): bool {
        return isset(self::PII_MAP[$tablecolumn]);
    }

    /**
     * Compose the per-output classification map from the validator's accessors.
     *
     * @param array $source_map output => "table.column" | null
     * @param array $references output => string[] underlying "table.column" list
     * @return array output => "table.column" | null | self::REDACT
     */
    public static function classify_columns(array $source_map, array $references): array {
        $out = [];
        foreach ($source_map as $name => $src) {
            if ($src !== null && self::is_pii($src)) {
                $out[$name] = $src;
                continue;
            }
            if ($src === null) {
                $hits = false;
                foreach ($references[$name] ?? [] as $ref) {
                    if (self::is_pii($ref)) {
                        $hits = true;
                        break;
                    }
                }
                $out[$name] = $hits ? self::REDACT : null;
                continue;
            }
            $out[$name] = null;
        }
        return $out;
    }

    /**
     * @param array $rows       Result rows (each array or object).
     * @param array $column_map output => "table.column" | null | self::REDACT (from classify_columns)
     * @return array            Rows (as arrays) with PII values replaced by tokens.
     */
    public function tokenize(array $rows, array $column_map): array {
        $result = [];
        foreach ($rows as $row) {
            $arr = (array) $row;
            foreach ($arr as $col => $val) {
                if ($val === null || $val === '') {
                    continue;
                }
                $class = $column_map[$col] ?? null;
                if ($class === null) {
                    continue;
                }
                $prefix = $class === self::REDACT ? 'REDACTED' : (self::PII_MAP[$class] ?? null);
                if ($prefix === null) {
                    continue;
                }
                $arr[$col] = $this->token_for($prefix, (string) $val);
            }
            $result[] = $arr;
        }
        return $result;
    }

    public function detokenize(string $text): string {
        if (empty($this->map)) {
            return $text;
        }
        $tokens = array_keys($this->map);
        // Longest token first so PERSON_11 is restored before PERSON_1.
        usort($tokens, fn($a, $b) => strlen($b) <=> strlen($a));
        foreach ($tokens as $token) {
            $text = str_replace($token, $this->map[$token], $text);
        }
        return $text;
    }

    private function token_for(string $prefix, string $value): string {
        $key = $prefix . "\0" . $value;
        if (isset($this->reverse[$key])) {
            return $this->reverse[$key];
        }
        $n = ($this->counters[$prefix] ?? 0) + 1;
        $this->counters[$prefix] = $n;
        $token = $prefix . '_' . $n;
        $this->reverse[$key] = $token;
        $this->map[$token]   = $value;
        return $token;
    }
}
```

- [ ] **Step 4: Run, verify all pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/pii_scrubber_test.php`
Expected: `OK (10 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
git add moodle/local/ai_analysis/classes/security/pii_scrubber.php moodle/local/ai_analysis/tests/pii_scrubber_test.php
git commit -m "feat(ai_analysis): add reversible-token pii_scrubber"
```

---

## Task 3: prompt_builder::build_format_system (TDD)

**Files:**
- Modify: `classes/ai/prompt_builder.php`
- Test: `tests/prompt_builder_test.php`

- [ ] **Step 1: Add failing tests** — append inside the existing `prompt_builder_test` class:

```php
    public function test_format_system_prompt_has_token_echo_rule(): void {
        $sys = \local_ai_analysis\ai\prompt_builder::build_format_system();
        $this->assertStringContainsString('PERSON_1', $sys);
        $this->assertStringContainsStringIgnoringCase('token', $sys);
        // Must instruct verbatim echo (no expansion/rename).
        $this->assertMatchesRegularExpression('/verbatim|exactly|never (expand|rename|change)/i', $sys);
    }

    public function test_format_system_prompt_forbids_invention_and_tables(): void {
        $sys = \local_ai_analysis\ai\prompt_builder::build_format_system();
        $this->assertMatchesRegularExpression('/only.*rows|never invent/i', $sys);
        $this->assertStringContainsStringIgnoringCase('table', $sys); // "Do not output markdown tables"
    }
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/prompt_builder_test.php`
Expected: errors — `Call to undefined method ... build_format_system()`.

- [ ] **Step 3: Implement** — add this static method to `prompt_builder`:

```php
    /**
     * System prompt for the AI #2 formatting pass. Static, server-controlled.
     * The token-echo rule is critical: de-tokenisation is a literal string
     * swap, so any rewrite of a token leaves a broken placeholder visible.
     */
    public static function build_format_system(): string {
        return <<<PROMPT
You are a data assistant that summarises Moodle query results for an educator in plain language.

RULES:
1. Answer ONLY from the rows provided in the user message. Never invent data that is not present.
2. Some values are opaque tokens such as PERSON_1, EMAIL_3, ID_2. Echo these tokens EXACTLY and verbatim. Never expand, rename, translate, or describe them (do not write "the first student"). They are placeholders substituted later; any change leaves a broken placeholder visible to the user.
3. Do not output markdown tables. Use concise prose, with short bullet lists only when helpful.
4. If the result set is empty, say so plainly.
5. Be concise and factual. No preamble such as "Sure" or "Here is".
PROMPT;
    }
```

- [ ] **Step 4: Run, verify all pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/prompt_builder_test.php`
Expected: `OK (19 tests, ...)` (17 existing + 2 new).

- [ ] **Step 5: Commit**

```bash
git add moodle/local/ai_analysis/classes/ai/prompt_builder.php moodle/local/ai_analysis/tests/prompt_builder_test.php
git commit -m "feat(ai_analysis): add format-pass system prompt builder"
```

---

## Task 4: format_result on interface + claude_client (TDD with fake transport)

**Files:**
- Modify: `classes/ai/ai_client_interface.php`
- Modify: `classes/ai/claude_client.php`
- Modify: `tests/claude_client_test.php`
- Modify: `tests/external_query_test.php` (keep the `stub_ai_client` satisfying the interface)

> **Order matters:** adding the method to the interface breaks every implementer until each defines it. This task updates the interface, `claude_client`, AND the `stub_ai_client` in `external_query_test.php` together so the suite never has a fatal "abstract method not implemented" state.

- [ ] **Step 1: Add the failing tests** — append inside the existing `claude_client_test` class in `tests/claude_client_test.php`:

```php
    public function test_format_result_targets_messages_endpoint_with_format_system(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 200, 'headers' => [], 'body' => json_encode([
            'content' => [['type' => 'text', 'text' => 'PERSON_1 has the top grade.']],
        ])];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $answer = $c->format_result('who scored highest', [['firstname' => 'PERSON_1', 'g' => 90]]);
        $this->assertSame('https://api.anthropic.com/v1/messages', $t->last_url);
        $this->assertSame('PERSON_1 has the top grade.', $answer);
        $body = json_decode($t->last_body, true);
        $this->assertStringContainsString('summarise', strtolower($body['system']));
        // Tokenised rows must reach the request body unchanged.
        $this->assertStringContainsString('PERSON_1', $body['messages'][0]['content']);
        $this->assertStringContainsString('who scored highest', $body['messages'][0]['content']);
    }

    public function test_format_result_strips_code_fences(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 200, 'headers' => [], 'body' => json_encode([
            'content' => [['type' => 'text', 'text' => "```\nPlain answer.\n```"]],
        ])];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->assertSame('Plain answer.', $c->format_result('q', []));
    }

    public function test_format_result_http_error_throws(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 500, 'headers' => [], 'body' => 'boom'];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(\local_ai_analysis\exception\ai_client_exception::class);
        $c->format_result('q', []);
    }

    public function test_format_result_unparseable_throws(): void {
        $t = new fake_http_transport();
        $t->next_response = ['status' => 200, 'headers' => [], 'body' => 'not json'];
        $c = new \local_ai_analysis\ai\claude_client($t, 'k');
        $this->expectException(\local_ai_analysis\exception\ai_client_exception::class);
        $c->format_result('q', []);
    }
```

- [ ] **Step 2: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/claude_client_test.php`
Expected: errors — `Call to undefined method ... format_result()`.

- [ ] **Step 3: Add the interface method** — in `classes/ai/ai_client_interface.php`, add inside the interface (after `generate_sql`):

```php
    /**
     * Summarise already-PII-scrubbed result rows into a plain-language answer.
     *
     * @param string $user_prompt The educator's original question (for intent).
     * @param array  $safe_rows   Tokenised rows — contains no real PII.
     * @return string             Plain-text answer that may contain tokens verbatim.
     * @throws \local_ai_analysis\exception\ai_client_exception
     */
    public function format_result(string $user_prompt, array $safe_rows): string;
```

- [ ] **Step 4: Implement in claude_client** — in `classes/ai/claude_client.php`, add the constant near the other consts:

```php
    private const FORMAT_MAX_TOKENS = 1024;
```

and add this method after `generate_sql()`:

```php
    public function format_result(string $user_prompt, array $safe_rows): string {
        $body = json_encode([
            'model'      => $this->model,
            'max_tokens' => self::FORMAT_MAX_TOKENS,
            'system'     => prompt_builder::build_format_system(),
            'messages'   => [['role' => 'user', 'content' => json_encode([
                'question' => $user_prompt,
                'rows'     => $safe_rows,
            ])]],
        ]);
        $headers = [
            'x-api-key: ' . $this->api_key,
            'anthropic-version: ' . self::ANTHROPIC_VERSION,
            'content-type: application/json',
        ];

        $response = $this->transport->post(self::ENDPOINT, $headers, $body);

        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new ai_client_exception('HTTP_' . $response['status'], $response['body']);
        }

        $envelope = json_decode($response['body'], true);
        $text = $envelope['content'][0]['text'] ?? null;
        if (!is_string($text)) {
            throw new ai_client_exception('PARSE_FAILED', $response['body']);
        }

        $stripped = trim($text);
        $stripped = preg_replace('/^```(?:json)?\s*/i', '', $stripped);
        $stripped = preg_replace('/\s*```\s*$/', '', $stripped);
        return trim($stripped);
    }
```

Add the `prompt_builder` import at the top of the file if not present (`use local_ai_analysis\ai\prompt_builder;` is in the same namespace, so a bare `prompt_builder::` reference resolves without a `use` — confirm the class is `local_ai_analysis\ai\prompt_builder`, which it is).

- [ ] **Step 5: Keep the stub_ai_client valid** — in `tests/external_query_test.php`, add to the `stub_ai_client` class (which `implements ai_client_interface`) a `format_result` so the interface stays satisfied:

```php
    public string $format_answer = 'formatted answer';
    /** @var array|null Captures the rows the gateway passed to format_result. */
    public ?array $last_format_rows = null;

    public function format_result(string $user_prompt, array $safe_rows): string {
        $this->last_format_rows = $safe_rows;
        return $this->format_answer;
    }
```

- [ ] **Step 6: Run both affected test files, verify pass**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/claude_client_test.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php
```
Expected: claude_client `OK (15 tests, ...)` (11 + 4 new); external_query `OK (7 tests, ...)` (unchanged — the gateway does not call format_result yet, so the stub additions are inert).

- [ ] **Step 7: Commit**

```bash
git add moodle/local/ai_analysis/classes/ai/ai_client_interface.php moodle/local/ai_analysis/classes/ai/claude_client.php moodle/local/ai_analysis/tests/claude_client_test.php moodle/local/ai_analysis/tests/external_query_test.php
git commit -m "feat(ai_analysis): add format_result to ai_client_interface and claude_client"
```

---

## Task 5: gateway integration + envelope fields + version bump (TDD end-to-end)

**Files:**
- Modify: `classes/external/query.php`
- Modify: `lang/en/local_ai_analysis.php`
- Modify: `version.php`
- Modify: `tests/external_query_test.php`

- [ ] **Step 1: Add the lang string** — append to `lang/en/local_ai_analysis.php`:

```php
$string['formatunavailable'] = 'Answer formatting is unavailable; showing raw results.';
```

- [ ] **Step 2: Add the failing tests** — append inside the existing `external_query_test` class. The `call()` helper takes only prompt/courseid today; add a format-aware helper and the new tests:

```php
    private function call_formatted(string $prompt): array {
        return \local_ai_analysis\external\query::execute(
            $prompt,
            $this->course->id,
            'req_' . random_int(1, 999999),
            true
        );
    }

    public function test_format_true_returns_detokenised_answer(): void {
        $this->stub->next_result = [
            'type'        => 'sql',
            'sql'         => 'SELECT id, firstname FROM mdl_user WHERE id = ? LIMIT 10',
            'params'      => [$this->teacher->id],
            'explanation' => '',
        ];
        // The stub echoes whatever answer we set; reference the token the scrubber will assign.
        $this->stub->format_answer = 'PERSON_1 is the only match.';
        $resp = $this->call_formatted('who am i');
        $this->assertSame('SUCCESS', $resp['status']);
        // The teacher's real firstname must be restored in the answer.
        $this->assertStringContainsString($this->teacher->firstname, $resp['answer']);
        $this->assertStringNotContainsString('PERSON_1', $resp['answer']);
        $this->assertSame('', $resp['format_note']);
    }

    public function test_format_true_never_sends_real_pii_to_ai(): void {
        $this->stub->next_result = [
            'type'        => 'sql',
            'sql'         => 'SELECT id, firstname FROM mdl_user WHERE id = ? LIMIT 10',
            'params'      => [$this->teacher->id],
            'explanation' => '',
        ];
        $this->stub->format_answer = 'ok';
        $this->call_formatted('who am i');
        // The rows handed to format_result must be tokenised — no real firstname.
        $this->assertNotNull($this->stub->last_format_rows);
        $flat = json_encode($this->stub->last_format_rows);
        $this->assertStringNotContainsString($this->teacher->firstname, $flat);
        $this->assertStringContainsString('PERSON_1', $flat);
    }

    public function test_format_false_matches_sprint2_envelope(): void {
        $this->stub->next_result = [
            'type'        => 'sql',
            'sql'         => 'SELECT id FROM mdl_user WHERE id = ? LIMIT 1',
            'params'      => [$this->teacher->id],
            'explanation' => '',
        ];
        $resp = $this->call('lookup me'); // existing helper, format defaults to false
        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertSame('', $resp['answer']);
        $this->assertSame('', $resp['format_note']);
        $this->assertNull($this->stub->last_format_rows); // format_result never called
    }

    public function test_format_failure_falls_back_to_raw_rows(): void {
        $this->stub->next_result = [
            'type'        => 'sql',
            'sql'         => 'SELECT id, firstname FROM mdl_user WHERE id = ? LIMIT 10',
            'params'      => [$this->teacher->id],
            'explanation' => '',
        ];
        $this->stub->throw_on_format = new \local_ai_analysis\exception\ai_client_exception('HTTP_500', 'boom');
        $resp = $this->call_formatted('who am i');
        $this->assertSame('SUCCESS', $resp['status']);   // result not blocked
        $this->assertSame('', $resp['answer']);
        $this->assertNotEmpty($resp['format_note']);
        $this->assertNotEmpty($resp['rows']);            // raw rows still returned
    }
```

Also extend `stub_ai_client` (in this same file) to support throwing from `format_result` — update the method added in Task 4:

```php
    public ?\Throwable $throw_on_format = null;

    public function format_result(string $user_prompt, array $safe_rows): string {
        $this->last_format_rows = $safe_rows;
        if ($this->throw_on_format !== null) {
            throw $this->throw_on_format;
        }
        return $this->format_answer;
    }
```

(Replace the Task 4 version of `format_result` with this one; add the `$throw_on_format` property alongside the others.)

- [ ] **Step 3: Run, verify failure**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: failures — `execute()` has no 4th param / `answer` key missing from the returned envelope.

- [ ] **Step 4: Add the `format` parameter** — in `classes/external/query.php`, in `execute_parameters()`, add after `request_id`:

```php
            'format'     => new external_value(PARAM_BOOL, 'Run the AI formatting pass (layer 7)', VALUE_DEFAULT, false),
```

- [ ] **Step 5: Add the two return fields** — in `execute_returns()`, add before `'error'`:

```php
            'answer'     => new external_value(PARAM_RAW, 'Natural-language answer when format=true', VALUE_DEFAULT, ''),
            'format_note' => new external_value(PARAM_TEXT, 'Soft note when formatting falls back', VALUE_DEFAULT, ''),
```

- [ ] **Step 6: Thread `format` through execute()** — change the signature:

```php
    public static function execute(string $prompt, int $courseid, string $request_id): array {
```
to
```php
    public static function execute(string $prompt, int $courseid, string $request_id, bool $format = false): array {
```

and in the `validate_parameters` call add `'format' => $format,` to the array, then after the existing assignments add:
```php
        $format = (bool) $params['format'];
```

- [ ] **Step 7: Keep the validator instance** — find the L5 validation block:

```php
        // L5: validate.
        try {
            (new sql_validator($manifest))->validate($sql, $bound_params);
        } catch (validation_exception $e) {
```
and change the first lines to retain the instance:
```php
        // L5: validate.
        $validator = new sql_validator($manifest);
        try {
            $validator->validate($sql, $bound_params);
        } catch (validation_exception $e) {
```

- [ ] **Step 8: Run scrub → format → detokenise after L6** — locate the success block that computes `$row_count` and writes the SUCCESS audit, and insert the formatting block immediately before the SUCCESS `audit_writer::write(...)` call:

```php
        $row_count = count($rows);

        $answer = '';
        $format_note = '';
        if ($format) {
            try {
                $classified = \local_ai_analysis\security\pii_scrubber::classify_columns(
                    $validator->get_column_source_map(),
                    $validator->get_column_references()
                );
                $scrubber  = new \local_ai_analysis\security\pii_scrubber();
                $safe_rows = $scrubber->tokenize($rows, $classified);
                $tokanswer = ai_client_factory::make()->format_result($prompt, $safe_rows);
                $answer    = $scrubber->detokenize($tokanswer);
            } catch (ai_client_exception | transport_exception $e) {
                $answer = '';
                $format_note = get_string('formatunavailable', 'local_ai_analysis');
                debugging('format_result failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            }
        }

        audit_writer::write(
            userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
            sql: $sql, status: 'SUCCESS', reason: '',
            provider: $provider, row_count: $row_count, duration_ms: self::elapsed_ms($start),
        );
```

(The existing `$row_count = count($rows);` line and SUCCESS audit call are already present — replace that region so the formatting block sits between them. Add `use local_ai_analysis\security\pii_scrubber;` to the top imports, or keep the fully-qualified references shown above.)

- [ ] **Step 9: Add the new fields to the success return** — in the success `return [...]` array, add:

```php
            'answer'      => $answer,
            'format_note' => $format_note,
```

- [ ] **Step 10: Add the new fields to error_envelope()** — in `error_envelope()`, add to the returned array:

```php
            'answer'      => '',
            'format_note' => '',
```

- [ ] **Step 11: Bump the version** — in `version.php`, change `$plugin->version = 2026052503;` to:

```php
$plugin->version   = 2026053000;
```

- [ ] **Step 12: Re-init PHPUnit (picks up version) and run the file**

Run:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php
```
Expected: `OK (11 tests, ...)` (7 existing + 4 new).

- [ ] **Step 13: Commit**

```bash
git add moodle/local/ai_analysis/classes/external/query.php moodle/local/ai_analysis/lang moodle/local/ai_analysis/version.php moodle/local/ai_analysis/tests/external_query_test.php
git commit -m "feat(ai_analysis): wire PII-scrubbed format_result pass into the gateway"
```

---

## Task 6: Final verification

**Files:** none — verification only.

- [ ] **Step 1: Run the full plugin suite by file path**

```bash
for t in manifest_builder audit_writer sql_validator prompt_builder claude_client rate_limiter query_executor pii_scrubber external_query; do
  docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/${t}_test.php 2>&1 | tail -1
done
```
Expected: 9 lines, each `OK (...)`. New/changed counts: sql_validator 19, prompt_builder 19, claude_client 15, pii_scrubber 10, external_query 11; others unchanged (manifest 7, audit 6, rate_limiter 5, query_executor 3). Combined ≥ 95 tests.

- [ ] **Step 2: Confirm the version upgrade applies cleanly**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/upgrade.php --non-interactive 2>&1 | tail -2
```
Expected: completes successfully (or "no upgrade needed" if already at 2026053000).

- [ ] **Step 3: Done — manual gate**

No commit. If anything fails, return to the relevant task. Otherwise the branch is ready for merge (per project rule: merge back to `main` locally after implementation completes).

---

## Self-review

### Spec coverage

- **`format` per-request flag + graceful fallback** → Task 5 (steps 4, 8). ✓
- **Two envelope fields (`answer`, `format_note`)** → Task 5 (steps 5, 9, 10). ✓
- **`pii_scrubber` curated map / tokenize / detokenize / classify** → Task 2. ✓
- **Reversible stable tokens + longest-first detokenise** → Task 2 (tests + impl). ✓
- **Derived-column redaction (`__REDACT__`)** → Task 2 (classify + tokenize). ✓
- **Alias-safe column-source map from `sql_validator`** → Task 1. ✓
- **`format_result` on interface + `claude_client`** → Task 4. ✓
- **Format system prompt with verbatim-token rule** → Task 3. ✓
- **PII-leak guard test** → Task 5 (test_format_true_never_sends_real_pii_to_ai). ✓
- **`format=false` regression parity** → Task 5 (test_format_false_matches_sprint2_envelope). ✓
- **AI #2 failure → SUCCESS + note + raw rows** → Task 5 (test_format_failure_falls_back_to_raw_rows). ✓
- **No new status codes / audit schema untouched** → Task 5 keeps the single SUCCESS audit write; no new statuses added. ✓

### Placeholder scan

No "TBD"/"TODO"/"handle edge cases". Every code step shows complete code. Commit messages carry no Claude/Anthropic trailer (project rule).

### Type consistency

- `get_column_source_map()` / `get_column_references()` defined in Task 1, consumed in Task 5 step 8 and tested in Task 2's `classify_columns`. ✓
- `classify_columns(array $source_map, array $references): array`, `tokenize(array $rows, array $column_map)`, `detokenize(string)`, `is_pii(string)` — signatures identical across Task 2 (definition), Task 2 tests, Task 5 (gateway call). ✓
- `pii_scrubber::REDACT` sentinel `'__REDACT__'` consistent between classify_columns output, tokenize handling, and Task 2 tests. ✓
- `format_result(string $user_prompt, array $safe_rows): string` identical across Task 4 (interface), Task 4 (claude_client), Task 4/5 (stub_ai_client), Task 5 (gateway call). ✓
- Envelope keys `answer` / `format_note` present in `execute_returns`, success return, and `error_envelope` (Task 5 steps 5/9/10). ✓
- Token prefix `REDACTED` for the `__REDACT__` class is internal to `tokenize`; tests assert `REDACTED_1` (Task 2). ✓
