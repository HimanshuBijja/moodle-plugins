# AI Analysis — Security Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship the security backbone of `local_ai_analysis`: plugin scaffolding, AST-based SQL validator, scoped schema manifest, audit log with encrypted prompt storage, capabilities, and a read-only DB user setup script. No AI calls, no frontend.

**Architecture:** Three pure PHP classes (`manifest_builder`, `sql_validator`, `audit_writer`) with narrow contracts and no shared state. The validator uses a vendored AST parser (`greenlion/php-sql-parser`) — never regex. The audit writer catches its own exceptions so any caller can audit failure paths without nested try/catch. Capabilities and an `install.xml`-defined audit table install via Moodle's plugin lifecycle.

**Tech Stack:** PHP 8.1, Moodle 4.5 plugin API, MariaDB 10.11, PHPUnit (Moodle's `advanced_testcase`), `greenlion/php-sql-parser` (vendored).

**Spec:** `docs/superpowers/specs/2026-05-25-ai-analysis-security-foundation-design.md`

**Working directory for all paths:** `/home/himanshu/moodle-instances/moodle-instance-8092/moodle/local/ai_analysis/`. Paths in this plan are relative to that directory unless prefixed with `moodle/`.

---

## Task 1: Plugin scaffolding

**Files:**
- Create: `version.php`
- Create: `lib.php`
- Create: `settings.php`
- Create: `lang/en/local_ai_analysis.php`
- Create: `README.md`

- [ ] **Step 1: Create `version.php`**

```php
<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_ai_analysis';
$plugin->version   = 2026052500;
$plugin->requires  = 2024100700; // Moodle 4.5
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.0 (Sprint 1: security foundation)';
```

- [ ] **Step 2: Create `lib.php`** (empty stub — page_init hook arrives in Sprint 4)

```php
<?php
defined('MOODLE_INTERNAL') || die();

// Intentionally empty in Sprint 1.
// Sprint 4 will add a page_init hook here to inject the chat widget into the footer.
```

- [ ] **Step 3: Create `settings.php`** (minimal admin category stub)

```php
<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_ai_analysis', get_string('pluginname', 'local_ai_analysis'));
    $ADMIN->add('localplugins', $settings);
    // Sprint 5 will populate this page with provider, API key, rate limit, retention settings.
}
```

- [ ] **Step 4: Create `lang/en/local_ai_analysis.php`**

```php
<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'AI Analysis';

// Capability strings.
$string['ai_analysis:query']          = 'Query the AI analysis chatbot in a course context';
$string['ai_analysis:queryglobal']    = 'Query the AI analysis chatbot in the system context';
$string['ai_analysis:viewaudit']      = 'View the AI analysis audit log';
$string['ai_analysis:decryptprompt']  = 'Decrypt stored AI analysis prompts (requires re-authentication)';
$string['ai_analysis:managepresets']  = 'Manage AI analysis query presets';

// Audit status strings (used by Sprint 5 audit viewer UI; declared now to keep langfile stable).
$string['status_success']            = 'Success';
$string['status_blocked_injection']  = 'Blocked: prompt injection';
$string['status_rate_limited']       = 'Rate limited';
$string['status_sql_invalid']        = 'SQL invalid';
$string['status_parse_failed']       = 'Parse failed';
$string['status_ai_invalid_json']    = 'AI returned invalid JSON';
$string['status_out_of_scope']       = 'Out of scope';

// Validator exception messages.
$string['validation_failed']         = 'SQL validation failed: {$a}';
```

- [ ] **Step 5: Create `README.md`**

```markdown
# local_ai_analysis

Moodle 4.5 local plugin that embeds an AI chatbot for natural-language queries against student data.

## Status

**Sprint 1 — Security Foundation (in progress).** No AI calls, no chatbot UI yet. This sprint ships the SQL validator, schema manifest builder, audit log, and capabilities. See `docs/superpowers/specs/` for the full design.

## Installation

After cloning into `moodle/local/ai_analysis/`:

1. Visit *Site administration → Notifications* to install the plugin database schema.
2. Follow `INSTALL.md` to create the read-only DB user and add encryption keys to `config.php`.
3. Verify capabilities under *Site administration → Users → Permissions → Define roles*.
```

- [ ] **Step 6: Install plugin and verify it loads**

Run from Moodle root:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/upgrade.php --non-interactive
```
Expected: output ends with `Command completed successfully.` and includes a line referencing `local_ai_analysis`.

- [ ] **Step 7: Commit**

```bash
git add moodle/local/ai_analysis/version.php moodle/local/ai_analysis/lib.php moodle/local/ai_analysis/settings.php moodle/local/ai_analysis/lang moodle/local/ai_analysis/README.md
git commit -m "feat(ai_analysis): scaffold local_ai_analysis plugin"
```

---

## Task 2: Vendor `greenlion/php-sql-parser`

**Files:**
- Create: `vendor/greenlion/php-sql-parser/` (library tree)
- Create: `vendor/autoload.php`

- [ ] **Step 1: Download the library release**

Run from the plugin root (`local/ai_analysis/`):
```bash
mkdir -p vendor/greenlion
cd vendor/greenlion
curl -sSL https://github.com/greenlion/PHP-SQL-Parser/archive/refs/tags/v4.7.0.tar.gz -o php-sql-parser.tar.gz
tar xzf php-sql-parser.tar.gz
mv PHP-SQL-Parser-4.7.0 php-sql-parser
rm php-sql-parser.tar.gz
```
Expected: `vendor/greenlion/php-sql-parser/src/PHPSQLParser/` directory exists and contains `PHPSQLParser.php` plus subfolders (`processors/`, `utils/`, `exceptions/`, etc.).

- [ ] **Step 2: Create a minimal PSR-4 autoloader**

Create `vendor/autoload.php`:

```php
<?php
// Minimal PSR-4 autoloader for vendored libraries.
// Avoids requiring a full composer install for production deployments.

spl_autoload_register(function (string $class): void {
    static $map = [
        'PHPSQLParser\\' => __DIR__ . '/greenlion/php-sql-parser/src/PHPSQLParser/',
    ];
    foreach ($map as $prefix => $base_dir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            continue;
        }
        $relative = substr($class, $len);
        $file = $base_dir . str_replace('\\', '/', $relative) . '.php';
        if (is_file($file)) {
            require $file;
            return;
        }
    }
});
```

- [ ] **Step 3: Smoke-test the autoloader**

Run:
```bash
docker exec moodle-web-8092 php -r "require '/var/www/html/local/ai_analysis/vendor/autoload.php'; \$p = new PHPSQLParser\PHPSQLParser('SELECT id FROM mdl_user', true); echo isset(\$p->parsed['SELECT']) ? 'OK' : 'FAIL';"
```
Expected output: `OK`.

- [ ] **Step 4: Commit**

```bash
git add moodle/local/ai_analysis/vendor
git commit -m "feat(ai_analysis): vendor greenlion/php-sql-parser v4.7.0"
```

---

## Task 3: `validation_exception` class

**Files:**
- Create: `classes/exception/validation_exception.php`

- [ ] **Step 1: Write the exception class**

```php
<?php
namespace local_ai_analysis\exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Thrown by sql_validator when a SQL string fails any validation rule.
 * Carries a machine-readable reason code (e.g. "TABLE_NOT_ALLOWED:mdl_config")
 * plus a truncated excerpt of the offending SQL for audit logging.
 */
class validation_exception extends \moodle_exception {

    /** @var string Machine-readable reason code. */
    public string $reason;

    /** @var string First 500 chars of the SQL that was rejected. */
    public string $sql_excerpt;

    public function __construct(string $reason, string $sql) {
        $this->reason      = $reason;
        $this->sql_excerpt = substr($sql, 0, 500);
        parent::__construct('validation_failed', 'local_ai_analysis', '', $reason);
    }
}
```

- [ ] **Step 2: Verify it autoloads**

Run:
```bash
docker exec moodle-web-8092 php -r "define('MOODLE_INTERNAL', true); require '/var/www/html/config.php'; \$e = new \local_ai_analysis\exception\validation_exception('TEST_REASON', 'SELECT 1'); echo \$e->reason;"
```
Expected output: `TEST_REASON`.

- [ ] **Step 3: Commit**

```bash
git add moodle/local/ai_analysis/classes/exception
git commit -m "feat(ai_analysis): add validation_exception"
```

---

## Task 4: `manifest_builder` (TDD)

**Files:**
- Create: `tests/manifest_builder_test.php`
- Create: `classes/manifest/manifest_builder.php`

- [ ] **Step 1: Initialise Moodle PHPUnit if not already done**

Run:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
```
Expected: prints `PHPUnit test environment setup complete.` (skip if already initialised).

- [ ] **Step 2: Write the failing tests**

Create `tests/manifest_builder_test.php`:

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\manifest\manifest_builder
 */
class manifest_builder_test extends \advanced_testcase {

    public function test_admin_returns_full_four_tables(): void {
        $m = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertEqualsCanonicalizing(
            ['mdl_user', 'mdl_grade_grades', 'mdl_course_modules', 'mdl_logstore_standard_log'],
            array_keys($m)
        );
        $this->assertArrayNotHasKey('_scope_note', $m['mdl_user']);
    }

    public function test_teacher_attaches_scope_note(): void {
        $m = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 42);
        $this->assertArrayHasKey('_scope_note', $m['mdl_user']);
        $this->assertStringContainsString('42', $m['mdl_user']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_logstore_standard_log']);
    }

    /**
     * @dataProvider role_provider
     */
    public function test_no_forbidden_columns_ever_appear(string $role, int $courseid): void {
        $forbidden = ['password', 'secret', 'sesskey', 'token', 'apikey', 'hash', 'salt', 'privatekey'];
        $m = \local_ai_analysis\manifest\manifest_builder::build($role, $courseid);
        foreach ($m as $table => $cols) {
            if (!is_array($cols)) continue;
            foreach ($cols as $key => $col) {
                if ($key === '_scope_note') continue;
                $this->assertNotContains($col, $forbidden, "Forbidden column '$col' appeared in $table for role=$role");
            }
        }
    }

    public static function role_provider(): array {
        return [
            ['admin', 0],
            ['manager', 0],
            ['editingteacher', 42],
            ['teacher', 99],
        ];
    }
}
```

- [ ] **Step 3: Run tests, verify they fail**

Run from Moodle root:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_manifest_builder
```
Expected: errors mentioning `Class "local_ai_analysis\manifest\manifest_builder" not found`.

- [ ] **Step 4: Implement `manifest_builder`**

Create `classes/manifest/manifest_builder.php`:

```php
<?php
namespace local_ai_analysis\manifest;

defined('MOODLE_INTERNAL') || die();

/**
 * Builds the allow-list manifest of tables and columns the AI may reference.
 *
 * The same manifest array is fed to (a) the AI prompt builder so the model
 * knows what it may reference, and (b) the SQL validator so it can reject
 * any SQL that strays outside the allow-list. Single source of truth.
 */
class manifest_builder {

    /** @var array<string, string[]> Hardcoded — never derived from the live DB. */
    private static array $FULL_MANIFEST = [
        'mdl_user'                  => ['id', 'firstname', 'lastname', 'city', 'department', 'timecreated'],
        'mdl_grade_grades'          => ['userid', 'itemid', 'finalgrade', 'timemodified'],
        'mdl_course_modules'        => ['id', 'course', 'module', 'completion'],
        'mdl_logstore_standard_log' => ['userid', 'courseid', 'eventname', 'timecreated'],
    ];

    public static function build(string $role, int $courseid): array {
        $manifest = self::$FULL_MANIFEST;

        if ($role !== 'admin' && $courseid > 0) {
            $manifest['mdl_user']['_scope_note'] =
                'Only users enrolled in course ' . $courseid;
            $manifest['mdl_logstore_standard_log']['_scope_note'] =
                'Always filter WHERE courseid = ' . $courseid;
        }
        return $manifest;
    }
}
```

- [ ] **Step 5: Run tests, verify they pass**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_manifest_builder
```
Expected: `OK (6 tests, ...)`.

- [ ] **Step 6: Commit**

```bash
git add moodle/local/ai_analysis/classes/manifest moodle/local/ai_analysis/tests/manifest_builder_test.php
git commit -m "feat(ai_analysis): add manifest_builder with role/course scoping"
```

---

## Task 5: Audit table + capabilities (`db/` files)

**Files:**
- Create: `db/install.xml`
- Create: `db/upgrade.php`
- Create: `db/access.php`

- [ ] **Step 1: Create `db/install.xml`**

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<XMLDB PATH="local/ai_analysis/db" VERSION="20260525" COMMENT="local_ai_analysis schema">
  <TABLES>
    <TABLE NAME="local_ai_analysis_audit" COMMENT="Audit log for every AI analysis request">
      <FIELDS>
        <FIELD NAME="id"               TYPE="int"  LENGTH="10"  NOTNULL="true" SEQUENCE="true"/>
        <FIELD NAME="userid"           TYPE="int"  LENGTH="10"  NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
        <FIELD NAME="courseid"         TYPE="int"  LENGTH="10"  NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
        <FIELD NAME="timecreated"      TYPE="int"  LENGTH="10"  NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
        <FIELD NAME="prompt_hash"      TYPE="char" LENGTH="64"  NOTNULL="true" SEQUENCE="false"/>
        <FIELD NAME="prompt_length"    TYPE="int"  LENGTH="5"   NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
        <FIELD NAME="prompt_encrypted" TYPE="text"              NOTNULL="false" SEQUENCE="false"/>
        <FIELD NAME="sql_executed"     TYPE="text"              NOTNULL="false" SEQUENCE="false"/>
        <FIELD NAME="row_count"        TYPE="int"  LENGTH="10"  NOTNULL="false" SEQUENCE="false"/>
        <FIELD NAME="status"           TYPE="char" LENGTH="40"  NOTNULL="true" SEQUENCE="false"/>
        <FIELD NAME="block_reason"     TYPE="char" LENGTH="120" NOTNULL="false" SEQUENCE="false"/>
        <FIELD NAME="provider"         TYPE="char" LENGTH="20"  NOTNULL="false" SEQUENCE="false"/>
        <FIELD NAME="duration_ms"      TYPE="int"  LENGTH="10"  NOTNULL="false" SEQUENCE="false"/>
        <FIELD NAME="useragent"        TYPE="char" LENGTH="255" NOTNULL="false" SEQUENCE="false"/>
      </FIELDS>
      <KEYS>
        <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
      </KEYS>
      <INDEXES>
        <INDEX NAME="ix_userid"      UNIQUE="false" FIELDS="userid"/>
        <INDEX NAME="ix_courseid"    UNIQUE="false" FIELDS="courseid"/>
        <INDEX NAME="ix_timecreated" UNIQUE="false" FIELDS="timecreated"/>
        <INDEX NAME="ix_status"      UNIQUE="false" FIELDS="status"/>
      </INDEXES>
    </TABLE>
  </TABLES>
</XMLDB>
```

- [ ] **Step 2: Create `db/upgrade.php`** (empty for now)

```php
<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_ai_analysis_upgrade(int $oldversion): bool {
    // No upgrades yet — install.xml is the source of truth in Sprint 1.
    return true;
}
```

- [ ] **Step 3: Create `db/access.php`**

```php
<?php
defined('MOODLE_INTERNAL') || die();

$capabilities = [
    'local/ai_analysis:query' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes'   => [
            'editingteacher' => CAP_ALLOW,
            'teacher'        => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
            'student'        => CAP_PROHIBIT,
            'guest'          => CAP_PROHIBIT,
        ],
    ],
    'local/ai_analysis:queryglobal' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => ['manager' => CAP_ALLOW],
    ],
    'local/ai_analysis:viewaudit' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [],
    ],
    'local/ai_analysis:decryptprompt' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [],
    ],
    'local/ai_analysis:managepresets' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes'   => [
            'editingteacher' => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
        ],
    ],
];
```

- [ ] **Step 4: Bump version and reinstall**

Edit `version.php`: change `$plugin->version = 2026052500;` to `$plugin->version = 2026052501;`.

Then run:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/upgrade.php --non-interactive
```
Expected: includes `local_ai_analysis ... 2026052501` and `Command completed successfully.`.

- [ ] **Step 5: Verify table exists**

Run:
```bash
docker exec moodle-db-8092 mariadb -umoodleuser -pmoodlepass moodle -e "DESCRIBE mdl_local_ai_analysis_audit;"
```
Expected: prints 14 rows (one per column) including `prompt_hash`, `prompt_encrypted`, `status`.

- [ ] **Step 6: Commit**

```bash
git add moodle/local/ai_analysis/db moodle/local/ai_analysis/version.php
git commit -m "feat(ai_analysis): add audit table schema and capability definitions"
```

---

## Task 6: `audit_writer` (TDD)

**Files:**
- Create: `tests/audit_writer_test.php`
- Create: `classes/audit/audit_writer.php`

- [ ] **Step 1: Write the failing tests**

Create `tests/audit_writer_test.php`:

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\audit\audit_writer
 */
class audit_writer_test extends \advanced_testcase {

    public function test_writes_hash_without_key(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        unset($CFG->ai_analysis_audit_key);

        \local_ai_analysis\audit\audit_writer::write(
            userid: 42,
            courseid: 7,
            prompt: 'hello world',
            sql: 'SELECT id FROM mdl_user',
            status: 'SUCCESS',
            reason: '',
            provider: 'claude'
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 42]);
        $this->assertNotFalse($row);
        $this->assertSame(hash('sha256', 'hello world'), $row->prompt_hash);
        $this->assertSame(11, (int)$row->prompt_length);
        $this->assertNull($row->prompt_encrypted);
        $this->assertSame('SUCCESS', $row->status);
        $this->assertSame('claude', $row->provider);
    }

    public function test_writes_encrypted_prompt_when_key_set(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('k', 32);

        \local_ai_analysis\audit\audit_writer::write(
            userid: 100, courseid: 0, prompt: 'secret prompt text',
            sql: null, status: 'BLOCKED_INJECTION', reason: 'ignore previous', provider: ''
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 100]);
        $this->assertNotNull($row->prompt_encrypted);
        $this->assertStringContainsString('::', $row->prompt_encrypted);

        // Round-trip decrypt.
        [$iv_b64, $ct_b64] = explode('::', $row->prompt_encrypted);
        $plain = openssl_decrypt(base64_decode($ct_b64), 'AES-256-CBC', $CFG->ai_analysis_audit_key, OPENSSL_RAW_DATA, base64_decode($iv_b64));
        $this->assertSame('secret prompt text', $plain);
    }

    public function test_truncates_useragent_and_sql(): void {
        global $DB;
        $this->resetAfterTest();
        $_SERVER['HTTP_USER_AGENT'] = str_repeat('A', 400);
        $long_sql = 'SELECT ' . str_repeat('x', 3000);

        \local_ai_analysis\audit\audit_writer::write(
            userid: 1, courseid: 0, prompt: 'p', sql: $long_sql,
            status: 'SUCCESS', reason: '', provider: ''
        );

        $row = $DB->get_record('local_ai_analysis_audit', ['userid' => 1]);
        $this->assertLessThanOrEqual(255, strlen($row->useragent));
        $this->assertLessThanOrEqual(2000, strlen($row->sql_executed));
    }

    public function test_never_throws_when_db_fails(): void {
        // Pass a deliberately oversized status (column is char(40)) to provoke a DB error.
        $this->resetAfterTest();
        $oversize_status = str_repeat('X', 200);

        // Must not throw.
        \local_ai_analysis\audit\audit_writer::write(
            userid: 1, courseid: 0, prompt: 'p', sql: null,
            status: $oversize_status, reason: '', provider: ''
        );
        $this->assertTrue(true); // Reached this line = no exception escaped.
    }
}
```

- [ ] **Step 2: Run tests, verify they fail**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_audit_writer
```
Expected: errors mentioning `Class "local_ai_analysis\audit\audit_writer" not found`.

- [ ] **Step 3: Implement `audit_writer`**

Create `classes/audit/audit_writer.php`:

```php
<?php
namespace local_ai_analysis\audit;

defined('MOODLE_INTERNAL') || die();

/**
 * Always-on audit writer. Catches all its own exceptions so any caller —
 * including error paths — can audit without nested try/catch.
 */
class audit_writer {

    public static function write(
        int $userid,
        int $courseid,
        string $prompt,
        ?string $sql,
        string $status,
        string $reason = '',
        string $provider = '',
        ?int $row_count = null,
        ?int $duration_ms = null
    ): void {
        global $DB, $CFG;

        try {
            $encrypted = null;
            if (!empty($CFG->ai_analysis_audit_key)) {
                $iv = openssl_random_pseudo_bytes(16);
                $ct = openssl_encrypt(
                    $prompt,
                    'AES-256-CBC',
                    $CFG->ai_analysis_audit_key,
                    OPENSSL_RAW_DATA,
                    $iv
                );
                if ($ct !== false) {
                    $encrypted = base64_encode($iv) . '::' . base64_encode($ct);
                }
            }

            $DB->insert_record('local_ai_analysis_audit', (object)[
                'userid'            => $userid,
                'courseid'          => $courseid,
                'timecreated'       => time(),
                'prompt_hash'       => hash('sha256', $prompt),
                'prompt_length'     => strlen($prompt),
                'prompt_encrypted'  => $encrypted,
                'sql_executed'      => $sql !== null ? substr($sql, 0, 2000) : null,
                'row_count'         => $row_count,
                'status'            => substr($status, 0, 40),
                'block_reason'      => substr($reason, 0, 120),
                'provider'          => substr($provider, 0, 20),
                'duration_ms'       => $duration_ms,
                'useragent'         => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            ]);
        } catch (\Throwable $e) {
            debugging(
                'local_ai_analysis audit write failed: ' . $e->getMessage(),
                DEBUG_DEVELOPER
            );
        }
    }
}
```

- [ ] **Step 4: Run tests, verify they pass**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_audit_writer
```
Expected: `OK (4 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
git add moodle/local/ai_analysis/classes/audit moodle/local/ai_analysis/tests/audit_writer_test.php
git commit -m "feat(ai_analysis): add audit_writer with optional AES-256 prompt encryption"
```

---

## Task 7a: `sql_validator` — parse, statement type, wildcard

**Files:**
- Create: `tests/sql_validator_test.php`
- Create: `classes/security/sql_validator.php`

- [ ] **Step 1: Write the initial test file covering rows 1, 2, 3, 12**

Create `tests/sql_validator_test.php`:

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * @covers \local_ai_analysis\security\sql_validator
 */
class sql_validator_test extends \advanced_testcase {

    private function manifest(): array {
        return [
            'mdl_user'                  => ['id', 'firstname', 'lastname', 'city', 'department', 'timecreated'],
            'mdl_grade_grades'          => ['userid', 'itemid', 'finalgrade', 'timemodified'],
            'mdl_course_modules'        => ['id', 'course', 'module', 'completion'],
            'mdl_logstore_standard_log' => ['userid', 'courseid', 'eventname', 'timecreated'],
        ];
    }

    private function validator(): \local_ai_analysis\security\sql_validator {
        return new \local_ai_analysis\security\sql_validator($this->manifest());
    }

    public function test_row1_valid_select_passes_unchanged(): void {
        $sql = 'SELECT id, firstname FROM mdl_user WHERE id = ? LIMIT 50';
        $this->assertTrue($this->validator()->validate($sql, [42]));
        $this->assertStringContainsString('LIMIT 50', $sql);
    }

    public function test_row2_select_star_rejected(): void {
        $this->expect_reject('SELECT * FROM mdl_user', [], 'WILDCARD_SELECT_FORBIDDEN');
    }

    public function test_row3_stacked_statement_rejected(): void {
        $sql = 'SELECT 1; DROP TABLE mdl_user';
        try {
            $this->validator()->validate($sql, []);
            $this->fail('expected validation_exception');
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertTrue(
                $e->reason === 'PARSE_FAILED' || $e->reason === 'FORBIDDEN_OP:DROP',
                "Got reason: $e->reason"
            );
        }
    }

    public function test_row12_update_rejected(): void {
        $sql = "UPDATE mdl_user SET firstname='x'";
        try {
            $this->validator()->validate($sql, []);
            $this->fail('expected validation_exception');
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertTrue(
                $e->reason === 'NOT_SELECT' || $e->reason === 'FORBIDDEN_OP:UPDATE',
                "Got reason: $e->reason"
            );
        }
    }

    private function expect_reject(string $sql, array $params, string $expected_reason): void {
        try {
            $this->validator()->validate($sql, $params);
            $this->fail("expected $expected_reason for: $sql");
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertSame($expected_reason, $e->reason, "for SQL: $sql");
        }
    }
}
```

- [ ] **Step 2: Run tests, verify they fail**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_sql_validator
```
Expected: errors mentioning `Class "local_ai_analysis\security\sql_validator" not found`.

- [ ] **Step 3: Implement validator with rules 0–2 (parse, statement type, wildcard)**

Create `classes/security/sql_validator.php`:

```php
<?php
namespace local_ai_analysis\security;

use local_ai_analysis\exception\validation_exception;
use PHPSQLParser\PHPSQLParser;

defined('MOODLE_INTERNAL') || die();

/**
 * AST-based SQL validator. Receives the same manifest array that was sent
 * to the AI prompt, so allow-lists cannot drift.
 *
 * validate() mutates $sql only to inject or lower LIMIT. Any other
 * deviation from policy is thrown as validation_exception with a
 * machine-readable reason code.
 */
class sql_validator {

    /** @var array<string, string[]> */
    private array $manifest;

    /** @var string[] */
    private const FORBIDDEN_OPS = [
        'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE',
        'ALTER', 'TRUNCATE', 'REPLACE', 'CALL', 'EXEC',
    ];

    public function __construct(array $manifest) {
        // Strip the _scope_note pseudo-columns so column matching is clean.
        foreach ($manifest as $table => $cols) {
            if (is_array($cols)) {
                $manifest[$table] = array_values(array_filter(
                    $cols,
                    fn($c, $k) => $k !== '_scope_note',
                    ARRAY_FILTER_USE_BOTH
                ));
            }
        }
        $this->manifest = $manifest;
    }

    public function validate(string &$sql, array $params): bool {
        // Rule 0: parse.
        try {
            $parser = new PHPSQLParser($sql, true);
            $ast = $parser->parsed;
        } catch (\Throwable $e) {
            throw new validation_exception('PARSE_FAILED', $sql);
        }
        if (!is_array($ast)) {
            throw new validation_exception('PARSE_FAILED', $sql);
        }

        // Rule 1: statement type.
        foreach (self::FORBIDDEN_OPS as $op) {
            if (array_key_exists($op, $ast)) {
                throw new validation_exception('FORBIDDEN_OP:' . $op, $sql);
            }
        }
        if (!array_key_exists('SELECT', $ast)) {
            throw new validation_exception('NOT_SELECT', $sql);
        }

        // Rule 2: no SELECT *.
        foreach ($ast['SELECT'] ?? [] as $col) {
            if (($col['base_expr'] ?? '') === '*') {
                throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
            }
        }

        // Rules 3-7 land in Tasks 7b and 7c.
        return true;
    }
}
```

- [ ] **Step 4: Run tests, verify rows 1, 2, 3, 12 pass**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_sql_validator
```
Expected: `OK (4 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
git add moodle/local/ai_analysis/classes/security moodle/local/ai_analysis/tests/sql_validator_test.php
git commit -m "feat(ai_analysis): sql_validator parse + statement type + wildcard rules"
```

---

## Task 7b: `sql_validator` — table & column allowlists, subquery, UNION

**Files:**
- Modify: `tests/sql_validator_test.php`
- Modify: `classes/security/sql_validator.php`

- [ ] **Step 1: Append failing tests for rows 4, 5, 6, 7, 11, 13, 14**

Add these methods to `tests/sql_validator_test.php` (before the closing brace, after `test_row12_update_rejected`):

```php
    public function test_row4_comment_trick_rejected(): void {
        // SELECT/**/password FROM mdl_user — comment between SELECT and column.
        $this->expect_reject('SELECT/**/password FROM mdl_user', [], 'COLUMN_NOT_ALLOWED:password');
    }

    public function test_row5_forbidden_table_rejected(): void {
        $this->expect_reject('SELECT id FROM mdl_config', [], 'TABLE_NOT_ALLOWED:mdl_config');
    }

    public function test_row6_union_to_forbidden_table_rejected(): void {
        $this->expect_reject(
            'SELECT id FROM mdl_user UNION SELECT id FROM mdl_config',
            [],
            'TABLE_NOT_ALLOWED:mdl_config'
        );
    }

    public function test_row7_subquery_rejected(): void {
        $this->expect_reject(
            'SELECT id FROM mdl_user WHERE id IN (SELECT userid FROM mdl_grade_grades)',
            [],
            'SUBQUERY_FORBIDDEN'
        );
    }

    public function test_row11_alias_resolution_passes(): void {
        $sql = 'SELECT u.id, u.firstname FROM mdl_user u WHERE u.id = ? LIMIT 10';
        $this->assertTrue($this->validator()->validate($sql, [1]));
    }

    public function test_row13_password_column_rejected(): void {
        $this->expect_reject('SELECT password FROM mdl_user', [], 'COLUMN_NOT_ALLOWED:password');
    }

    public function test_row14_join_passes(): void {
        $sql = 'SELECT u.id, gg.finalgrade FROM mdl_user u JOIN mdl_grade_grades gg ON u.id = gg.userid LIMIT 10';
        $this->assertTrue($this->validator()->validate($sql, []));
    }
```

- [ ] **Step 2: Run tests, verify the 7 new rows fail**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_sql_validator
```
Expected: 7 failures named `test_row4` through `test_row14`.

- [ ] **Step 3: Extend `sql_validator` with rules 3–5 (tables, columns, subquery)**

Replace `classes/security/sql_validator.php` with:

```php
<?php
namespace local_ai_analysis\security;

use local_ai_analysis\exception\validation_exception;
use PHPSQLParser\PHPSQLParser;

defined('MOODLE_INTERNAL') || die();

class sql_validator {

    /** @var array<string, string[]> */
    private array $manifest;

    private const FORBIDDEN_OPS = [
        'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE',
        'ALTER', 'TRUNCATE', 'REPLACE', 'CALL', 'EXEC',
    ];

    public function __construct(array $manifest) {
        foreach ($manifest as $table => $cols) {
            if (is_array($cols)) {
                $manifest[$table] = array_values(array_filter(
                    $cols,
                    fn($c, $k) => $k !== '_scope_note',
                    ARRAY_FILTER_USE_BOTH
                ));
            }
        }
        $this->manifest = $manifest;
    }

    public function validate(string &$sql, array $params): bool {
        // Rule 0: parse.
        try {
            $parser = new PHPSQLParser($sql, true);
            $ast = $parser->parsed;
        } catch (\Throwable $e) {
            throw new validation_exception('PARSE_FAILED', $sql);
        }
        if (!is_array($ast)) {
            throw new validation_exception('PARSE_FAILED', $sql);
        }

        // Rule 1: statement type.
        foreach (self::FORBIDDEN_OPS as $op) {
            if (array_key_exists($op, $ast)) {
                throw new validation_exception('FORBIDDEN_OP:' . $op, $sql);
            }
        }
        if (!array_key_exists('SELECT', $ast) && !array_key_exists('UNION', $ast) && !array_key_exists('UNION ALL', $ast)) {
            throw new validation_exception('NOT_SELECT', $sql);
        }

        // Rule 5 (do FIRST): reject any subquery anywhere in the AST.
        // Caveat: UNION at the top level is allowed and is NOT a subquery — it's
        // a sibling SELECT. We detect subqueries by walking for expr_type==subquery.
        $this->reject_subqueries($ast, $sql);

        // Rule 2: no SELECT * — applies to every top-level SELECT, including each branch of a UNION.
        $this->check_wildcards($ast, $sql);

        // Rule 3 + Rule 4: collect tables (with aliases) and verify columns.
        // Process each top-level SELECT (including UNION branches) independently.
        foreach ($this->iter_top_selects($ast) as $select_ast) {
            $alias_to_table = $this->collect_tables($select_ast, $sql);
            $this->check_columns($select_ast, $alias_to_table, $sql);
        }

        return true;
    }

    /** Yields each top-level SELECT statement (handles UNION branches). */
    private function iter_top_selects(array $ast): iterable {
        if (array_key_exists('UNION', $ast) || array_key_exists('UNION ALL', $ast)) {
            $branches = $ast['UNION'] ?? $ast['UNION ALL'];
            foreach ($branches as $branch) {
                if (is_array($branch) && array_key_exists('SELECT', $branch)) {
                    yield $branch;
                }
            }
            return;
        }
        if (array_key_exists('SELECT', $ast)) {
            yield $ast;
        }
    }

    private function check_wildcards(array $ast, string $sql): void {
        foreach ($this->iter_top_selects($ast) as $select_ast) {
            foreach ($select_ast['SELECT'] ?? [] as $col) {
                if (($col['base_expr'] ?? '') === '*') {
                    throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
                }
                // Walk inside expressions for nested *.
                if (($col['expr_type'] ?? '') === 'colref' && ($col['base_expr'] ?? '') === '*') {
                    throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
                }
            }
        }
    }

    /**
     * Collects every table referenced in FROM/JOIN. Returns alias→table map.
     * Throws TABLE_NOT_ALLOWED on any unknown table.
     */
    private function collect_tables(array $select_ast, string $sql): array {
        $aliases = [];
        $from = $select_ast['FROM'] ?? [];
        foreach ($from as $node) {
            if (($node['expr_type'] ?? '') !== 'table') {
                continue;
            }
            $table = $node['table'] ?? null;
            if (!$table || !array_key_exists($table, $this->manifest)) {
                throw new validation_exception('TABLE_NOT_ALLOWED:' . ($table ?? '?'), $sql);
            }
            $alias = $node['alias']['name'] ?? $table;
            $aliases[$alias] = $table;
            // Also accept the bare table name as its own alias (for unaliased refs).
            $aliases[$table] = $table;
        }
        return $aliases;
    }

    /**
     * Walks SELECT, WHERE, GROUP, HAVING, ORDER for any colref and verifies
     * each column is in the manifest for its (possibly aliased) table.
     */
    private function check_columns(array $select_ast, array $aliases, string $sql): void {
        $clauses = ['SELECT', 'WHERE', 'GROUP', 'HAVING', 'ORDER', 'FROM'];
        foreach ($clauses as $clause) {
            if (!isset($select_ast[$clause])) {
                continue;
            }
            $this->walk_colrefs($select_ast[$clause], $aliases, $sql);
        }
    }

    private function walk_colrefs($node, array $aliases, string $sql): void {
        if (!is_array($node)) {
            return;
        }
        // A single AST node (associative) versus a list of nodes (numeric).
        if (isset($node['expr_type'])) {
            if ($node['expr_type'] === 'colref') {
                $base = $node['base_expr'] ?? '';
                if ($base === '*' || str_ends_with($base, '.*')) {
                    throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
                }
                $parts = explode('.', $base);
                if (count($parts) === 2) {
                    [$alias, $col] = $parts;
                    $col = trim($col, '`"');
                    $alias = trim($alias, '`"');
                    if (!isset($aliases[$alias])) {
                        throw new validation_exception('TABLE_NOT_ALLOWED:' . $alias, $sql);
                    }
                    $table = $aliases[$alias];
                    if (!in_array($col, $this->manifest[$table], true)) {
                        throw new validation_exception('COLUMN_NOT_ALLOWED:' . $col, $sql);
                    }
                } else if (count($parts) === 1) {
                    $col = trim($parts[0], '`"');
                    // Unqualified — require unique resolution across all aliased tables.
                    $tables = array_unique(array_values($aliases));
                    $matches = [];
                    foreach ($tables as $t) {
                        if (in_array($col, $this->manifest[$t], true)) {
                            $matches[] = $t;
                        }
                    }
                    if (count($matches) === 0) {
                        throw new validation_exception('COLUMN_NOT_ALLOWED:' . $col, $sql);
                    }
                    if (count($matches) > 1) {
                        throw new validation_exception('AMBIGUOUS_COLUMN:' . $col, $sql);
                    }
                }
            }
            // Recurse into sub_tree for function args, expressions, etc.
            if (isset($node['sub_tree']) && is_array($node['sub_tree'])) {
                $this->walk_colrefs($node['sub_tree'], $aliases, $sql);
            }
            return;
        }
        // List of nodes.
        foreach ($node as $child) {
            $this->walk_colrefs($child, $aliases, $sql);
        }
    }

    private function reject_subqueries($node, string $sql): void {
        if (!is_array($node)) {
            return;
        }
        if (isset($node['expr_type']) && $node['expr_type'] === 'subquery') {
            throw new validation_exception('SUBQUERY_FORBIDDEN', $sql);
        }
        foreach ($node as $child) {
            if (is_array($child)) {
                $this->reject_subqueries($child, $sql);
            }
        }
    }
}
```

- [ ] **Step 4: Run tests, verify all 11 rows pass**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_sql_validator
```
Expected: `OK (11 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
git add moodle/local/ai_analysis/classes/security/sql_validator.php moodle/local/ai_analysis/tests/sql_validator_test.php
git commit -m "feat(ai_analysis): sql_validator table+column allowlists, subquery rejection"
```

---

## Task 7c: `sql_validator` — LIMIT enforcement & param type check

**Files:**
- Modify: `tests/sql_validator_test.php`
- Modify: `classes/security/sql_validator.php`

- [ ] **Step 1: Append tests for rows 8, 9, 10**

Add to `tests/sql_validator_test.php` (before the closing brace of the class):

```php
    public function test_row8_missing_limit_gets_appended(): void {
        $sql = 'SELECT id, firstname FROM mdl_user WHERE id = ?';
        $this->assertTrue($this->validator()->validate($sql, [1]));
        $this->assertMatchesRegularExpression('/LIMIT\s+1000\s*$/i', $sql);
    }

    public function test_row9_oversized_limit_rewritten(): void {
        $sql = 'SELECT id FROM mdl_user LIMIT 5000';
        $this->assertTrue($this->validator()->validate($sql, []));
        $this->assertMatchesRegularExpression('/LIMIT\s+1000\b/i', $sql);
        $this->assertDoesNotMatchRegularExpression('/5000/', $sql);
    }

    public function test_row10_non_scalar_param_rejected(): void {
        $sql = 'SELECT id FROM mdl_user WHERE id = ? LIMIT 10';
        $this->expect_reject($sql, [['array']], 'INVALID_PARAM_TYPE');
    }
```

- [ ] **Step 2: Run tests, verify the 3 new rows fail**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_sql_validator
```
Expected: 3 failures named `test_row8`, `test_row9`, `test_row10`.

- [ ] **Step 3: Add LIMIT enforcement and param-type check**

Edit `classes/security/sql_validator.php`. Find these three lines at the bottom of `validate()`:

```php
        return true;
    }
}
```

Replace them with the block below. This inserts the param-type check and LIMIT enforcement before `return true;`, keeps the `}` closing `validate()`, adds the new `enforce_limit()` method, and ends with the class-closing `}`:

```php
        // Rule 7: param types — scalar or null only.
        foreach ($params as $p) {
            if ($p !== null && !is_scalar($p)) {
                throw new validation_exception('INVALID_PARAM_TYPE', $sql);
            }
        }

        // Rule 6: LIMIT enforcement.
        $sql = $this->enforce_limit($sql, $ast, 1000);

        return true;
    }

    private function enforce_limit(string $sql, array $ast, int $max): string {
        $limit_node = $ast['LIMIT'] ?? null;
        if ($limit_node === null) {
            // Strip any trailing semicolon, append LIMIT.
            return rtrim(rtrim($sql), ';') . ' LIMIT ' . $max;
        }
        $rowcount = (int)($limit_node['rowcount'] ?? $max);
        if ($rowcount > $max) {
            // Replace the rowcount in the source SQL via case-insensitive regex
            // anchored on the LIMIT keyword. The AST has already proven LIMIT exists.
            $sql = preg_replace(
                '/\bLIMIT\s+(?:\d+\s*,\s*)?\d+\b/i',
                'LIMIT ' . $max,
                $sql,
                1
            );
        }
        return $sql;
    }
}
```

- [ ] **Step 4: Run tests, verify all 14 rows pass**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis_sql_validator
```
Expected: `OK (14 tests, ...)`.

- [ ] **Step 5: Commit**

```bash
git add moodle/local/ai_analysis/classes/security/sql_validator.php moodle/local/ai_analysis/tests/sql_validator_test.php
git commit -m "feat(ai_analysis): sql_validator LIMIT enforcement and param-type check"
```

---

## Task 8: Read-only DB user script + INSTALL.md

**Files:**
- Create: `db/readonly_grants.sql`
- Create: `INSTALL.md`

- [ ] **Step 1: Create `db/readonly_grants.sql`**

```sql
-- Run as root against the Moodle database.
-- Idempotent: safe to re-run.

CREATE USER IF NOT EXISTS 'moodle_ai_ro'@'%' IDENTIFIED BY 'REPLACE_WITH_STRONG_PASSWORD';

GRANT SELECT ON moodle.mdl_user                  TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_grade_grades          TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_course_modules        TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_logstore_standard_log TO 'moodle_ai_ro'@'%';

-- Explicitly NO grants on mdl_config, mdl_user_password_resets, mdl_sessions.
-- Add new allow-listed tables here as later sprints expand the manifest.

FLUSH PRIVILEGES;
```

- [ ] **Step 2: Create `INSTALL.md`**

```markdown
# local_ai_analysis — Installation

This plugin requires a one-time setup step beyond the standard Moodle plugin install: a read-only DB user and two `config.php` entries.

## 1. Plugin install

Place this directory at `moodle/local/ai_analysis/` and visit *Site administration → Notifications*. Moodle will create the `mdl_local_ai_analysis_audit` table and register the plugin's capabilities.

## 2. Read-only DB user

The plugin's Sprint-2 query executor will connect with a read-only MariaDB user — never the main Moodle user. Even if every PHP-layer validation is bypassed, `INSERT`/`UPDATE`/`DELETE`/`DROP` will fail at the DB server.

Generate a strong password:

```bash
openssl rand -base64 32
```

Edit `db/readonly_grants.sql` and replace `REPLACE_WITH_STRONG_PASSWORD` with the generated value, then apply it:

```bash
docker exec -i moodle-db-8092 mariadb -uroot -prootpass moodle < moodle/local/ai_analysis/db/readonly_grants.sql
```

Verify:

```bash
docker exec moodle-db-8092 mariadb -umoodle_ai_ro -p<password> moodle -e "SHOW GRANTS FOR CURRENT_USER();"
```

Expected: four `GRANT SELECT` lines and nothing else.

## 3. Audit prompt encryption key

Encrypted prompt storage uses AES-256-CBC. Generate a 32-byte key:

```bash
openssl rand -hex 32
```

## 4. Add to `config.php`

Append to `moodle/config.php` *before* the final `require_once(...)`:

```php
$CFG->ai_analysis_dbuser    = 'moodle_ai_ro';
$CFG->ai_analysis_dbpass    = '<password from step 2>';
$CFG->ai_analysis_audit_key = '<key from step 3>';
```

Sprint 1 reads only `ai_analysis_audit_key`. The two DB credentials are consumed by Sprint 2's query executor; setting them now means no `config.php` edits later.

## 5. Verify

Run the PHPUnit suite from the Moodle root:

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis
```

Expected: all `local_ai_analysis_*_test` classes pass.
```

- [ ] **Step 3: Verify the SQL script is idempotent**

Run (using a placeholder password just to validate syntax):
```bash
docker exec -i moodle-db-8092 mariadb -uroot -prootpass -e "$(sed 's/REPLACE_WITH_STRONG_PASSWORD/dummy_password_for_test/' moodle/local/ai_analysis/db/readonly_grants.sql)"
docker exec -i moodle-db-8092 mariadb -uroot -prootpass -e "$(sed 's/REPLACE_WITH_STRONG_PASSWORD/dummy_password_for_test/' moodle/local/ai_analysis/db/readonly_grants.sql)"
```
Expected: no errors on either invocation (second run is the idempotency check).

Then clean up the test user:
```bash
docker exec moodle-db-8092 mariadb -uroot -prootpass -e "DROP USER IF EXISTS 'moodle_ai_ro'@'%';"
```

- [ ] **Step 4: Commit**

```bash
git add moodle/local/ai_analysis/db/readonly_grants.sql moodle/local/ai_analysis/INSTALL.md
git commit -m "feat(ai_analysis): add readonly DB user script and INSTALL.md"
```

---

## Task 9: Final verification

**Files:** none (verification only)

- [ ] **Step 1: Run the full plugin test suite**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit --filter local_ai_analysis
```
Expected: `OK (X tests, ...)` where X ≥ 22 (14 validator + 6 manifest + 4 audit, plus any added during implementation).

- [ ] **Step 2: Verify capabilities are present**

```bash
docker exec moodle-db-8092 mariadb -umoodleuser -pmoodlepass moodle -e "SELECT name FROM mdl_capabilities WHERE name LIKE 'local/ai_analysis:%' ORDER BY name;"
```
Expected: 5 rows — `:decryptprompt`, `:managepresets`, `:query`, `:queryglobal`, `:viewaudit`.

- [ ] **Step 3: Verify audit table structure**

```bash
docker exec moodle-db-8092 mariadb -umoodleuser -pmoodlepass moodle -e "SHOW CREATE TABLE mdl_local_ai_analysis_audit\G"
```
Expected: contains all 14 columns from the design spec, plus indexes on `userid`, `courseid`, `timecreated`, `status`.

- [ ] **Step 4: Done — mark sprint complete**

No commit; this is a manual verification gate. If any check fails, return to the relevant task and fix.
