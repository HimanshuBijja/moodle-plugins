# Sprint 5 — Admin / Management & Compliance — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the admin/compliance layer — browsable audit log, decrypt-prompt with self-audit, GDPR Privacy API, retention scheduled task, settings polish — plus fix transient HTTP 429/5xx to map to `AI_TRANSPORT_ERROR`.

**Architecture:** New admin report page (`table_sql`) + AJAX decrypt function reuse the existing audit table and a new shared `audit_crypto` helper (extracted from `audit_writer` so encrypt/decrypt share one cipher). A `scheduled_task` purges old rows; a `privacy\provider` satisfies GDPR. All new code follows existing plugin idioms (`core_external\*`, `advanced_testcase`, lang strings).

**Tech Stack:** Moodle 4.5, PHP 8.1+, MariaDB 10.11, PHPUnit (Docker), AES-256-CBC (openssl), Moodle `table_sql` / scheduled_task / privacy API / external API.

**Testing convention (CLAUDE.md):** Run tests by **file path** inside the container, never `--filter`. After any schema/services/task change run init first:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/<name>_test.php
```

---

## File Structure

**Create:**
- `classes/audit/audit_crypto.php` — shared key-normalise + encrypt + decrypt (one cipher impl).
- `classes/task/purge_audit_task.php` — scheduled task deleting old audit rows.
- `db/tasks.php` — schedules the task daily.
- `classes/privacy/provider.php` — GDPR metadata + export + delete.
- `classes/external/decrypt_prompt.php` — AJAX fn returning a decrypted prompt + self-audit.
- `classes/report/audit_table.php` — `table_sql` subclass for the audit log.
- `audit.php` — admin report page rendering the table + filters.
- `amd/src/audit_reveal.js` (+ `amd/build/audit_reveal.min.js` + `.map`) — reveal button JS.
- Test files: `tests/audit_crypto_test.php`, `tests/base_http_ai_client_test.php` (or extend), `tests/purge_audit_task_test.php`, `tests/privacy_provider_test.php`, `tests/decrypt_prompt_test.php`, `tests/audit_table_test.php`.

**Modify:**
- `classes/audit/audit_writer.php` — use `audit_crypto::encrypt()`.
- `classes/ai/base_http_ai_client.php:52-53` — 429/5xx → `transport_exception`.
- `db/services.php` — register `local_ai_analysis_decrypt_prompt`.
- `settings.php` — `retentiondays` setting, headings, audit-log link, reports externalpage.
- `lang/en/local_ai_analysis.php` — new strings.
- `version.php` — bump to `2026053100`, release `0.5.0`.
- `docs/ai-memory/*` — features-log, current-state, decisions.

---

## Task 1: Shared crypto helper (`audit_crypto`) + refactor writer

**Files:**
- Create: `classes/audit/audit_crypto.php`
- Modify: `classes/audit/audit_writer.php`
- Test: `tests/audit_crypto_test.php`

- [ ] **Step 1: Write the failing test**

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\audit\audit_crypto;

/**
 * @covers \local_ai_analysis\audit\audit_crypto
 */
class audit_crypto_test extends \advanced_testcase {

    public function test_round_trip_with_hex_key(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('ab', 32); // 64 hex chars.
        $stored = audit_crypto::encrypt('who failed quiz 3');
        $this->assertNotNull($stored);
        $this->assertStringContainsString('::', $stored);
        $this->assertSame('who failed quiz 3', audit_crypto::decrypt($stored));
    }

    public function test_no_key_returns_null(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = '';
        $this->assertNull(audit_crypto::encrypt('x'));
        $this->assertNull(audit_crypto::decrypt('aaaa::bbbb'));
    }

    public function test_decrypt_garbage_returns_null(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('ab', 32);
        $this->assertNull(audit_crypto::decrypt('not-valid-format'));
        $this->assertNull(audit_crypto::decrypt('!!!::!!!'));
    }
}
```

- [ ] **Step 2: Run to verify it fails**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/audit_crypto_test.php
```
Expected: FAIL — class `audit_crypto` not found.

- [ ] **Step 3: Create the helper**

`classes/audit/audit_crypto.php`:
```php
<?php
namespace local_ai_analysis\audit;

defined('MOODLE_INTERNAL') || die();

/**
 * Shared AES-256-CBC helper for audit prompts. Single source of the cipher so
 * audit_writer (encrypt) and decrypt_prompt (decrypt) cannot drift. Storage
 * format: base64(iv) . '::' . base64(ciphertext). Never throws.
 */
class audit_crypto {

    /** Encrypt a prompt for storage, or null if no usable key / failure. */
    public static function encrypt(string $plain): ?string {
        global $CFG;
        $key = self::normalize_key($CFG->ai_analysis_audit_key ?? '');
        if ($key === null) {
            return null;
        }
        $iv = openssl_random_pseudo_bytes(16);
        $ct = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($ct === false) {
            return null;
        }
        return base64_encode($iv) . '::' . base64_encode($ct);
    }

    /** Decrypt stored ciphertext back to plaintext, or null on any problem. */
    public static function decrypt(string $stored): ?string {
        global $CFG;
        $key = self::normalize_key($CFG->ai_analysis_audit_key ?? '');
        if ($key === null) {
            return null;
        }
        $parts = explode('::', $stored, 2);
        if (count($parts) !== 2) {
            return null;
        }
        $iv = base64_decode($parts[0], true);
        $ct = base64_decode($parts[1], true);
        if ($iv === false || $ct === false || strlen($iv) !== 16) {
            return null;
        }
        $pt = openssl_decrypt($ct, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        return $pt === false ? null : $pt;
    }

    /**
     * Accept the key as 32 raw bytes or 64 hex digits; return 32 raw bytes or
     * null (logged via debugging) if empty / wrong size / wrong format.
     */
    public static function normalize_key(string $raw): ?string {
        if ($raw === '') {
            return null;
        }
        if (strlen($raw) === 32) {
            return $raw;
        }
        if (strlen($raw) === 64 && ctype_xdigit($raw)) {
            return hex2bin($raw);
        }
        debugging(
            'local_ai_analysis_audit_key must be 32 raw bytes or 64 hex digits; '
            . 'got ' . strlen($raw) . ' chars. Prompt will not be encrypted.',
            DEBUG_DEVELOPER
        );
        return null;
    }
}
```

- [ ] **Step 4: Refactor `audit_writer` to use it**

In `classes/audit/audit_writer.php`, replace the inline encryption block (the
`$encrypted = null; $key = self::normalize_aes_key(...) ... } }` section) with:
```php
            $encrypted = \local_ai_analysis\audit\audit_crypto::encrypt($prompt);
```
and **delete** the now-unused private `normalize_aes_key()` method.

- [ ] **Step 5: Run to verify pass + no regression**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/audit_crypto_test.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/audit_writer_test.php
```
Expected: PASS (both). If `audit_writer_test.php` does not exist, skip its run.

- [ ] **Step 6: Commit**

```bash
git add classes/audit/audit_crypto.php classes/audit/audit_writer.php tests/audit_crypto_test.php
git commit -m "feat(ai_analysis): extract shared audit_crypto (encrypt+decrypt)

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 2: 429 / 5xx → transport_exception

**Files:**
- Modify: `classes/ai/base_http_ai_client.php:52-53`
- Test: `tests/base_http_ai_client_test.php`

- [ ] **Step 1: Write the failing test**

If `tests/base_http_ai_client_test.php` exists, add these methods; else create the file. The base client is abstract — use a minimal concrete subclass exposing the response handler. Inspect the abstract methods first; the test subclass must implement `endpoint()`, `auth_headers()`, `build_sql_payload()`, `build_format_payload()`, `extract_text()` and declare `DEFAULT_MODEL`. The handler under test is the non-2xx branch around line 52.

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\exception\transport_exception;
use local_ai_analysis\exception\ai_client_exception;

/**
 * @covers \local_ai_analysis\ai\base_http_ai_client
 */
class base_http_ai_client_test extends \advanced_testcase {

    public function test_http_429_is_transport_error(): void {
        $client = $this->make_client(429, 'rate limited');
        $this->expectException(transport_exception::class);
        $client->generate_sql('manifest', 'prompt');
    }

    public function test_http_503_is_transport_error(): void {
        $client = $this->make_client(503, 'unavailable');
        $this->expectException(transport_exception::class);
        $client->generate_sql('manifest', 'prompt');
    }

    public function test_http_400_is_ai_client_error(): void {
        $client = $this->make_client(400, 'bad request');
        $this->expectException(ai_client_exception::class);
        $client->generate_sql('manifest', 'prompt');
    }

    /**
     * Build a concrete base_http_ai_client backed by a fake transport that
     * returns the given HTTP status/body. Reuse the existing fake transport
     * pattern from the claude_client tests (http_transport_interface).
     */
    private function make_client(int $status, string $body) {
        // See claude_client_test.php for the fake transport + concrete subclass
        // wiring; mirror it here returning ['status' => $status, 'body' => $body].
        // Implementation provided by the engineer following the existing seam.
    }
}
```

> NOTE for implementer: locate the existing transport fake (search `http_transport_interface` in `tests/`). Construct the smallest concrete `base_http_ai_client` subclass that the suite already uses, or define an anonymous subclass in the test. The assertion that matters: 429 and 503 throw `transport_exception`; 400 throws `ai_client_exception`.

- [ ] **Step 2: Run to verify it fails**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/base_http_ai_client_test.php
```
Expected: FAIL — 429/503 currently throw `ai_client_exception`.

- [ ] **Step 3: Apply the fix**

`classes/ai/base_http_ai_client.php` — add at top with the other `use`s:
```php
use local_ai_analysis\exception\transport_exception;
```
Replace the non-2xx branch (lines ~52-53):
```php
        if ($response['status'] < 200 || $response['status'] >= 300) {
            $code = (int) $response['status'];
            if ($code === 429 || $code >= 500) {
                throw new transport_exception('HTTP_' . $code . ': ' . $response['body']);
            }
            throw new ai_client_exception('HTTP_' . $code, $response['body']);
        }
```

- [ ] **Step 4: Run to verify pass**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/base_http_ai_client_test.php
```
Expected: PASS (all three).

- [ ] **Step 5: Commit**

```bash
git add classes/ai/base_http_ai_client.php tests/base_http_ai_client_test.php
git commit -m "fix(ai_analysis): map HTTP 429/5xx to transport_exception

Provider rate-limit/transient errors now surface as AI_TRANSPORT_ERROR
instead of AI_INVALID_JSON.

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 3: Retention scheduled task

**Files:**
- Create: `classes/task/purge_audit_task.php`, `db/tasks.php`
- Test: `tests/purge_audit_task_test.php`

- [ ] **Step 1: Write the failing test**

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\task\purge_audit_task;

/**
 * @covers \local_ai_analysis\task\purge_audit_task
 */
class purge_audit_task_test extends \advanced_testcase {

    private function seed(int $timecreated): void {
        global $DB;
        $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => 1, 'courseid' => 0, 'timecreated' => $timecreated,
            'prompt_hash' => 'h', 'prompt_length' => 1, 'status' => 'SUCCESS',
        ]);
    }

    public function test_deletes_rows_older_than_retention(): void {
        global $DB;
        $this->resetAfterTest();
        set_config('retentiondays', 30, 'local_ai_analysis');
        $now = time();
        $this->seed($now - 40 * DAYSECS); // older -> delete
        $this->seed($now - 10 * DAYSECS); // newer -> keep
        (new purge_audit_task())->execute();
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit'));
    }

    public function test_zero_retention_keeps_everything(): void {
        global $DB;
        $this->resetAfterTest();
        set_config('retentiondays', 0, 'local_ai_analysis');
        $this->seed(time() - 9999 * DAYSECS);
        (new purge_audit_task())->execute();
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit'));
    }
}
```

- [ ] **Step 2: Run to verify it fails**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/purge_audit_task_test.php
```
Expected: FAIL — class `purge_audit_task` not found.

- [ ] **Step 3: Create the task**

`classes/task/purge_audit_task.php`:
```php
<?php
namespace local_ai_analysis\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Deletes audit rows older than the configured retention window.
 * retentiondays <= 0 disables purging (keep forever).
 */
class purge_audit_task extends \core\task\scheduled_task {

    public function get_name(): string {
        return get_string('task_purge_audit', 'local_ai_analysis');
    }

    public function execute(): void {
        global $DB;
        $days = (int) get_config('local_ai_analysis', 'retentiondays');
        if ($days <= 0) {
            mtrace('local_ai_analysis: audit retention disabled (retentiondays <= 0).');
            return;
        }
        $cutoff = time() - ($days * DAYSECS);
        $before = $DB->count_records_select('local_ai_analysis_audit', 'timecreated < ?', [$cutoff]);
        $DB->delete_records_select('local_ai_analysis_audit', 'timecreated < ?', [$cutoff]);
        mtrace("local_ai_analysis: purged {$before} audit rows older than {$days} days.");
    }
}
```

- [ ] **Step 4: Create `db/tasks.php`**

```php
<?php
defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'local_ai_analysis\\task\\purge_audit_task',
        'blocking'  => 0,
        'minute'    => '0',
        'hour'      => '3',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
];
```

- [ ] **Step 5: Add lang string + run init + tests**

Add to `lang/en/local_ai_analysis.php`:
```php
$string['task_purge_audit'] = 'Purge old AI analysis audit records';
```
Then:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/purge_audit_task_test.php
```
Expected: PASS (both methods).

- [ ] **Step 6: Commit**

```bash
git add classes/task/purge_audit_task.php db/tasks.php lang/en/local_ai_analysis.php tests/purge_audit_task_test.php
git commit -m "feat(ai_analysis): add audit retention scheduled task

Daily task deletes audit rows older than retentiondays (0 = keep forever).

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 4: Privacy API provider

**Files:**
- Create: `classes/privacy/provider.php`
- Test: `tests/privacy_provider_test.php`

- [ ] **Step 1: Write the failing test**

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\request\writer;
use core_privacy\local\request\approved_contextlist;
use local_ai_analysis\privacy\provider;

/**
 * @covers \local_ai_analysis\privacy\provider
 */
class privacy_provider_test extends \core_privacy\tests\provider_testcase {

    private function seed(int $userid): void {
        global $DB;
        $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => $userid, 'courseid' => 0, 'timecreated' => time(),
            'prompt_hash' => 'h', 'prompt_length' => 5, 'status' => 'SUCCESS',
        ]);
    }

    public function test_metadata_not_empty(): void {
        $this->resetAfterTest();
        $collection = new \core_privacy\local\metadata\collection('local_ai_analysis');
        $collection = provider::get_metadata($collection);
        $this->assertNotEmpty($collection->get_collection());
    }

    public function test_get_contexts_for_userid(): void {
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->seed((int) $user->id);
        $contextlist = provider::get_contexts_for_userid((int) $user->id);
        $this->assertCount(1, $contextlist);
        $this->assertEquals(
            \context_system::instance()->id,
            $contextlist->current()->id
        );
    }

    public function test_delete_data_for_user(): void {
        global $DB;
        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->seed((int) $user->id);
        $this->seed((int) $user->id);
        $other = $this->getDataGenerator()->create_user();
        $this->seed((int) $other->id);

        $ctxlist = new approved_contextlist($user, 'local_ai_analysis',
            [\context_system::instance()->id]);
        provider::delete_data_for_user($ctxlist);

        $this->assertEquals(0, $DB->count_records('local_ai_analysis_audit', ['userid' => $user->id]));
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit', ['userid' => $other->id]));
    }
}
```

- [ ] **Step 2: Run to verify it fails**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/privacy_provider_test.php
```
Expected: FAIL — class `provider` not found.

- [ ] **Step 3: Create the provider**

`classes/privacy/provider.php`:
```php
<?php
namespace local_ai_analysis\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use context;
use context_system;

class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_ai_analysis_audit', [
            'userid'           => 'privacy:metadata:audit:userid',
            'courseid'         => 'privacy:metadata:audit:courseid',
            'timecreated'      => 'privacy:metadata:audit:timecreated',
            'prompt_hash'      => 'privacy:metadata:audit:prompt_hash',
            'prompt_length'    => 'privacy:metadata:audit:prompt_length',
            'prompt_encrypted' => 'privacy:metadata:audit:prompt_encrypted',
            'sql_executed'     => 'privacy:metadata:audit:sql_executed',
            'row_count'        => 'privacy:metadata:audit:row_count',
            'status'           => 'privacy:metadata:audit:status',
            'provider'         => 'privacy:metadata:audit:provider',
            'duration_ms'      => 'privacy:metadata:audit:duration_ms',
            'useragent'        => 'privacy:metadata:audit:useragent',
        ], 'privacy:metadata:audit');
        return $collection;
    }

    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();
        global $DB;
        if ($DB->record_exists('local_ai_analysis_audit', ['userid' => $userid])) {
            $contextlist->add_system_context();
        }
        return $contextlist;
    }

    public static function get_users_in_context(userlist $userlist): void {
        if (!$userlist->get_context() instanceof context_system) {
            return;
        }
        $userlist->add_from_sql('userid', 'SELECT userid FROM {local_ai_analysis_audit}', []);
    }

    public static function export_user_data(approved_contextlist $contextlist): void {
        global $DB;
        foreach ($contextlist->get_contexts() as $context) {
            if (!$context instanceof context_system) {
                continue;
            }
            $rows = $DB->get_records('local_ai_analysis_audit',
                ['userid' => $contextlist->get_user()->id], 'timecreated ASC');
            $data = array_map(static function($r) {
                return [
                    'timecreated'   => userdate($r->timecreated),
                    'courseid'      => $r->courseid,
                    'status'        => $r->status,
                    'provider'      => $r->provider,
                    'prompt_length' => $r->prompt_length,
                    'row_count'     => $r->row_count,
                    'sql_executed'  => $r->sql_executed,
                ];
            }, array_values($rows));
            if ($data) {
                writer::with_context($context)->export_data(
                    [get_string('privacy:path:audit', 'local_ai_analysis')],
                    (object) ['records' => $data]
                );
            }
        }
    }

    public static function delete_data_for_all_users_in_context(context $context): void {
        global $DB;
        if ($context instanceof context_system) {
            $DB->delete_records('local_ai_analysis_audit');
        }
    }

    public static function delete_data_for_user(approved_contextlist $contextlist): void {
        global $DB;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context instanceof context_system) {
                $DB->delete_records('local_ai_analysis_audit',
                    ['userid' => $contextlist->get_user()->id]);
            }
        }
    }

    public static function delete_data_for_users(approved_userlist $userlist): void {
        global $DB;
        if (!$userlist->get_context() instanceof context_system) {
            return;
        }
        [$insql, $params] = $DB->get_in_or_equal($userlist->get_userids(), SQL_PARAMS_NAMED);
        $DB->delete_records_select('local_ai_analysis_audit', "userid $insql", $params);
    }
}
```

- [ ] **Step 4: Add privacy lang strings**

Add to `lang/en/local_ai_analysis.php`:
```php
$string['privacy:metadata:audit'] = 'Audit log of AI analysis queries made by the user.';
$string['privacy:metadata:audit:userid'] = 'The user who made the query.';
$string['privacy:metadata:audit:courseid'] = 'The course context of the query.';
$string['privacy:metadata:audit:timecreated'] = 'When the query was made.';
$string['privacy:metadata:audit:prompt_hash'] = 'SHA-256 hash of the prompt.';
$string['privacy:metadata:audit:prompt_length'] = 'Character length of the prompt.';
$string['privacy:metadata:audit:prompt_encrypted'] = 'The prompt, stored AES-256-CBC encrypted.';
$string['privacy:metadata:audit:sql_executed'] = 'The validated SQL that was executed.';
$string['privacy:metadata:audit:row_count'] = 'Number of rows returned.';
$string['privacy:metadata:audit:status'] = 'Outcome status of the query.';
$string['privacy:metadata:audit:provider'] = 'The AI provider used.';
$string['privacy:metadata:audit:duration_ms'] = 'Request duration in milliseconds.';
$string['privacy:metadata:audit:useragent'] = 'Browser user agent string.';
$string['privacy:path:audit'] = 'AI analysis audit log';
```

- [ ] **Step 5: Run tests**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/privacy_provider_test.php
```
Expected: PASS (all three).

- [ ] **Step 6: Commit**

```bash
git add classes/privacy/provider.php lang/en/local_ai_analysis.php tests/privacy_provider_test.php
git commit -m "feat(ai_analysis): add GDPR privacy provider (export + delete)

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 5: Decrypt-prompt AJAX function

**Files:**
- Create: `classes/external/decrypt_prompt.php`
- Modify: `db/services.php`
- Test: `tests/decrypt_prompt_test.php`

- [ ] **Step 1: Write the failing test**

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\external\decrypt_prompt;
use local_ai_analysis\audit\audit_crypto;

/**
 * @covers \local_ai_analysis\external\decrypt_prompt
 */
class decrypt_prompt_test extends \advanced_testcase {

    private function seed_encrypted(string $plain): int {
        global $DB;
        return (int) $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => 2, 'courseid' => 0, 'timecreated' => time(),
            'prompt_hash' => hash('sha256', $plain), 'prompt_length' => strlen($plain),
            'prompt_encrypted' => audit_crypto::encrypt($plain), 'status' => 'SUCCESS',
        ]);
    }

    public function test_admin_reveals_and_self_audits(): void {
        global $DB, $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('cd', 32);
        $this->setAdminUser();
        $id = $this->seed_encrypted('list failing students');

        $result = decrypt_prompt::execute($id);
        $this->assertEquals('SUCCESS', $result['status']);
        $this->assertEquals('list failing students', $result['prompt']);
        $this->assertEquals(1, $DB->count_records('local_ai_analysis_audit', ['status' => 'PROMPT_REVEALED']));
    }

    public function test_missing_ciphertext_returns_not_found(): void {
        global $DB;
        $this->resetAfterTest();
        $this->setAdminUser();
        $id = (int) $DB->insert_record('local_ai_analysis_audit', (object)[
            'userid' => 2, 'courseid' => 0, 'timecreated' => time(),
            'prompt_hash' => 'h', 'prompt_length' => 0, 'prompt_encrypted' => null,
            'status' => 'BLOCKED_INJECTION',
        ]);
        $result = decrypt_prompt::execute($id);
        $this->assertEquals('NOT_FOUND', $result['status']);
        $this->assertEquals('', $result['prompt']);
    }

    public function test_without_capability_throws(): void {
        global $CFG;
        $this->resetAfterTest();
        $CFG->ai_analysis_audit_key = str_repeat('cd', 32);
        $user = $this->getDataGenerator()->create_user();
        $this->setUser($user); // no decryptprompt cap
        $id = $this->seed_encrypted('x');
        $this->expectException(\required_capability_exception::class);
        decrypt_prompt::execute($id);
    }
}
```

- [ ] **Step 2: Run to verify it fails**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/decrypt_prompt_test.php
```
Expected: FAIL — class not found.

- [ ] **Step 3: Create the external function**

`classes/external/decrypt_prompt.php`:
```php
<?php
namespace local_ai_analysis\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

use local_ai_analysis\audit\audit_crypto;
use local_ai_analysis\audit\audit_writer;

defined('MOODLE_INTERNAL') || die();

/**
 * Reveal (decrypt) a stored audit prompt. Capability + sesskey gated by the
 * AJAX layer. Every successful reveal writes its own PROMPT_REVEALED audit row.
 */
class decrypt_prompt extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'id' => new external_value(PARAM_INT, 'Audit row id to reveal'),
        ]);
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'status' => new external_value(PARAM_ALPHANUMEXT, 'SUCCESS, NOT_FOUND or DECRYPT_FAILED'),
            'prompt' => new external_value(PARAM_RAW, 'Decrypted prompt, empty unless SUCCESS'),
        ]);
    }

    public static function execute(int $id): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), ['id' => $id]);
        $context = \context_system::instance();
        self::validate_context($context);
        require_capability('local/ai_analysis:decryptprompt', $context);

        $row = $DB->get_record('local_ai_analysis_audit', ['id' => $params['id']]);
        if (!$row || $row->prompt_encrypted === null || $row->prompt_encrypted === '') {
            return ['status' => 'NOT_FOUND', 'prompt' => ''];
        }

        $plain = audit_crypto::decrypt($row->prompt_encrypted);
        if ($plain === null) {
            return ['status' => 'DECRYPT_FAILED', 'prompt' => ''];
        }

        audit_writer::write(
            (int) $USER->id, 0, 'reveal', null,
            'PROMPT_REVEALED', 'revealed audit id ' . $params['id']
        );

        return ['status' => 'SUCCESS', 'prompt' => $plain];
    }
}
```

- [ ] **Step 4: Register in `db/services.php`**

Add to the `$functions` array:
```php
    'local_ai_analysis_decrypt_prompt' => [
        'classname'     => 'local_ai_analysis\\external\\decrypt_prompt',
        'methodname'    => 'execute',
        'description'   => 'Decrypt and return a stored audit prompt (admin only).',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/ai_analysis:decryptprompt',
    ],
```

- [ ] **Step 5: Run init + tests**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/decrypt_prompt_test.php
```
Expected: PASS (all three).

- [ ] **Step 6: Commit**

```bash
git add classes/external/decrypt_prompt.php db/services.php tests/decrypt_prompt_test.php
git commit -m "feat(ai_analysis): add decrypt_prompt AJAX fn with self-audit

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 6: Audit viewer report page + reveal JS

**Files:**
- Create: `classes/report/audit_table.php`, `audit.php`, `amd/src/audit_reveal.js`, `amd/build/audit_reveal.min.js`, `amd/build/audit_reveal.min.js.map`
- Modify: `settings.php` (register reports externalpage), `lang/en/local_ai_analysis.php`
- Test: `tests/audit_table_test.php`

- [ ] **Step 1: Write the failing test (query-building seam)**

The test exercises the WHERE/params builder, not HTML. `audit_table` exposes a
static `build_filter(array $filters): array` returning `[$where, $params]` so it is
unit-testable without rendering.

```php
<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

use local_ai_analysis\report\audit_table;

/**
 * @covers \local_ai_analysis\report\audit_table
 */
class audit_table_test extends \advanced_testcase {

    public function test_empty_filters_match_all(): void {
        [$where, $params] = audit_table::build_filter([]);
        $this->assertEquals('1=1', $where);
        $this->assertEquals([], $params);
    }

    public function test_filters_build_constraints(): void {
        [$where, $params] = audit_table::build_filter([
            'userid' => 7, 'courseid' => 3, 'status' => 'SUCCESS',
            'datefrom' => 100, 'dateto' => 200,
        ]);
        $this->assertStringContainsString('userid = :userid', $where);
        $this->assertStringContainsString('courseid = :courseid', $where);
        $this->assertStringContainsString('status = :status', $where);
        $this->assertStringContainsString('timecreated >= :datefrom', $where);
        $this->assertStringContainsString('timecreated <= :dateto', $where);
        $this->assertEquals(7, $params['userid']);
        $this->assertEquals('SUCCESS', $params['status']);
        $this->assertEquals(200, $params['dateto']);
    }
}
```

- [ ] **Step 2: Run to verify it fails**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/audit_table_test.php
```
Expected: FAIL — class not found.

- [ ] **Step 3: Create `audit_table`**

`classes/report/audit_table.php`:
```php
<?php
namespace local_ai_analysis\report;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/tablelib.php');

use local_ai_analysis\audit\audit_crypto;

/**
 * Audit log report table. Sortable, paginated, downloadable. The reveal action
 * column appears only for users with the decryptprompt capability.
 */
class audit_table extends \table_sql {

    public function __construct(string $uniqueid, array $filters = []) {
        parent::__construct($uniqueid);

        $columns = ['timecreated', 'userid', 'courseid', 'status', 'provider',
            'prompt_length', 'row_count', 'duration_ms', 'sql_executed'];
        $headers = [
            get_string('col_time', 'local_ai_analysis'),
            get_string('col_user', 'local_ai_analysis'),
            get_string('col_course', 'local_ai_analysis'),
            get_string('col_status', 'local_ai_analysis'),
            get_string('col_provider', 'local_ai_analysis'),
            get_string('col_promptlen', 'local_ai_analysis'),
            get_string('col_rows', 'local_ai_analysis'),
            get_string('col_duration', 'local_ai_analysis'),
            get_string('col_sql', 'local_ai_analysis'),
        ];

        $candecrypt = has_capability('local/ai_analysis:decryptprompt',
            \context_system::instance());
        if ($candecrypt && !$this->is_downloading()) {
            $columns[] = 'actions';
            $headers[] = get_string('col_actions', 'local_ai_analysis');
        }

        $this->define_columns($columns);
        $this->define_headers($headers);
        $this->sortable(true, 'timecreated', SORT_DESC);
        $this->no_sorting('actions');
        $this->no_sorting('sql_executed');
        $this->collapsible(false);

        [$where, $params] = self::build_filter($filters);
        $this->set_sql('id, userid, courseid, timecreated, status, provider, '
            . 'prompt_length, row_count, duration_ms, sql_executed, prompt_encrypted',
            '{local_ai_analysis_audit}', $where, $params);
    }

    /** Build WHERE + named params from optional filters. */
    public static function build_filter(array $filters): array {
        $clauses = [];
        $params = [];
        if (!empty($filters['userid'])) {
            $clauses[] = 'userid = :userid';
            $params['userid'] = (int) $filters['userid'];
        }
        if (!empty($filters['courseid'])) {
            $clauses[] = 'courseid = :courseid';
            $params['courseid'] = (int) $filters['courseid'];
        }
        if (!empty($filters['status'])) {
            $clauses[] = 'status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['datefrom'])) {
            $clauses[] = 'timecreated >= :datefrom';
            $params['datefrom'] = (int) $filters['datefrom'];
        }
        if (!empty($filters['dateto'])) {
            $clauses[] = 'timecreated <= :dateto';
            $params['dateto'] = (int) $filters['dateto'];
        }
        return [$clauses ? implode(' AND ', $clauses) : '1=1', $params];
    }

    public function col_timecreated($row) {
        return userdate($row->timecreated);
    }

    public function col_userid($row) {
        if ($this->is_downloading()) {
            return $row->userid;
        }
        $url = new \moodle_url('/user/profile.php', ['id' => $row->userid]);
        return \html_writer::link($url, fullname(\core_user::get_user($row->userid) ?: (object)['firstname' => 'User', 'lastname' => $row->userid]));
    }

    public function col_courseid($row) {
        return $row->courseid ? $row->courseid : '-';
    }

    public function col_sql_executed($row) {
        return $row->sql_executed ? shorten_text(s($row->sql_executed), 120) : '';
    }

    public function col_actions($row) {
        if (empty($row->prompt_encrypted)) {
            return '';
        }
        return \html_writer::tag('button', get_string('reveal_prompt', 'local_ai_analysis'), [
            'type' => 'button',
            'class' => 'btn btn-link btn-sm local-ai-reveal',
            'data-audit-id' => $row->id,
        ]);
    }
}
```

- [ ] **Step 4: Run to verify pass**

```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/audit_table_test.php
```
Expected: PASS (both methods).

- [ ] **Step 5: Create `audit.php`**

```php
<?php
require(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/ai_analysis:viewaudit', $context);

admin_externalpage_setup('localaianalysisaudit');

$download = optional_param('download', '', PARAM_ALPHA);
$filters = [
    'userid'   => optional_param('userid', 0, PARAM_INT),
    'courseid' => optional_param('courseid', 0, PARAM_INT),
    'status'   => optional_param('status', '', PARAM_ALPHANUMEXT),
    'datefrom' => optional_param('datefrom', 0, PARAM_INT),
    'dateto'   => optional_param('dateto', 0, PARAM_INT),
];

$table = new \local_ai_analysis\report\audit_table('local_ai_analysis_audit', $filters);
$baseurl = new moodle_url('/local/ai_analysis/audit.php', array_filter($filters));
$table->define_baseurl($baseurl);
$table->is_downloadable(true);
$table->show_download_buttons_at([TABLE_P_BOTTOM]);

if ($download) {
    $table->is_downloading($download, 'ai_analysis_audit', 'audit');
}

if (!$table->is_downloading()) {
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('audit_report', 'local_ai_analysis'));
    $PAGE->requires->js_call_amd('local_ai_analysis/audit_reveal', 'init');
}

$table->out(50, true);

if (!$table->is_downloading()) {
    echo $OUTPUT->footer();
}
```

- [ ] **Step 6: Register the report page in `settings.php`**

Inside the `if ($hassiteconfig) {` block, after the settings page is added:
```php
    $ADMIN->add('reports', new admin_externalpage(
        'localaianalysisaudit',
        get_string('audit_report', 'local_ai_analysis'),
        new moodle_url('/local/ai_analysis/audit.php'),
        'local/ai_analysis:viewaudit'
    ));
```

- [ ] **Step 7: Create the reveal AMD module**

`amd/src/audit_reveal.js`:
```javascript
import Ajax from 'core/ajax';
import Notification from 'core/notification';

export const init = () => {
    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.local-ai-reveal');
        if (!btn) {
            return;
        }
        e.preventDefault();
        const id = parseInt(btn.getAttribute('data-audit-id'), 10);
        btn.disabled = true;
        Ajax.call([{
            methodname: 'local_ai_analysis_decrypt_prompt',
            args: {id: id},
        }])[0].then((res) => {
            const cell = btn.parentNode;
            if (res.status === 'SUCCESS') {
                cell.textContent = res.prompt;
            } else {
                cell.textContent = '[' + res.status + ']';
            }
            return res;
        }).catch((err) => {
            btn.disabled = false;
            Notification.exception(err);
        });
    });
};
```

`amd/build/audit_reveal.min.js` (hand-authored named define, per the Sprint-4
dev-mode requirement — the `.map` must exist beside it):
```javascript
define("local_ai_analysis/audit_reveal", ["core/ajax", "core/notification"], function(Ajax, Notification) {
    return {
        init: function() {
            document.addEventListener("click", function(e) {
                var btn = e.target.closest(".local-ai-reveal");
                if (!btn) { return; }
                e.preventDefault();
                var id = parseInt(btn.getAttribute("data-audit-id"), 10);
                btn.disabled = true;
                Ajax.call([{ methodname: "local_ai_analysis_decrypt_prompt", args: { id: id } }])[0]
                    .then(function(res) {
                        var cell = btn.parentNode;
                        if (res.status === "SUCCESS") { cell.textContent = res.prompt; }
                        else { cell.textContent = "[" + res.status + "]"; }
                        return res;
                    })
                    .catch(function(err) { btn.disabled = false; Notification.exception(err); });
            });
        }
    };
});
```

`amd/build/audit_reveal.min.js.map`:
```json
{"version":3,"file":"audit_reveal.min.js","sources":["../src/audit_reveal.js"],"sourcesContent":[],"names":[],"mappings":""}
```

- [ ] **Step 8: Add report lang strings**

Add to `lang/en/local_ai_analysis.php`:
```php
$string['audit_report'] = 'AI analysis audit log';
$string['reveal_prompt'] = 'Reveal prompt';
$string['col_time'] = 'Time';
$string['col_user'] = 'User';
$string['col_course'] = 'Course';
$string['col_status'] = 'Status';
$string['col_provider'] = 'Provider';
$string['col_promptlen'] = 'Prompt length';
$string['col_rows'] = 'Rows';
$string['col_duration'] = 'Duration (ms)';
$string['col_sql'] = 'SQL';
$string['col_actions'] = 'Actions';
```

- [ ] **Step 9: Bump version, run init, purge caches, full suite**

In `version.php` set `$plugin->version = 2026053100;` and
`$plugin->release = '0.5.0 (Sprint 5: admin/management & compliance)';`
```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/upgrade.php --non-interactive
docker exec moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite
```
Expected: all tests PASS.

- [ ] **Step 10: Commit**

```bash
git add classes/report/audit_table.php audit.php amd/src/audit_reveal.js amd/build/audit_reveal.min.js amd/build/audit_reveal.min.js.map settings.php lang/en/local_ai_analysis.php version.php tests/audit_table_test.php
git commit -m "feat(ai_analysis): add audit log report page + reveal action

table_sql report under Site admin > Reports; reveal button calls the
decrypt_prompt AJAX fn (admins with decryptprompt cap only).

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 7: Settings polish (headings + retentiondays + audit link)

**Files:**
- Modify: `settings.php`, `lang/en/local_ai_analysis.php`

- [ ] **Step 1: Add headings, retention field, and audit link**

Restructure the `$settings->add(...)` block in `settings.php` to group under headings.
Insert these around the existing settings (keep all existing settings; only add
headings + the retention field + the link):

```php
    // --- Provider ---
    $settings->add(new admin_setting_heading('local_ai_analysis/h_provider',
        get_string('h_provider', 'local_ai_analysis'), ''));
    // (existing provider select stays here)

    // --- API keys & models ---
    $settings->add(new admin_setting_heading('local_ai_analysis/h_keys',
        get_string('h_keys', 'local_ai_analysis'), ''));
    // (existing claude/openai/gemini key + model settings stay here)

    // --- Limits ---
    $settings->add(new admin_setting_heading('local_ai_analysis/h_limits',
        get_string('h_limits', 'local_ai_analysis'), ''));
    // (existing rate_limit_per_min stays here)

    // --- Audit & retention ---
    $settings->add(new admin_setting_heading('local_ai_analysis/h_audit',
        get_string('h_audit', 'local_ai_analysis'), ''));

    $settings->add(new admin_setting_configtext(
        'local_ai_analysis/retentiondays',
        get_string('setting_retentiondays', 'local_ai_analysis'),
        get_string('setting_retentiondays_desc', 'local_ai_analysis'),
        '365',
        PARAM_INT
    ));

    $settings->add(new admin_setting_description(
        'local_ai_analysis/auditlink',
        get_string('h_audit', 'local_ai_analysis'),
        \html_writer::link(
            new moodle_url('/local/ai_analysis/audit.php'),
            get_string('audit_report', 'local_ai_analysis')
        )
    ));
```

- [ ] **Step 2: Add lang strings**

```php
$string['h_provider'] = 'AI provider';
$string['h_keys'] = 'API keys & models';
$string['h_limits'] = 'Rate limiting';
$string['h_audit'] = 'Audit & retention';
$string['setting_retentiondays'] = 'Audit retention (days)';
$string['setting_retentiondays_desc'] = 'Delete audit log records older than this many days. Set to 0 to keep records forever. The daily cleanup task enforces this.';
```

- [ ] **Step 3: Verify settings render (no fatal)**

```bash
docker exec moodle-web-8092 php /var/www/html/admin/cli/purge_caches.php
docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite
```
Expected: all tests PASS (settings.php is parsed during bootstrap; a syntax error would fail the suite). Manually confirm the settings page loads in the browser.

- [ ] **Step 4: Commit**

```bash
git add settings.php lang/en/local_ai_analysis.php
git commit -m "feat(ai_analysis): settings headings, retention field, audit link

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Task 8: Docs update (project rule)

**Files:**
- Modify: `docs/ai-memory/02-features-log.md`, `docs/ai-memory/04-current-state.md`, `docs/ai-memory/03-decisions.md`

- [ ] **Step 1: Update the three ai-memory docs**

- `02-features-log.md`: add a Sprint 5 entry — audit report page (`audit.php` + `audit_table`), decrypt_prompt AJAX fn + self-audit `PROMPT_REVEALED`, privacy provider, retention task + `retentiondays` setting, settings headings, 429/5xx transport mapping, shared `audit_crypto`. List changed files + new external function + new scheduled task.
- `04-current-state.md`: move Sprint 5 from "Next" to "Done"; update version to `2026053100` / `0.5.0`; remove the resolved "HTTP 429 mis-mapped" pending bug; note new report page, privacy provider, scheduled task, `retentiondays`. Update "Next" to: optional Sprint 3c (Ollama), grunt/ESLint rebuild on node-22 host, manual browser smoke-tests.
- `03-decisions.md`: record decisions — decrypt reveal = cap+sesskey+self-audit (no password re-entry); retention = delete (default 365, 0=forever); GDPR erasure = delete (not anonymise); audit_crypto extracted to keep one cipher impl.

- [ ] **Step 2: Commit**

```bash
git add docs/ai-memory/
git commit -m "docs(ai-memory): record Sprint 5 admin/management completion

Signed-off-by: HimanshuBijja <tgpa.himanshu@gmail.com>"
```

---

## Self-Review notes

- **Spec coverage:** audit viewer (T6), decrypt+self-audit (T5), Privacy API (T4),
  retention task (T3), settings polish + retentiondays + headings + link (T7), 429/5xx
  (T2), shared crypto (T1 — supports T5), docs (T8). All spec sections covered.
- **Type consistency:** `audit_crypto::encrypt/decrypt/normalize_key`, status strings
  `PROMPT_REVEALED`/`NOT_FOUND`/`DECRYPT_FAILED`, `build_filter` return `[$where,$params]`,
  setting key `retentiondays`, externalpage id `localaianalysisaudit`, AMD module
  `local_ai_analysis/audit_reveal`, service `local_ai_analysis_decrypt_prompt` — all used
  consistently across tasks.
- **Known caveat:** AMD build files are hand-authored (no node-22 here); flagged in T8
  current-state for a grunt/ESLint rebuild before release, consistent with Sprint 4.
- **Ordering:** T1 before T5 (decrypt needs `audit_crypto`); T3 lang string for task name
  added in T3; retention *setting* registered in T7 but the task reads `get_config`
  which the T3 test sets directly, so T3 is green independently.
