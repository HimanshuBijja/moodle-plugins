# Sub-project B3 — Feedback Analytics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a fast-path "course feedback ratings" capability driven by the custom `mod_customfeedback` star ratings (1–5), via two read-only SQL views, a deterministic intent template, and a Chart.js bar-chart hint for the global ranking.

**Architecture:** Two `CREATE OR REPLACE VIEW`s (`mdl_ai_course_feedback`, `mdl_ai_feedback_activity`) computed directly from `mdl_customfeedback*`; both added to the manifest allow-list; a new `course_feedback` intent (scope-aware: courseid>0 → that course, courseid=0 → worst-first ranking gated by `queryglobal`) served by `sql_template` with no AI call. A new optional third return value from `sql_template::build()` carries a chart hint that the gateway feeds through the existing `validate_chart()` so the fast-path can render a bar chart. Aggregates only — no `userid` projected, zero PII.

**Tech Stack:** PHP 8.1, Moodle 4.5 plugin, MariaDB 10.11 views, PHPUnit (Docker), greenlion/php-sql-parser (existing validator), Chart.js (existing widget).

---

## File Structure

- **Create** `classes/db/course_feedback_view.php` — DDL for the per-course rating view.
- **Create** `classes/db/feedback_activity_view.php` — DDL for the per-activity rating view.
- **Create** `tests/feedback_views_test.php` — view behaviour (math, filtering, exclusions, no-PII).
- **Modify** `db/install.php` — create both views on install (skip PHPUNIT).
- **Modify** `db/upgrade.php` — new upgrade step `2026061301`.
- **Modify** `db/readonly_grants.sql` — +2 SELECT grants.
- **Modify** `version.php` — bump to `2026061301` / `0.12.0`.
- **Modify** `classes/manifest/manifest_builder.php` — +2 view entries + scope notes.
- **Modify** `classes/intent/synonym_dictionary.php` — feedback synonym family.
- **Modify** `classes/intent/intent_registry.php` — `course_feedback` entry; add `feedback` disqualifier to `student_listing`/`course_staff`.
- **Modify** `classes/intent/sql_template.php` — `course_feedback` branch + 3-tuple return with chart hint.
- **Modify** `classes/external/query.php` — thread the template chart hint into `validate_chart()`.
- **Modify** `tests/sql_template_test.php`, `tests/intent_classifier_test.php`, `tests/manifest_builder_test.php`, `tests/external_query_test.php` — new assertions.
- **Modify** `docs/ai-memory/02-features-log.md`, `03-decisions.md`, `04-current-state.md`.

**Test command (Docker, file-path form — never `--filter`):**
```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/<name>_test.php
```
One-time after schema change:
```bash
docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php
```

---

## Task 1: The two feedback view DDL classes

**Files:**
- Create: `classes/db/course_feedback_view.php`
- Create: `classes/db/feedback_activity_view.php`
- Test: `tests/feedback_views_test.php`

- [ ] **Step 1: Write the failing test**

Create `tests/feedback_views_test.php`:

```php
<?php
namespace local_ai_analysis;

use local_ai_analysis\db\course_feedback_view;
use local_ai_analysis\db\feedback_activity_view;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\course_feedback_view
 * @covers \local_ai_analysis\db\feedback_activity_view
 */
class feedback_views_test extends \advanced_testcase {

    protected function setUp(): void {
        global $DB;
        parent::setUp();
        course_feedback_view::create($DB);
        feedback_activity_view::create($DB);
    }

    protected function tearDown(): void {
        global $DB;
        $p = $DB->get_prefix();
        $DB->execute('DROP VIEW IF EXISTS ' . $p . course_feedback_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $p . feedback_activity_view::VIEW);
        parent::tearDown();
    }

    /**
     * Seed one custom-feedback activity in a course with the given star values,
     * plus (optionally) one free-text question + answer that must be ignored.
     * Returns the new customfeedback id.
     */
    private function seed_feedback(int $courseid, array $stars, bool $withtext = false): int {
        global $DB;
        $now = time();
        $cfid = $DB->insert_record('customfeedback', (object) [
            'course' => $courseid, 'name' => 'Survey', 'intro' => '', 'introformat' => 1,
            'allowmulti' => 0, 'timecreated' => $now, 'timemodified' => $now,
        ]);
        $qid = $DB->insert_record('customfeedback_q', (object) [
            'customfeedbackid' => $cfid, 'type' => 'star', 'name' => 'Rate', 'intro' => '',
            'introformat' => 1, 'required' => 1, 'sortorder' => 1,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        $textqid = 0;
        if ($withtext) {
            $textqid = $DB->insert_record('customfeedback_q', (object) [
                'customfeedbackid' => $cfid, 'type' => 'text', 'name' => 'Comment', 'intro' => '',
                'introformat' => 1, 'required' => 0, 'sortorder' => 2,
                'timecreated' => $now, 'timemodified' => $now,
            ]);
        }
        foreach ($stars as $val) {
            $rid = $DB->insert_record('customfeedback_r', (object) [
                'customfeedbackid' => $cfid, 'userid' => 7, 'timecreated' => $now,
            ]);
            $DB->insert_record('customfeedback_a', (object) [
                'responseid' => $rid, 'questionid' => $qid, 'valuestar' => $val, 'valuetext' => null,
            ]);
            if ($withtext) {
                $DB->insert_record('customfeedback_a', (object) [
                    'responseid' => $rid, 'questionid' => $textqid, 'valuestar' => null,
                    'valuetext' => 'a comment',
                ]);
            }
        }
        return $cfid;
    }

    public function test_course_view_aggregates_star_ratings(): void {
        global $DB;
        $this->resetAfterTest();
        $c = $this->getDataGenerator()->create_course(['fullname' => 'Alpha']);
        // Ratings 1,2,3,4,5 -> avg 3.0; two of five are <=2 -> pct_low 40.0.
        $this->seed_feedback($c->id, [1, 2, 3, 4, 5], true);
        $this->resetDebugging();

        $row = $DB->get_record('ai_course_feedback', ['courseid' => $c->id], '*', MUST_EXIST);
        $this->assertSame('Alpha', $row->coursename);
        $this->assertSame(1, (int) $row->activity_count);
        $this->assertSame(5, (int) $row->submission_count);
        $this->assertSame(5, (int) $row->rating_count); // text answers ignored
        $this->assertEquals(3.0, (float) $row->avg_rating);
        $this->assertEquals(50.0, (float) $row->avg_rating_pct); // (3-1)/4*100
        $this->assertEquals(40.0, (float) $row->pct_low);
        // Aggregate-only: userid must not be a column on the view.
        $this->assertObjectNotHasProperty('userid', $row);
    }

    public function test_course_view_rolls_up_multiple_activities(): void {
        global $DB;
        $this->resetAfterTest();
        $c = $this->getDataGenerator()->create_course();
        $this->seed_feedback($c->id, [2, 2]); // avg 2
        $this->seed_feedback($c->id, [4, 4]); // avg 4
        $this->resetDebugging();

        $row = $DB->get_record('ai_course_feedback', ['courseid' => $c->id], '*', MUST_EXIST);
        $this->assertSame(2, (int) $row->activity_count);
        $this->assertSame(4, (int) $row->rating_count);
        // Mean of individual ratings (2,2,4,4) = 3.0, NOT mean-of-activity-means.
        $this->assertEquals(3.0, (float) $row->avg_rating);
    }

    public function test_activity_view_is_per_activity(): void {
        global $DB;
        $this->resetAfterTest();
        $c = $this->getDataGenerator()->create_course();
        $cf1 = $this->seed_feedback($c->id, [1, 1]); // avg 1
        $cf2 = $this->seed_feedback($c->id, [5, 5]); // avg 5
        $this->resetDebugging();

        $a1 = $DB->get_record('ai_feedback_activity', ['activityid' => $cf1], '*', MUST_EXIST);
        $a2 = $DB->get_record('ai_feedback_activity', ['activityid' => $cf2], '*', MUST_EXIST);
        $this->assertEquals(1.0, (float) $a1->avg_rating);
        $this->assertEquals(5.0, (float) $a2->avg_rating);
        $this->assertSame(1, (int) $a1->star_question_count);
    }

    public function test_site_course_is_excluded(): void {
        global $DB;
        $this->resetAfterTest();
        $this->seed_feedback(1, [5]); // site course id=1
        $this->resetDebugging();
        $this->assertFalse($DB->record_exists('ai_course_feedback', ['courseid' => 1]));
    }
}
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/feedback_views_test.php`
Expected: FATAL/ERROR — class `course_feedback_view` not found.

- [ ] **Step 3: Create `classes/db/course_feedback_view.php`**

```php
<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_course_feedback` view: one row per course
 * (course > 1) with at least one custom-feedback star rating, aggregating
 * mdl_customfeedback* directly. Exposes avg_rating (1-5), avg_rating_pct,
 * pct_low and counts — no respondent identity, so no PII. Created by
 * install/upgrade; skipped under PHPUNIT (tests create/drop it per-class).
 */
class course_feedback_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_course_feedback';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_course_feedback AS
SELECT cf.course AS courseid,
       c.fullname AS coursename,
       COUNT(DISTINCT cf.id) AS activity_count,
       COUNT(DISTINCT r.id) AS submission_count,
       COUNT(a.valuestar) AS rating_count,
       ROUND(AVG(a.valuestar), 2) AS avg_rating,
       ROUND(100 * (AVG(a.valuestar) - 1) / 4, 1) AS avg_rating_pct,
       ROUND(100 * SUM(CASE WHEN a.valuestar <= 2 THEN 1 ELSE 0 END) / COUNT(a.valuestar), 1) AS pct_low
FROM {$p}customfeedback cf
JOIN {$p}customfeedback_r r ON r.customfeedbackid = cf.id
JOIN {$p}customfeedback_a a ON a.responseid = r.id AND a.valuestar IS NOT NULL
JOIN {$p}customfeedback_q q ON q.id = a.questionid AND q.type = 'star'
JOIN {$p}course c ON c.id = cf.course
WHERE cf.course > 1
GROUP BY cf.course, c.fullname";
    }

    /** Create (or replace) the view. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
```

- [ ] **Step 4: Create `classes/db/feedback_activity_view.php`**

```php
<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_feedback_activity` view: one row per
 * custom-feedback activity (in a course > 1) with at least one star rating.
 * Same aggregation as ai_course_feedback but grouped per activity, for
 * "which survey got the worst ratings" questions (AI fallback in v1). No PII.
 * Created by install/upgrade; skipped under PHPUNIT (tests manage it).
 */
class feedback_activity_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_feedback_activity';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_feedback_activity AS
SELECT cf.id AS activityid,
       cf.name AS activityname,
       cf.course AS courseid,
       c.fullname AS coursename,
       COUNT(DISTINCT q.id) AS star_question_count,
       COUNT(DISTINCT r.id) AS submission_count,
       COUNT(a.valuestar) AS rating_count,
       ROUND(AVG(a.valuestar), 2) AS avg_rating,
       ROUND(100 * (AVG(a.valuestar) - 1) / 4, 1) AS avg_rating_pct,
       ROUND(100 * SUM(CASE WHEN a.valuestar <= 2 THEN 1 ELSE 0 END) / COUNT(a.valuestar), 1) AS pct_low
FROM {$p}customfeedback cf
JOIN {$p}customfeedback_r r ON r.customfeedbackid = cf.id
JOIN {$p}customfeedback_a a ON a.responseid = r.id AND a.valuestar IS NOT NULL
JOIN {$p}customfeedback_q q ON q.id = a.questionid AND q.type = 'star'
JOIN {$p}course c ON c.id = cf.course
WHERE cf.course > 1
GROUP BY cf.id, cf.name, cf.course, c.fullname";
    }

    /** Create (or replace) the view. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
```

- [ ] **Step 5: Run the test to verify it passes**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/feedback_views_test.php`
Expected: PASS (4 tests).

> If `customfeedback*` tables are missing in the test DB, run the init command in the header first, then re-run. (They exist on this instance — `phpu_customfeedback*` confirmed.)

- [ ] **Step 6: Commit**

```bash
git add local/ai_analysis/classes/db/course_feedback_view.php local/ai_analysis/classes/db/feedback_activity_view.php local/ai_analysis/tests/feedback_views_test.php
git commit -m "feat(ai_analysis): custom-feedback rating views (course + activity)"
```

---

## Task 2: Install / upgrade / grants / version wiring

**Files:**
- Modify: `db/install.php`
- Modify: `db/upgrade.php:19-23`
- Modify: `db/readonly_grants.sql`
- Modify: `version.php`

- [ ] **Step 1: Add the views to `db/install.php`**

In `xmldb_local_ai_analysis_install()`, inside the existing `if (!defined('PHPUNIT_TEST') || !PHPUNIT_TEST)` block, after the `course_performance_view::create($DB);` line add:

```php
        \local_ai_analysis\db\course_feedback_view::create($DB);
        \local_ai_analysis\db\feedback_activity_view::create($DB);
```

- [ ] **Step 2: Add the upgrade step to `db/upgrade.php`**

After the `if ($oldversion < 2026061203) { … }` block (before `return true;`) add:

```php
    if ($oldversion < 2026061301) {
        // Sub-project B3: create the read-only custom-feedback rating views.
        \local_ai_analysis\db\course_feedback_view::create($DB);
        \local_ai_analysis\db\feedback_activity_view::create($DB);
        upgrade_plugin_savepoint(true, 2026061301, 'local', 'ai_analysis');
    }
```

- [ ] **Step 3: Add the grants to `db/readonly_grants.sql`**

After the `mdl_ai_course_performance` grant line add:

```sql
GRANT SELECT ON moodle.mdl_ai_course_feedback   TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_ai_feedback_activity TO 'moodle_ai_ro'@'%';
```

- [ ] **Step 4: Bump `version.php`**

```php
$plugin->version   = 2026061301;
$plugin->release   = '0.12.0';
```

- [ ] **Step 5: Re-init the PHPUnit DB so the new version installs cleanly**

Run: `docker exec moodle-web-8092 php /var/www/html/admin/tool/phpunit/cli/init.php`
Expected: completes without error.

- [ ] **Step 6: Commit**

```bash
git add local/ai_analysis/db/install.php local/ai_analysis/db/upgrade.php local/ai_analysis/db/readonly_grants.sql local/ai_analysis/version.php
git commit -m "feat(ai_analysis): install/upgrade/grants for B3 feedback views; bump 0.12.0"
```

---

## Task 3: Manifest entries + scope notes

**Files:**
- Modify: `classes/manifest/manifest_builder.php:33` and `:80`
- Test: `tests/manifest_builder_test.php`

- [ ] **Step 1: Write the failing test**

Append to `tests/manifest_builder_test.php` (inside the test class):

```php
    public function test_feedback_views_are_allowlisted(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_course_feedback', $manifest);
        $this->assertArrayHasKey('mdl_ai_feedback_activity', $manifest);
        $this->assertContains('avg_rating', $manifest['mdl_ai_course_feedback']);
        $this->assertContains('pct_low', $manifest['mdl_ai_course_feedback']);
        $this->assertContains('activityid', $manifest['mdl_ai_feedback_activity']);
    }

    public function test_feedback_views_get_scope_note_for_scoped_role(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 23);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_course_feedback']);
        $this->assertStringContainsString('23', $manifest['mdl_ai_course_feedback']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_feedback_activity']);
    }
```

- [ ] **Step 2: Run to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: FAIL — `mdl_ai_course_feedback` key absent.

- [ ] **Step 3: Add the allow-list entries**

In `classes/manifest/manifest_builder.php`, after the `'mdl_ai_course_performance' => [...]` line (line 33) add:

```php
        'mdl_ai_course_feedback'    => ['courseid', 'coursename', 'activity_count', 'submission_count', 'rating_count', 'avg_rating', 'avg_rating_pct', 'pct_low'],
        'mdl_ai_feedback_activity'  => ['activityid', 'activityname', 'courseid', 'coursename', 'star_question_count', 'submission_count', 'rating_count', 'avg_rating', 'avg_rating_pct', 'pct_low'],
```

- [ ] **Step 4: Add the scope notes**

After the `$manifest['mdl_ai_course_performance']['_scope_note'] = …;` statement (line 80) add:

```php
            $manifest['mdl_ai_course_feedback']['_scope_note'] =
                'Course-level student-feedback rating summary (avg_rating 1-5, pct_low = % ratings <=2); always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_ai_feedback_activity']['_scope_note'] =
                'Per-feedback-activity rating summary (avg_rating 1-5); always filter WHERE courseid = ' . $courseid;
```

- [ ] **Step 5: Run to verify it passes**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/manifest_builder_test.php`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add local/ai_analysis/classes/manifest/manifest_builder.php local/ai_analysis/tests/manifest_builder_test.php
git commit -m "feat(ai_analysis): manifest entries + scope notes for B3 feedback views"
```

---

## Task 4: Intent — synonyms, registry, template (with chart hint)

**Files:**
- Modify: `classes/intent/synonym_dictionary.php:69` (end of MAP)
- Modify: `classes/intent/intent_registry.php`
- Modify: `classes/intent/sql_template.php`
- Test: `tests/intent_classifier_test.php`, `tests/sql_template_test.php`

- [ ] **Step 1: Write the failing classifier tests**

Append to `tests/intent_classifier_test.php` (inside the class):

```php
    public function test_poor_feedback_matches_course_feedback(): void {
        $this->assertSame('course_feedback',
            \local_ai_analysis\intent\intent_classifier::classify('which courses have poor feedback'));
    }

    public function test_course_feedback_rating_matches_course_feedback(): void {
        $this->assertSame('course_feedback',
            \local_ai_analysis\intent\intent_classifier::classify('show feedback rating for this course'));
    }

    public function test_list_students_not_shadowed_by_feedback(): void {
        $this->assertSame('student_listing',
            \local_ai_analysis\intent\intent_classifier::classify('list students'));
    }

    public function test_student_feedback_prefers_course_feedback(): void {
        // "feedback" is a disqualifier for student_listing, so this routes to feedback.
        $this->assertSame('course_feedback',
            \local_ai_analysis\intent\intent_classifier::classify('list student feedback'));
    }
```

- [ ] **Step 2: Run to verify it fails**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: FAIL — classify returns null / `student_listing` for feedback prompts.

- [ ] **Step 3: Add the synonym family**

In `classes/intent/synonym_dictionary.php`, before the closing `];` of `MAP` (after the course-performance family at line 69) add:

```php
        // feedback / ratings family
        'feedback'     => 'feedback',
        'feedbacks'    => 'feedback',
        'rating'       => 'feedback',
        'ratings'      => 'feedback',
        'rated'        => 'feedback',
        'star'         => 'feedback',
        'stars'        => 'feedback',
        'satisfaction' => 'feedback',
        'survey'       => 'feedback',
        'surveys'      => 'feedback',
        'review'       => 'feedback',
        'reviews'      => 'feedback',
```

- [ ] **Step 4: Add the registry entry and disqualifiers**

In `classes/intent/intent_registry.php`:

(a) Add `'feedback'` to the `none_of` array of the `student_listing` entry and the `course_staff` entry (so feedback questions don't route to a listing). For `student_listing` the `none_of` already lists submission qualifiers; append `'feedback'`. Do the same for `course_staff`.

(b) After the `course_performance` entry (before the closing `];`) add:

```php
            [
                'id'       => 'course_feedback',
                'requires' => ['feedback'],
                'any_of'   => [],
                'none_of'  => ['students', 'staff', 'risk', 'performance'],
            ],
```

- [ ] **Step 5: Run classifier tests to verify they pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php`
Expected: PASS (including pre-existing tests).

- [ ] **Step 6: Write the failing template tests**

Append to `tests/sql_template_test.php` (inside the class):

```php
    public function test_course_feedback_scoped_binds_courseid_and_no_chart(): void {
        [$sql, $params, $chart] = \local_ai_analysis\intent\sql_template::build('course_feedback', 23);
        $this->assertStringContainsStringIgnoringCase('from mdl_ai_course_feedback', $sql);
        $this->assertStringContainsStringIgnoringCase('where f.courseid = ?', $sql);
        $this->assertSame([23], $params);
        $this->assertNull($chart); // single course -> answer, not chart
    }

    public function test_course_feedback_global_ranks_with_bar_chart(): void {
        [$sql, $params, $chart] = \local_ai_analysis\intent\sql_template::build('course_feedback', 0);
        $this->assertStringContainsStringIgnoringCase('order by f.avg_rating asc', $sql);
        $this->assertStringNotContainsStringIgnoringCase('where', $sql);
        $this->assertSame([], $params);
        $this->assertSame(['type' => 'bar', 'x' => 'coursename', 'y' => 'avg_rating'], $chart);
    }

    public function test_course_feedback_both_shapes_pass_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$scoped, $sp] = \local_ai_analysis\intent\sql_template::build('course_feedback', 23);
        [$global, $gp] = \local_ai_analysis\intent\sql_template::build('course_feedback', 0);
        $this->assertTrue($validator->validate($scoped, $sp));
        $this->assertTrue($validator->validate($global, $gp));
    }
```

- [ ] **Step 7: Run to verify they fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php`
Expected: FAIL — `build('course_feedback', …)` throws unknown-intent / returns 2-tuple.

- [ ] **Step 8: Update `sql_template.php`**

(a) Add the column const after `COURSE_PERFORMANCE_COLS`:

```php
    /** Output columns for the course-feedback template (both shapes). */
    private const COURSE_FEEDBACK_COLS =
        'f.courseid, f.coursename, f.activity_count, f.submission_count, '
        . 'f.rating_count, f.avg_rating, f.avg_rating_pct, f.pct_low';
```

(b) Update the docblock of `build()` to `@return array{0:string,1:array,2:?array}` and make EVERY case return a 3-element array (third = chart hint or null). Replace the whole `switch` body with:

```php
        switch ($intentid) {
            case 'student_listing':
                return [self::STUDENT_LISTING_SQL, [$courseid], null];
            case 'course_staff':
                return [self::COURSE_STAFF_SQL, [$courseid], null];
            case 'at_risk_students':
                return [self::AT_RISK_SQL, [$courseid], null];
            case 'course_performance':
                if ($courseid > 0) {
                    return ['SELECT ' . self::COURSE_PERFORMANCE_COLS
                        . ' FROM mdl_ai_course_performance p WHERE p.courseid = ? LIMIT 1000', [$courseid], null];
                }
                return ['SELECT ' . self::COURSE_PERFORMANCE_COLS
                    . ' FROM mdl_ai_course_performance p ORDER BY p.at_risk_pct DESC LIMIT 1000', [],
                    ['type' => 'bar', 'x' => 'coursename', 'y' => 'at_risk_pct']];
            case 'course_feedback':
                if ($courseid > 0) {
                    return ['SELECT ' . self::COURSE_FEEDBACK_COLS
                        . ' FROM mdl_ai_course_feedback f WHERE f.courseid = ? LIMIT 1000', [$courseid], null];
                }
                return ['SELECT ' . self::COURSE_FEEDBACK_COLS
                    . ' FROM mdl_ai_course_feedback f ORDER BY f.avg_rating ASC LIMIT 1000', [],
                    ['type' => 'bar', 'x' => 'coursename', 'y' => 'avg_rating']];
            default:
                throw new \coding_exception('Unknown intent template: ' . $intentid);
        }
```

> Existing callers using `[$sql, $params] = build(...)` keep working — PHP list-destructuring ignores the extra element.

- [ ] **Step 9: Run template + classifier + sql_template tests**

Run:
```bash
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/sql_template_test.php
docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/intent_classifier_test.php
```
Expected: PASS both.

- [ ] **Step 10: Commit**

```bash
git add local/ai_analysis/classes/intent/ local/ai_analysis/tests/intent_classifier_test.php local/ai_analysis/tests/sql_template_test.php
git commit -m "feat(ai_analysis): course_feedback intent + template with bar-chart hint"
```

---

## Task 5: Gateway fast-path chart hint

**Files:**
- Modify: `classes/external/query.php` (fast-path block ~159-165, chart line ~255)
- Test: `tests/external_query_test.php`

- [ ] **Step 1: Write the failing end-to-end tests**

First extend the existing `setUp()`/`tearDown()` in `tests/external_query_test.php` to manage the feedback views. In `setUp()`, after `course_performance_view::create($DB);` add:

```php
        \local_ai_analysis\db\course_feedback_view::create($DB);
        \local_ai_analysis\db\feedback_activity_view::create($DB);
```

In `tearDown()`, before the `course_performance_view` drop, add:

```php
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . \local_ai_analysis\db\feedback_activity_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . \local_ai_analysis\db\course_feedback_view::VIEW);
```

Then append these tests inside the class:

```php
    /** Seed a star-rating custom-feedback activity in a course. */
    private function seed_feedback(int $courseid, array $stars): void {
        global $DB;
        $now = time();
        $cfid = $DB->insert_record('customfeedback', (object) [
            'course' => $courseid, 'name' => 'Survey', 'intro' => '', 'introformat' => 1,
            'allowmulti' => 0, 'timecreated' => $now, 'timemodified' => $now,
        ]);
        $qid = $DB->insert_record('customfeedback_q', (object) [
            'customfeedbackid' => $cfid, 'type' => 'star', 'name' => 'Rate', 'intro' => '',
            'introformat' => 1, 'required' => 1, 'sortorder' => 1,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        foreach ($stars as $val) {
            $rid = $DB->insert_record('customfeedback_r', (object) [
                'customfeedbackid' => $cfid, 'userid' => 7, 'timecreated' => $now,
            ]);
            $DB->insert_record('customfeedback_a', (object) [
                'responseid' => $rid, 'questionid' => $qid, 'valuestar' => $val, 'valuetext' => null,
            ]);
        }
    }

    public function test_course_feedback_scoped_fast_path_no_chart(): void {
        $this->seed_feedback($this->course->id, [2, 4]);
        $resp = $this->call('feedback rating for this course');
        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertSame('', $resp['chart']);       // single-course shape -> answer, no chart
        $this->assertSame(0, $this->stub->call_count); // no LLM call
    }

    public function test_course_feedback_global_fast_path_returns_bar_chart(): void {
        $this->setAdminUser(); // admin satisfies queryglobal and bypasses scope notes
        $this->resetDebugging();
        $this->seed_feedback($this->course->id, [1, 2]);
        $resp = $this->call('which courses have the poorest feedback', 0);
        $this->assertSame('SUCCESS', $resp['status']);
        $this->assertSame(0, $this->stub->call_count);
        $this->assertSame(
            ['type' => 'bar', 'x' => 'coursename', 'y' => 'avg_rating'],
            json_decode($resp['chart'], true)
        );
    }
```

- [ ] **Step 2: Run to verify they fail**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: FAIL — global test's `chart` is `''` because the template hint is not yet threaded through.

- [ ] **Step 3: Thread the chart hint through the gateway**

In `classes/external/query.php`:

(a) Where the fast-path locals are initialised (the `$sql = ''; $bound_params = [];` lines, ~157-158), add:

```php
        $template_chart = null;
```

(b) Change the intent destructuring line (~163) from:

```php
            [$sql, $bound_params] = sql_template::build($intent, $courseid);
```
to:
```php
            [$sql, $bound_params, $template_chart] = sql_template::build($intent, $courseid);
```

(c) Change the chart-spec line (~255) from:

```php
        $chart_spec = self::validate_chart(($ai !== null ? ($ai['chart'] ?? null) : null), array_keys($source_map));
```
to:
```php
        $chart_spec = self::validate_chart(($ai !== null ? ($ai['chart'] ?? null) : $template_chart), array_keys($source_map));
```

- [ ] **Step 4: Run to verify they pass**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/external_query_test.php`
Expected: PASS (existing + 2 new). The scoped test confirms no chart; the global test confirms the validated bar chart.

- [ ] **Step 5: Commit**

```bash
git add local/ai_analysis/classes/external/query.php local/ai_analysis/tests/external_query_test.php
git commit -m "feat(ai_analysis): thread template chart hint into fast-path chart spec"
```

---

## Task 6: Full-suite verification + docs

**Files:**
- Modify: `docs/ai-memory/02-features-log.md`, `docs/ai-memory/03-decisions.md`, `docs/ai-memory/04-current-state.md`

- [ ] **Step 1: Run the whole plugin test suite**

Run: `docker exec moodle-web-8092 vendor/bin/phpunit --testsuite local_ai_analysis_testsuite`
Expected: all tests pass (240 prior + the new ones). Report only failures.

- [ ] **Step 2: Update `docs/ai-memory/02-features-log.md`**

Append a "Sub-project B3 — Feedback Analytics" entry: the two views (`mdl_ai_course_feedback`, `mdl_ai_feedback_activity`), grain + columns, source = custom `mod_customfeedback` star ratings only, the `course_feedback` intent (scope-aware, global gated by `queryglobal`), the generic template chart-hint mechanism (3-tuple `sql_template::build()` → `validate_chart()`), new files/APIs, +2 RO grants, version `2026061301`/`0.12.0`, and the deferred non-goals (free-text sentiment, core mod_feedback, activity-level fast-path template, materialised table).

- [ ] **Step 3: Update `docs/ai-memory/03-decisions.md`**

Record the major decisions: (1) custom plugin star ratings only (not core mod_feedback / empty plugins); (2) two views computed direct from base tables, not view-on-view, to keep course avg a true mean-of-ratings; (3) aggregate-only projection (userid never exposed) → no pii_scrubber change; (4) generic template chart-hint so fast-path rankings render a bar chart while single-row results stay plain answers (shape-driven viz); (5) `feedback` added as a disqualifier to `student_listing`/`course_staff`.

- [ ] **Step 4: Update `docs/ai-memory/04-current-state.md`**

Bump the header (version `2026061301` / `0.12.0`, new test count). Add the two views to the manifest section (now 14 tables + 5 views). Add a "B3 done" bullet. Add an action item: **the user must apply the +2 view grants from `db/readonly_grants.sql` as root on the live DB** (the views are created by the Moodle upgrade, but the RO user needs the SELECT grants).

- [ ] **Step 5: Commit**

```bash
git add local/ai_analysis/docs/ai-memory/
git commit -m "docs(ai_analysis): record sub-project B3 (feedback analytics)"
```

---

## Self-Review notes

- **Spec coverage:** two views (Task 1) ✓; install/upgrade/grants/version (Task 2) ✓; manifest + scope notes (Task 3) ✓; intent synonyms/registry/template + global gating via existing `queryglobal` path (Task 4) ✓; template chart-hint + shape-driven viz (Tasks 4–5) ✓; activity view manifest-only/AI-fallback (no template) ✓; tests at every layer (Tasks 1,3,4,5) ✓; docs (Task 6) ✓; deferred non-goals recorded (Task 6) ✓.
- **No PII:** views project no `userid`; Task 1 asserts `userid` absent. No `pii_scrubber` change needed — matches spec.
- **Type consistency:** `sql_template::build()` returns a uniform 3-tuple `[string, array, ?array]` across all cases; gateway reads all three; view classes expose `VIEW` const + `definition_sql(string)` + `create(\moodle_database)` exactly like `course_performance_view`.
- **Global ranking auth:** `courseid=0` enforcement of `queryglobal` is the existing gateway behaviour (same path as `course_performance`); no new capability code. The admin user in the Task 5 global test satisfies it.
