# Design — Sub-project 3a: PII scrubber + format_result for `local_ai_analysis`

**Date:** 2026-05-30
**Plugin path:** `local/ai_analysis/`
**Plugin component:** `local_ai_analysis`
**Moodle target:** 4.5 · PHP 8.1+ · MariaDB 10.11
**Status:** Approved, ready for implementation planning

## Parent project

Third of five sub-projects, first half of Sprint 3:

1. Security foundation ✅ merged
2. Pipeline + Claude provider ✅ merged
3. **Additional providers + PII scrubber + AI formatting pass** — this spec covers the **PII scrubber + `format_result`** half. Additional providers (OpenAI/Gemini/Ollama) are deferred to a separate spec (3b).
4. Frontend widget (Mustache + AMD + Chart.js)
5. Admin & management (audit viewer, decrypt UI, settings polish, Privacy API, retention task)

Sub-project 2 implemented pipeline layers 2–6 and 8, deferring **layer 7 (AI formatting pass)** to here. The Sprint 2 spec lives at `docs/superpowers/specs/2026-05-25-ai-analysis-pipeline-claude-design.md`.

## Why this slice now

Sub-project 2 returns raw result rows — perfect for testing and for the eventual frontend to render directly, but two things are missing before those rows can be turned into a natural-language answer by an AI:

1. **A formatting pass** (layer 7) that turns rows into a plain-language answer for the educator.
2. **A PII safety gate** so that real student data (names, emails, IDs) never crosses the wire to the external AI provider during that formatting pass.

These two are coupled: the scrubber must run **before** the formatting AI call. They ship together. Additional AI providers are independent of both and are deferred.

## Scope

**In scope**
- `pii_scrubber` — column-classified, reversible-token tokenisation of result rows + de-tokenisation of the AI answer.
- A curated `table.column → PII type` classification map.
- A column-source map surfaced from `sql_validator` so tokenisation is alias-safe.
- `format_result()` added to `ai_client_interface` and implemented in `claude_client`.
- `prompt_builder::build_format_system()` — the AI #2 system prompt.
- Gateway integration: a per-request `format` flag, two new envelope fields, graceful fallback.
- Tests for every component plus end-to-end formatting flow with a stubbed AI.

**Out of scope**
- Additional AI providers (Sub-project 3b).
- Frontend chat widget / Chart.js (Sub-project 4).
- Audit viewer, decrypt UI, retention task, Privacy API (Sub-project 5).
- Persisting or auditing the token map or the formatted answer (explicitly never persisted).

## Architecture — where the new layers sit

The new work slots in **after L6 (query execution), before the response envelope is built**, and runs **only when the request sets `format=true`**.

```
L6   query_executor::run()  → $rows           (real PII values)
        │
        ├─ format=false ───────────────────► envelope with raw rows   (Sprint-2 behaviour, unchanged)
        │
        └─ format=true:
             L6.5  pii_scrubber::tokenize($rows, $column_map)
                       → $safe_rows (PERSON_1, EMAIL_1…)  + in-memory token map
             L7     ai_client::format_result($prompt, $safe_rows)
                       → $tokenised_answer   (NL text referencing tokens)
             L7.5  pii_scrubber::detokenize($tokenised_answer)
                       → $answer             (real values restored)
             return envelope with raw rows + $answer
```

### Invariants

- **Raw rows in the envelope are always the real values** — the teacher is authorised to see their students' data. Tokenisation only protects data in transit to the external AI.
- **The token map is request-scoped, in-memory, and never persisted or logged.** It lives as instance state on the `pii_scrubber` for the duration of one `execute()` call.
- **The audit row shape is unchanged** (Sprint 1 contract). Status stays `SUCCESS` even when formatting falls back. The formatted answer is not audited.
- **The external AI provider is the only party that ever sees tokens** instead of real data.

## Data flow of a formatted query

1. Teacher asks a question; `format=true`.
2. AI #1 (`generate_sql`) → SQL (unchanged from Sprint 2).
3. SQL validated + executed → raw rows with real PII.
4. `pii_scrubber::tokenize` maps `Alice Smith → PERSON_1`, `a@x.edu → EMAIL_1`; builds the request-scoped `token → real value` map.
5. `format_result` sends the original prompt + tokenised rows to AI #2; AI answers referencing only tokens ("PERSON_1 has the highest grade").
6. `pii_scrubber::detokenize` restores real values → "Alice Smith has the highest grade".
7. Envelope returns real rows + the de-tokenised `answer`.

## Component contracts

### `external\query` gateway changes

`execute_parameters` gains:
- `format` — `PARAM_BOOL`, `VALUE_DEFAULT 0`.

`execute_returns` gains:
- `answer` — `PARAM_RAW`, `VALUE_DEFAULT ''` — the de-tokenised NL answer; empty when `format=false` or on fallback.
- `format_note` — `PARAM_TEXT`, `VALUE_DEFAULT ''` — soft note set on graceful fallback.

`execute()` after the existing L6 success block:
- If `!$format`: return the Sprint-2 envelope (with `answer=''`, `format_note=''`).
- If `$format`: build the column-source map (from the validator, see below), tokenise, call `format_result`, de-tokenise, attach `answer`. On any `ai_client_exception`/`transport_exception` from AI #2: set `answer=''`, `format_note=get_string('formatunavailable', …)`, keep `status=SUCCESS`, and `debugging()` the cause. The audit row is still the `SUCCESS` row already written for the query.

No new status codes. The Sprint-2 status enum is unchanged.

### `security\pii_scrubber`

`classes/security/pii_scrubber.php`. One instance per request; holds the token map as instance state.

**Curated PII map** — class constant keyed by `table.column → token prefix`:

```
mdl_user.firstname     → PERSON
mdl_user.lastname      → PERSON
mdl_user.firstnamephonetic → PERSON
mdl_user.lastnamephonetic  → PERSON
mdl_user.middlename    → PERSON
mdl_user.alternatename → PERSON
mdl_user.email         → EMAIL
mdl_user.username      → USERNAME
mdl_user.idnumber      → ID
mdl_user.phone1        → PHONE
mdl_user.phone2        → PHONE
mdl_user.address       → ADDRESS
mdl_user.city          → LOCATION
mdl_user.country       → LOCATION
mdl_user.institution   → ORG
mdl_user.department    → ORG
mdl_user.lastip        → IP
```

The map is reviewed in code and extended as the manifest grows (the manifest today is `mdl_user`, `mdl_grade_grades`, `mdl_course_modules`, `mdl_logstore_standard_log`; only `mdl_user` carries PII columns among the currently-allowed set, but the map is keyed by `table.column` to stay correct as tables are added).

**API:**
```php
/**
 * @param array $rows       Result rows (each an array/object keyed by output column).
 * @param array $column_map output column name => classification, where classification is one of:
 *                            - "table.column"  source column (looked up in the curated PII map)
 *                            - null            derived/no single source, treat as non-PII
 *                            - "__REDACT__"    derived expression that references a PII column; mask wholesale
 * @return array            Rows with PII values replaced by tokens.
 */
public function tokenize(array $rows, array $column_map): array;

/**
 * Replace every token in $text with its original value. Longest token first.
 * @return string
 */
public function detokenize(string $text): string;
```

**Token scheme:** `PREFIX_N` (e.g. `PERSON_1`, `EMAIL_3`). Stable per distinct real value within a request — the same real value always maps to the same token, and the same token always restores to the same value. Counter is per-prefix.

**De-tokenisation ordering:** replace longest token strings first so `PERSON_1` does not partially clobber `PERSON_11`.

**Column classification rule:** for each output column, act on its `$column_map` classification:
  - `"table.column"` present in the curated map → tokenise that column's values with the mapped prefix.
  - `"table.column"` absent from the curated map → pass through (non-PII).
  - `null` (derived/function expression with no PII references) → pass through.
  - `"__REDACT__"` (derived expression referencing a PII column) → mask the whole output value with prefix `REDACTED`. This prevents `CONCAT(firstname, lastname)` from leaking while letting pure aggregates (`COUNT`, `AVG`, `SUM`) pass through untouched.

The gateway composes this single `$column_map` from the validator's two accessors (below): each output column's source, with derived columns flagged `"__REDACT__"` where `get_derived_pii_columns()` reports a PII reference.

### `security\sql_validator` change (column-source map)

`sql_validator` already resolves every column reference to its table during `validate()`. This sub-project surfaces that resolution as a byproduct so the scrubber is alias-safe.

- New public accessor after `validate()`: `get_column_source_map(): array` returning `output column name => "table.column" | null`.
  - Plain column `firstname` → `mdl_user.firstname`.
  - Aliased column `firstname AS fn` → key `fn`, value `mdl_user.firstname`.
  - Derived/function output (`COUNT(id)`, `CONCAT(firstname, lastname) AS full`) → value `null`, plus a companion set of PII columns referenced by that expression so the gateway/scrubber can apply the derived-column rule. Represented as: derived entries map to `null`; a second accessor `get_derived_pii_columns(): array` returns `output column name => bool` (true if the expression references any PII column). 
- Existing validation behaviour is unchanged; these are additive read-only accessors populated during the existing AST walk.

### `ai\ai_client_interface` change

Add the second method Sub-project 2's docblock anticipated:

```php
/**
 * Summarise already-PII-scrubbed result rows into a plain-language answer.
 *
 * @param string $user_prompt  The educator's original question (for intent).
 * @param array  $safe_rows    Tokenised rows — no real PII.
 * @return string              Plain-text answer that may contain tokens verbatim.
 * @throws \local_ai_analysis\exception\ai_client_exception
 */
public function format_result(string $user_prompt, array $safe_rows): string;
```

`claude_client` implements it; `ai_client_factory` and the test stub need no structural change beyond implementing the new method.

### `ai\claude_client::format_result`

- Reuses the injected `http_transport_interface` and API key — no new transport.
- System prompt from `prompt_builder::build_format_system()`.
- User-role content: JSON of `{question, rows}` where `rows` are the tokenised rows.
- `max_tokens` ≈ 1024 (prose, larger than the SQL call's 800).
- Parses the Anthropic envelope, returns `content[0].text` as plain text (strips optional code fences, same as `generate_sql`). Non-2xx or unparseable → `ai_client_exception`.

### `ai\prompt_builder::build_format_system`

Returns a static system prompt instructing the AI to:
- Act as an assistant that summarises query results for an educator in plain language.
- Answer **only** from the rows provided; never invent data.
- Treat values like `PERSON_1`, `EMAIL_3` as opaque tokens and **echo them verbatim** — never expand, rename, or describe them ("the first student"), because de-tokenisation is a literal string swap and any rewrite leaves a raw token visible to the user.
- Not emit markdown tables (the frontend renders rows itself); prose only.
- State plainly when the result set is empty.

## Error handling

| Situation | Behaviour |
|---|---|
| `format=false` | L6.5/L7/L7.5 skipped; envelope identical to Sprint 2 (`answer=''`, `format_note=''`). |
| AI #2 throws (`ai_client_exception` / `transport_exception`) | Caught in gateway. Real rows returned; `answer=''`; `format_note` set; `status=SUCCESS`; cause sent to `debugging()`. |
| Scrubber finds no PII columns | Normal path; tokenise is a no-op; formatting proceeds. |
| Query fails before L6 (blocked / rate-limited / SQL invalid / query failed) | Never reaches formatting; existing statuses and audit behaviour unchanged. |

No new status codes; the Sprint-1 audit schema and Sprint-2 status enum are untouched. Formatting is a best-effort enrichment on top of an already-successful query.

## Testing strategy

**`tests/pii_scrubber_test.php`** (security-critical — broadest coverage):
- Every curated PII column is tokenised.
- Aliased PII column (`firstname AS fn`) is still tokenised (alias-safe via column-source map).
- Derived column referencing PII (`CONCAT(firstname, lastname)`) is masked.
- Pure aggregate (`COUNT(id)`, `AVG(finalgrade)`) passes through untouched.
- Stable tokens: same real value → same token across rows.
- Round-trip: `detokenize(tokenize(rows))`-style answer restores originals exactly.
- Longest-token-first ordering (`PERSON_11` vs `PERSON_1`).
- Empty rows; rows with no PII columns.

**`tests/claude_client_test.php`** (extend):
- `format_result` targets the messages endpoint with the format system prompt.
- Returns plain text; code-fence stripping works.
- Token-bearing rows survive into the request body unchanged.
- AI #2 non-2xx / unparseable → `ai_client_exception`.

**`tests/external_query_test.php`** (extend):
- `format=true` happy path returns a de-tokenised `answer` with real values.
- `format=false` envelope matches Sprint 2 exactly (regression guard).
- AI #2 failure → `status=SUCCESS`, real rows, non-empty `format_note`, empty `answer`.
- **PII-leak guard:** assert the stubbed AI #2 received only tokenised rows — no real PII string appears in what was passed to `format_result`.

**`tests/sql_validator_test.php`** (extend):
- `get_column_source_map()` correct for plain columns, aliases, and derived expressions.
- `get_derived_pii_columns()` flags expressions that reference PII columns.

## Configuration

No new `config.php` entries. No new plugin settings in this sub-project (the `format` toggle is per-request, chosen by the caller/frontend). `version.php` bumps on completion to register no new DB objects — but a version bump is still made to reflect the code change.

## Files

New files in **bold**; existing modified files in plain.

```
local/ai_analysis/
├── classes/
│   ├── ai/
│   │   ├── ai_client_interface.php        (add format_result)
│   │   ├── claude_client.php              (implement format_result)
│   │   └── prompt_builder.php             (add build_format_system)
│   ├── security/
│   │   ├── sql_validator.php              (add column-source + derived-PII accessors)
│   │   └── **pii_scrubber.php**
│   └── external/
│       └── query.php                      (format param, L6.5/L7/L7.5, envelope fields)
├── lang/en/local_ai_analysis.php          (add formatunavailable string)
├── tests/
│   ├── **pii_scrubber_test.php**
│   ├── claude_client_test.php             (extend)
│   ├── external_query_test.php            (extend)
│   └── sql_validator_test.php             (extend)
└── version.php                            (bump)
```

## Done criteria

1. `format=true` returns a plain-language `answer` with real values restored.
2. `format=false` behaves byte-identically to Sprint 2.
3. No real PII value is ever present in the payload passed to `format_result` (asserted by test).
4. AI #2 failure degrades gracefully to raw rows + note, status `SUCCESS`.
5. Aliased and derived PII columns are correctly masked.
6. Full plugin PHPUnit suite passes (Sprint 1 + 2 + new), run by file path.
