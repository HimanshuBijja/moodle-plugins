# Sprint 8 (Sub-project A) — Intent → SQL Templates

**Date:** 2026-06-11
**Status:** Design approved, pre-implementation
**Component:** `local_ai_analysis`

## Context

This is sub-project **A** of a six-part roadmap decomposition (A intent-templates → C
role/people → B analytics-views → D memory-polish; E schema-pruning and F RAG deferred).
Each sub-project gets its own spec → plan → build cycle. This spec covers **A only**.

### Problem

Today every query — even trivial, high-frequency ones like "students list" — makes a full
LLM round-trip to generate SQL. That inherits three costs:

1. **Unreliability** — weak/quota-limited models (gemini-2.5-flash-lite, Ollama 3b) sometimes
   mis-generate SQL for even simple listings; the no-subquery `sql_validator` rejects their
   over-complications.
2. **Tokens / latency / quota** — every query spends an API call (Gemini free-tier is
   per-day/per-model and exhausts quickly).
3. **Non-determinism** — the same question can yield different SQL run to run.

### Goal

Insert a **deterministic fast-path** for known query shapes: a question that matches a known
intent is served by a hand-written, parameterized SQL template with **no LLM call**. Unknown
or paraphrase-heavy questions fall through to the existing AI pipeline unchanged. v1 ships the
**framework end-to-end** proven on a single intent — `student_listing` — so adding further
intents later is just a registry entry + template.

## Non-goals (v1)

- Grade-filtered listings ("failed students"), submissions, counts — deferred; fall through to AI.
- Named-course resolution ("students in DBMS") — deferred; falls through to AI.
- Follow-up / multi-turn intent mutation ("only failed ones", "sort by marks") — sub-project D.
- Ranking/comparison shapes ("top performers") — sub-project B (need views; validator forbids
  the subqueries they require).
- Role-based student filtering — sub-project C (see Semantic Caveat).
- Admin-editable intent/synonym config — YAGNI; PHP arrays for v1.

## Architecture

### Placement in the pipeline

The fast-path is inserted into `classes/external/query.php` **after** input sanitisation and
rate-limiting, **before** the AI call. It never replaces the security layers — only the SQL
*author*.

```
sanitise → rate-limit → normalize → classify
   ├─ confident match → build template SQL ─┐
   └─ no match → existing AI pipeline ───────┤   (unchanged)
                                             ↓
                          sql_validator → query_executor → audit
```

**Invariant:** template-produced SQL flows through the exact same `sql_validator`,
read-only `query_executor`, and `audit_writer` as AI-generated SQL. Every existing guarantee
(SELECT-only, manifest-scoped, read-only connection, audited) holds identically. The fast-path
adds a new SQL *source*, not a new trust boundary.

**Rate-limit:** still applies to the template path in v1 (admins bypass as today). Keeps the
path simple and protects the DB regardless of SQL source.

### Components (new `classes/intent/`)

| Component | Responsibility | Depends on |
|---|---|---|
| `query_normalizer` | Lowercase, trim, collapse whitespace/punctuation, apply `synonym_dictionary`. Returns a normalized token form **for classification only**. | `synonym_dictionary` |
| `synonym_dictionary` | PHP array mapping surface terms → canonical tokens (`show/get/display → list`, `pupils/learners → students`, etc.). Same pattern as `manifest_builder`. | — |
| `intent_classifier` | Match normalized tokens against `intent_registry`; return `{intent_id, confidence, slots}` or `null` below threshold. **Never throws.** | `intent_registry`, `query_normalizer` |
| `intent_registry` | Declares each intent: trigger rules, required slots, template id. v1 = one entry `student_listing`. | — |
| `sql_template` builder | Maps an intent + slots → a fixed parameterized SELECT with bound params. | — |

### The `student_listing` template

```sql
SELECT u.id, u.firstname, u.lastname
FROM mdl_user u
JOIN mdl_user_enrolments ue ON ue.userid = u.id
JOIN mdl_enrol e ON e.id = ue.enrolid
WHERE e.courseid = :courseid
  AND ue.status = 0
  AND e.status = 0
ORDER BY u.lastname
LIMIT 1000
```

- `:courseid` is bound from the widget's current course context (not parsed from the question).
- Table prefix `mdl_` is translated to the runtime prefix by the existing `translate_prefix()`
  exactly as for AI SQL.
- This is the join already proven on this instance ("how many students enrolled" → SUCCESS).

### Classification flow

1. `query_normalizer` canonicalizes the sanitised prompt.
2. `intent_classifier` evaluates each registry entry's trigger rules, producing a confidence
   score. v1 `student_listing` triggers when the normalized tokens contain a list-verb token
   AND a students-noun token (e.g. "list students", "show students", "students list",
   "current course students"), with no out-of-scope qualifier (a grade/submission/named-course
   term lowers confidence below threshold → fall through).
3. Confident match → resolve slots (courseid from context) → build template SQL → continue to
   `sql_validator`.
4. No confident match → existing AI pipeline, untouched.

### Course slot resolution

v1 resolves the course **only** from the widget's current `courseid`. If the question names a
different course, the named-course qualifier lowers classifier confidence → AI fallback. No
fuzzy `mdl_course` lookup, no cross-course permission question in v1.

## Semantic Caveat (explicit, known limitation)

With role tables still excluded from the manifest (until sub-project C), **"students" means
active enrolled users** — which technically includes enrolled teachers/non-students. v1 ships
the enrolment definition (the proven query). True student-*role* filtering arrives with C. This
is a documented limitation, not a defect.

## Audit & observability

Each audit row records which route served the query by reusing the existing **`provider`**
audit column (`char(20)`, nullable): value `template` for fast-path rows, the real provider
name (`gemini`/`claude`/…) for AI rows. **No schema migration.** Enables later measurement of
template hit-rate vs AI fallback.

## Error handling

- `intent_classifier` and `query_normalizer` never throw to the AJAX layer (honour the
  no-exceptions-to-AJAX rule). Any internal anomaly → return `null` → AI fallback.
- Template SQL that somehow fails `sql_validator` returns the normal `SQL_INVALID` envelope
  (this would be a template bug surfaced by tests, not masked by silent fallback).
- All existing status codes are unchanged; no new status code is introduced (a template query
  ends in `SUCCESS`/`QUERY_FAILED` like any other).

## Testing

**Unit:**
- `query_normalizer` — synonym application, punctuation/whitespace normalization.
- `intent_classifier` — every phrasing of the listing intent ("list students", "show students",
  "students list", "current course students") → `student_listing`; unrelated prompts
  ("failed students", "who is the teacher", "what is this course") → `null`.
- `sql_template` builder — produces the expected SQL + bound `:courseid`, and the result
  **passes `sql_validator`**.

**Integration (`external_query`):**
- Template path returns rows with the AI client stub asserting it was **never called** — proves
  the zero-token fast-path.
- A non-matching prompt still routes to the (stubbed) AI client — proves fallback intact.
- Audit row for the template path carries `provider = 'template'`.

## Files (anticipated)

- New: `classes/intent/query_normalizer.php`, `synonym_dictionary.php`,
  `intent_classifier.php`, `intent_registry.php`, `sql_template.php` (exact split finalized in
  the plan).
- Modified: `classes/external/query.php` (insert fast-path branch), `audit_writer` call site
  (pass `provider = 'template'`).
- New tests under `tests/`.
- `version.php` bump.
- Doc updates: `docs/ai-memory/02-features-log.md`, `04-current-state.md`, `03-decisions.md`.

## Decisions captured

- **Deterministic fast-path + AI fallback** (not prompt-normalization-only, not intent→AI-SQL).
- **Deterministic keyword + synonym classification** (no LLM classifier in v1).
- **One intent in v1** (`student_listing`), full framework around it.
- **Current-course context only** for the course slot.
- **Reuse `provider` audit column** for route tracking (no migration).
- **Template SQL keeps the full validator/executor/audit path** (no new trust boundary).
