# Sub-project C — Role / People Queries (course staff)

**Date:** 2026-06-12
**Status:** Design approved, pre-implementation
**Component:** `local_ai_analysis`

## Context

Sub-project **C** of the six-part roadmap decomposition (A intent-templates ✅ → **C
role/people** → B analytics-views → D memory-polish; E/F deferred). Each sub-project has its
own spec → plan → build cycle. This spec covers **C only**.

### Problem

Role/people questions ("who teaches this course", "who is the lecturer") currently return
`OUT_OF_SCOPE` by design: `mdl_role`, `mdl_role_assignments`, and `mdl_context` are
deliberately excluded from the manifest, because allow-listing them would expose site-wide
role structure to both the AI and the read-only (RO) DB user. The user has decided to revisit
this — but under a firm privacy constraint.

### Privacy constraint (the shaping decision)

- **Visible as "staff":** the four staff roles — `manager`, `coursecreator`, `editingteacher`,
  `teacher` — at **course context** only.
- **Hidden entirely:** the configured **site-admins** (`$CFG`/`mdl_config` `siteadmins`, a CSV
  of user ids; user id 2 on this instance) — excluded **even if they also hold a staff role**.
- **Never exposed:** usernames, emails, idnumbers. Only `firstname` + `lastname` are visible as
  identity (matching how `mdl_user` already exposes names, not usernames).

### Goal

Make course-staff questions answerable safely, by exposing a **pre-filtered, read-only DB
view** (never the raw role tables) to the manifest + RO user, and adding one deterministic
fast-path template (extending sub-project A) for the flagship "who teaches this course".

## Non-goals (v1)

- Lecturer **performance/comparison** ("best performing lecturer", "compare all lecturers") —
  sub-project B (analytics); also needs a metric definition. Out of scope.
- Category-level / system-level role assignments — only course-context (level 50) staff appear.
- "What courses does <name> teach", "list all staff across courses" as dedicated templates —
  these work through the AI path against the view, but get no fast-path template in v1.
- Student role filtering — sub-project A already lists enrolled users; not revisited here.
- Exposing any user column beyond `firstname`, `lastname`, `role`.

## Architecture

### 1. The safe view — privacy enforced in the data layer

A read-only DB view `mdl_ai_course_staff` is the **single** gateway to people data:

```sql
CREATE OR REPLACE VIEW mdl_ai_course_staff AS
SELECT ra.id, ctx.instanceid AS courseid, u.id AS userid,
       u.firstname, u.lastname, r.shortname AS role
FROM mdl_role_assignments ra
JOIN mdl_context ctx ON ctx.id = ra.contextid AND ctx.contextlevel = 50   -- course context
JOIN mdl_role r      ON r.id  = ra.roleid
JOIN mdl_user u      ON u.id  = ra.userid
WHERE r.shortname IN ('manager','coursecreator','editingteacher','teacher')
  AND NOT EXISTS (SELECT 1 FROM mdl_config c
                  WHERE c.name = 'siteadmins' AND FIND_IN_SET(u.id, c.value))
```

The `mdl_` literal prefix is translated to the runtime prefix at view-creation time (see §2).
The privacy guarantees are physical, not advisory:
- Only the 4 staff roles, only course-context (level 50) assignments.
- **Site-admins excluded dynamically** via `FIND_IN_SET(u.id, siteadmins)` — auto-updates if
  the admin list changes, and excludes a site-admin even when they hold a staff role.
- Only `firstname`, `lastname`, `role` projected — no username/email/idnumber column exists in
  the view to be queried.
- The RO user is granted SELECT on the **view only**, never on `mdl_role_assignments` /
  `mdl_context` / `mdl_role`. The AI and validator therefore cannot express a query that
  reaches a hidden person or column.

**Known v1 limitation (documented):** managers/staff assigned at category or system context do
not appear per-course (the view requires course-context). Acceptable for "who teaches this
course".

### 2. Where the view lives (production AND test DB)

The plugin owns the view so it exists everywhere the code runs:
- `db/install.php` — `xmldb_local_ai_analysis_install()` creates the view via
  `$DB->execute('CREATE OR REPLACE VIEW ' . $CFG->prefix . 'ai_course_staff AS ...')`. This
  runs on fresh installs **and** the PHPUnit test DB (init re-installs plugins), so the view
  exists as `phpu_ai_course_staff` for validator/template tests.
- `db/upgrade.php` — a new upgrade step (guarded by the new `version.php` number) runs the same
  `CREATE OR REPLACE VIEW` for existing production installs.
- `db/readonly_grants.sql` — add `GRANT SELECT ON <db>.mdl_ai_course_staff TO 'moodle_ai_ro'@…`
  (source of truth for the manual production grant).

MariaDB-only target, so raw `CREATE OR REPLACE VIEW` via `$DB->execute()` is acceptable (XMLDB
has no view support). The SQL is written with `$CFG->prefix` interpolated for every table.

### 3. Manifest exposure + course scoping

`manifest_builder` gains `mdl_ai_course_staff => ['courseid','userid','firstname','lastname','role']`.
For non-admin + courseid>0, a `_scope_note` instructs filtering to the current course
(`WHERE courseid = <id>`), exactly like the other course-scoped tables. The RO grant on all
14+1 tables/views remains the source of truth in `db/readonly_grants.sql`.

Exposing the view to the manifest unlocks **all** staff query shapes via the AI path (who
teaches X, what courses X teaches, list staff) — generated SQL is validated against the view's
allow-listed columns.

### 4. Fast-path template + classifier extension (extends sub-project A)

- **Template:** new `course_staff` case in `sql_template::build()`:
  `SELECT userid, firstname, lastname, role FROM mdl_ai_course_staff WHERE courseid = ? ORDER BY lastname LIMIT 1000`,
  param `[$courseid]`. Unit-tested to pass `sql_validator`.
- **Synonym dictionary** gains a **staff family** → canonical `staff`:
  `teacher, teachers, lecturer, lecturers, faculty, instructor, instructors, professor,
  professors, tutor, tutors, staff`; teaching **verbs** `teach, teaches, teaching` → `staff`;
  and interrogative `who` → `list` (so "who teaches this course" / "who is the lecturer" match).
- **Registry** gains a `course_staff` entry: `requires=['staff']`,
  `any_of=['list','enrolled']`, `none_of=[student/grade/submission qualifiers]`.
  `student_listing` and `course_staff` require different nouns (`students` vs `staff`), so they
  are mutually exclusive; registry order is irrelevant for them.
- **Effect on A:** additive. The `who → list` mapping means some `who`-phrasings about students
  now hit `student_listing` (a strict improvement). A couple of existing `intent_classifier`
  test expectations are updated accordingly; no behavior is removed.

### 5. PII

The view's `firstname`/`lastname` are identity columns. `pii_scrubber` column classification is
extended so the view's name columns are tokenized in the format pass, exactly as `mdl_user`
names are today. `role` and `userid`/`courseid` are not PII.

## Error handling

- No new status codes. Staff queries succeed as `SUCCESS` or fail through the existing envelopes
  (`OUT_OF_SCOPE` if the AI declines, `SQL_INVALID`, `QUERY_FAILED`).
- If the view is missing (e.g. RO grant not yet applied in production), a staff query fails as
  `QUERY_FAILED` and is audited — never a fatal. Install/upgrade creates the view; the grant is
  the only manual production step (documented in INSTALL.md).
- Classifier remains never-throwing (returns null → AI fallback) per the existing contract.

## Testing

**View / data layer:**
- View exists after install with the expected columns (query `phpu_ai_course_staff`).
- **RO-safety / site-admin exclusion (critical):** seed a user who holds BOTH a `manager` role
  on a course AND is listed in `siteadmins`; assert the view does **not** return them, while a
  plain `editingteacher` on the same course **is** returned.
- Only course-context assignments appear (a category-context manager is absent).
- Only `firstname/lastname/role` columns exist — no username/email reachable.

**Template / classifier (extends A's test files):**
- `course_staff` template builds expected SQL + bound `:courseid` and **passes `sql_validator`**
  (against a manifest that includes the view).
- Classifier: "who teaches this course", "who is the lecturer", "list teachers", "faculty of
  this course" → `course_staff`; student phrasings still → `student_listing`; grade/submission
  staff phrasings → null (AI fallback).

**Gateway (extends `external_query_test`):**
- A staff fast-path query returns rows, the AI stub `call_count === 0`, audit `provider='template'`.
- Manifest scope-note restricts a non-admin teacher to their own course's staff.
- Hermetic enrolment/role setup via direct `$DB` inserts (role_assignments + context), avoiding
  enrol_user()/role hooks that enumerate plugins (per the A sub-project test convention).

## Files (anticipated)

- New: `db/install.php` (or add view creation if it exists), `db/upgrade.php` step,
  `tests/course_staff_view_test.php`.
- Modified: `classes/manifest/manifest_builder.php` (+view + scope-note),
  `classes/intent/synonym_dictionary.php` (+staff family, who→list),
  `classes/intent/intent_registry.php` (+course_staff entry),
  `classes/intent/sql_template.php` (+course_staff case),
  `classes/security/pii_scrubber.php` (+view name columns),
  `db/readonly_grants.sql` (+view grant), `version.php` bump,
  `tests/intent_classifier_test.php` + `tests/sql_template_test.php` +
  `tests/external_query_test.php` (extend), `INSTALL.md` (view grant note),
  `docs/ai-memory/02,03,04`.

## Decisions captured

- **Staff = manager + coursecreator + editingteacher + teacher**, course context only; **site-
  admins excluded dynamically** even when they hold a staff role.
- **Exposure via a pre-filtered read-only VIEW** (`mdl_ai_course_staff`), never the raw role
  tables; RO user granted SELECT on the view only.
- **Plugin owns the view** (install.php + upgrade.php) so it exists in prod and the PHPUnit DB.
- **One fast-path template** (`course_staff`) + AI-path exposure for everything else.
- **Only `firstname/lastname/role`** projected; usernames/emails never reachable.
