# Design — Sub-project 3b: OpenAI + Gemini providers for `local_ai_analysis`

**Date:** 2026-05-30
**Plugin path:** `local/ai_analysis/`
**Plugin component:** `local_ai_analysis`
**Moodle target:** 4.5 · PHP 8.1+ · MariaDB 10.11
**Status:** Approved, ready for implementation planning

## Parent project

Third sub-project, second half of Sprint 3:

1. Security foundation ✅ merged
2. Pipeline + Claude provider ✅ merged
3. Additional providers + PII scrubber + AI formatting pass
   - 3a: PII scrubber + `format_result` ✅ merged
   - 3b: **OpenAI + Gemini providers — this spec**
4. Frontend widget (Mustache + AMD + Chart.js)
5. Admin & management (audit viewer, decrypt UI, settings polish, Privacy API, retention task)

Ollama (self-hosted) is intentionally deferred — it has a different config/networking path (local HTTP, no API key) and can be its own slice later.

## Why this slice now

Sub-project 2 shipped a single hard-wired provider (Claude) behind `ai_client_interface`, and 3a added the `format_result` method to that interface. Both methods are now stable. This slice makes the provider genuinely pluggable: an admin can choose OpenAI or Google Gemini instead of Claude from the settings page, with no other behaviour change. The SQL-generation output contract, the validator, the PII scrubber, and the gateway are all untouched — only the AI client layer grows.

## Scope

**In scope**
- Abstract `base_http_ai_client` (template-method) holding the provider-independent request/parse flow shared by all JSON-over-HTTP providers.
- Refactor `claude_client` onto the base (behaviour-preserving; its existing tests are the safety net).
- New `openai_client` (Chat Completions) and `gemini_client` (generateContent).
- `ai_client_factory` cases for `openai` and `gemini`.
- Settings: provider dropdown options, per-provider API key + free-text model field (with sensible defaults), plus a `claude_model` field for parity.
- Tests for each new client (fake transport) + factory dispatch; existing `claude_client_test` must pass unchanged.

**Out of scope**
- Ollama / self-hosted providers.
- Any change to `ai_client_interface`, `sql_validator`, `pii_scrubber`, `prompt_builder`, `manifest_builder`, the gateway, or the audit schema.
- Per-provider prompt tuning — the existing `prompt_builder` system prompts are used verbatim for all providers.
- Streaming responses.

## Architecture

### Template-method base class

New `classes/ai/base_http_ai_client.php` implements `ai_client_interface` and owns the entire shared flow. Concrete providers implement only five small hooks.

```php
abstract class base_http_ai_client implements ai_client_interface {

    public function __construct(
        protected http_transport_interface $transport,
        protected string $api_key,
        protected string $model = '',
    ) {}

    final public function generate_sql(string $system_prompt, string $user_prompt): array {
        $payload  = $this->build_sql_payload($system_prompt, $user_prompt);
        $response = $this->post($payload);
        $text     = $this->extract_text($response);            // throws PARSE_FAILED if not a string
        $stripped = $this->strip_fences($text);
        $decoded  = json_decode($stripped, true);
        if (!is_array($decoded)) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        if (isset($decoded['error']) && is_string($decoded['error'])) {
            return ['type' => 'out_of_scope', 'message' => $decoded['error']];
        }
        if (!isset($decoded['sql']) || !isset($decoded['params']) || !is_array($decoded['params'])) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        return [
            'type'        => 'sql',
            'sql'         => (string) $decoded['sql'],
            'params'      => $decoded['params'],
            'explanation' => (string) ($decoded['explanation'] ?? ''),
        ];
    }

    final public function format_result(string $user_prompt, array $safe_rows): string {
        $payload  = $this->build_format_payload($user_prompt, $safe_rows);
        $response = $this->post($payload);
        return trim($this->strip_fences($this->extract_text($response)));
    }

    /** POST the JSON-encoded payload and return the decoded response envelope. */
    protected function post(array $payload): array {
        $headers  = $this->auth_headers();
        $response = $this->transport->post($this->endpoint(), $headers, json_encode($payload));
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new ai_client_exception('HTTP_' . $response['status'], $response['body']);
        }
        $decoded = json_decode($response['body'], true);
        return is_array($decoded) ? $decoded : [];
    }

    protected function strip_fences(string $text): string {
        $stripped = trim($text);
        $stripped = preg_replace('/^```\w*\s*/i', '', $stripped);
        $stripped = preg_replace('/\s*```\s*$/', '', $stripped);
        return $stripped;
    }

    /** Resolve the effective model: explicit config, else the provider default. */
    protected function model(): string {
        return $this->model !== '' ? $this->model : static::DEFAULT_MODEL;
    }

    abstract protected function endpoint(): string;
    abstract protected function auth_headers(): array;
    abstract protected function build_sql_payload(string $system_prompt, string $user_prompt): array;
    abstract protected function build_format_payload(string $user_prompt, array $safe_rows): array;

    /** Extract the assistant text from the provider's decoded response, or '' if absent. */
    abstract protected function extract_text(array $response): string;
}
```

Notes:
- `generate_sql`/`format_result` are `final` — the no-drift guarantee. A future provider with a fundamentally different flow (e.g. streaming) would implement `ai_client_interface` directly rather than extend this base.
- `extract_text` returns `''` when the expected path is missing; the empty string then fails `json_decode`/shape checks and surfaces as `PARSE_FAILED`, matching Claude's current behaviour. (The base does not call `is_string` since the abstract return type is already `string`; an absent path yields `''`.)
- Each subclass declares `protected const DEFAULT_MODEL`.

### claude_client refactor

`claude_client` is rewritten to extend `base_http_ai_client`, keeping only Anthropic specifics. Its `generate_sql`, `format_result`, `post_and_extract_text`, and `strip_fences` (added in 2/3a/Task 4) are removed in favour of the base.

```php
class claude_client extends base_http_ai_client {
    protected const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
    private const ENDPOINT = 'https://api.anthropic.com/v1/messages';
    private const ANTHROPIC_VERSION = '2023-06-01';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string { return self::ENDPOINT; }

    protected function auth_headers(): array {
        return [
            'x-api-key: ' . $this->api_key,
            'anthropic-version: ' . self::ANTHROPIC_VERSION,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_SQL,
            'system'     => $system_prompt,
            'messages'   => [['role' => 'user', 'content' => $user_prompt]],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_FORMAT,
            'system'     => prompt_builder::build_format_system(),
            'messages'   => [['role' => 'user', 'content' => json_encode([
                'question' => $user_prompt,
                'rows'     => $safe_rows,
            ])]],
        ];
    }

    protected function extract_text(array $response): string {
        return is_string($response['content'][0]['text'] ?? null) ? $response['content'][0]['text'] : '';
    }
}
```

**`claude_client_test` (15 tests) must pass unchanged.** It is the behaviour-preservation contract for the refactor. The fake transport returns `['status','headers','body']`; the base's `post()` consumes exactly that shape, so the tests need no edits.

### openai_client (new)

```php
class openai_client extends base_http_ai_client {
    protected const DEFAULT_MODEL = 'gpt-4o';
    private const ENDPOINT = 'https://api.openai.com/v1/chat/completions';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string { return self::ENDPOINT; }

    protected function auth_headers(): array {
        return [
            'Authorization: Bearer ' . $this->api_key,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'model'           => $this->model(),
            'max_tokens'      => self::MAX_TOKENS_SQL,
            'response_format' => ['type' => 'json_object'],
            'messages'        => [
                ['role' => 'system', 'content' => $system_prompt],
                ['role' => 'user',   'content' => $user_prompt],
            ],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_FORMAT,
            'messages'   => [
                ['role' => 'system', 'content' => prompt_builder::build_format_system()],
                ['role' => 'user',   'content' => json_encode(['question' => $user_prompt, 'rows' => $safe_rows])],
            ],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['choices'][0]['message']['content'] ?? null;
        return is_string($t) ? $t : '';
    }
}
```

`response_format: {type:json_object}` is set for SQL generation (forces valid JSON, cutting `AI_INVALID_JSON`) and omitted for formatting (prose).

### gemini_client (new)

```php
class gemini_client extends base_http_ai_client {
    protected const DEFAULT_MODEL = 'gemini-2.0-flash';
    private const BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::BASE . $this->model() . ':generateContent';
    }

    protected function auth_headers(): array {
        return [
            'x-goog-api-key: ' . $this->api_key,   // header, not ?key= query param — keeps key out of URL logs
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt): array {
        return [
            'systemInstruction' => ['parts' => [['text' => $system_prompt]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => $user_prompt]]]],
            'generationConfig'  => ['maxOutputTokens' => self::MAX_TOKENS_SQL, 'responseMimeType' => 'application/json'],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'systemInstruction' => ['parts' => [['text' => prompt_builder::build_format_system()]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => json_encode(['question' => $user_prompt, 'rows' => $safe_rows])]]]],
            'generationConfig'  => ['maxOutputTokens' => self::MAX_TOKENS_FORMAT],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['candidates'][0]['content']['parts'][0]['text'] ?? null;
        return is_string($t) ? $t : '';
    }
}
```

`responseMimeType: application/json` is the Gemini equivalent of OpenAI's JSON mode, set for SQL generation only.

Both new clients reuse the existing `moodle_curl_transport` unchanged (a plain `post(url, headers, body)`).

### Factory

`ai_client_factory::make()` extends its `match($provider)`:

```php
$provider = get_config('local_ai_analysis', 'provider') ?: 'claude';
$transport = new moodle_curl_transport();
return match ($provider) {
    'claude' => new claude_client($transport, (string) get_config('local_ai_analysis', 'claude_api_key'), (string) get_config('local_ai_analysis', 'claude_model')),
    'openai' => new openai_client($transport, (string) get_config('local_ai_analysis', 'openai_api_key'), (string) get_config('local_ai_analysis', 'openai_model')),
    'gemini' => new gemini_client($transport, (string) get_config('local_ai_analysis', 'gemini_api_key'), (string) get_config('local_ai_analysis', 'gemini_model')),
    default  => throw new \coding_exception('Unsupported AI provider: ' . $provider),
};
```

The `set_override`/`reset_override` PHPUNIT seam is untouched. `get_config` returning `false` for an unset model coerces to `''`, which `model()` resolves to the provider default — no migration needed.

### Settings

`settings.php` gains:
- Provider dropdown options: `['claude' => 'Claude (Anthropic)', 'openai' => 'OpenAI', 'gemini' => 'Google Gemini']`.
- `claude_model` — `admin_setting_configtext`, default `claude-sonnet-4-20250514` (parity; existing `claude_api_key` unchanged).
- `openai_api_key` — `admin_setting_configpasswordunmask`.
- `openai_model` — `admin_setting_configtext`, default `gpt-4o`.
- `gemini_api_key` — `admin_setting_configpasswordunmask`.
- `gemini_model` — `admin_setting_configtext`, default `gemini-2.0-flash`.

Model fields are free-text (not a fixed dropdown) so new model names can be entered without a code change. New lang strings for every label/description. `version.php` bumps (no DB schema change).

## Data flow

Unchanged from Sub-project 2/3a. The gateway calls `ai_client_factory::make()->generate_sql(...)` and (when `format=true`) `->format_result(...)`. Whichever concrete client the factory returns produces the same typed array / string contract. The validator receives the same manifest, the scrubber tokenises the same way, the audit row records the (now meaningful) `provider` string.

## Error handling

No new error paths; providers slot into the existing envelope contract:

| Situation | Behaviour |
|---|---|
| Non-2xx from provider | base `post()` throws `ai_client_exception('HTTP_<code>', body)` → gateway `AI_INVALID_JSON`. |
| Unparseable / missing text path / missing `{sql,params}` | `ai_client_exception('PARSE_FAILED')` → gateway `AI_INVALID_JSON`. |
| `{error}` in decoded SQL response | returned as `['type'=>'out_of_scope', ...]` → gateway `OUT_OF_SCOPE`. |
| Transport failure (DNS/TLS/timeout) | `moodle_curl_transport` throws `transport_exception` → gateway `AI_TRANSPORT_ERROR`. |
| Blank API key | provider returns 401 → `HTTP_401` → `AI_INVALID_JSON`. Keys are not pre-validated. |
| Unknown provider config value | factory `default` → `coding_exception`. |

## Testing strategy

- **`base_http_ai_client`** — abstract; exercised only through subclasses, no standalone test.
- **`claude_client_test`** (existing 15) — must pass **unchanged** after the refactor. Primary safety net.
- **`openai_client_test`** (new, fake transport): endpoint; `Authorization: Bearer <key>`; `build_sql_payload` shape incl. `response_format:{type:json_object}` and system+user messages; happy-path `{sql,params}` return; code-fence stripping; `{error}` → `out_of_scope`; HTTP 4xx and 5xx → `ai_client_exception`; malformed body → `PARSE_FAILED`; `format_result` targets chat endpoint, returns prose, has `max_tokens:1024` and NO `response_format`; `extract_text` reads `choices[0].message.content`.
- **`gemini_client_test`** (new, fake transport): endpoint includes the model and `:generateContent`; `x-goog-api-key` header; `build_sql_payload` shape with `systemInstruction`/`contents`/`generationConfig.responseMimeType`; same happy/fence/out_of_scope/HTTP-error/parse cases; `format_result` omits `responseMimeType` and uses `maxOutputTokens:1024`; `extract_text` reads `candidates[0].content.parts[0].text`.
- **`ai_client_factory_test`** (new): with `provider` config set, `make()` returns the matching client class for `claude`/`openai`/`gemini`, and throws `coding_exception` for an unknown provider. Uses `set_config` in-test; resets the override in tearDown.

The fake-transport pattern from `claude_client_test` is reused — zero live API calls.

## Files

New files in **bold**; existing modified files in plain.

```
local/ai_analysis/
├── classes/ai/
│   ├── **base_http_ai_client.php**
│   ├── claude_client.php              (refactor onto base)
│   ├── **openai_client.php**
│   ├── **gemini_client.php**
│   └── ai_client_factory.php          (openai + gemini cases, pass model)
├── settings.php                       (dropdown options, per-provider key + model)
├── lang/en/local_ai_analysis.php      (new setting strings)
├── tests/
│   ├── claude_client_test.php         (unchanged — must stay green)
│   ├── **openai_client_test.php**
│   ├── **gemini_client_test.php**
│   └── **ai_client_factory_test.php**
└── version.php                        (bump)
```

## Done criteria

1. With `provider=openai` (and key set), the full pipeline returns validated SQL results — and a formatted answer when `format=true`.
2. Same for `provider=gemini`.
3. `claude_client_test`'s 15 tests pass unchanged after the refactor.
4. The SQL-output parsing exists in exactly one place (`base_http_ai_client`); no provider duplicates it.
5. Provider, key, and model are all admin-configurable; switching providers needs no code change.
6. Full plugin PHPUnit suite passes (Sprint 1 + 2 + 3a + new), run by file path.
