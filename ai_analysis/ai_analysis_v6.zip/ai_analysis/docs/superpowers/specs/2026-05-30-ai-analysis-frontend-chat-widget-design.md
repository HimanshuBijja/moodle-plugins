# Sprint 4 — Frontend Chat Widget Design

## Overview

Add a floating chat widget to `local_ai_analysis` that allows authorised users to query student data via natural language from any Moodle page. The widget consumes the existing `local_ai_analysis_query` external function and renders results as a data table, an auto-detected Chart.js bar chart, and an AI-formatted prose answer.

---

## Architecture

### Files

| File | Action | Responsibility |
|---|---|---|
| `lib.php` | Modify | Add `local_ai_analysis_before_footer()` hook — capability check, render widget template |
| `templates/chat_widget.mustache` | Create | Widget shell: FAB + drawer + fullscreen overlay skeleton |
| `amd/src/chat_widget.js` | Create | AMD module: state machine, AJAX, result rendering, Chart.js, session history |
| `styles.css` | Create | Widget styles scoped to `.local-ai-analysis-widget` |
| `version.php` | Modify | Bump version to 2026053002 |

No new PHP classes. No database changes. No new external functions.

### Injection Point

`local_ai_analysis_before_footer()` in `lib.php` (a legacy `before_footer` callback — Moodle 4.5 captures its **return value** and appends it to the footer via `before_footer_html_generation::process_legacy_callbacks()`):

1. Check `has_capability('local/ai_analysis:query', $PAGE->context)`. Return `''` immediately if not capable. The capability is **CONTEXT_COURSE** level, so it is checked in the current page context (a teacher holds it inside their course, not system-wide); checking `context_system` would hide the widget from teachers. The `local_ai_analysis_query` external function re-checks the capability server-side, so this is a display gate only.
2. Build template context: `courseid` from `$PAGE->course->id`.
3. Call `$PAGE->requires->js_call_amd('local_ai_analysis/chat_widget', 'init', [$courseid])` — `courseid` is passed as the init argument (Moodle idiom), not read from a DOM data attribute.
4. **Return** `$OUTPUT->render_from_template('local_ai_analysis/chat_widget', $ctx)` (do not echo — core concatenates the returned string).

---

## Widget States

Three states managed entirely in the AMD JS module:

### State 1 — Collapsed (FAB only)
- A single circular button (🤖) fixed at `bottom: 20px; right: 20px`.
- Visible on all Moodle pages for capable users.
- Click → transition to `drawer`.

### State 2 — Compact Drawer
- Panel anchored `bottom: 0; right: 0`. Fixed width ~320px, max height ~60vh.
- **Header**: "🤖 AI Assistant" + three icon buttons: ＋ (new/clear), ⤢ (expand to fullscreen), ✕ (close → collapsed).
- **Results area**: scrollable, shows table + chart + AI answer for the last query.
- **Input**: pinned to the bottom of the drawer. Single-line text input + "Ask →" button.
- Loading state: input disabled, button shows "…".

### State 3 — Full-Screen Overlay
- Covers entire viewport (`position: fixed; inset: 0`). `z-index: 9999`.
- **Header bar**: "🤖 AI Data Assistant" + ＋, ⤡ (collapse to drawer), ✕ (close → collapsed).
- **Sidebar** (fixed ~180px wide): session history list — past prompts from current page load (in-memory JS array). "+ New chat" clears the current result view.
- **Main area** (flex-grow):
  - *Welcome sub-state* (no result yet): centred heading "What should we analyse today?", three suggested-query chips, centred constrained input box.
  - *Thread sub-state* (after a query): user prompt bubble (right-aligned), AI response block (table + chart + answer prose), centred constrained input at the bottom.
- **Input**: centred, `max-width: 600px`, pinned to bottom of main area. Not edge-to-edge.

### State Transitions

```
collapsed ──[FAB click]──> drawer
drawer    ──[⤢ click]───> fullscreen
fullscreen ──[⤡ click]──> drawer
drawer    ──[✕ click]───> collapsed
fullscreen ──[✕ click]──> collapsed
* ＋ click: clear result, stay in current state
```

---

## Data Flow

1. User submits prompt (Enter or button click).
2. AMD generates a UUID `request_id` (`crypto.randomUUID()` or fallback).
3. Calls `core/ajax` with:
   ```js
   {methodname: 'local_ai_analysis_query', args: {
     prompt,
     courseid,   // passed into init() by lib.php
     request_id,
     format: true
   }}
   ```
4. On `SUCCESS` response:
   - Parse `rows` (array of JSON strings → objects).
   - Render data table.
   - Run chart auto-detection (see below) → render Chart.js if applicable.
   - Display `answer` prose below the table.
   - If `format_note` present, show as small caption.
   - Push `{prompt, answer}` to in-memory session history array.
5. On non-`SUCCESS` response: display `error` string inline. No chart. No table.
6. Re-enable input after response (success or error).

---

## Chart Auto-Detection

After parsing rows:

1. Identify the **first column** where every row value is numeric (parseable by `parseFloat`, non-NaN).
2. Identify the **first non-numeric column** as labels.
3. If a numeric column is found AND `rows.length >= 2`: render a vertical bar chart using Chart.js via `require(['core/chartjs'])`.
4. Otherwise: skip chart, show table + answer only.

Chart is rendered into a `<canvas>` element appended below the table. Destroyed and re-created on each new query result.

---

## Session History

- JS array `sessionHistory` — populated on each successful query: `{prompt, rowCount}`.
- Displayed in the fullscreen sidebar as a clickable list (click re-displays that query's result from a parallel `resultCache` map keyed by `request_id`).
- Cleared when "+ New chat" is clicked.
- Never persisted to server. Never sent to the AI.

---

## Mustache Template

`templates/chat_widget.mustache` renders the full widget DOM skeleton in a hidden/collapsed state. The AMD module toggles CSS classes to show/hide sections. Template context:

```json
{
  "courseid": 42
}
```

UI strings are emitted into the template via `{{#str}}...{{/str}}` from the plugin lang file (placeholder, button labels, headings, error caption). `courseid` is available in the context if the template needs it, but the AMD module receives it via the `init` argument.

---

## Styles

`styles.css` — all rules prefixed with `.local-ai-analysis-widget` to avoid collisions with Moodle theme styles. Moodle auto-loads this file. Key rules:

- FAB: `position: fixed; bottom: 20px; right: 20px; z-index: 1050`.
- Drawer: `position: fixed; bottom: 0; right: 0; z-index: 1060; width: 340px`.
- Fullscreen overlay: `position: fixed; inset: 0; z-index: 9999`.
- Input container: `max-width: 600px; margin: 0 auto`.
- Table: `width: 100%; border-collapse: collapse` with alternating row background.
- Answer block: left `3px` border in Moodle blue (`#0F6CBF`), light background.

---

## Testing

### PHPUnit (`tests/lib_test.php`)

New test class `local_ai_analysis_lib_test`:

- `test_widget_rendered_for_capable_user`: enrol a test user as editingteacher, set `$PAGE` context to the course context, call `local_ai_analysis_before_footer()`, assert the **returned string** contains the widget root element marker.
- `test_widget_not_rendered_for_incapable_user`: a plain user with no capability in the page context, assert the returned string is empty (`''`).

Existing 118 tests must pass unchanged.

### Manual Smoke-Test Checklist (not automated)

- FAB appears on a Moodle course page when logged in as a teacher.
- FAB does not appear when logged in as a student without the capability.
- Clicking FAB opens the drawer.
- Submitting a valid prompt returns a table + chart + answer.
- Submitting an out-of-scope prompt shows error message inline.
- ⤢ expands to fullscreen; ⤡ collapses back to drawer.
- ✕ closes to FAB.
- ＋ clears the result.
- Session history list updates in fullscreen sidebar after each query.

---

## Constraints & Non-Goals

- **No Behat tests** in Sprint 4 scope.
- **No AMD unit tests** (Karma/Jest not configured for this plugin).
- **No persistent history** — all session state is in-memory JS only.
- **No conversation threading** — each AJAX call is independent; prior results are not sent to the AI.
- **No mobile-specific layout** — responsive enough via CSS flexbox, but no dedicated mobile breakpoints.
- **No i18n for JS strings** — lang strings are embedded in the Mustache template as `data-*` attributes and read by the AMD module.
