# Design — Sub-project 1: Security Foundation for `local_ai_analysis`

**Date:** 2026-05-25
**Plugin path:** `local/ai_analysis/`
**Plugin component:** `local_ai_analysis`
**Moodle target:** 4.5 · PHP 8.1+ · MariaDB 10.11
**Status:** Approved, ready for implementation planning

## Parent project

This is the first of five sub-projects that together deliver an AI chatbot for Moodle (natural-language queries → validated SQL → formatted answers). The sub-projects are:

1. **Security foundation** — this spec
2. Pipeline + Claude provider — AI client interface, prompt builder, AJAX gateway, query executor
3. Additional providers + PII — OpenAI / Gemini / Ollama clients, PII scrubber, result formatter
4. Frontend widget — Mustache template, AMD chat widget, Chart.js renderer, footer injection
5. Admin & management — presets, audit viewer UI, decrypt UI, settings polish, Privacy API, retention scheduled task

The full parent specification (eight-layer pipeline, threat model, all sprints) lives in the user's brainstorming input; the parent design intentionally aligns with that document but renames the component to `local_ai_analysis` to match the existing plugin directory.

## Why this slice first

Every downstream sprint depends on three guarantees:
- A SQL string returned by any AI provider can be rejected before it reaches the database.
- A read-only DB role exists as a final backstop if PHP validation is ever bypassed.
- Every request path can be audited without the audit writer throwing.

This sprint produces those guarantees and nothing else. It has zero AI calls, zero user-facing UI, and zero dependencies on later sprints. The seams are explicit so Sprint 2's gateway can wire them together without reaching inside any component.

## Scope

**In scope**
- Plugin scaffolding for `local_ai_analysis` (version, lang, minimal settings stub, empty `lib.php`)
- Vendored `greenlion/php-sql-parser` library under `local/ai_analysis/vendor/`
- Schema manifest builder (core 4 tables only)
- SQL validator (AST-based) with full PHPUnit test matrix
- Audit writer + `local_ai_analysis_audit` table (SHA-256 hash always, AES-256-CBC encrypted prompt when key is set)
- Capability definitions (including forward-declared capabilities used in later sprints)
- Read-only DB user GRANT script + `INSTALL.md` instructions

**Out of scope**
- AI clients, prompt builder, AJAX gateway, query executor, rate limiter, PII scrubber
- Frontend widget, settings page UI beyond a minimal stub
- Presets, audit viewer UI, decrypt UI
- Privacy API, scheduled retention task

## Directory structure

```
local/ai_analysis/
├── version.php                          # component=local_ai_analysis, version, requires Moodle 4.5
├── lib.php                              # empty stub (page_init hook lands in Sprint 4)
├── settings.php                         # minimal stub — admin category placeholder
├── lang/en/local_ai_analysis.php        # strings for capabilities, audit statuses, exceptions
├── db/
│   ├── access.php                       # capability definitions
│   ├── install.xml                      # local_ai_analysis_audit table
│   ├── upgrade.php                      # empty
│   └── readonly_grants.sql              # one-time SQL for sysadmin
├── classes/
│   ├── manifest/
│   │   └── manifest_builder.php
│   ├── security/
│   │   └── sql_validator.php
│   ├── audit/
│   │   └── audit_writer.php
│   └── exception/
│       └── validation_exception.php
├── vendor/
│   └── greenlion/php-sql-parser/        # vendored, committed to repo
├── tests/
│   ├── sql_validator_test.php
│   ├── manifest_builder_test.php
│   └── audit_writer_test.php
├── INSTALL.md                           # readonly DB user setup steps
└── README.md                            # one-pager — purpose + Sprint 1 status
```

## Component boundaries

Each unit has one purpose, no shared state, and a contract narrow enough to hold in mind:

- **`manifest_builder`** is pure. Signature: `(string $role, int $courseid) → array`. No DB access. No globals. The returned array is the single source of truth: it is later fed to the AI prompt builder (Sprint 2) and to the SQL validator (this sprint). Because both consumers receive the same array, allowlists cannot drift.
- **`sql_validator`** takes a manifest array + SQL string (by reference) + params array. Returns `bool` on success (mutating SQL only to enforce `LIMIT`) or throws `validation_exception` on failure. No DB access. Depends only on the vendored parser and the exception class.
- **`audit_writer`** exposes one static `write()` method. Takes scalar args + `$DB`. Catches its own exceptions, routes failures to `debugging()`, returns `void`. It never throws — so callers can `audit_writer::write(...)` in error paths without nested try/catch.
- **`validation_exception`** carries a machine-readable `reason` code (e.g. `TABLE_NOT_ALLOWED:mdl_config`) and a truncated SQL excerpt. Sprint 2's gateway maps the reason code to the audit `status` / `block_reason` fields.

These boundaries are the reason this slice is testable end-to-end with PHPUnit alone — no Moodle bootstrap needed for manifest or validator, no AI key needed for audit.

## SQL validator design

The validator is the most security-critical component in the entire plugin. It runs after the AI has returned a SQL string but before any DB execution. It must hold against AI mistakes, prompt-injection-induced malicious SQL, and edge cases (comment tricks, stacked statements, UNION attacks, subqueries).

Constructor: `__construct(array $manifest)`.
Method: `validate(string &$sql, array $params): bool` — mutates `$sql` only to inject or lower the `LIMIT`; throws `validation_exception($reason_code, $sql_excerpt)` on any rejection.

Validation order (each step short-circuits via throw):

1. **PARSE** — `new PHPSQLParser($sql, true)` → AST. Any exception → `PARSE_FAILED`.
2. **STATEMENT TYPE** — top-level AST must contain `SELECT` and none of `INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, REPLACE, CALL, EXEC` → `FORBIDDEN_OP:<op>` or `NOT_SELECT`.
3. **NO WILDCARD** — walk the `SELECT` clause; any `base_expr === '*'` → `WILDCARD_SELECT_FORBIDDEN`.
4. **TABLE ALLOWLIST** — recursively collect every `table` node in FROM/JOIN (including nested via UNION). Each must be a key in the manifest → `TABLE_NOT_ALLOWED:<name>`.
5. **COLUMN ALLOWLIST** — recursively collect every `colref` node. Each `column` must be in `manifest[table]`. Aliases resolved via FROM/JOIN aliases. Unqualified columns are rejected unless exactly one table is in scope → `COLUMN_NOT_ALLOWED:<col>` / `AMBIGUOUS_COLUMN:<col>`.
6. **NO SUBQUERY** — recursive walk; any `expr_type == 'subquery'` anywhere in the AST → `SUBQUERY_FORBIDDEN`.
7. **LIMIT ENFORCEMENT** — if no `LIMIT` clause: append `LIMIT 1000`. If present and `> 1000`: rewrite to 1000. String surgery uses AST positions, never regex on raw SQL.
8. **PARAM TYPES** — every `$params` element must be `is_scalar()` or `null` → `INVALID_PARAM_TYPE`.

### Test matrix (`tests/sql_validator_test.php`)

Implemented as a single `@dataProvider` so adding a row is one line. TDD: every row exists as a pending assertion before the validator is implemented; rows are unblocked one by one as the validator grows.

| # | Input | Expected |
|---|---|---|
| 1 | `SELECT id, firstname FROM mdl_user WHERE id = ? LIMIT 50` | pass, sql unchanged |
| 2 | `SELECT * FROM mdl_user` | reject `WILDCARD_SELECT_FORBIDDEN` |
| 3 | `SELECT 1; DROP TABLE mdl_user` | reject (`PARSE_FAILED` or `FORBIDDEN_OP:DROP`) |
| 4 | `SELECT/**/password FROM mdl_user` | reject `COLUMN_NOT_ALLOWED:password` |
| 5 | `SELECT id FROM mdl_config` | reject `TABLE_NOT_ALLOWED:mdl_config` |
| 6 | `SELECT id FROM mdl_user UNION SELECT id FROM mdl_config` | reject `TABLE_NOT_ALLOWED:mdl_config` |
| 7 | `SELECT id FROM mdl_user WHERE id IN (SELECT userid FROM mdl_grade_grades)` | reject `SUBQUERY_FORBIDDEN` |
| 8 | `SELECT id, firstname FROM mdl_user WHERE id = ?` (no LIMIT) | pass, `LIMIT 1000` appended |
| 9 | `SELECT id FROM mdl_user LIMIT 5000` | pass, `LIMIT` rewritten to 1000 |
| 10 | params = `[['array']]` | reject `INVALID_PARAM_TYPE` |
| 11 | `SELECT u.id, u.firstname FROM mdl_user u WHERE u.id = ?` | pass (alias resolution) |
| 12 | `UPDATE mdl_user SET firstname='x'` | reject `NOT_SELECT` or `FORBIDDEN_OP:UPDATE` |
| 13 | `SELECT password FROM mdl_user` | reject `COLUMN_NOT_ALLOWED:password` |
| 14 | `SELECT u.id, gg.finalgrade FROM mdl_user u JOIN mdl_grade_grades gg ON u.id = gg.userid` | pass |

## Schema manifest

Hardcoded PHP array in `manifest_builder.php`. Never derived from `information_schema` — drift between live DB and manifest must be impossible.

```php
private static array $FULL_MANIFEST = [
    'mdl_user'                  => ['id', 'firstname', 'lastname', 'city', 'department', 'timecreated'],
    'mdl_grade_grades'          => ['userid', 'itemid', 'finalgrade', 'timemodified'],
    'mdl_course_modules'        => ['id', 'course', 'module', 'completion'],
    'mdl_logstore_standard_log' => ['userid', 'courseid', 'eventname', 'timecreated'],
];
```

Excluded by design (Sprint 1):
- `mdl_attendance_log` — third-party plugin, not guaranteed present.
- `mdl_quiz_attempts` — add when quiz-related queries are scoped in.
- Any table containing credentials (`mdl_config`, `mdl_user_password_resets`, `mdl_sessions`) — never allowlisted at any sprint.

Build behaviour:
- `build('admin', $courseid)` returns the full manifest unmodified.
- `build($other_role, $courseid)` with `$courseid > 0` attaches `_scope_note` strings to scope `mdl_user` and `mdl_logstore_standard_log` to that course. The note is consumed by the AI prompt; the validator ignores `_scope_note` keys.
- The forbidden global columns (`password, secret, sesskey, token, apikey, hash, salt, privatekey`) are asserted-absent in `manifest_builder_test.php` across every role/course variant.

## Audit table

Defined in `db/install.xml` as `local_ai_analysis_audit`:

| Field | XMLDB type | Notes |
|---|---|---|
| `id` | int(10) sequence | PK |
| `userid` | int(10) | indexed |
| `courseid` | int(10) | indexed; 0 = system context |
| `timecreated` | int(10) | indexed |
| `prompt_hash` | char(64) | SHA-256 of raw prompt, always set |
| `prompt_length` | int(5) | char count |
| `prompt_encrypted` | text (long) | nullable; format `base64(iv)::base64(ciphertext)` when `$CFG->ai_analysis_audit_key` is set |
| `sql_executed` | text | nullable; first 2000 chars of validated SQL |
| `row_count` | int(10) | nullable; populated from Sprint 2+ |
| `status` | char(40) | indexed; one of: SUCCESS, BLOCKED_INJECTION, RATE_LIMITED, SQL_INVALID, PARSE_FAILED, AI_INVALID_JSON, OUT_OF_SCOPE |
| `block_reason` | char(120) | nullable; e.g. `TABLE_NOT_ALLOWED:mdl_config` |
| `provider` | char(20) | nullable |
| `duration_ms` | int(10) | nullable |
| `useragent` | char(255) | nullable |

### `audit_writer::write()` contract

- Always computes and stores `prompt_hash` and `prompt_length`.
- Encrypts the prompt with `openssl_encrypt($prompt, 'AES-256-CBC', $CFG->ai_analysis_audit_key, 0, $iv)` only when `!empty($CFG->ai_analysis_audit_key)`; stores `base64(iv) . '::' . base64(ciphertext)`.
- Truncates `sql_executed` to 2000 characters and `useragent` to 255.
- Wraps the entire insert in `try / catch`. Failures route to `debugging('local_ai_analysis audit write failed: ' . $e->getMessage(), DEBUG_DEVELOPER)`. Never surfaces an exception to the caller.

## Capabilities (`db/access.php`)

```php
return [
    'local/ai_analysis:query' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes'   => [
            'editingteacher' => CAP_ALLOW,
            'teacher'        => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
            'student'        => CAP_PROHIBIT,
            'guest'          => CAP_PROHIBIT,
        ],
    ],
    'local/ai_analysis:queryglobal' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => ['manager' => CAP_ALLOW],
    ],
    'local/ai_analysis:viewaudit' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [], // admin-only by default
    ],
    'local/ai_analysis:decryptprompt' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [], // admin-only, requires re-auth in Sprint 5
    ],
    'local/ai_analysis:managepresets' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes'   => [
            'editingteacher' => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
        ],
    ],
];
```

`managepresets` and `decryptprompt` are declared now even though their UI ships in Sprint 5, so role admins don't see the capability list shift across sprints.

## Read-only DB user (`db/readonly_grants.sql`)

Script the sysadmin runs once against MariaDB. Idempotent via `IF NOT EXISTS`.

```sql
CREATE USER IF NOT EXISTS 'moodle_ai_ro'@'%' IDENTIFIED BY '<replace-me>';
GRANT SELECT ON moodle.mdl_user                  TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_grade_grades          TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_course_modules        TO 'moodle_ai_ro'@'%';
GRANT SELECT ON moodle.mdl_logstore_standard_log TO 'moodle_ai_ro'@'%';
-- Explicitly NO grants on mdl_config, mdl_user_password_resets, mdl_sessions.
FLUSH PRIVILEGES;
```

`INSTALL.md` documents:
- Running the script inside the `moodle-db-8092` container.
- Generating a strong password (suggested: `openssl rand -base64 32`).
- Generating a 32-byte AES key for audit encryption (`openssl rand -hex 32`).
- Adding to `config.php`:
  ```php
  $CFG->ai_analysis_dbuser    = 'moodle_ai_ro';
  $CFG->ai_analysis_dbpass    = '...';
  $CFG->ai_analysis_audit_key = '...';
  ```

No PHP code in Sprint 1 reads `ai_analysis_dbuser` or `ai_analysis_dbpass`. They are consumed by Sprint 2's `query_executor`. `ai_analysis_audit_key` is read by `audit_writer` if set; absence is a supported state (Sprint 1 still works without encryption).

## Testing strategy

- **PHPUnit setup**: Moodle's standard `tests/` layout. Run from Moodle root after `php admin/tool/phpunit/cli/init.php`:
  ```
  vendor/bin/phpunit --filter local_ai_analysis
  ```
- **`sql_validator_test.php`**: 14-row matrix as a `@dataProvider`. Each row asserts either `(return value === true, mutated SQL matches expected)` or `(exception class === validation_exception, reason code matches)`.
- **`manifest_builder_test.php`**:
  - `build('admin', 42)` returns 4 tables, no `_scope_note`.
  - `build('editingteacher', 42)` returns 4 tables with `_scope_note` on `mdl_user` and `mdl_logstore_standard_log`.
  - For every role × courseid combo, none of the forbidden global column names appear in any returned column list.
- **`audit_writer_test.php`**:
  - Without `$CFG->ai_analysis_audit_key`: record inserted, `prompt_encrypted === null`, hash correct.
  - With key set: `prompt_encrypted` is non-null and round-trips back to the original plaintext via `openssl_decrypt`.
  - When `$DB->insert_record` throws (mocked): `write()` returns `void` and emits a `debugging()` message.

## Done criteria

1. Plugin installs cleanly on the 8092 instance and is visible under *Site administration → Plugins → Local plugins*.
2. All five capabilities appear in the role definition UI.
3. `local_ai_analysis_audit` table exists in MariaDB with the columns and indexes above.
4. All PHPUnit tests pass: 14 validator rows + manifest builder cases + audit writer cases.
5. `INSTALL.md` walks a fresh admin through readonly user setup; `readonly_grants.sql` is idempotent and re-runnable without error.
6. Vendored `greenlion/php-sql-parser` library is committed; installers do not need `composer install`.

## Risks and open questions

- **AST parser quality.** `greenlion/php-sql-parser` is mature but not bulletproof; the validator's defence-in-depth posture (read-only DB user as final backstop) is what makes that acceptable. If a specific evasion is later discovered, the fix is a new rule + a new test row, not a rewrite.
- **Column alias resolution.** Step 5 of validation needs careful walking of FROM/JOIN aliases. Test row 11 and 14 must both pass; if the implementation finds the AST's alias info awkward, fall back to rejecting unqualified columns when more than one table is in scope (test row would shift to require aliases).
- **`prompt_encrypted` column type.** `text (long)` in XMLDB maps to `LONGTEXT` on MariaDB. Encrypted prompts are short (< 2 KB), so `text` would suffice, but `text (long)` future-proofs against larger inputs in later sprints.
