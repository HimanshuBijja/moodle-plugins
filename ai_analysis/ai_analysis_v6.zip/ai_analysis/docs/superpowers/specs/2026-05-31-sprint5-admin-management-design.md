# Sprint 5 — Admin / Management & Compliance — Design

**Date:** 2026-05-31
**Plugin:** `local_ai_analysis` (Moodle 4.5, PHP 8.1+, MariaDB 10.11)
**Target version:** `0.5.0` (`$plugin->version = 2026053100+`)

## Goal

Add the admin/compliance layer on top of the working NL→SQL pipeline: a browsable
audit log, the ability to decrypt a stored prompt (with its own audit trail), GDPR
Privacy API support, a retention/cleanup scheduled task, and settings polish. Plus a
small tech-debt fix so transient provider HTTP errors map to the correct status.

## Background / current state

- Sprints 1–4 done and deployed. Pipeline (auth → sanitise → rate-limit → manifest →
  AI → validate → read-only execute → audit) works end-to-end.
- Audit rows are already written on every path by `audit_writer::write()` into
  `local_ai_analysis_audit`. Prompts are stored as SHA-256 hash + AES-256-CBC
  ciphertext (`$CFG->ai_analysis_audit_key`).
- Capabilities `local/ai_analysis:viewaudit` and `local/ai_analysis:decryptprompt`
  already exist (CONTEXT_SYSTEM, no archetypes — admin-assign only). **No new caps needed.**
- No scheduled task, no `db/tasks.php`, no `classes/privacy/provider.php` yet.
- Gateway (`classes/external/query.php`) already maps `transport_exception` →
  `AI_TRANSPORT_ERROR`. The 429 bug is upstream in the client layer.

### Audit table fields (`local_ai_analysis_audit`)

`id, userid, courseid, timecreated, prompt_hash, prompt_length, prompt_encrypted,
sql_executed, row_count, status, block_reason, provider, duration_ms, useragent`.
Indexes on `userid`, `courseid`, `timecreated`, `status`.

## Decisions (locked)

| Topic | Decision |
|-------|----------|
| Audit viewer | Moodle `table_sql` report under Site admin → Reports |
| Decrypt reveal | `decryptprompt` cap + sesskey; **every reveal writes its own audit row** (`status=PROMPT_REVEALED`); no password re-entry |
| Retention | Configurable `retentiondays` setting (default **365**); daily task **deletes** rows older than that; **0 = keep forever** (no-op) |
| GDPR erasure | **Delete** the user's audit rows (export then delete) |
| Settings polish | Add `retentiondays` field; group settings under headings; add "View audit log" link |
| Model hint text | Out of scope this sprint |
| 429/5xx | Client layer throws `transport_exception` for HTTP 429 + 5xx → `AI_TRANSPORT_ERROR` |

## Components

### 1. Audit viewer

**Files:**
- Create `classes/report/audit_table.php` — extends `\table_sql`.
- Create `audit.php` — admin page (top-level script), `require_login`,
  `require_capability('local/ai_analysis:viewaudit', context_system::instance())`,
  `admin_externalpage_setup('localaianalysisaudit')`.
- Modify `settings.php` — register the external admin page under the `reports` category:
  `$ADMIN->add('reports', new admin_externalpage('localaianalysisaudit', get_string('audit_report', ...), "$CFG->wwwroot/local/ai_analysis/audit.php", 'local/ai_analysis:viewaudit'));`

**`audit_table` columns** (in order): `timecreated` (formatted `userdate`),
`userid` (linked fullname via cached user lookup), `courseid` (course shortname or `-`
for site/0), `status`, `provider`, `prompt_length`, `row_count`, `duration_ms`,
`sql_executed` (truncated to ~120 chars with `shorten_text`), and an `actions` column
holding a **Reveal prompt** button **only when** the viewer has `decryptprompt` **and**
the row has a non-null `prompt_encrypted`.

`table_sql` config: sortable on time/status/provider/userid/courseid; default sort
`timecreated DESC`; pagination (50/page); `is_downloadable(true)` for CSV/Excel
(the `actions` column is excluded from download via `$this->is_downloading()` guard).

**Filter form** (`audit.php`, simple `moodleform` or inline params): `userid`
(autocomplete or raw id), `courseid`, `status` (dropdown of the known status codes +
`PROMPT_REVEALED`), `datefrom`, `dateto`. Filters become the `table_sql` WHERE clause +
params. Empty filters = no constraint.

### 2. Decrypt-prompt AJAX function

**Files:**
- Create `classes/external/decrypt_prompt.php` — `external_function` with
  `execute_parameters()` taking `id` (PARAM_INT, the audit row id), `execute()`,
  `execute_returns()` returning `{ status, prompt }`.
- Modify `db/services.php` — register `local_ai_analysis_decrypt_prompt`
  (`ajax => true`, `capabilities => 'local/ai_analysis:decryptprompt'`).
- Modify `lang/en/local_ai_analysis.php` — strings for the report, reveal button,
  status `PROMPT_REVEALED`, etc.

**`execute(int $id)` flow:**
1. `require_capability('local/ai_analysis:decryptprompt', context_system::instance())`
   (sesskey enforced by the AJAX layer).
2. Load the audit row; if missing or `prompt_encrypted` null → return
   `{status: 'NOT_FOUND', prompt: ''}`.
3. Decrypt `prompt_encrypted` with the existing crypto helper / `$CFG->ai_analysis_audit_key`.
4. **Write a self-audit row** via `audit_writer`: `userid = current admin`,
   `status = 'PROMPT_REVEALED'`, `block_reason = 'revealed audit id ' . $id`,
   `prompt_encrypted = null`, `prompt_hash = ''`, `courseid = 0`. (Records who revealed
   whose prompt, when.)
5. Return `{status: 'SUCCESS', prompt: <plaintext>}`.

Decryption reuses the same routine `audit_writer` uses to encrypt (factor a shared
`crypto`/`audit_crypto` helper if encryption is currently inline in `audit_writer`, so
encrypt and decrypt share one implementation — no duplicated cipher/IV logic).

**Frontend:** the Reveal button in `audit_table` is a small `<button data-audit-id>`;
a tiny AMD module `amd/src/audit_reveal.js` (+ hand-authored `build/.min.js` + `.map`,
per the established dev-mode requirement) calls `core/ajax` and swaps the cell content
with the returned plaintext (escaped). Reuse the Sprint-4 AMD build/map convention.

### 3. Privacy API

**Files:**
- Create `classes/privacy/provider.php`.

Implements:
- `\core_privacy\local\metadata\provider` — `get_metadata()` declares the audit table
  and each stored field (userid, courseid, timecreated, prompt_hash, prompt_length,
  prompt_encrypted, sql_executed, row_count, status, provider, duration_ms, useragent)
  with lang-string descriptions. Note that the prompt is stored encrypted.
- `\core_privacy\local\request\plugin\provider`:
  - `get_contexts_for_userid($userid)` → system context if the user has any audit rows.
  - `export_user_data(approved_contextlist)` → writes the user's audit rows to the
    export (decrypted prompt **not** included by default — export the metadata + hash;
    include plaintext only if trivially available, otherwise omit and note it).
  - `delete_data_for_user(approved_contextlist)` → `DELETE` the user's rows.
  - `delete_data_for_all_users_in_context(context)` → delete all rows (system context).
- `\core_privacy\local\request\core_userlist_provider`:
  - `get_users_in_context(userlist)` and `delete_data_for_users(approved_userlist)`.

### 4. Retention scheduled task

**Files:**
- Create `classes/task/purge_audit_task.php` — extends `\core\task\scheduled_task`.
- Create `db/tasks.php` — schedule `purge_audit_task` daily (e.g. hour `3`, minute `0`).
- Modify `settings.php` / `lang` — `retentiondays` setting (admin_setting_configtext,
  PARAM_INT, default `365`).

**`execute()`:** read `get_config('local_ai_analysis', 'retentiondays')`; if `<= 0`
return (no-op, `mtrace` "retention disabled"); else compute
`$cutoff = time() - ($days * DAYSECS)` and
`$DB->delete_records_select('local_ai_analysis_audit', 'timecreated < ?', [$cutoff])`;
`mtrace` the deleted count.

### 5. Settings polish

**Modify** `settings.php`:
- Wrap existing settings in `admin_setting_heading` sections: **Provider**, **API keys**,
  **Limits**, **Audit & retention**.
- Add `retentiondays` under "Audit & retention".
- Add a static `admin_setting_description` (or heading with link) pointing to
  `audit.php` — "View audit log".

### 6. 429 / 5xx transport mapping (tech-debt)

**Modify** `classes/ai/base_http_ai_client.php:52-53`:

```php
if ($response['status'] < 200 || $response['status'] >= 300) {
    $code = (int) $response['status'];
    if ($code === 429 || $code >= 500) {
        throw new transport_exception('HTTP_' . $code . ': ' . $response['body']);
    }
    throw new ai_client_exception('HTTP_' . $code, $response['body']);
}
```

Add `use local_ai_analysis\exception\transport_exception;`. Gateway already maps
`transport_exception` → `AI_TRANSPORT_ERROR`, so a provider 429 now surfaces as a
transport error (retry-able) instead of `AI_INVALID_JSON`.

## Data flow

- **View audit:** admin → `audit.php` → cap check → `audit_table` builds SQL from
  filters → renders paginated table. CSV download via `table_sql` built-in.
- **Reveal:** Reveal button → `audit_reveal.js` → `core/ajax` →
  `local_ai_analysis_decrypt_prompt(id)` → cap+sesskey → decrypt → self-audit write →
  plaintext back → cell updated.
- **Retention:** cron → `purge_audit_task::execute()` → delete rows older than cutoff.
- **GDPR:** Moodle privacy subsystem → `provider` export/delete.

## Error handling

- Decrypt fn never throws to the AJAX layer for expected cases: missing row /
  null ciphertext → `{status:'NOT_FOUND'}`. Capability failure is handled by the
  external API framework (403). Decryption failure (bad key/corrupt) → `{status:'DECRYPT_FAILED'}`.
- Retention task: guarded by `retentiondays > 0`; `mtrace` count; let unexpected DB
  errors bubble (cron records the failure) — no silent swallow.

## Testing (PHPUnit, file-path form, Docker)

- `tests/purge_audit_task_test.php` — seed rows at varied `timecreated`; assert rows
  older than `retentiondays` deleted, newer kept; `retentiondays=0` → nothing deleted.
- `tests/privacy_provider_test.php` — `get_metadata` non-empty; `export_user_data`
  exports the right user's rows only; `delete_data_for_user` removes them; userlist
  provider returns/deletes correctly.
- `tests/decrypt_prompt_test.php` — without cap → exception; with cap → correct
  plaintext returned AND a `PROMPT_REVEALED` audit row written; null ciphertext →
  `NOT_FOUND`.
- `tests/audit_table_test.php` — filter→WHERE/params mapping produces expected SQL
  constraints (test the query-building seam, not full HTML render).
- `tests/base_http_ai_client_test.php` (extend existing if present) — HTTP 429 → 
  `transport_exception`; HTTP 503 → `transport_exception`; HTTP 400 → `ai_client_exception`.

All 120 existing tests must still pass. Run
`admin/tool/phpunit/cli/init.php` after schema/task/services changes.

## Out of scope

- Per-course teacher audit view (cap is system-level by design).
- Model-name validation / hint text.
- Sprint 3c Ollama provider (separate, deferred).
- Anonymise-instead-of-delete (chosen: delete).

## Files summary

**Create:** `classes/report/audit_table.php`, `audit.php`,
`classes/external/decrypt_prompt.php`, `classes/privacy/provider.php`,
`classes/task/purge_audit_task.php`, `db/tasks.php`, `amd/src/audit_reveal.js`
(+ `amd/build/audit_reveal.min.js` + `.map`), plus the test files above.

**Modify:** `settings.php`, `db/services.php`, `lang/en/local_ai_analysis.php`,
`classes/ai/base_http_ai_client.php`, `version.php`, and (if cipher is inline) a shared
crypto helper used by both `audit_writer` and `decrypt_prompt`.

## Post-implementation (per project rules)

Update `docs/ai-memory/02-features-log.md`, `04-current-state.md`,
`03-decisions.md`. Note new task, new privacy provider, new report page, new setting,
and the 429 mapping change.
