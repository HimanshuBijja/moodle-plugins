# Sub-project B1 — Student Engagement & Risk View

**Date:** 2026-06-12
**Status:** Design approved, pre-implementation
**Component:** `local_ai_analysis`

## Context

Sub-project **B** of the roadmap (analytics) decomposes by data domain:
- **B1 — Student engagement & risk** (this spec) — submissions + activity + grades.
- B2 — Course performance (grade distribution, completion rates).
- B3 — Feedback analytics (mod_feedback).
- Deferred: attendance (no `mod_attendance` data on this instance), lecturer
  performance/comparison (metric undefined; staff identity now exists via sub-project C).

B1 is the first slice. Each B-slice is its own spec → plan → build cycle.

This is an **experimental instance with dummy data** — free to add/seed/delete; more
plugins may arrive later, so the design stays extensible (new signals = new view columns).

### Data reality (this instance)

- `logstore_standard_log`: ~6.5M rows — richest signal (activity recency + volume).
- `assign_submission`: ~1,850 submitted — rich (missing-submission signal).
- `grade_grades`: 125 graded across 5 courses — **sparse**; a supplementary signal only.

### Problem

Ranking/aggregation analytics ("students at risk", "least engaged") need GROUP BY +
ranking that the `sql_validator` forbids at the user-SQL level (no subqueries). And "risk"
needs a consistent, explainable definition. Both are solved by a **pre-computed view** that
does the aggregation internally and exposes flat, rankable columns — the same pattern
sub-project C proved.

### Goal

A read-only view `mdl_ai_student_engagement` exposing per-(course, student) engagement
metrics plus a transparent `risk_band`, added to the manifest, with one `at_risk_students`
fast-path template extending the sub-project-A intent framework.

## Non-goals (v1)

- Materialized/metric table + refresh task — v1 is a live view (see Performance). Documented
  scale path, not built now.
- Course-level rollups (B2), feedback (B3), attendance (no data), lecturer performance.
- Trend-over-time analytics ("completion trends") — point-in-time snapshot only in v1.
- Tunable thresholds via settings UI — thresholds are documented constants in the view DDL;
  tuning = editing the view definition (v1).

## Architecture

### 1. The view `mdl_ai_student_engagement`

**Grain:** one row per (course, student), where *student* = actively enrolled user
(`user_enrolments.status = 0` ⋈ `enrol.status = 0`) who is **NOT** course staff (excluded via
`NOT EXISTS` against `mdl_ai_course_staff`, the sub-project-C view). This yields a true student
population (no teachers), reusing C.

**Hard rule — `courseid = 0` is never included.** The view MUST carry an explicit
`WHERE e.courseid > 0` (or `<> 0`). `courseid = 0` is the system context (logins, admin events —
~6.46M of the 6.5M log rows), not a real course; at-risk analytics over it is meaningless. This
exclusion is unconditional: even a site-wide query ("at-risk students across the whole site",
admin / courseid=0 context) must never surface a `courseid = 0` row. The filter lives in the view
definition itself so no caller (template or AI-generated SQL) can re-introduce it.

**Columns:**
| Column | Source | Meaning |
|---|---|---|
| `courseid` | enrol.courseid | course |
| `userid` | user.id | student |
| `firstname`, `lastname` | user | identity (PII; no username/email) |
| `last_activity_days` | `DATEDIFF(NOW(), FROM_UNIXTIME(MAX(log.timecreated)))` | days since last activity; NULL = never |
| `activity_count` | `COUNT(log)` per course/user | engagement volume |
| `missing_submissions` | `COUNT(assign in course)` − `COUNT(submitted by user)` | unsubmitted assignments |
| `avg_grade` | `AVG(grade_grades.finalgrade)` where `grade_items.itemtype='course'` | course avg; NULL when ungraded |
| `risk_band` | derived (see below) | `high`/`medium`/`low` |

**risk_band rule (transparent, tunable defaults).** Count "bad" signals:
- `last_activity_days > 14` OR last activity is NULL (never active)
- `missing_submissions > 0`
- `avg_grade IS NOT NULL AND avg_grade < 40`
- `activity_count < 5`

Then: **`>= 3` bad → `high`; `1–2` → `medium`; `0` → `low`.**

**Internal shape.** The view is an outer SELECT over a derived table: the inner query computes
the four metrics (via LEFT JOINs to per-student subaggregates of logstore / assign+submission /
grade) and a `badcount` sum; the outer maps `badcount` → `risk_band`. All complexity is internal
to the view definition — the AI and `sql_validator` only ever see the flat columns. The view
references `mdl_ai_course_staff`, so sub-project C must be installed (it is, merged).

**Privacy.** Only `firstname`/`lastname` identity exposed (no username/email/idnumber), matching
C. RO user granted SELECT on the view only.

### 2. View ownership + the PHPUnit constraint (reuse C's pattern)

`classes/db/student_engagement_view.php` holds the DDL (`definition_sql($prefix)` + `create($db)`
via `$DB->execute()`, since `change_database_structure` rejects `CREATE OR REPLACE VIEW`).
`db/install.php` creates it on real installs but **skips under PHPUNIT** (a non-updatable
aggregate view breaks Moodle's `reset_database()` `DELETE FROM`); `db/upgrade.php` adds a
version-guarded create for existing installs. Tests create/drop the view per-class in
`setUp`/`tearDown` (drop before `parent::tearDown()`), exactly as `course_staff_view_test` does.
`db/readonly_grants.sql` adds the SELECT grant.

### 3. Performance: live view now, metric table later

The view aggregates ~6.5M log rows live per query. Acceptable for v1 on an experimental
instance. **Documented scale path (not built in v1):** a metric *table* populated by a scheduled
task (`db/tasks.php`), refreshed periodically — the roadmap's "metric tables". Recorded in
`03-decisions.md` and `04-current-state.md` as the next optimisation when data grows or queries
slow.

### 4. Manifest + fast-path template + classifier

- Manifest gains `mdl_ai_student_engagement => [courseid, userid, firstname, lastname,
  last_activity_days, activity_count, missing_submissions, avg_grade, risk_band]` with a course
  scope-note (non-admin + courseid>0 → filter WHERE courseid). Unlocks all engagement/risk
  queries via the AI path.
- `sql_template` gains an `at_risk_students` case:
  `SELECT userid, firstname, lastname, last_activity_days, missing_submissions, avg_grade, risk_band
   FROM mdl_ai_student_engagement WHERE courseid = ? AND risk_band = 'high'
   ORDER BY last_activity_days DESC LIMIT 1000` (param `[$courseid]`). Validator-clean.
- `synonym_dictionary` gains `risk → risk`, `struggling → risk`, `disengaged → risk`. New
  registry entry `at_risk_students`: `requires=['risk']`, `any_of=['students','list','enrolled']`,
  `none_of=['staff']`. Composes cleanly: `risk` is already a disqualifier for `student_listing`
  and `course_staff`, so "students at risk" stops falling through to the AI and gets the
  dedicated template. Mutually exclusive with the other intents (different required token).

### 5. PII

`pii_scrubber` `PII_MAP` gains `mdl_ai_student_engagement.firstname` / `.lastname` → `PERSON`.
The metric columns (`risk_band`, counts, days, avg_grade, ids) are not PII.

## Error handling

No new status codes. Engagement queries end `SUCCESS`/`QUERY_FAILED` like any other. If the view
is missing (RO grant not yet applied in production), queries fail `QUERY_FAILED` (audited, never
fatal). Classifier remains never-throwing.

## Testing

**View / metric correctness** (`tests/student_engagement_view_test.php`, per-class view
create/drop):
- Seed a course; enrol 2+ students (direct `$DB` enrolment inserts, hermetic) and a teacher.
- Seed logstore events (recent vs >14d old), assign + submissions (one student missing one),
  grades for one student. Assert each metric column computes correctly.
- Assert `risk_band` matches the rule (construct a clearly-high student: no recent activity +
  missing submission + low activity → high; a clean student → low).
- Assert **staff are excluded** (the enrolled teacher does not appear).
- Assert **no `courseid = 0` row ever appears** (even after seeding course-0 logs / a course-0
  context) — `SELECT COUNT(*) ... WHERE courseid = 0` on the view is 0.
- Assert only `firstname/lastname` identity columns exist (no `username`/`email`).

**Template / classifier** (extend A's test files):
- `at_risk_students` template builds expected SQL + bound courseid and **passes `sql_validator`**.
- Classifier: "students at risk", "at risk students", "who is at risk", "struggling students"
  → `at_risk_students`; plain "list students" still → `student_listing`; "who teaches" still →
  `course_staff`.

**Gateway e2e** (extend `external_query_test`, with view create/drop in setUp/tearDown):
- "students at risk" → SUCCESS, AI stub `call_count === 0`, audit `provider='template'`.

**Full suite** green after each task.

## Files (anticipated)

- New: `classes/db/student_engagement_view.php`, `tests/student_engagement_view_test.php`.
- Modify: `db/install.php` (+ create engagement view, PHPUNIT-skip), `db/upgrade.php` (+ step),
  `db/readonly_grants.sql` (+ grant), `classes/manifest/manifest_builder.php` (+ view + scope-note),
  `classes/intent/synonym_dictionary.php` (+ risk family), `classes/intent/intent_registry.php`
  (+ at_risk_students), `classes/intent/sql_template.php` (+ case),
  `classes/security/pii_scrubber.php` (+ view names), `version.php` (bump → 2026061202 / 0.10.0),
  `tests/intent_classifier_test.php` + `tests/sql_template_test.php` + `tests/external_query_test.php`
  + `tests/manifest_builder_test.php` + `tests/pii_scrubber_test.php` (extend), `INSTALL.md`,
  `docs/ai-memory/02,03,04`.

## Decisions captured

- **Four signals** (activity recency, activity volume, missing submissions, avg grade) exposed as
  raw metrics; grades supplementary (sparse data).
- **Transparent rule-based `risk_band`** (count of bad signals → high/medium/low) over a black-box
  score; thresholds are documented, tunable constants.
- **Student population = enrolled minus staff** (reuses C's view) — cleaner than A's
  enrolment-only definition.
- **`courseid = 0` unconditionally excluded** in the view (`WHERE courseid > 0`) — never appears,
  even in a site-wide/admin query.
- **Live view in v1**; metric table + scheduled refresh is the documented scale path.
- Same view-ownership + PHPUnit-skip + per-test create/drop pattern as sub-project C.
- View created via `$DB->execute()` (not `change_database_structure`).
