# Sprint 6 — Conversational context, smart visualisation, entity linking, table expansion

**Date:** 2026-06-10
**Status:** Approved (design)
**Component:** `local_ai_analysis`

## Summary

Four cohesive improvements to the NL→SQL chatbot, built in order 1→2→4→3:

1. **Multi-turn conversational context** — follow-up questions ("now filter that to last month").
2. **AI-driven chart spec** — the model proposes a validated chart instead of a frontend heuristic guess.
3. **Course / user link cards** — results that contain a course or user `id` become clickable links to the course / profile.
4. **Manifest table expansion** — add assignment, quiz, and group tables so common questions become answerable.

These share two new response-envelope fields (`chart`, `links`) and both lean on the existing
`sql_validator::get_column_source_map()` (output column → `table.column`) as the single source of truth.

Role/context tables (`mdl_role`, `mdl_role_assignments`, `mdl_context`) remain **intentionally excluded**
(prior decision: avoid exposing site-wide role structure). "Who is the teacher" stays `OUT_OF_SCOPE`.

## Non-goals

- Server-side conversation persistence (history is client-replayed).
- Rich course cards (image, enrolment counts) — basic name+link card only.
- Reversing the role-table exclusion.
- Rebuilding AMD min bundles inline (host node too old; `grunt amd` in a node:22 container is a final step).

---

## §1 Multi-turn conversational context

### Behaviour
The chat widget already holds prior turns in memory (`sessionHistory` + `resultCache`). It replays the last
N successful turns to the server, which forwards them to the AI as conversation context so the model can refine
a previous answer.

### Design
- **External fn** (`classes/external/query.php`):
  - New optional param `history`: `external_multiple_structure` of
    `external_single_structure({prompt: PARAM_TEXT, sql: PARAM_RAW})`, default `[]`.
  - `execute()` gains a trailing `array $history = []`.
  - `private const MAX_HISTORY_TURNS = 5;` — keep only the last 5 entries.
  - Each history `prompt` is re-run through `prompt_builder::sanitise_user_prompt()`. A failing entry is
    **dropped silently** (best-effort context, never fatal). The `sql` field is treated as opaque context text.
  - Cleaned history is passed to `generate_sql()`.
- **AI client layer**:
  - `ai_client_interface::generate_sql(string $system, string $prompt, array $history = [])`.
  - `base_http_ai_client` threads `$history` into `build_sql_payload(string $system, string $prompt, array $history = [])`.
  - Each provider builds the message list as:
    `system` (claude: top-level `system` field; openai/gemini/ollama: existing shape)
    then for each history turn a `user` message (the prompt) + an `assistant` message
    (`{"sql":"<prior sql>","params":[],"explanation":""}`), then the final `user` message (current prompt).
- **Widget** (`amd/src/chat_widget.js`):
  - `submitQuery` builds `history` from the last 5 `SUCCESS` turns
    (`{prompt, sql: resultCache[id].response.sql}`, skipping empty-sql turns) and adds it to the ajax `args`.

### Security
Replayed history is untrusted, but every generated SQL is still validated by `sql_validator` against the
manifest, so forged history cannot widen access. History prompts are sanitised before reaching the model.

### Tests
- `external_query_test`: history forwarded to the stubbed client; capped at 5; malformed entry dropped, not fatal.
- Per-provider client tests: payload contains history `user`/`assistant` messages in order before the final user turn.

---

## §2 AI-driven chart spec

### Behaviour
The model optionally proposes how to chart the result. The server validates the proposal against the actual
output columns; the widget renders the validated spec, or falls back to the current heuristic.

### Design
- **Prompt** (`prompt_builder::build_system`): add a rule asking the model to optionally include
  `"chart": {"type": "bar|line|pie", "x": "<col>", "y": "<col>", "reason": "..."}` in its JSON response,
  or omit it when no chart helps.
- **Response parsing** (`base_http_ai_client::generate_sql` + the JSON shape each provider returns): capture the
  optional `chart` object alongside `sql`/`params`/`explanation`.
- **Validation** (in `query.php`, after SQL validation succeeds): using
  `sql_validator::get_column_source_map()` keys (the output column names):
  - `type` ∈ `{bar, line, pie}` else reject.
  - `x` and `y` must each be an existing output column name, else reject.
  - On reject or absence → `chart` envelope field is empty; widget uses the heuristic.
- **Envelope**: new `chart` field — `external_value(PARAM_RAW)` carrying a JSON-encoded
  `{type,x,y}` (or `''`). Encoded as a string for the same reason rows are (external_api shape limits).
- **Widget**: if `response.chart` present and valid against the parsed rows' keys, build that chart;
  else call existing `maybeBuildChart` heuristic.

### Tests
- `external_query_test`: valid chart spec passes through; bad `type` / unknown column → empty `chart`.
- Provider tests: a `chart` object in the model JSON is parsed and surfaced.

---

## §3 Course / user link cards

### Behaviour
When a result column is sourced from `mdl_course.id` or `mdl_user.id`, the widget renders that value as a link
to the course (`/course/view.php?id=`) or user profile (`/user/profile.php?id=`).

### Design
- **Backend** (`query.php`): walk `sql_validator::get_column_source_map()`; for each output column whose source
  is exactly `mdl_course.id` → mark `course`, `mdl_user.id` → mark `user`. Emit a `links` envelope field:
  `external_value(PARAM_RAW)` = JSON `{ "<colname>": "course"|"user", ... }` (or `'{}'`).
- **Prompt nudge**: add a rule encouraging the model to include the `id` column when listing users or courses,
  so links can be produced (links simply do not appear when no id column is selected).
- **Widget** (`buildTable`): when a column name is in the `links` map, render the cell as an `<a>` to the
  appropriate Moodle URL (use `M.cfg.wwwroot`). Link text stays the raw cell value.

### Security
Target pages enforce Moodle capabilities; a link the user cannot follow yields a Moodle permission error, never
a data leak. Raw rows already contain real ids (the PII scrubber only tokenises the copy sent to the format pass).

### Tests
- `external_query_test`: a query selecting `mdl_user.id` / `mdl_course.id` yields the right `links` map;
  a query without ids yields `'{}'`.

---

## §4 Manifest table expansion

### Tables added to `manifest_builder::$FULL_MANIFEST`
Minimal columns — enough for the common questions, no more:

- `mdl_assign` → `id`, `course`, `name`, `duedate`
- `mdl_assign_submission` → `id`, `assignment`, `userid`, `status`, `timemodified`
- `mdl_quiz` → `id`, `course`, `name`
- `mdl_quiz_grades` → `id`, `quiz`, `userid`, `grade`, `timemodified`
- `mdl_groups` → `id`, `courseid`, `name`
- `mdl_groups_members` → `id`, `groupid`, `userid`

### Scope notes (non-admin, courseid > 0)
- `mdl_assign`, `mdl_quiz`, `mdl_groups` → filter `WHERE course/courseid = <courseid>`.
- `mdl_assign_submission` → join to `mdl_assign` via `assignment` to scope to the course.
- `mdl_quiz_grades` → join to `mdl_quiz` via `quiz` to scope to the course.
- `mdl_groups_members` → join to `mdl_groups` via `groupid` to scope to the course.

### Read-only grants (`db/readonly_grants.sql`)
Add `GRANT SELECT` on the six new tables to `moodle_ai_ro`; apply live on this instance.

### PII map (`pii_scrubber::PII_MAP`)
No new free-text identity columns are added (names here are assignment/quiz/group names, not personal data),
so the existing `mdl_user`-scoped map stays correct. `userid` columns are ids, handled by existing id tokenisation
rules. Confirm in tests that no new PII leak path opens.

### Tests
- `manifest_builder_test`: new tables present; scope notes applied for non-admin + courseid.
- `sql_validator_test`: a join across the new tables validates; an out-of-manifest column still rejected.

---

## Rollout / verification

- All work is TDD, tests run in Docker, file-path form only (never `--filter`).
- Run `init.php` once, then the full plugin testsuite must pass.
- Final step: rebuild AMD (`grunt amd` in a `node:22-slim` container) and purge caches.
- Bump `version.php` once at the end of the sprint.
- Update `docs/ai-memory/02-features-log.md`, `03-decisions.md`, `04-current-state.md`.
- `audit.php` is off-limits (uncommitted user work).

## Affected files

- `classes/external/query.php` (params, history, chart validation, links, envelope)
- `classes/ai/ai_client_interface.php`, `base_http_ai_client.php`, `claude_client.php`,
  `openai_client.php`, `gemini_client.php`, `ollama_client.php` (history, chart parse)
- `classes/ai/prompt_builder.php` (chart + id-inclusion rules)
- `classes/manifest/manifest_builder.php` (new tables + scope notes)
- `classes/security/pii_scrubber.php` (verify only)
- `db/readonly_grants.sql`
- `amd/src/chat_widget.js` (history send, chart spec, link cells) + AMD rebuild
- `tests/*` (external_query, provider clients, manifest_builder, sql_validator, pii_scrubber)
- `version.php`, `docs/ai-memory/*`
