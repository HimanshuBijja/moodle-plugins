# Sub-project D — Wire Conversation History End-to-End

**Date:** 2026-06-15
**Status:** Approved (brainstorming)
**Target version:** 2026061501 / 0.13.0

## Problem

The multi-turn conversation machinery built in Sprint 6 is dead from the user's
perspective. `classes/external/query.php::execute()` accepts a `history`
parameter — an array of `{prompt, sql}` turns (oldest first) — re-sanitises each
prior prompt, caps to the last `MAX_HISTORY_TURNS` (5), and threads them into
`ai_client_factory::make()->generate_sql($system, $prompt, $history)` (plus a
self-correction retry path). But the frontend widget never sends it:
`amd/src/chat_widget.js` calls the external function with
`args: {prompt, courseid, request_id, format}` only. Every question therefore
starts cold, and follow-ups like "now only the ones below 40" lose all context.

## Scope

**In scope (the single roadmap item selected):**
- Make the widget send conversation history to the backend so multi-turn context
  reaches the AI fallback path.

**Explicitly out of scope (deferred):**
- Persisting history across page reloads (sessionStorage / localStorage / DB).
  History stays in-memory for the page session and resets on reload.
- Follow-up / multi-turn **intent mutation** in the deterministic fast-path
  ("only the failed ones", "sort by marks"). Templates do not consume history;
  only the AI-fallback path gains context.
- Cross-session user preferences / personalization (no new schema).

## Design

Frontend-only change plus one backend contract test. **No backend logic
changes** — `execute()` already implements the full history pipeline.

### 1. Build the history list in the widget

The widget already keeps `resultCache[requestId] = {prompt, response}` for every
exchange and an ordered `sessionHistory` array of `{requestId, prompt}`.

The response envelope already exposes the validated SQL
(`response.sql`, `query.php::execute_returns()`), so everything the backend needs
is already in the browser.

Construct the outbound history as an ordered (oldest-first) array of
`{prompt, sql}` built from **successful turns only**:
- include a turn iff `response.status === 'SUCCESS'` **and** `response.sql` is a
  non-empty string;
- skip error / out-of-scope turns (their `sql` is `''`) so the AI is never fed a
  prompt with no SQL.

### 2. Send it

Add `history` to the `args` object in `submitQuery()`:

```js
args: {prompt, courseid: courseId, request_id: requestId, format: true, history}
```

Cap the client-side array to the **last 5** turns (mirrors backend
`MAX_HISTORY_TURNS`) to keep the payload small. The backend still slices and
re-sanitises defensively, so the cap is an optimisation, not a trust boundary.

The history sent with a given turn is the conversation **before** that turn
(i.e. built before pushing the current exchange into the cache).

### 3. In-memory only

No persistence layer. `sessionHistory` / `resultCache` already live only for the
page session; a reload starts a fresh conversation. This matches the selected
scope.

### 4. Templates unaffected

The deterministic fast-path (`classes/intent/`) classifies and builds SQL without
history. That path is unchanged; history only enriches the AI-fallback branch.

## Data flow

```
user submits turn N
  -> widget builds history = last 5 SUCCESS turns (1..N-1), oldest first
  -> AJAX local_ai_analysis_query(args incl. history)
  -> execute(): sanitise prompt, rate-limit, manifest
       -> intent match?  yes -> template SQL (history ignored)
                         no  -> generate_sql(system, prompt, sanitised+capped history)
  -> validate -> execute (RO) -> audit -> envelope (incl. sql)
  -> widget caches {prompt, response}; pushes turn N onto history for turn N+1
```

## Testing

- **Backend contract test** (PHPUnit, `execute()` seam): pass a `history` array
  and assert it reaches the stubbed AI client's `generate_sql()` call (sanitised
  and capped). This pins the contract the widget now depends on so a future
  backend change can't silently break multi-turn. Reuse the existing AI-client
  stub injection (`ai_client_factory::set_override()`).
- **No widget JS unit test** — consistent with existing plugin practice (the
  widget AMD is not unit-tested here). Coverage is the manual browser smoke-test.
- **Manual smoke-test:** ask a question that returns rows (e.g. a student
  listing), then a follow-up ("now only the ones below 40" / "sort by grade") and
  confirm the second result builds on the first. Purge caches first so the
  rebuilt AMD loads.

## Build / release

- Bump `version.php` → `2026061501`, release `0.13.0`.
- Rebuild AMD via the `node:22-slim` recipe (keep source lint-clean), then purge
  caches on deploy.
- Update the four ai-memory docs (`02-features-log.md`, `04-current-state.md`,
  `03-decisions.md`, and note changed files / no DB change / no new APIs).

## Risks / notes

- The external function signature already declares `history` (with the
  `{prompt, sql}` single-structure), so adding it to the widget args needs no
  signature change and no version-gated AJAX change.
- No DB schema change, no new capability, no manifest change.
- Payload growth is bounded by the client-side 5-turn cap; SQL strings are
  small. Acceptable.
