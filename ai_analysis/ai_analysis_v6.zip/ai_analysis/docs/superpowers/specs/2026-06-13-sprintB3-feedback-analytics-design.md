# Sub-project B3 — Feedback Analytics (custom star ratings)

**Date:** 2026-06-13
**Status:** Design approved → spec
**Version target:** `version.php` = `2026061301` / release `0.12.0`
**Branch:** `feature/sprintB3-feedback-analytics`

## 1. Goal

Add a fast-path capability for **course feedback ratings** — "which courses have poor
feedback?", "feedback rating for this course", "lowest-rated courses". The scored data
source is the instance's **custom `mod_customfeedback` plugin**, which stores 1–5 **star
ratings** (`valuestar`). Mirrors the B1→B2 pattern: read-only SQL view(s) + a deterministic
intent template + manifest exposure, reusing the existing validator / executor / audit
pipeline unchanged.

## 2. Scope decisions (locked during brainstorm)

| Decision | Choice |
|---|---|
| Feedback source | **Custom `mod_customfeedback` star ratings only.** Core `mod_feedback` Likert and the empty `local_feedbackenhance` / `local_cust_feedback` families are out of scope. |
| View grain | **Two views** — per-course (headline) **and** per-activity (detail). |
| Free-text answers | **Deferred** — textarea/`valuetext` sentiment needs an AI pass, not a SQL view. |
| Visualisation | **Professional, shape-driven** (§7). Includes a generic **template chart-hint** extension so fast-path rankings render a Chart.js bar chart. |

## 3. Data model (verified on this instance)

`mod_customfeedback` tables (real data: 4 activities on courses 5/39/23, 5 submissions,
~12 star answers; `valuestar` confirmed clean integers 1–5):

```
mdl_customfeedback     (id, course, name, allowmulti, timecreated, timemodified)
mdl_customfeedback_q   (id, customfeedbackid, type ∈ {'star','text'}, name, sortorder, required)
mdl_customfeedback_r   (id, customfeedbackid, userid, timecreated)   -- one row per submission; HAS userid
mdl_customfeedback_a   (id, responseid, questionid, valuestar tinyint, valuetext longtext)
```

**Star-rating base join** (the single source both views aggregate):

```sql
FROM {p}customfeedback cf
JOIN {p}customfeedback_r r ON r.customfeedbackid = cf.id
JOIN {p}customfeedback_a a ON a.responseid = r.id AND a.valuestar IS NOT NULL
JOIN {p}customfeedback_q q ON q.id = a.questionid AND q.type = 'star'
JOIN {p}course c           ON c.id = cf.course
WHERE cf.course > 1
```

`a.valuestar` is the unit of measure (one 1–5 data point per star answer). `text`-type
questions and `valuetext` are ignored (the `valuestar IS NOT NULL` + `q.type='star'`
predicates exclude them). `cf.course > 1` drops the site course, matching B1/B2's
`courseid > 0` convention.

**Privacy:** `mdl_customfeedback_r.userid` exists (this plugin is *not* anonymous), but it
is **never projected** — both views emit course/activity aggregates only. Zero identity
columns ⇒ **no `pii_scrubber` changes**, same as B2.

## 4. The two views

Both are computed **directly from the base join** (not view-on-view). Course-level
`avg_rating` is therefore a true mean of individual ratings, not a mean-of-activity-means —
deliberately different from B2's rollup approach to avoid a weighting bug.

### 4a. `mdl_ai_feedback_activity` — grain: one row per activity with ≥1 star answer
`classes/db/feedback_activity_view.php` (const `VIEW = 'ai_feedback_activity'`)

| Column | Definition |
|---|---|
| `activityid` | `cf.id` |
| `activityname` | `cf.name` |
| `courseid` | `cf.course` |
| `coursename` | `c.fullname` |
| `star_question_count` | `COUNT(DISTINCT q.id)` |
| `submission_count` | `COUNT(DISTINCT r.id)` |
| `rating_count` | `COUNT(a.valuestar)` |
| `avg_rating` | `ROUND(AVG(a.valuestar), 2)` (1–5) |
| `avg_rating_pct` | `ROUND(100 * (AVG(a.valuestar) - 1) / 4, 1)` (0–100) |
| `pct_low` | `ROUND(100 * SUM(a.valuestar <= 2) / COUNT(a.valuestar), 1)` |

`GROUP BY cf.id, cf.name, cf.course, c.fullname`

### 4b. `mdl_ai_course_feedback` — grain: one row per course (course > 1) with ≥1 star answer
`classes/db/course_feedback_view.php` (const `VIEW = 'ai_course_feedback'`)

| Column | Definition |
|---|---|
| `courseid` | `cf.course` |
| `coursename` | `c.fullname` |
| `activity_count` | `COUNT(DISTINCT cf.id)` |
| `submission_count` | `COUNT(DISTINCT r.id)` |
| `rating_count` | `COUNT(a.valuestar)` |
| `avg_rating` | `ROUND(AVG(a.valuestar), 2)` (1–5) |
| `avg_rating_pct` | `ROUND(100 * (AVG(a.valuestar) - 1) / 4, 1)` |
| `pct_low` | `ROUND(100 * SUM(a.valuestar <= 2) / COUNT(a.valuestar), 1)` |

`GROUP BY cf.course, c.fullname`

> Each view class mirrors `course_performance_view`: a `VIEW` const, `definition_sql(string $p)`
> returning `CREATE OR REPLACE VIEW …`, and `create(\moodle_database $db)`.

## 5. Pipeline wiring

### 5a. Install / upgrade / grants
- `db/install.php` — create both views after the existing view chain (skip under `PHPUNIT_TEST`,
  same join-view/`reset_database` reasoning as C/B1/B2). No inter-dependency on the engagement
  views — these read `mdl_customfeedback*` directly, so ordering among them is free; create them
  last for clarity.
- `db/upgrade.php` — new step `2026061301`: create both views (guarded, idempotent `CREATE OR REPLACE`).
- `db/readonly_grants.sql` — **+2 grants**: `SELECT` on `mdl_ai_feedback_activity` and
  `mdl_ai_course_feedback` for `moodle_ai_ro`. (Views are `SQL SECURITY DEFINER`; the RO user
  needs SELECT on the views only — same as B1/B2.) **Applied live by the user as root**, like the
  other view grants.
- `version.php` → `2026061301` / `0.12.0`.

### 5b. Manifest (`classes/manifest/manifest_builder.php`)
- Add both views to the `$tables` allow-list with their column lists (§4).
- Add `_scope_note`s for the non-admin / `courseid > 0` case filtering each view to the current
  course (`courseid = :courseid`), mirroring the existing `mdl_ai_course_performance` note.

### 5c. Intent fast-path
- **`synonym_dictionary`** — new `feedback` family folding: `feedback`, `rating`, `ratings`,
  `rated`, `star`, `stars`, `satisfaction`, `survey`, `surveys` → canonical token `feedback`;
  and the poor-quality qualifiers `poor`, `worst`, `lowest`, `bad`, `negative` (reuse existing
  `worst`/`lowest` where already present). Add a `courses → enrolled`-style gap-fill only if
  needed for matching (see registry below).
- **`intent_registry`** — new entry:
  ```
  id       => 'course_feedback'
  requires => ['feedback']
  any_of   => ['course', 'courses', 'rating', 'enrolled']   // tune so "feedback rating",
                                                             // "course feedback", "poor feedback" match
  none_of  => ['students', 'staff', 'risk', 'performance']  // keep disjoint from B1/B2/C
  ```
- **`sql_template`** — new `course_feedback` branch, scope-aware (mirrors `course_performance`):
  - `courseid > 0` → `SELECT <cols> FROM mdl_ai_course_feedback WHERE courseid = ? LIMIT 1000`
  - `courseid = 0` → `SELECT <cols> FROM mdl_ai_course_feedback ORDER BY avg_rating ASC LIMIT 1000`
    (worst-first ranking; `courseid = 0` path is gated upstream by the `queryglobal` capability,
    exactly as `course_performance`).
  - Output cols: `courseid, coursename, activity_count, submission_count, rating_count,
    avg_rating, avg_rating_pct, pct_low`.
- The **per-activity view is manifest-only** (no fast-path template in v1) — it is available to the
  AI fallback for questions like "which survey got the worst ratings in this course". An
  activity-level fast-path template is a documented deferred enhancement.

## 6. Template chart-hint extension (generic)

Today charts only render on the AI path (`$ai['chart']`); the `provider='template'` fast-path
passes `null` to `validate_chart()` → table only. To render the feedback ranking as a bar chart
(and incidentally let B1/B2 fast-paths chart too):

- `sql_template::build()` returns an **optional third element**: `[$sql, $params, $chart|null]`
  where `$chart = ['type' => 'bar', 'x' => '<col>', 'y' => '<col>']` or `null`.
  - `course_feedback`, `courseid = 0` → `['type'=>'bar', 'x'=>'coursename', 'y'=>'avg_rating']`.
  - `course_feedback`, `courseid > 0` (single row) → `null` (a one-row result is an answer, not a chart — §7).
  - Existing templates default to `null` (unchanged behaviour) — optionally B2's global
    `course_performance` can opt into a bar chart in the same change.
- `external/query.php` fast-path passes the template's chart through the **existing**
  `validate_chart($templateChart, array_keys($source_map))` — so the same column-existence
  validation applies; an invalid hint degrades to no chart. No new trust surface.
- Backward compatibility: callers reading two elements still work (PHP list-destructuring a
  3-element array with two targets is fine); update the gateway's destructuring to read the third.

## 7. Visualisation policy (professional, shape-driven)

Representation is chosen by **result shape**, not forced:

| Result shape | Rendering |
|---|---|
| Single scalar / single course's rating | Plain-language **answer** (+ the one-row table). No chart. |
| Multi-row ranking (courses × `avg_rating`) | **Table + Chart.js bar chart** (template chart-hint, §6). |
| Per-activity list within a course (AI path) | Table; bar chart when the AI proposes a valid spec. |

This honours "tables + charts where necessary, normal answers where not." The widget already
renders all three (table always; chart when `chart_spec` present; `answer` text from the
`format_result` pass). No frontend/AMD changes are required — the existing
`chat_widget.js` consumes whatever the envelope carries.

## 8. Testing

PHPUnit, file-path form, Docker. New/updated:
- `tests/feedback_views_test.php` — create both views (and the `mdl_customfeedback*` base tables
  if not present in the test DB) per-class, drop after; assert grain, `avg_rating` math,
  `pct_low`, `course > 1` exclusion, star-only filtering (ignores `text`/`valuetext`), and that
  `userid` is absent from the projection.
- `manifest_*` test — both views present with expected columns; `_scope_note`s applied for
  non-admin `courseid > 0`.
- `sql_template` / `intent_classifier` test — `course_feedback` matches its phrasings and stays
  disjoint from `student_listing`/`course_staff`/`at_risk_students`/`course_performance`; both
  scope shapes pass `sql_validator`; chart-hint returned only for the `courseid = 0` shape.
- End-to-end gateway test — `course_feedback` fast-path (`provider='template'`) through
  validator + executor + audit, asserting `chart` populated for the ranking shape and empty for
  the single-course shape.

## 9. Deferred non-goals

- Free-text (`valuetext`) sentiment scoring — needs an AI pass.
- Core `mod_feedback` Likert and `local_feedbackenhance`/`local_cust_feedback` (empty here).
- Activity-level fast-path template (activity view is AI-fallback-only in v1).
- Materialised metric table / scheduled task — unnecessary at this data volume (the live views
  read a handful of rows); documented path only.

## 10. Touched files (summary)

`classes/db/course_feedback_view.php` (new), `classes/db/feedback_activity_view.php` (new),
`db/install.php`, `db/upgrade.php`, `db/readonly_grants.sql`, `version.php`,
`classes/manifest/manifest_builder.php`, `classes/intent/synonym_dictionary.php`,
`classes/intent/intent_registry.php`, `classes/intent/sql_template.php`,
`classes/external/query.php` (fast-path chart hint), `tests/*`, `docs/ai-memory/*`.
