# Sub-project B2 — Course Performance View

**Date:** 2026-06-12
**Status:** Design approved, pre-implementation
**Component:** `local_ai_analysis`

## Context

Sub-project **B** (analytics) decomposes by data domain. **B1** (student engagement & risk)
is merged. **B2** (this spec) rolls B1's per-student metrics up to the **course** level to
answer "which courses are underperforming / how is this course doing". B3 (feedback) and D
(memory) remain.

Experimental instance, dummy data. Data reality (unchanged from B1): submissions rich, logs
rich, grades sparse (125 across 5 courses).

### Problem

Course-comparison analytics ("underperforming courses") rank ACROSS courses — the first
analytics in this plugin that is inherently cross-course (B1/C/A were always within one
course). Ranking needs aggregation the `sql_validator` forbids at user-SQL level, and
cross-course access must respect scope (a non-admin teacher must not see a site-wide ranking).
Both are solved by a pre-computed view + a scope-aware template.

### Goal

A read-only view `mdl_ai_course_performance` (one row per course) that rolls up the B1
engagement view, added to the manifest, with one **scope-aware** `course_performance` fast-path
template.

## Non-goals (v1)

- A course `performance_band` (good/fair/poor) — raw rollups only; "underperforming" = ranked by
  `at_risk_pct`.
- Activity/engagement rollups (avg activity, % active) — not selected; only at-risk, grade, and
  completion rollups.
- Trends over time, feedback (B3), materialized metric table (documented scale path, not built).
- Courses with zero students (they simply do not appear — nothing to assess).

## Architecture

### 1. The view `mdl_ai_course_performance`

**Grain:** one row per course. Built by `GROUP BY courseid` over `mdl_ai_student_engagement`
(the B1 view), joined to `mdl_course` for the course name. By building on the engagement view it
**inherits** the enrolled-minus-staff student population and the `courseid > 0` exclusion — no
need to re-express them.

**Columns:**
| Column | Derivation | Notes |
|---|---|---|
| `courseid` | engagement.courseid | |
| `coursename` | `mdl_course.fullname` | not PII |
| `student_count` | `COUNT(*)` | students in the course |
| `at_risk_high` | `SUM(risk_band = 'high')` | |
| `at_risk_medium` | `SUM(risk_band = 'medium')` | |
| `at_risk_low` | `SUM(risk_band = 'low')` | |
| `at_risk_pct` | `ROUND(100 * at_risk_high / student_count, 1)` | flagship ranking metric |
| `avg_grade` | `AVG(engagement.avg_grade)` | NULL when ungraded (sparse) |
| `avg_missing_submissions` | `AVG(missing_submissions)` | |
| `pct_no_missing` | `ROUND(100 * SUM(missing_submissions = 0) / student_count, 1)` | completion signal |

`student_count` ≥ 1 for every row (rows come from grouping student rows), so the percentage
divisions never divide by zero.

**No PII.** The view exposes only course identity (id, name) + aggregate counts/metrics — no
student names or identifiers. `pii_scrubber` is **not** modified.

### 2. View ownership (3-view dependency chain)

`classes/db/course_performance_view.php` holds the DDL (`definition_sql($prefix)` + `create($db)`
via `$DB->execute()`). The dependency chain is **staff → engagement → performance** (performance
selects from engagement, which selects from staff). Creation order matters:
- `db/install.php`: create staff, then engagement, then performance (real installs; PHPUNIT-skip
  as before).
- `db/upgrade.php`: new version-guarded step (2026061203) creates the performance view (staff +
  engagement already created by their earlier steps).
- `db/readonly_grants.sql`: SELECT grant on the performance view.
- Tests create all three views in setUp (staff → engagement → performance) and drop in reverse
  (performance → engagement → staff) before `parent::tearDown()`.

### 3. Manifest exposure

`manifest_builder` gains `mdl_ai_course_performance => [courseid, coursename, student_count,
at_risk_high, at_risk_medium, at_risk_low, at_risk_pct, avg_grade, avg_missing_submissions,
pct_no_missing]` with a course scope-note (non-admin + courseid>0 → `WHERE courseid = <id>`).
Exposing it unlocks course-performance queries via the AI path.

### 4. Scope-aware fast-path template

`sql_template::build('course_performance', $courseid)` returns two shapes:
- **`$courseid > 0`** (scoped):
  `SELECT courseid, coursename, student_count, at_risk_high, at_risk_pct, avg_grade,
   avg_missing_submissions, pct_no_missing FROM mdl_ai_course_performance WHERE courseid = ?
   LIMIT 1000`, params `[$courseid]`.
- **`$courseid === 0`** (global ranking; the gateway has already enforced the `queryglobal`
  capability before the fast-path runs):
  `SELECT courseid, coursename, student_count, at_risk_high, at_risk_pct, avg_grade,
   avg_missing_submissions, pct_no_missing FROM mdl_ai_course_performance
   ORDER BY at_risk_pct DESC LIMIT 1000`, params `[]`.

A non-admin can never reach the global branch (gateway gates `courseid = 0` on `queryglobal`), so
the template is scope-safe by construction. Both shapes are unit-tested against `sql_validator`.

### 5. Classifier

New `course_performance` intent. `synonym_dictionary` gains `underperforming → performance`,
`performance → performance`, `performing → performance`, `health → performance`. Registry entry:
`requires=['performance']`, `any_of=['enrolled']` (note: `course`/`courses` already canonicalize
to `enrolled`), `none_of=['students','staff','risk']`. Distinct required token (`performance`)
from the other intents, so "underperforming courses" routes here while "courses with at-risk
students" still routes to `at_risk_students` (requires `risk`).

## Error handling

No new status codes. Same envelopes. Missing view → `QUERY_FAILED` (audited). Classifier
never throws.

## Testing

**View / rollup correctness** (`tests/course_performance_view_test.php`, create/drop all three
views per-class):
- Seed 2 courses. Course A: 2 students both high-risk (no activity + missing submission).
  Course B: 2 students low-risk (active + submitted). Assert per course: `student_count = 2`,
  `at_risk_high` (2 vs 0), `at_risk_pct` (100.0 vs 0.0), `pct_no_missing` (0.0 vs 100.0),
  `coursename` matches.
- Assert `courseid = 0` never appears (inherited).
- Assert a course with only staff (no students) does not appear.

**Template / classifier** (extend A's test files):
- `course_performance` template: `courseid > 0` → SQL contains `WHERE courseid = ?` + params
  `[55]`; `courseid = 0` → SQL contains `ORDER BY at_risk_pct DESC`, no `WHERE`, params `[]`.
  BOTH pass `sql_validator`.
- Classifier: "underperforming courses", "course performance", "how is this course performing"
  → `course_performance`; "students at risk" still → `at_risk_students`; "list students" still →
  `student_listing`.

**Gateway e2e** (extend `external_query_test`, create/drop all three views in setUp/tearDown):
- Scoped teacher (courseid>0) asks "course performance" → SUCCESS, AI stub `call_count === 0`,
  audit `provider='template'`, returns their course's row. (The global branch is covered by the
  template unit test.)

**Full suite** green after each task.

## Files (anticipated)

- New: `classes/db/course_performance_view.php`, `tests/course_performance_view_test.php`.
- Modify: `db/install.php` (+ performance view, after engagement), `db/upgrade.php` (+ step
  2026061203), `db/readonly_grants.sql` (+ grant), `classes/manifest/manifest_builder.php`
  (+ view + scope-note), `classes/intent/synonym_dictionary.php` (+ performance family),
  `classes/intent/intent_registry.php` (+ course_performance), `classes/intent/sql_template.php`
  (+ scope-aware case), `version.php` (bump → 2026061203 / 0.11.0),
  `tests/{intent_classifier,sql_template,external_query,manifest_builder}_test.php` (extend),
  `INSTALL.md`, `docs/ai-memory/02,03,04`.
- **Not** modified: `classes/security/pii_scrubber.php` (no identity columns).

## Decisions captured

- **Course view rolls up the B1 engagement view** (view-on-view) — inherits student population +
  courseid=0 exclusion (DRY).
- **Metrics:** at-risk counts + at_risk_pct, avg_grade, avg_missing_submissions + pct_no_missing
  (no activity rollup, no course band).
- **"Underperforming" = ranked by `at_risk_pct` DESC** (no opinionated course band).
- **Scope-aware template:** courseid>0 → that course's row; courseid=0 → global ranking
  (gateway's queryglobal gate makes it scope-safe).
- **No PII handling** (no student identity exposed).
- Same view-ownership + PHPUNIT-skip + per-test create/drop pattern; `$DB->execute()` for DDL;
  3-view create-order staff→engagement→performance.
