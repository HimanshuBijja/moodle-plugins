# Major Decisions

## Bugfix — AI SQL placeholder/param-count mismatch (0.13.1)

- **Fix the invariant in the validator, not the executor** — the violated invariant (positional `?` count must equal bound-param count) belongs in `sql_validator` because it already receives both `sql` and `params` and is the single source of truth for SQL safety. Placing the check there moves detection *before* execution and, crucially, *into* the existing self-correction retry loop (which only catches `validation_exception`). Catching it at the executor would just produce a cleaner error, not a recovery.
- **Literal-aware placeholder count** — strip quoted string literals before counting `?` so a `?` inside a string value isn't mistaken for a placeholder (same robustness reasoning as the existing LIMIT-rewrite literal handling).
- **Make the retry corrective prompt param-aware** — the guard only helps if the model can recover, so the retry message now states the `?`/params contract explicitly. Tested both directions: recovery-on-retry → SUCCESS, and exhaustion → `SQL_INVALID` (not raw `QUERY_FAILED`).
- **Diagnosed via the audit log, resisted the obvious conclusion** — the symptom appeared during multi-turn (sub-project D) smoke-testing, but the audit row showed the follow-up *did* carry prior context and failed for an unrelated, pre-existing reason. Root-cause-first debugging avoided "fixing" the history wiring that was already correct.

## Sub-project D — Conversation History Wiring

- **Scoped "memory polish" down to the one real gap** — the roadmap item was vague ("session/user context"). Exploration revealed the Sprint 6 multi-turn backend was fully built and tested but the widget never sent `history`, so multi-turn never worked. The user selected only "wire history end-to-end"; persistence, fast-path follow-up mutation, and cross-session prefs were explicitly deferred. Highest value for the least surface (frontend-only, no backend/schema change).
- **Successful-turns-only history filter** — `buildHistory()` includes a turn only when `response.status === 'SUCCESS'` and `response.sql` is non-empty. A prior failed/out-of-scope turn (empty `sql`) would feed the AI a prompt with no SQL, adding noise; skipping it keeps the context clean and matches the backend's `{prompt, sql}` contract.
- **In-memory only, AI-fallback only** — history lives in the existing `sessionHistory`/`resultCache` (resets on reload); no persistence added. Deterministic templates ignore history (follow-up intent mutation stays deferred); only the AI-fallback branch gains context. Keeps the change small and the fast-path deterministic.
- **No duplicate backend test** — the `history` contract (`execute()` passes it to `generate_sql`, caps to 5, drops malformed turns) was already covered by Sprint 6's `external_query_test.php`. This work depends on that contract rather than changing it, so it adds no PHP tests; verification is the full suite (still green) + a manual browser smoke-test (no JS test harness exists in this plugin, consistent with prior widget work).
- **Client cap mirrors backend `MAX_HISTORY_TURNS=5`** — an optimisation to keep the payload small, not a trust boundary; the backend still slices and re-sanitises defensively.

## Sub-project B3 — Feedback Analytics (custom star ratings)

- **Custom `mod_customfeedback` star ratings only — not core `mod_feedback`** — the user owns a custom feedback plugin storing clean 1–5 `valuestar` integers. Core `mod_feedback` has more data (513 vs 5 submissions) but encodes ratings as a multichoice option index requiring `presentation`-string parsing and a "radio = ordered worst→best scale" assumption. The user chose the custom plugin only: cleaner schema, the mechanism they actually built. Core Likert + the empty `local_feedbackenhance`/`local_cust_feedback` families are explicit non-goals.
- **Two views, computed direct from base tables (NOT view-on-view)** — deliberately different from B2's rollup of the B1 view. Course-level `avg_rating` must be a true mean of individual ratings; rolling up activity-level averages would be a mean-of-means weighting bug. Both `mdl_ai_course_feedback` and `mdl_ai_feedback_activity` share one base join, differing only in `GROUP BY`. Cost is trivial (a handful of `customfeedback` rows), so no DRY/scale concern.
- **Aggregate-only projection → zero PII** — `mdl_customfeedback_r.userid` exists (this plugin is non-anonymous, unlike core feedback), but neither view projects it. Course/activity grain means identity never leaves the view, so no `pii_scrubber` entries needed. A test asserts `userid` is absent from the view row.
- **Generic template chart-hint; visualisation is shape-driven** — rather than special-casing B3, `sql_template::build()` returns an optional chart spec as a 3rd tuple element, fed through the existing `validate_chart()`. Multi-row rankings get a Chart.js bar chart; single-row (one course) results return no chart → a plain answer. "Professional viz = tables + charts where they help, plain answers where they don't." B2's global ranking opted into the same mechanism.
- **`feedback` is a disqualifier for `student_listing`/`course_staff`** — so "list student feedback" routes to `course_feedback`, not a student listing. Conversely `course_feedback`'s `none_of` omits `students` (keeping it would block that same phrase). Feedback is treated as the stronger intent signal when it co-occurs with listing words.

## Sub-project B2 — Course Performance View

- **Roll up the B1 engagement view (view-on-view DRY), not raw base tables** — `mdl_ai_course_performance` GROUPs BY on `mdl_ai_student_engagement` rather than re-joining the base tables independently. This avoids duplicating the enrolled-minus-staff population logic and the risk_band thresholds; if B1 changes, B2 follows automatically. The trade-off (deeper view chain, heavier global query) is accepted as reasonable at current scale.
- **Metrics = at-risk counts/pct + avg_grade + completion (no per-activity rollup, no course band)** — the view exposes `at_risk_high/medium/low`, `at_risk_pct`, `avg_grade`, `avg_missing_submissions`, and `pct_no_missing`. Per-activity/module rollup was considered and rejected (adds complexity, not needed for the first course-level summary). A course-band signal (`'red'/'amber'/'green'`) was considered but left out: the raw `at_risk_pct` + counts are more flexible and composable for AI queries.
- **"Underperforming" = rank by `at_risk_pct DESC`** — the natural answer to "which courses are struggling most" is the proportion of high-risk students. `at_risk_pct` was chosen over `avg_grade` or `avg_missing_submissions` because it synthesises the B1 multi-signal risk_band into one course-level rate. Other orderings (e.g. lowest avg_grade) remain possible via the AI pipeline's SQL generation.
- **Scope-aware template: `courseid>0` → that course's row; `courseid=0` → global ranking gated by `queryglobal`** — a teacher in a course context gets exactly their course's row without needing a `WHERE courseid=?` in the prompt. A manager or admin at system scope (courseid=0) gets a full cross-course ranking, but this requires the `queryglobal` capability (existing gate). The global path is the heaviest (view-on-view across all courses + the logstore), so gating it behind `queryglobal` is both a security and a pragmatic guard.
- **No PII — no identity columns** — the view exposes only courseid, coursename, and aggregate metrics. No `userid`, `firstname`, or `lastname`. `pii_scrubber::PII_MAP` is unchanged. Individual student identity remains accessible only via `mdl_ai_student_engagement` (which has its own PII map entries).
- **3-view create-order: staff → engagement → performance** — `mdl_ai_course_performance` depends on `mdl_ai_student_engagement`, which depends on `mdl_ai_course_staff`. `db/install.php` creates them in this order; `db/upgrade.php` creates the performance view in its own step (2026061203) after B1's step (2026061202). Tests drop in reverse order (performance → engagement → staff) to satisfy DDL dependency resolution.

---

## Sub-project B1 — Student Engagement & Risk View

- **Four signals exposed raw, not a composite black-box score** — activity recency (last_activity_days > 14 or never), activity volume (activity_count < 5), missing submissions (missing_submissions > 0), and average grade (avg_grade < 40 when present) are all visible as individual columns. The `risk_band` derivation is a plain SQL CASE expression against those columns — transparent thresholds that teachers can audit and that will not surprise them with an unexplained label.
- **Transparent rule-based risk_band over a black-box model** — thresholds (14d inactivity, avg_grade < 40, activity_count < 5, any missing submission) were chosen to be sensible defaults and are hard-coded in the view DDL. Explicitly preferred over a trained model: no training data needed, no model drift, trivially explainable to a teacher. Thresholds can be adjusted in the view DDL if needed.
- **Student = enrolled minus staff (reuses sub-project C's view)** — `NOT EXISTS (SELECT 1 FROM mdl_ai_course_staff WHERE ...)` excludes anyone who appears in the staff view from the engagement view. This avoids duplicating role-exclusion logic and keeps the definition aligned: if the staff view changes, engagement automatically follows.
- **courseid=0 unconditionally excluded in the view** — a row with courseid=0 is a logstore artefact, not a real course enrolment. Excluding it in the view (not just in scope-notes) prevents it from ever appearing in AI results regardless of how a query is phrased.
- **Live view in v1; materialized metric table + scheduled task as the documented scale path** — at current data volume the live GROUP BY is acceptable. Documenting the scale path (a separate `mdl_ai_student_engagement_metrics` table refreshed by a scheduled task) avoids future architectural surprise without the cost of building it now. The decision to NOT build it in v1 is explicit.
- **`$DB->execute()` for view DDL** — same reasoning as sub-project C: `change_database_structure()` is for XMLDB-modelled DDL (tables, indexes); `CREATE OR REPLACE VIEW` must use `$DB->execute()`.
- **install.php PHPUNIT-skip + per-test create/drop; engagement view created after staff view, dropped before** — the engagement view has a `NOT EXISTS` dependency on `mdl_ai_course_staff`; it must be created after and dropped before the staff view to satisfy DDL dependency order. The PHPUNIT skip pattern mirrors sub-project C for the same reason (non-updatable join-view breaks Moodle's `reset_database()`).

---

## Sub-project C — Role/People Queries

- **Staff = manager + coursecreator + editingteacher + teacher at course context only** — the four roles that meaningfully represent "course staff". System/category-context-only assignments are intentionally excluded; adding parent-context traversal adds complexity and surface area for a minority edge case.
- **Site-admins excluded dynamically, not by a static list** — `FIND_IN_SET(u.id, (SELECT value FROM mdl_config WHERE name='siteadmins'))` reads the live siteadmins config at query time, so it stays correct as admins are added/removed without any view DDL change. A static exclusion list would drift.
- **Exposure via a pre-filtered read-only VIEW, never raw role tables** — `mdl_ai_course_staff` is a purpose-built view that projects exactly the columns and rows needed. Raw `mdl_role_assignments`/`mdl_context`/`mdl_role` tables remain out of the manifest and unreachable by the RO user, limiting the blast radius of any future AI misuse.
- **Plugin owns the VIEW via install/upgrade — install skips PHPUNIT to avoid breaking reset_database** — `db/install.php` creates the view on production installs but gates on `!defined('PHPUNIT_TEST')`. A non-updatable join-view cannot survive Moodle's `reset_database()` (which does per-class truncate/restore of base tables), so PHPUnit test classes create/drop the view themselves in `setUp`/`tearDown`. This is the correct pattern for any join-view in a Moodle plugin.
- **Only firstname, lastname, role projected — no username, email, or idnumber** — deliberately minimal PII surface. A teacher querying "who are the staff" needs names and roles; they do not need login credentials or institutional IDs, which would widen the data accessible via the AI widget unnecessarily.
- **View created via `$DB->execute()`, not `change_database_structure()`** — `change_database_structure()` is for DDL that Moodle's XMLDB layer can model (tables, indexes); it does not accept `CREATE OR REPLACE VIEW`. `$DB->execute()` is the correct API for arbitrary DDL in install/upgrade scripts.

## Sprint 8 (A) — Intent → SQL Templates

- **Deterministic fast-path + AI fallback, not prompt-normalisation-only or intent→AI-SQL** — classified intents short-circuit directly to a hard-coded parameterised template (no AI call). Unmatched prompts fall through to the full existing AI pipeline unchanged. This preserves AI coverage for the long tail while making the common case zero-latency, zero-cost, and fully deterministic.
- **Deterministic keyword + synonym classification, no LLM classifier in v1** — the classifier runs entirely offline against a curated synonym dictionary and declarative requires/any_of/none_of rules. No model call for classification; no probabilistic misfire; easy to audit and extend. An LLM-based classifier would add latency + cost on every request even when falling through to the AI anyway.
- **Current-course context only for the `courseid` slot; named-course resolution deferred** — the gateway supplies the page courseid to the template. Resolving "students in Math 101" (named course) requires either manifest data or a follow-up query, adding complexity and ambiguity that belongs to a later sub-project. v1 templates only answer about the current course.
- **Reuse the audit `provider` column for route tracking (value `'template'`), no schema migration** — the existing column records which AI client was used; `'template'` is a valid sentinel for the fast-path. No DDL needed, no version-migration logic, and the audit report already displays the column. A dedicated `route` column would be cleaner long-term but is not worth a migration for one new value.

## Sprint 6 (conversational + viz + links + tables)

- **Client-replayed history, not server-stored sessions** — the widget resends prior `{prompt,sql}` turns each request. Zero DB change; since every SQL is re-validated against the manifest, a forged history cannot widen access. History prompts are re-sanitised; failures dropped silently (best-effort).
- **History capped at 5 turns** — bounds token cost; the cap + per-prompt sanitisation happen in the gateway, not the client (client input is untrusted).
- **AI proposes charts, server validates** — the model returns an optional chart spec, but the gateway only honours it when `type` is allow-listed and `x`/`y` are real output columns. The frontend numeric-column heuristic stays as fallback so weak models still chart.
- **Linking driven by `column_source_map`, not the AI** — the validator already resolves each output column to `table.column`; the gateway tags `mdl_user.id`/`mdl_course.id` columns as link targets. The AI is only *nudged* to include ids; it never controls link generation. Click-through safety is delegated to Moodle's own capability checks on the target page.
- **Raw rows already carry real ids** — linking needs no new data path: the PII scrubber only tokenises the copy sent to the format-pass AI; the `rows` returned to the browser are unscrubbed, so ids/names are present for an authorised teacher.
- **Table expansion stops short of role/context tables** — added assignment/quiz/group tables (high-value, low role-exposure). `mdl_role`/`mdl_role_assignments`/`mdl_context` remain excluded by the earlier decision; "who is the teacher" stays OUT_OF_SCOPE. Revisit only on explicit demand.
- **Live RO grants are a separate deploy step** — `db/readonly_grants.sql` is the source of truth, but new tables aren't queryable in production until the grants are applied on `moodle_ai_ro` (PHPUnit uses global $DB and is unaffected).

## Sprint 2

- **Constructor injection everywhere** for test seams — no live API/network in PHPUnit. `claude_client` takes transport; `ai_client_factory` has PHPUNIT_TEST-gated override; `query_executor` takes optional $DB.
- **No exceptions to the AJAX layer** — gateway catches every domain exception, returns typed envelope + audit row. Only capability denials propagate (Moodle's external API handles those).
- **Manifest is single source of truth** — validator receives the exact array sent to the AI so the allow-list cannot drift.
- **Read-only DB user** (`$CFG->ai_analysis_dbuser`) is the last line of defence — even if PHP validation is bypassed, DML/DDL fails at the server. Tests fall back to global $DB when creds absent.
- **Prefix translation in gateway** — AI + validator always work with canonical `mdl_`; gateway swaps to runtime prefix at execution. Keeps the manifest/validator environment-independent.
- **Rows JSON-encoded as strings** in the response envelope — `external_multiple_structure` can't declare arbitrary row shapes statically.
- **PHPUnit by file path, never `--filter`** — unrelated half-installed plugins (auth/secureotp, theme/sprout, theme/verdant, local/tgpa_timetable) disrupt filter-based discovery.

## Sprint 3a (PII scrubber + format_result)

- **Reversible tokens, not redaction** — PII is tokenised (`PERSON_1`) before the formatting AI call and de-tokenised in the answer afterward. The teacher is authorised and sees real values; only the external AI ever sees tokens. Token map is in-memory/per-request, never persisted or logged.
- **Column classification, curated map** — the scrubber owns an explicit `table.column → prefix` map (deterministic, auditable), not value-pattern heuristics. PII knowledge lives only in `pii_scrubber`; `sql_validator` stays PII-agnostic and just surfaces source/reference maps.
- **Alias-safe via validator** — tokenisation keys off the validator's resolved column-source map, not raw row keys, so `firstname AS fn` is still masked. Derived expressions referencing PII are wholesale-redacted (`__REDACT__`); pure aggregates pass through.
- **`strtr` for detokenise** — single-pass simultaneous replacement avoids the cascade bug where a real value equal to another person's token gets double-substituted.
- **Per-request `format` flag + graceful fallback** — formatting is opt-in per call; an AI #2 failure never blocks results (status stays SUCCESS, raw rows + `format_note` returned). No new status codes; Sprint-1 audit schema untouched.
- **Verbatim-token-echo rule in the AI #2 prompt** — de-tokenisation is a literal string swap, so the prompt forbids the AI from expanding/renaming tokens; tested by round-trip assertions.

## Sprint 3b (OpenAI + Gemini providers)

- **Template-method base, not duplication** — `base_http_ai_client` owns the provider-independent flow with `final generate_sql()`/`format_result()`; the SQL-output parsing (the part feeding the validator) lives in exactly one place and cannot drift between providers. New providers are ~30-line subclasses implementing five hooks. A truly different provider (e.g. streaming) would implement `ai_client_interface` directly instead.
- **Refactor guarded by existing tests** — `claude_client`'s 15 tests are the behaviour-preservation contract; they passed unchanged after moving its logic to the base.
- **Native JSON-output mode per provider** — OpenAI `response_format:{type:json_object}` and Gemini `responseMimeType:application/json`, applied to SQL generation only (not the prose formatting pass), to cut `AI_INVALID_JSON`.
- **Gemini key as header, not query param** — `x-goog-api-key` keeps the key out of any URL logging (vs `?key=`).
- **Free-text model settings with defaults** — per-provider model is an `admin_setting_configtext` pre-filled with a default, so new model names need no code change (chosen over a fixed dropdown).
- **OpenAI + Gemini only; Ollama deferred** — the two hosted APIs share Claude's shape; self-hosted Ollama (local HTTP, no key) is a separate slice.

## Sprint 4 (frontend chat widget)

- **Legacy `before_footer` callback returning a string, not the hook class** — `local_ai_analysis_before_footer()` is simpler and trivially unit-testable (call it, assert on the returned HTML). Moodle 4.5 still captures legacy-callback return values via `before_footer_html_generation::process_legacy_callbacks()`. A full `db/hooks.php` subscriber was unnecessary for a one-shot footer injection.
- **Capability checked against `$PAGE->context`, not `context_system`** — `local/ai_analysis:query` is CONTEXT_COURSE level, so a teacher holds it inside their course, not site-wide. Checking the page context shows the FAB wherever the user can actually query (course pages for teachers; everywhere for system-level grant holders). The external function re-checks server-side, so this is only a display gate.
- **Single shared panel for drawer + fullscreen** — one DOM skeleton; `data-state` + CSS switch geometry. Avoids duplicate markup and keeps the state machine to three values. Welcome vs results toggled by `data-view`.
- **Client-side chart auto-detection** — first column that is all-numeric across rows (with ≥2 rows) becomes the bar-chart series, first other column the labels; otherwise table + answer only. No server hint needed; keeps the external API unchanged.
- **In-memory, single-shot history** — each query is independent (never sent back to the AI); history lives in JS for the page load only, with a `resultCache` for click-to-revisit. No persistence, no DB, no extra privacy surface.
- **Hand-authored AMD build** — environment lacked a node-22 toolchain for grunt, so `amd/build/chat_widget.min.js` was written directly as a named `define()` module (Moodle requires the `build/*.min.js` filename, not true minification). Must be regenerated via grunt on a node-22 host before release (also runs ESLint).

## Sprint 5 (admin / management & compliance)

- **Decrypt reveal = capability + sesskey + self-audit, no password re-entry** — admins holding `decryptprompt` reveal a prompt with one click; every reveal writes its own `PROMPT_REVEALED` audit row (who revealed which id, when). Accountability via the audit trail itself was preferred over per-reveal re-authentication friction.
- **Retention = hard delete, configurable, default 365, 0 = forever** — a daily scheduled task deletes audit rows older than `retentiondays`. Chosen over anonymise-in-place: simpler, and the audit table's only real PII (encrypted prompt + block_reason) is exactly what should disappear on expiry.
- **GDPR erasure = delete the rows (not anonymise)** — matches 'right to erasure' cleanly and is consistent with the retention policy; export returns the user's rows (metadata + SQL, prompt left encrypted).
- **One shared cipher (`audit_crypto`)** — encrypt (writer) and decrypt (reveal) must use the identical key-normalisation + AES-CBC format, so the logic was extracted to a single helper rather than duplicated; drift here would corrupt or expose data.
- **429/5xx are transport, not parse errors** — provider rate-limit/transient failures are retry-able and distinct from a malformed AI response; mapping them to `transport_exception`/`AI_TRANSPORT_ERROR` lets the UI message them correctly instead of the misleading `AI_INVALID_JSON`.
- **Audit viewer = Moodle `table_sql` admin report (system-level)** — reused the platform's sorting/pagination/CSV/download rather than a custom page; viewer is admin-only by the existing `viewaudit` system capability (no per-course teacher view, by design).
- **Roles/teacher still NOT exposed** — unchanged from Sprint 4; manifest deliberately omits role/context tables.

## Sprint 3c (Ollama provider)

- **Subclass `openai_client`, don't extend `base_http_ai_client` directly** — Ollama ships an OpenAI-compatible `/v1/chat/completions` endpoint, so the entire payload/extraction/error surface is already correct. The new client is ~3 overrides (endpoint, auth, default model) + a constructor. Maximum reuse, zero new wire-format code, no risk of SQL-parsing drift (still inherited as `final` from the base).
- **base_url occupies the api_key constructor slot** — `base_http_ai_client.__construct(transport, api_key, model)` is fixed; rather than widen it, `ollama_client`'s own constructor takes `(transport, base_url, model)` and passes `''` for api_key upward. Keeps the base contract untouched while giving Ollama the one config it actually needs.
- **No Authorization header** — Ollama has no auth; `auth_headers()` returns content-type only. Sending an empty Bearer would be harmless but misleading.
- **Default model `qwen2.5-coder`** — code/SQL-tuned, best at the structured JSON+SQL task; field is free-text so admins can switch to any pulled model.
- **Inherited `response_format: json_object`** — Ollama's OpenAI-compat layer honors it on recent versions; on older ones it's ignored and JSON still arrives via the system prompt + `strip_fences`. Either way the base parser copes. Verified live: qwen2.5 returned a clean JSON object.
- **AMD rebuilt in a node:22 container, not on host** — Moodle's grunt hard-gates node ≥22.11 and the host has node-20; a throwaway `node:22-slim` container mounting the moodle tree (run as the www-data gid for the group-writable ignore files) regenerates builds + real source maps without touching the host toolchain. This retires the "hand-authored AMD builds" caveat from Sprints 4–5.

## Sprint 3c addendum (configurable timeout)

- **Single global `request_timeout`, threaded via the factory, not per-provider** — every provider can be slow under some condition (cloud APIs near 30s on big prompts; local CPU models far beyond). One setting, read once in `ai_client_factory::make()` and passed to each client's constructor, keeps the knob discoverable and avoids four near-identical settings. Default 30 preserves prior behaviour; raise only when needed.
- **Timeout lives on the client, applied in `base_http_ai_client::post()`** — the transport already accepted a `$timeout` arg but the base never passed it. Storing it on the client (ctor param) and forwarding in the one `post()` call is the minimal, single-point change; the `http_transport_interface` contract is untouched.
- **Pull a small model rather than only widen the timeout** — on CPU, qwen2.5:7b ≈ 64s is unusable as widget UX even if it technically completes. qwen2.5:3b (same family, ≈10s warm) is the pragmatic default for CPU hosts; the timeout still rises to absorb cold-load (~42s) and occasional slow generations.
