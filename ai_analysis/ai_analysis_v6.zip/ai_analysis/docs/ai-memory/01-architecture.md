# Architecture

## Request pipeline (8 layers)

Orchestrator: `classes/external/query.php` — single `execute(prompt, courseid, request_id)`.

1. **Auth + caps** — `require_capability('local/ai_analysis:query')`; courseid=0 also needs `queryglobal`.
2. **Input sanitisation** — `prompt_builder::sanitise_user_prompt()`: 3–800 chars + injection blocklist.
3. **Rate limit** — `rate_limiter::consume()`: per-user token bucket in `cache_application`, 1 token/60s, capacity from config; admins bypass.
4. **Manifest + system prompt** — `manifest_builder::build()` → schema snapshot; `prompt_builder::build_system()` embeds it.
5. **AI call** — `ai_client_factory::make()` → provider (claude only); `claude_client::generate_sql()` via injected `http_transport_interface`.
6. **SQL validation** — `sql_validator::validate()` (AST, greenlion/php-sql-parser): SELECT only, no DDL/DML, no wildcards, no subqueries, manifest-scoped tables/cols, scalar params, LIMIT ≤ 1000.
7. **Execution** — `query_executor::run()`: separate read-only `moodle_database` (`$CFG->ai_analysis_dbuser/dbpass`); tests inject global `$DB`.
8. **Audit** — `audit_writer::write()` on EVERY path including errors. Prompt stored as SHA-256 hash + AES-256-CBC ciphertext (`$CFG->ai_analysis_audit_key`).

Failures return a typed envelope (never throw to AJAX) + audit row with `status`.

## Key patterns

- **Injection test seams**: `claude_client`(transport arg), `ai_client_factory`(set/reset_override, PHPUNIT_TEST-gated), `query_executor`(optional $DB arg).
- **No exceptions to AJAX layer**: status ∈ {BLOCKED_INJECTION, RATE_LIMITED, AI_INVALID_JSON, AI_TRANSPORT_ERROR, OUT_OF_SCOPE, SQL_INVALID, QUERY_FAILED, SUCCESS}.
- **Manifest = single source of truth**: validator receives the exact manifest sent to AI; allow-list can't drift.
- **Prefix translation**: gateway `translate_prefix()` swaps `mdl_` → runtime prefix (`phpu_` in PHPUnit). AI + validator always see `mdl_`.
- **Row wire format**: each result row JSON-encoded to a string (external_multiple_structure can't express arbitrary row shapes); frontend/tests `json_decode` on receipt.

## Config (config.php)

```php
$CFG->ai_analysis_dbuser    = 'moodle_ai_ro';
$CFG->ai_analysis_dbpass    = '...';
$CFG->ai_analysis_audit_key = '...'; // 32 raw bytes or 64 hex chars
```

Plugin settings via get_config/set_config under `local_ai_analysis`: `provider`, `claude_api_key`, `rate_limit_per_min`.

## Testing

Docker only. File-path form, never `--filter`:
`docker exec moodle-web-8092 vendor/bin/phpunit local/ai_analysis/tests/<name>_test.php`
