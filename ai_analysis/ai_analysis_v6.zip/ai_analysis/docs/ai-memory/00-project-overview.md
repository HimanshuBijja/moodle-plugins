# Project Overview

`local_ai_analysis` — Moodle 4.5 local plugin. Natural-language-to-SQL chatbot for querying student data. PHP 8.1+ / MariaDB 10.11. AI provider: Claude (Anthropic Messages API).

## Goal

Educators ask questions in plain English ("which students haven't submitted assignment 3?"); the plugin translates to validated, read-only SQL, executes it, returns rows. Every layer is security-gated and audited.

## Five sprints

1. Security foundation — sql_validator, manifest_builder, audit_writer, capabilities. ✅ merged
2. Pipeline + Claude provider — AI client, rate limiter, AJAX gateway, read-only executor. ✅ complete
3. More providers (OpenAI/Gemini/Ollama) + PII scrubber + AI `format_result` pass. ⏳ next
4. Frontend chat widget (Mustache + AMD + Chart.js). ⏳
5. Admin/management — audit viewer, decrypt UI, Privacy API, retention task, settings polish. ⏳

## Specs

`docs/superpowers/specs/` — full design docs per sub-project.
`docs/superpowers/plans/` — task-by-task implementation plans.
