// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AI Analysis floating chat widget.
 *
 * @module     local_ai_analysis/chat_widget
 * @copyright  2026 Himanshu Bijja
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {call as fetchMany} from 'core/ajax';
import ChartJS from 'core/chartjs';
import Notification from 'core/notification';

const SELECTORS = {
    ROOT: '[data-region="ai-widget"]',
    INPUT: '[data-region="input"]',
    THREAD: '[data-region="thread"]',
    HISTORY: '[data-region="history"]',
    SEND: '[data-action="send"]',
};

const STATE = {COLLAPSED: 'collapsed', DRAWER: 'drawer', FULLSCREEN: 'fullscreen'};

// Mirror backend query.php::MAX_HISTORY_TURNS. Client-side cap keeps the payload
// small; the backend still slices and re-sanitises defensively.
const MAX_HISTORY_TURNS = 5;

let courseId = 0;
const sessionHistory = [];
const resultCache = {};
let charts = [];

/**
 * Initialise the widget.
 *
 * @param {Number} courseid The current course id.
 */
export const init = (courseid) => {
    courseId = parseInt(courseid, 10) || 0;
    const root = document.querySelector(SELECTORS.ROOT);
    if (!root || root.dataset.initialised) {
        return;
    }
    root.dataset.initialised = '1';
    registerListeners(root);
};

/**
 * Wire up delegated click + keydown listeners.
 *
 * @param {HTMLElement} root The widget root element.
 */
const registerListeners = (root) => {
    root.addEventListener('click', (e) => {
        const actionEl = e.target.closest('[data-action]');
        if (actionEl) {
            handleAction(root, actionEl.dataset.action, actionEl);
            return;
        }
        const histEl = e.target.closest('[data-history-id]');
        if (histEl) {
            showCached(root, histEl.dataset.historyId);
        }
    });
    const input = root.querySelector(SELECTORS.INPUT);
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            submitQuery(root, input.value);
        }
    });
};

/**
 * Dispatch a data-action click.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} action The action name.
 * @param {HTMLElement} el The clicked element.
 */
const handleAction = (root, action, el) => {
    switch (action) {
        case 'open':
            setState(root, STATE.DRAWER);
            focusInput(root);
            break;
        case 'expand':
            setState(root, STATE.FULLSCREEN);
            focusInput(root);
            break;
        case 'collapse':
            setState(root, STATE.DRAWER);
            focusInput(root);
            break;
        case 'close':
            setState(root, STATE.COLLAPSED);
            break;
        case 'new':
            clearThread(root);
            root.dataset.view = 'welcome';
            focusInput(root);
            break;
        case 'send':
            submitQuery(root, root.querySelector(SELECTORS.INPUT).value);
            break;
        case 'suggest':
            submitQuery(root, el.textContent.trim());
            break;
        default:
            break;
    }
};

/**
 * Set the widget state attribute.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} state One of STATE.*.
 */
const setState = (root, state) => {
    root.dataset.state = state;
};

/**
 * Focus the prompt input shortly after a state change.
 *
 * @param {HTMLElement} root The widget root element.
 */
const focusInput = (root) => {
    const input = root.querySelector(SELECTORS.INPUT);
    if (input) {
        setTimeout(() => input.focus(), 50);
    }
};

/**
 * Toggle the loading state of the input + send button.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {Boolean} loading Whether a request is in flight.
 */
const setLoading = (root, loading) => {
    const input = root.querySelector(SELECTORS.INPUT);
    const send = root.querySelector(SELECTORS.SEND);
    input.disabled = loading;
    send.disabled = loading;
    send.textContent = loading ? root.dataset.strLoading : root.dataset.strAsk;
};

/**
 * Generate a RFC4122-ish unique id, falling back when crypto is unavailable.
 *
 * @return {String} A unique request id.
 */
const generateRequestId = () => {
    if (window.crypto && window.crypto.randomUUID) {
        return window.crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = Math.floor(Math.random() * 16);
        const v = c === 'x' ? r : (r % 4 + 8);
        return v.toString(16);
    });
};

/**
 * Build the multi-turn history payload from prior successful exchanges.
 *
 * Oldest-first; includes a turn only when it succeeded and produced SQL, so the
 * AI is never fed a prompt with no SQL. Capped to the last MAX_HISTORY_TURNS.
 *
 * @return {Array<{prompt: String, sql: String}>} Prior turns for the backend.
 */
const buildHistory = () => sessionHistory
    .map((item) => resultCache[item.requestId])
    .filter((rec) => rec && rec.response
        && rec.response.status === 'SUCCESS'
        && typeof rec.response.sql === 'string'
        && rec.response.sql.length > 0)
    .slice(-MAX_HISTORY_TURNS)
    .map((rec) => ({prompt: rec.prompt, sql: rec.response.sql}));

/**
 * Submit a prompt to the external function and render the result.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} rawPrompt The user's prompt.
 */
const submitQuery = (root, rawPrompt) => {
    const prompt = (rawPrompt || '').trim();
    if (!prompt) {
        return;
    }
    const requestId = generateRequestId();
    root.querySelector(SELECTORS.INPUT).value = '';
    root.dataset.view = 'thread';
    setLoading(root, true);

    const history = buildHistory();

    fetchMany([{
        methodname: 'local_ai_analysis_query',
        args: {prompt: prompt, courseid: courseId, request_id: requestId, format: true, history: history},
    }])[0]
        .then((response) => {
            cacheAndRender(root, prompt, requestId, response);
            return response;
        })
        .catch((error) => {
            renderError(root, prompt, root.dataset.msgFailed || root.dataset.strError);
            Notification.exception(error);
        })
        .always(() => {
            setLoading(root, false);
            focusInput(root);
        });
};

/**
 * Cache a successful exchange, push to history, and render it.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} prompt The user's prompt.
 * @param {String} requestId The request id.
 * @param {Object} response The external function response envelope.
 */
const cacheAndRender = (root, prompt, requestId, response) => {
    resultCache[requestId] = {prompt: prompt, response: response};
    sessionHistory.push({requestId: requestId, prompt: prompt});
    renderHistory(root);
    renderRecord(root, resultCache[requestId]);
};

/**
 * Re-display a cached exchange from history.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} requestId The request id key.
 */
const showCached = (root, requestId) => {
    const record = resultCache[requestId];
    if (!record) {
        return;
    }
    root.dataset.view = 'thread';
    renderRecord(root, record);
};

/**
 * Destroy any live charts and empty the thread.
 *
 * @param {HTMLElement} root The widget root element.
 */
const clearThread = (root) => {
    charts.forEach((c) => c.destroy());
    charts = [];
    root.querySelector(SELECTORS.THREAD).innerHTML = '';
};

/**
 * Render a cached exchange (prompt bubble + result) into the thread.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {Object} record A {prompt, response} record.
 */
const renderRecord = (root, record) => {
    clearThread(root);
    const thread = root.querySelector(SELECTORS.THREAD);
    thread.appendChild(buildUserBubble(record.prompt));

    const response = record.response;
    if (!response || response.status !== 'SUCCESS') {
        thread.appendChild(buildErrorBlock(friendlyMessage(root, response)));
        return;
    }

    const rows = parseRows(response.rows);
    let links = {};
    try {
        links = JSON.parse(response.links || '{}');
    } catch (e) {
        // Malformed links JSON — treat as empty.
    }
    if (rows.length) {
        thread.appendChild(buildTable(rows, links));
        let chart = null;
        if (response.chart) {
            try {
                const spec = JSON.parse(response.chart);
                if (spec && spec.type && spec.x && spec.y &&
                        rows[0] !== undefined &&
                        Object.prototype.hasOwnProperty.call(rows[0], spec.x) &&
                        Object.prototype.hasOwnProperty.call(rows[0], spec.y)) {
                    chart = buildChartFromSpec(rows, spec);
                }
            } catch (e) {
                // Parse failed; fall through to heuristic.
            }
        }
        if (!chart) {
            chart = maybeBuildChart(rows);
        }
        if (chart) {
            thread.appendChild(chart.wrapper);
            charts.push(new ChartJS(chart.canvas.getContext('2d'), chart.config));
        }
    }
    if (response.answer) {
        thread.appendChild(buildAnswer(response.answer));
    }
    if (response.format_note) {
        thread.appendChild(buildCaption(response.format_note));
    }
    thread.scrollTop = thread.scrollHeight;
};

/**
 * Render an error exchange (prompt bubble + error block).
 *
 * @param {HTMLElement} root The widget root element.
 * @param {String} prompt The user's prompt.
 * @param {String} message The error message.
 */
const renderError = (root, prompt, message) => {
    clearThread(root);
    const thread = root.querySelector(SELECTORS.THREAD);
    thread.appendChild(buildUserBubble(prompt));
    thread.appendChild(buildErrorBlock(message));
};

/**
 * Map a non-success response to a human-friendly message.
 *
 * @param {HTMLElement} root The widget root element.
 * @param {Object} response The external function response envelope (may be null).
 * @return {String} A user-facing message.
 */
const friendlyMessage = (root, response) => {
    const byStatus = {
        OUT_OF_SCOPE: root.dataset.msgScope,
        RATE_LIMITED: root.dataset.msgRate,
        BLOCKED_INJECTION: root.dataset.msgBlocked,
    };
    const status = response ? response.status : null;
    return byStatus[status] || root.dataset.msgFailed || root.dataset.strError;
};

/**
 * Parse the response rows (array of JSON strings) into objects.
 *
 * @param {Array} rows The raw rows from the response.
 * @return {Array} Parsed row objects.
 */
const parseRows = (rows) => {
    if (!Array.isArray(rows)) {
        return [];
    }
    const out = [];
    rows.forEach((r) => {
        try {
            out.push(typeof r === 'string' ? JSON.parse(r) : r);
        } catch (e) {
            // Skip an unparseable row.
        }
    });
    return out;
};

/**
 * Create an element with optional class and text (text set safely).
 *
 * @param {String} tag The tag name.
 * @param {String|null} className The class name, or null.
 * @param {String|Number|null} text The text content, or null/undefined.
 * @return {HTMLElement} The created element.
 */
const el = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) {
        node.className = className;
    }
    if (text !== undefined && text !== null) {
        node.textContent = String(text);
    }
    return node;
};

/**
 * Build the right-aligned user prompt bubble.
 *
 * @param {String} prompt The user's prompt.
 * @return {HTMLElement} The bubble wrapper.
 */
const buildUserBubble = (prompt) => {
    const wrap = el('div', 'lai-msg lai-msg-user');
    wrap.appendChild(el('div', 'lai-bubble', prompt));
    return wrap;
};

/**
 * Build an error block.
 *
 * @param {String} message The error message.
 * @return {HTMLElement} The error element.
 */
const buildErrorBlock = (message) => el('div', 'lai-error', message);

/**
 * Build the AI answer prose block.
 *
 * @param {String} answer The formatted answer.
 * @return {HTMLElement} The answer element.
 */
const buildAnswer = (answer) => el('div', 'lai-answer', answer);

/**
 * Build a small caption (e.g. format note).
 *
 * @param {String} note The caption text.
 * @return {HTMLElement} The caption element.
 */
const buildCaption = (note) => el('div', 'lai-caption', note);

/**
 * Build a data table from row objects, rendering linked columns as anchors.
 *
 * @param {Array} rows Parsed row objects (non-empty).
 * @param {Object} links Map of column name to entity type ('course'|'user').
 * @return {HTMLElement} The table wrapper.
 */
const buildTable = (rows, links) => {
    const cols = Object.keys(rows[0]);
    const wrap = el('div', 'lai-table-wrap');
    const table = el('table', 'lai-table');

    const thead = el('thead');
    const htr = el('tr');
    cols.forEach((c) => htr.appendChild(el('th', null, c)));
    thead.appendChild(htr);
    table.appendChild(thead);

    const tbody = el('tbody');
    rows.forEach((row) => {
        const tr = el('tr');
        cols.forEach((c) => {
            const td = el('td');
            const value = row[c];
            const entityType = links && links[c];
            if (entityType === 'course' || entityType === 'user') {
                const href = entityType === 'course'
                    ? M.cfg.wwwroot + '/course/view.php?id=' + encodeURIComponent(value)
                    : M.cfg.wwwroot + '/user/profile.php?id=' + encodeURIComponent(value);
                const a = document.createElement('a');
                a.href = href;
                a.textContent = String(value);
                a.target = '_blank';
                a.rel = 'noopener';
                a.className = 'lai-link';
                td.appendChild(a);
            } else {
                td.textContent = value !== null && value !== undefined ? String(value) : '';
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    table.appendChild(tbody);

    wrap.appendChild(table);
    return wrap;
};

/**
 * Test whether a value is finite-numeric.
 *
 * @param {*} v The value.
 * @return {Boolean} True if numeric.
 */
const isNumeric = (v) => v !== null && v !== '' && !isNaN(parseFloat(v)) && isFinite(v);

/** Colour palette used by pie charts. */
const PIE_COLORS = [
    '#0F6CBF', '#E66A1A', '#2CA02C', '#D62728', '#9467BD',
    '#8C564B', '#E377C2', '#7F7F7F', '#BCBD22', '#17BECF',
];

/**
 * Build a chart from an AI-proposed spec {type, x, y}.
 *
 * @param {Array} rows Parsed row objects (non-empty).
 * @param {{type: string, x: string, y: string}} spec Validated chart spec.
 * @return {Object} {wrapper, canvas, config}
 */
const buildChartFromSpec = (rows, spec) => {
    const labels = rows.map((r) => String(r[spec.x]));
    const values = rows.map((r) => parseFloat(r[spec.y]));

    const wrapper = el('div', 'lai-chart-wrap');
    const canvas = document.createElement('canvas');
    wrapper.appendChild(canvas);

    let config;
    if (spec.type === 'pie') {
        const colors = rows.map((_, i) => PIE_COLORS[i % PIE_COLORS.length]);
        config = {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{label: spec.y, data: values, backgroundColor: colors}],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {legend: {display: true}},
            },
        };
    } else {
        config = {
            type: spec.type,
            data: {
                labels: labels,
                datasets: [{label: spec.y, data: values, backgroundColor: '#0F6CBF'}],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {legend: {display: false}},
                scales: {y: {beginAtZero: true}},
            },
        };
    }
    return {wrapper: wrapper, canvas: canvas, config: config};
};

/**
 * Build a bar-chart config if the rows contain a numeric column.
 *
 * @param {Array} rows Parsed row objects.
 * @return {Object|null} {wrapper, canvas, config} or null when no chart applies.
 */
const maybeBuildChart = (rows) => {
    if (rows.length < 2) {
        return null;
    }
    const cols = Object.keys(rows[0]);
    let valueKey = null;
    for (let i = 0; i < cols.length; i++) {
        if (rows.every((r) => isNumeric(r[cols[i]]))) {
            valueKey = cols[i];
            break;
        }
    }
    if (!valueKey) {
        return null;
    }
    const labelKey = cols.find((c) => c !== valueKey) || cols[0];
    const labels = rows.map((r) => String(r[labelKey]));
    const values = rows.map((r) => parseFloat(r[valueKey]));

    const wrapper = el('div', 'lai-chart-wrap');
    const canvas = document.createElement('canvas');
    wrapper.appendChild(canvas);

    const config = {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{label: valueKey, data: values, backgroundColor: '#0F6CBF'}],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {legend: {display: false}},
            scales: {y: {beginAtZero: true}},
        },
    };
    return {wrapper: wrapper, canvas: canvas, config: config};
};

/**
 * Re-render the session history list (newest first).
 *
 * @param {HTMLElement} root The widget root element.
 */
const renderHistory = (root) => {
    const list = root.querySelector(SELECTORS.HISTORY);
    list.innerHTML = '';
    sessionHistory.slice().reverse().forEach((item) => {
        const li = el('li', 'lai-history-item', item.prompt);
        li.dataset.historyId = item.requestId;
        list.appendChild(li);
    });
};
