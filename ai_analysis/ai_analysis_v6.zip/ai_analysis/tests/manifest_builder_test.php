<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\manifest\manifest_builder
 */
class manifest_builder_test extends \advanced_testcase {

    public function test_admin_returns_full_manifest(): void {
        $m = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertEqualsCanonicalizing(
            [
                'mdl_user', 'mdl_course', 'mdl_grade_grades', 'mdl_grade_items',
                'mdl_course_modules', 'mdl_enrol', 'mdl_user_enrolments', 'mdl_logstore_standard_log',
                'mdl_assign', 'mdl_assign_submission', 'mdl_quiz', 'mdl_quiz_grades',
                'mdl_groups', 'mdl_groups_members', 'mdl_ai_course_staff', 'mdl_ai_student_engagement',
                'mdl_ai_course_performance', 'mdl_ai_course_feedback', 'mdl_ai_feedback_activity',
            ],
            array_keys($m)
        );
        $this->assertArrayNotHasKey('_scope_note', $m['mdl_user']);
        $this->assertArrayNotHasKey('_scope_note', $m['mdl_course']);
    }

    public function test_teacher_attaches_scope_note(): void {
        $m = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 42);
        $this->assertArrayHasKey('_scope_note', $m['mdl_user']);
        $this->assertStringContainsString('42', $m['mdl_user']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_logstore_standard_log']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_course']);
        $this->assertStringContainsString('42', $m['mdl_course']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_grade_items']);
        $this->assertStringContainsString('42', $m['mdl_grade_items']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_enrol']);

        // New tables must carry scope notes for non-admin + courseid.
        $this->assertArrayHasKey('_scope_note', $m['mdl_assign']);
        $this->assertStringContainsString('42', $m['mdl_assign']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_assign_submission']);
        $this->assertStringContainsString('42', $m['mdl_assign_submission']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_quiz']);
        $this->assertStringContainsString('42', $m['mdl_quiz']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_quiz_grades']);
        $this->assertStringContainsString('42', $m['mdl_quiz_grades']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_groups']);
        $this->assertStringContainsString('42', $m['mdl_groups']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $m['mdl_groups_members']);
        $this->assertStringContainsString('42', $m['mdl_groups_members']['_scope_note']);
    }

    public function test_manifest_includes_course_staff_view(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_course_staff', $manifest);
        $this->assertSame(
            ['courseid', 'userid', 'firstname', 'lastname', 'role'],
            $manifest['mdl_ai_course_staff']
        );
    }

    public function test_course_staff_view_gets_scope_note_for_scoped_teacher(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 77);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_course_staff']);
        $this->assertStringContainsString('77', $manifest['mdl_ai_course_staff']['_scope_note']);
    }

    /**
     * @dataProvider role_provider
     */
    public function test_no_forbidden_columns_ever_appear(string $role, int $courseid): void {
        // Sensitive columns that must NEVER appear in any manifest variant.
        $forbidden = ['password', 'secret', 'sesskey', 'token', 'apikey', 'hash', 'salt', 'privatekey'];
        $m = \local_ai_analysis\manifest\manifest_builder::build($role, $courseid);
        foreach ($m as $table => $cols) {
            if (!is_array($cols)) continue;
            foreach ($cols as $key => $col) {
                if ($key === '_scope_note') continue;
                $this->assertNotContains($col, $forbidden, "Forbidden column '$col' appeared in $table for role=$role");
            }
        }
    }

    public static function role_provider(): array {
        return [
            ['admin', 0],
            ['manager', 0],
            ['editingteacher', 0],
            ['editingteacher', 42],
            ['teacher', 99],
        ];
    }

    public function test_manifest_includes_student_engagement_view(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_student_engagement', $manifest);
        $this->assertSame(
            ['courseid', 'userid', 'firstname', 'lastname', 'last_activity_days',
             'activity_count', 'missing_submissions', 'avg_grade', 'risk_band'],
            $manifest['mdl_ai_student_engagement']
        );
    }

    public function test_engagement_view_gets_scope_note_for_scoped_teacher(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 88);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_student_engagement']);
        $this->assertStringContainsString('88', $manifest['mdl_ai_student_engagement']['_scope_note']);
    }

    public function test_manifest_includes_course_performance_view(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_course_performance', $manifest);
        $this->assertSame(
            ['courseid', 'coursename', 'student_count', 'at_risk_high', 'at_risk_medium',
             'at_risk_low', 'at_risk_pct', 'avg_grade', 'avg_missing_submissions', 'pct_no_missing'],
            $manifest['mdl_ai_course_performance']
        );
    }

    public function test_course_performance_view_gets_scope_note_for_scoped_teacher(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 99);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_course_performance']);
        $this->assertStringContainsString('99', $manifest['mdl_ai_course_performance']['_scope_note']);
    }

    public function test_feedback_views_are_allowlisted(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $this->assertArrayHasKey('mdl_ai_course_feedback', $manifest);
        $this->assertArrayHasKey('mdl_ai_feedback_activity', $manifest);
        $this->assertContains('avg_rating', $manifest['mdl_ai_course_feedback']);
        $this->assertContains('pct_low', $manifest['mdl_ai_course_feedback']);
        $this->assertContains('activityid', $manifest['mdl_ai_feedback_activity']);
    }

    public function test_feedback_views_get_scope_note_for_scoped_role(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 23);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_course_feedback']);
        $this->assertStringContainsString('23', $manifest['mdl_ai_course_feedback']['_scope_note']);
        $this->assertArrayHasKey('_scope_note', $manifest['mdl_ai_feedback_activity']);
    }
}
