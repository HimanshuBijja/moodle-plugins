<?php
namespace local_ai_analysis;

use local_ai_analysis\db\course_feedback_view;
use local_ai_analysis\db\feedback_activity_view;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\course_feedback_view
 * @covers \local_ai_analysis\db\feedback_activity_view
 */
class feedback_views_test extends \advanced_testcase {

    protected function setUp(): void {
        global $DB;
        parent::setUp();
        course_feedback_view::create($DB);
        feedback_activity_view::create($DB);
    }

    protected function tearDown(): void {
        global $DB;
        $p = $DB->get_prefix();
        $DB->execute('DROP VIEW IF EXISTS ' . $p . course_feedback_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $p . feedback_activity_view::VIEW);
        parent::tearDown();
    }

    /**
     * Seed one custom-feedback activity in a course with the given star values,
     * plus (optionally) one free-text question + answer that must be ignored.
     * Returns the new customfeedback id.
     */
    private function seed_feedback(int $courseid, array $stars, bool $withtext = false): int {
        global $DB;
        $now = time();
        $cfid = $DB->insert_record('customfeedback', (object) [
            'course' => $courseid, 'name' => 'Survey', 'intro' => '', 'introformat' => 1,
            'allowmulti' => 0, 'timecreated' => $now, 'timemodified' => $now,
        ]);
        $qid = $DB->insert_record('customfeedback_q', (object) [
            'customfeedbackid' => $cfid, 'type' => 'star', 'name' => 'Rate', 'intro' => '',
            'introformat' => 1, 'required' => 1, 'sortorder' => 1,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        $textqid = 0;
        if ($withtext) {
            $textqid = $DB->insert_record('customfeedback_q', (object) [
                'customfeedbackid' => $cfid, 'type' => 'text', 'name' => 'Comment', 'intro' => '',
                'introformat' => 1, 'required' => 0, 'sortorder' => 2,
                'timecreated' => $now, 'timemodified' => $now,
            ]);
        }
        foreach ($stars as $val) {
            $rid = $DB->insert_record('customfeedback_r', (object) [
                'customfeedbackid' => $cfid, 'userid' => 7, 'timecreated' => $now,
            ]);
            $DB->insert_record('customfeedback_a', (object) [
                'responseid' => $rid, 'questionid' => $qid, 'valuestar' => $val, 'valuetext' => null,
            ]);
            if ($withtext) {
                $DB->insert_record('customfeedback_a', (object) [
                    'responseid' => $rid, 'questionid' => $textqid, 'valuestar' => null,
                    'valuetext' => 'a comment',
                ]);
            }
        }
        return $cfid;
    }

    public function test_course_view_aggregates_star_ratings(): void {
        global $DB;
        $this->resetAfterTest();
        $c = $this->getDataGenerator()->create_course(['fullname' => 'Alpha']);
        // Ratings 1,2,3,4,5 -> avg 3.0; two of five are <=2 -> pct_low 40.0.
        $this->seed_feedback($c->id, [1, 2, 3, 4, 5], true);
        $this->resetDebugging();

        $row = $DB->get_record('ai_course_feedback', ['courseid' => $c->id], '*', MUST_EXIST);
        $this->assertSame('Alpha', $row->coursename);
        $this->assertSame(1, (int) $row->activity_count);
        $this->assertSame(5, (int) $row->submission_count);
        $this->assertSame(5, (int) $row->rating_count); // text answers ignored
        $this->assertEquals(3.0, (float) $row->avg_rating);
        $this->assertEquals(50.0, (float) $row->avg_rating_pct); // (3-1)/4*100
        $this->assertEquals(40.0, (float) $row->pct_low);
        // Aggregate-only: userid must not be a column on the view.
        $this->assertObjectNotHasProperty('userid', $row);
    }

    public function test_course_view_rolls_up_multiple_activities(): void {
        global $DB;
        $this->resetAfterTest();
        $c = $this->getDataGenerator()->create_course();
        $this->seed_feedback($c->id, [2, 2]); // avg 2
        $this->seed_feedback($c->id, [4, 4]); // avg 4
        $this->resetDebugging();

        $row = $DB->get_record('ai_course_feedback', ['courseid' => $c->id], '*', MUST_EXIST);
        $this->assertSame(2, (int) $row->activity_count);
        $this->assertSame(4, (int) $row->rating_count);
        // Mean of individual ratings (2,2,4,4) = 3.0, NOT mean-of-activity-means.
        $this->assertEquals(3.0, (float) $row->avg_rating);
    }

    public function test_activity_view_is_per_activity(): void {
        global $DB;
        $this->resetAfterTest();
        $c = $this->getDataGenerator()->create_course();
        $cf1 = $this->seed_feedback($c->id, [1, 1]); // avg 1
        $cf2 = $this->seed_feedback($c->id, [5, 5]); // avg 5
        $this->resetDebugging();

        $a1 = $DB->get_record('ai_feedback_activity', ['activityid' => $cf1], '*', MUST_EXIST);
        $a2 = $DB->get_record('ai_feedback_activity', ['activityid' => $cf2], '*', MUST_EXIST);
        $this->assertEquals(1.0, (float) $a1->avg_rating);
        $this->assertEquals(5.0, (float) $a2->avg_rating);
        $this->assertSame(1, (int) $a1->star_question_count);
    }

    public function test_site_course_is_excluded(): void {
        global $DB;
        $this->resetAfterTest();
        $this->seed_feedback(1, [5]); // site course id=1
        $this->resetDebugging();
        $this->assertFalse($DB->record_exists('ai_course_feedback', ['courseid' => 1]));
    }
}
