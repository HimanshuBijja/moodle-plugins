<?php
namespace local_ai_analysis;

use local_ai_analysis\intent\sql_template;
use local_ai_analysis\manifest\manifest_builder;
use local_ai_analysis\security\sql_validator;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * @covers \local_ai_analysis\intent\sql_template
 */
class sql_template_test extends \advanced_testcase {

    public function test_student_listing_builds_sql_with_bound_courseid(): void {
        [$sql, $params] = sql_template::build('student_listing', 42);
        $this->assertStringContainsStringIgnoringCase('from mdl_user', $sql);
        $this->assertStringContainsStringIgnoringCase('mdl_user_enrolments', $sql);
        $this->assertStringContainsStringIgnoringCase('mdl_enrol', $sql);
        $this->assertSame([42], $params);
    }

    public function test_student_listing_sql_passes_validator(): void {
        // The manifest the validator uses is the same one the gateway builds.
        $manifest  = manifest_builder::build('editingteacher', 42);
        $validator = new sql_validator($manifest);
        [$sql, $params] = sql_template::build('student_listing', 42);
        // validate() takes $sql by reference and throws on any policy breach.
        $this->assertTrue($validator->validate($sql, $params));
    }

    public function test_unknown_intent_throws(): void {
        $this->expectException(\coding_exception::class);
        sql_template::build('no_such_intent', 1);
    }

    public function test_course_staff_builds_sql_with_bound_courseid(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_staff', 55);
        $this->assertStringContainsStringIgnoringCase('from mdl_ai_course_staff', $sql);
        $this->assertSame([55], $params);
    }

    public function test_course_staff_sql_passes_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 55);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_staff', 55);
        $this->assertTrue($validator->validate($sql, $params));
    }

    public function test_at_risk_builds_sql_with_bound_courseid(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('at_risk_students', 66);
        $this->assertStringContainsStringIgnoringCase('from mdl_ai_student_engagement', $sql);
        $this->assertStringContainsStringIgnoringCase("risk_band = 'high'", $sql);
        $this->assertSame([66], $params);
    }

    public function test_at_risk_sql_passes_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('editingteacher', 66);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('at_risk_students', 66);
        $this->assertTrue($validator->validate($sql, $params));
    }

    public function test_course_performance_scoped_binds_courseid(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_performance', 55);
        $this->assertStringContainsStringIgnoringCase('where p.courseid = ?', $sql);
        $this->assertSame([55], $params);
    }

    public function test_course_performance_global_ranks_no_params(): void {
        [$sql, $params] = \local_ai_analysis\intent\sql_template::build('course_performance', 0);
        $this->assertStringContainsStringIgnoringCase('order by p.at_risk_pct desc', $sql);
        $this->assertStringNotContainsStringIgnoringCase('where', $sql);
        $this->assertSame([], $params);
    }

    public function test_course_performance_both_shapes_pass_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$scoped, $sp] = \local_ai_analysis\intent\sql_template::build('course_performance', 55);
        [$global, $gp] = \local_ai_analysis\intent\sql_template::build('course_performance', 0);
        $this->assertTrue($validator->validate($scoped, $sp));
        $this->assertTrue($validator->validate($global, $gp));
    }

    public function test_course_feedback_scoped_binds_courseid_and_no_chart(): void {
        [$sql, $params, $chart] = \local_ai_analysis\intent\sql_template::build('course_feedback', 23);
        $this->assertStringContainsStringIgnoringCase('from mdl_ai_course_feedback', $sql);
        $this->assertStringContainsStringIgnoringCase('where f.courseid = ?', $sql);
        $this->assertSame([23], $params);
        $this->assertNull($chart); // single course -> answer, not chart
    }

    public function test_course_feedback_global_ranks_with_bar_chart(): void {
        [$sql, $params, $chart] = \local_ai_analysis\intent\sql_template::build('course_feedback', 0);
        $this->assertStringContainsStringIgnoringCase('order by f.avg_rating asc', $sql);
        $this->assertStringNotContainsStringIgnoringCase('where', $sql);
        $this->assertSame([], $params);
        $this->assertSame(['type' => 'bar', 'x' => 'coursename', 'y' => 'avg_rating'], $chart);
    }

    public function test_course_feedback_both_shapes_pass_validator(): void {
        $manifest  = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $validator = new \local_ai_analysis\security\sql_validator($manifest);
        [$scoped, $sp] = \local_ai_analysis\intent\sql_template::build('course_feedback', 23);
        [$global, $gp] = \local_ai_analysis\intent\sql_template::build('course_feedback', 0);
        $this->assertTrue($validator->validate($scoped, $sp));
        $this->assertTrue($validator->validate($global, $gp));
    }
}
