<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\ai\ollama_client;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * Fake transport recording the last request and replaying a canned response.
 */
class ollama_fake_transport implements http_transport_interface {
    public ?string $last_url = null;
    public ?array $last_headers = null;
    public ?string $last_body = null;
    public ?int $last_timeout = null;
    public array $next_response = ['status' => 200, 'headers' => [], 'body' => ''];

    public function post(string $url, array $headers, string $body, int $timeout = 30): array {
        $this->last_url = $url;
        $this->last_headers = $headers;
        $this->last_body = $body;
        $this->last_timeout = $timeout;
        return $this->next_response;
    }
}

/**
 * @covers \local_ai_analysis\ai\ollama_client
 */
class ollama_client_test extends \advanced_testcase {

    private function chat_response(string $content): array {
        return ['status' => 200, 'headers' => [], 'body' => json_encode([
            'choices' => [['message' => ['role' => 'assistant', 'content' => $content]]],
        ])];
    }

    public function test_default_base_url_and_model_no_auth_header(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":"x"}');
        $c = new ollama_client($t);
        $c->generate_sql('SYS', 'USR');
        $this->assertSame('http://localhost:11434/v1/chat/completions', $t->last_url);
        // No Authorization header is sent (Ollama has no auth).
        foreach ($t->last_headers as $h) {
            $this->assertStringNotContainsStringIgnoringCase('Authorization', $h);
        }
        $body = json_decode($t->last_body, true);
        $this->assertSame('qwen2.5-coder', $body['model']);
        // OpenAI-compatible payload is inherited unchanged.
        $this->assertSame(['type' => 'json_object'], $body['response_format']);
        $this->assertSame('SYS', $body['messages'][0]['content']);
    }

    public function test_custom_base_url_trailing_slash_stripped(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new ollama_client($t, 'http://ollama.internal:11434/');
        $c->generate_sql('s', 'u');
        $this->assertSame('http://ollama.internal:11434/v1/chat/completions', $t->last_url);
    }

    public function test_custom_model_used(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new ollama_client($t, '', 'llama3.1');
        $c->generate_sql('s', 'u');
        $this->assertSame('llama3.1', json_decode($t->last_body, true)['model']);
    }

    public function test_happy_path_inherits_parsing(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user WHERE id = ? LIMIT 10","params":[5],"explanation":"by id"}');
        $c = new ollama_client($t);
        $r = $c->generate_sql('s', 'u');
        $this->assertSame('sql', $r['type']);
        $this->assertSame([5], $r['params']);
    }

    public function test_out_of_scope_inherited(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"error":"out_of_scope"}');
        $c = new ollama_client($t);
        $this->assertSame('out_of_scope', $c->generate_sql('s', 'u')['type']);
    }

    public function test_timeout_threaded_to_transport(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new ollama_client($t, '', '', 120);
        $c->generate_sql('s', 'u');
        $this->assertSame(120, $t->last_timeout);
    }

    public function test_default_timeout_is_30(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}');
        $c = new ollama_client($t);
        $c->generate_sql('s', 'u');
        $this->assertSame(30, $t->last_timeout);
    }

    public function test_format_result_inherited(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('PERSON_1 has the top grade.');
        $c = new ollama_client($t);
        $answer = $c->format_result('who scored highest', [['firstname' => 'PERSON_1']]);
        $this->assertSame('PERSON_1 has the top grade.', $answer);
        $this->assertArrayNotHasKey('response_format', json_decode($t->last_body, true));
    }

    public function test_history_messages_inherited_from_openai_client(): void {
        $t = new ollama_fake_transport();
        $t->next_response = $this->chat_response('{"sql":"SELECT id FROM mdl_user LIMIT 10","params":[],"explanation":""}');
        $c = new ollama_client($t);
        $history = [
            ['prompt' => 'list users', 'sql' => 'SELECT id FROM mdl_user LIMIT 10'],
        ];
        $c->generate_sql('SYS', 'filter to admins', $history);
        $body = json_decode($t->last_body, true);
        // messages: [system, user-hist1, assistant-hist1, user-final]
        $this->assertCount(4, $body['messages']);
        $this->assertSame('system',    $body['messages'][0]['role']);
        $this->assertSame('user',      $body['messages'][1]['role']);
        $this->assertSame('list users', $body['messages'][1]['content']);
        $this->assertSame('assistant', $body['messages'][2]['role']);
        $this->assertSame('user',      $body['messages'][3]['role']);
        $this->assertSame('filter to admins', $body['messages'][3]['content']);
    }
}
