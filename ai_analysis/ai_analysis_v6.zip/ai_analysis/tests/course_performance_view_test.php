<?php
namespace local_ai_analysis;

use local_ai_analysis\db\course_staff_view;
use local_ai_analysis\db\student_engagement_view;
use local_ai_analysis\db\course_performance_view;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\course_performance_view
 */
class course_performance_view_test extends \advanced_testcase {

    protected function setUp(): void {
        global $DB;
        parent::setUp();
        course_staff_view::create($DB);
        student_engagement_view::create($DB);
        course_performance_view::create($DB);
    }

    protected function tearDown(): void {
        global $DB;
        $p = $DB->get_prefix();
        $DB->execute('DROP VIEW IF EXISTS ' . $p . course_performance_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $p . student_engagement_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $p . course_staff_view::VIEW);
        parent::tearDown();
    }

    private function enrol(int $userid, int $courseid): void {
        global $DB;
        $inst = $DB->get_record('enrol', ['courseid' => $courseid, 'enrol' => 'manual'], '*', MUST_EXIST);
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $inst->id, 'userid' => $userid, 'status' => 0,
            'timestart' => 0, 'timeend' => 0, 'modifierid' => 0,
            'timecreated' => time(), 'timemodified' => time(),
        ]);
    }

    private function log(int $userid, int $courseid, int $time): void {
        global $DB;
        $DB->insert_record('logstore_standard_log', (object) [
            'eventname' => '\\core\\event\\course_viewed', 'component' => 'core',
            'action' => 'viewed', 'target' => 'course', 'crud' => 'r', 'edulevel' => 0,
            'contextid' => 1, 'contextlevel' => 50, 'contextinstanceid' => $courseid,
            'userid' => $userid, 'courseid' => $courseid, 'anonymous' => 0,
            'timecreated' => $time, 'origin' => 'web', 'ip' => '0.0.0.0',
        ]);
    }

    public function test_rollup_metrics_and_exclusions(): void {
        global $DB;
        $this->resetAfterTest();
        $now = time();

        // Course A: 2 high-risk students (no activity, missing submission).
        $ca = $this->getDataGenerator()->create_course(['fullname' => 'Alpha']);
        $this->getDataGenerator()->get_plugin_generator('mod_assign')->create_instance(['course' => $ca->id]);
        foreach ([0, 1] as $i) {
            $s = $this->getDataGenerator()->create_user();
            $this->enrol($s->id, $ca->id);
        }

        // Course B: 2 low-risk students (active + submitted).
        $cb = $this->getDataGenerator()->create_course(['fullname' => 'Beta']);
        $asgB = $this->getDataGenerator()->get_plugin_generator('mod_assign')->create_instance(['course' => $cb->id]);
        foreach ([0, 1] as $i) {
            $s = $this->getDataGenerator()->create_user();
            $this->enrol($s->id, $cb->id);
            for ($k = 0; $k < 6; $k++) {
                $this->log($s->id, $cb->id, $now - $k * 60);
            }
            $DB->insert_record('assign_submission', (object) [
                'assignment' => $asgB->id, 'userid' => $s->id, 'status' => 'submitted',
                'groupid' => 0, 'attemptnumber' => 0, 'latest' => 1,
                'timecreated' => $now, 'timemodified' => $now,
            ]);
        }

        // Course C: only a teacher (staff), no students -> must not appear.
        $cc = $this->getDataGenerator()->create_course(['fullname' => 'Gamma']);
        $ccctx = \context_course::instance($cc->id);
        $teacher = $this->getDataGenerator()->create_user();
        $this->enrol($teacher->id, $cc->id);
        $trole = $DB->get_record('role', ['shortname' => 'editingteacher'], '*', MUST_EXIST);
        $DB->insert_record('role_assignments', (object) [
            'roleid' => $trole->id, 'contextid' => $ccctx->id, 'userid' => $teacher->id,
            'timemodified' => $now, 'modifierid' => 0, 'component' => '', 'itemid' => 0, 'sortorder' => 0,
        ]);

        // Clear any debugging from half-installed sibling themes (sprout/verdant) — unrelated to our plugin.
        $this->resetDebugging();

        $a = $DB->get_record('ai_course_performance', ['courseid' => $ca->id], '*', MUST_EXIST);
        $this->assertSame('Alpha', $a->coursename);
        $this->assertSame(2, (int) $a->student_count);
        $this->assertSame(2, (int) $a->at_risk_high);
        $this->assertEquals(100.0, (float) $a->at_risk_pct);
        $this->assertEquals(0.0, (float) $a->pct_no_missing);

        $b = $DB->get_record('ai_course_performance', ['courseid' => $cb->id], '*', MUST_EXIST);
        $this->assertSame(2, (int) $b->student_count);
        $this->assertSame(0, (int) $b->at_risk_high);
        $this->assertEquals(0.0, (float) $b->at_risk_pct);
        $this->assertEquals(100.0, (float) $b->pct_no_missing);

        $this->assertFalse($DB->record_exists('ai_course_performance', ['courseid' => $cc->id]));
        $this->assertSame(0, $DB->count_records('ai_course_performance', ['courseid' => 0]));
    }
}
