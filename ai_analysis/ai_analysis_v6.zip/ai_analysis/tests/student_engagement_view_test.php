<?php
namespace local_ai_analysis;

use local_ai_analysis\db\course_staff_view;
use local_ai_analysis\db\student_engagement_view;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\student_engagement_view
 */
class student_engagement_view_test extends \advanced_testcase {

    /** Both views must exist; engagement references the staff view. Create staff first. */
    protected function setUp(): void {
        global $DB;
        parent::setUp();
        course_staff_view::create($DB);
        student_engagement_view::create($DB);
    }

    protected function tearDown(): void {
        global $DB;
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . student_engagement_view::VIEW);
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . course_staff_view::VIEW);
        parent::tearDown();
    }

    /** Active manual enrolment, no role (so the user is a "student", not staff). */
    private function enrol(int $userid, int $courseid): void {
        global $DB;
        $inst = $DB->get_record('enrol', ['courseid' => $courseid, 'enrol' => 'manual'], '*', MUST_EXIST);
        $DB->insert_record('user_enrolments', (object) [
            'enrolid' => $inst->id, 'userid' => $userid, 'status' => 0,
            'timestart' => 0, 'timeend' => 0, 'modifierid' => 0,
            'timecreated' => time(), 'timemodified' => time(),
        ]);
    }

    /** Minimal valid logstore row. */
    private function log(int $userid, int $courseid, int $time): void {
        global $DB;
        $DB->insert_record('logstore_standard_log', (object) [
            'eventname' => '\\core\\event\\course_viewed', 'component' => 'core',
            'action' => 'viewed', 'target' => 'course', 'crud' => 'r', 'edulevel' => 0,
            'contextid' => 1, 'contextlevel' => 50, 'contextinstanceid' => $courseid,
            'userid' => $userid, 'courseid' => $courseid, 'anonymous' => 0,
            'timecreated' => $time, 'origin' => 'web', 'ip' => '0.0.0.0',
        ]);
    }

    public function test_metrics_risk_band_and_exclusions(): void {
        global $DB;
        $this->resetAfterTest();
        $now = time();

        $course = $this->getDataGenerator()->create_course();
        $coursectx = \context_course::instance($course->id);

        $assign = $this->getDataGenerator()->get_plugin_generator('mod_assign')
            ->create_instance(['course' => $course->id]);

        // High-risk student: old activity (>14d), few events (<5), no submission, no grade.
        $high = $this->getDataGenerator()->create_user();
        $this->enrol($high->id, $course->id);
        $this->log($high->id, $course->id, $now - 30 * DAYSECS);
        $this->log($high->id, $course->id, $now - 31 * DAYSECS);
        $this->log($high->id, 0, $now); // course-0 log: must never surface.

        // Low-risk student: recent + many events, submitted, good grade.
        $low = $this->getDataGenerator()->create_user();
        $this->enrol($low->id, $course->id);
        for ($i = 0; $i < 6; $i++) {
            $this->log($low->id, $course->id, $now - $i * 60);
        }
        $DB->insert_record('assign_submission', (object) [
            'assignment' => $assign->id, 'userid' => $low->id, 'status' => 'submitted',
            'groupid' => 0, 'attemptnumber' => 0, 'latest' => 1,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        $gi = $DB->insert_record('grade_items', (object) [
            'courseid' => $course->id, 'itemtype' => 'course', 'grademax' => 100,
            'timecreated' => $now, 'timemodified' => $now,
        ]);
        $DB->insert_record('grade_grades', (object) [
            'itemid' => $gi, 'userid' => $low->id, 'finalgrade' => 85,
            'timecreated' => $now, 'timemodified' => $now,
        ]);

        // A teacher (staff) — must be excluded.
        $teacher = $this->getDataGenerator()->create_user();
        $this->enrol($teacher->id, $course->id);
        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher'], '*', MUST_EXIST);
        $DB->insert_record('role_assignments', (object) [
            'roleid' => $teacherrole->id, 'contextid' => $coursectx->id, 'userid' => $teacher->id,
            'timemodified' => $now, 'modifierid' => 0, 'component' => '', 'itemid' => 0, 'sortorder' => 0,
        ]);

        // Clear any debugging from half-installed sibling themes (sprout/verdant) triggered
        // during course/user/context setup — unrelated to this plugin under test.
        $this->resetDebugging();

        // Key by userid (first field) so multiple students in one course don't collapse
        // under get_records()'s first-column-as-key rule.
        $rows = $DB->get_records('ai_student_engagement', ['courseid' => $course->id], '',
            'userid, courseid, firstname, lastname, last_activity_days, activity_count, missing_submissions, avg_grade, risk_band');
        $byuser = [];
        foreach ($rows as $r) {
            $byuser[(int) $r->userid] = $r;
        }

        $this->assertArrayNotHasKey((int) $teacher->id, $byuser);

        $this->assertArrayHasKey((int) $high->id, $byuser);
        $h = $byuser[(int) $high->id];
        $this->assertSame('high', $h->risk_band);
        $this->assertSame(2, (int) $h->activity_count);
        $this->assertSame(1, (int) $h->missing_submissions);
        $this->assertGreaterThanOrEqual(29, (int) $h->last_activity_days);
        $this->assertNull($h->avg_grade);

        $l = $byuser[(int) $low->id];
        $this->assertSame('low', $l->risk_band);
        $this->assertSame(6, (int) $l->activity_count);
        $this->assertSame(0, (int) $l->missing_submissions);
        $this->assertEquals(85.0, (float) $l->avg_grade);

        $this->assertSame(0, $DB->count_records('ai_student_engagement', ['courseid' => 0]));

        $this->assertTrue(property_exists($h, 'firstname'));
        $this->assertTrue(property_exists($h, 'lastname'));
        $this->assertFalse(property_exists($h, 'username'));
        $this->assertFalse(property_exists($h, 'email'));
    }
}
