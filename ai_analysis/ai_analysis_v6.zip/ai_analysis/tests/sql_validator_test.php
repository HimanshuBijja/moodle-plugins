<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../vendor/autoload.php');

/**
 * @covers \local_ai_analysis\security\sql_validator
 */
class sql_validator_test extends \advanced_testcase {

    private function manifest(): array {
        return [
            'mdl_user'                  => ['id', 'firstname', 'lastname', 'city', 'department', 'timecreated'],
            'mdl_grade_grades'          => ['userid', 'itemid', 'finalgrade', 'timemodified'],
            'mdl_course_modules'        => ['id', 'course', 'module', 'completion'],
            'mdl_logstore_standard_log' => ['userid', 'courseid', 'eventname', 'timecreated'],
        ];
    }

    private function validator(): \local_ai_analysis\security\sql_validator {
        return new \local_ai_analysis\security\sql_validator($this->manifest());
    }

    public function test_row1_valid_select_passes_unchanged(): void {
        $sql = 'SELECT id, firstname FROM mdl_user WHERE id = ? LIMIT 50';
        $this->assertTrue($this->validator()->validate($sql, [42]));
        $this->assertStringContainsString('LIMIT 50', $sql);
    }

    public function test_row2_select_star_rejected(): void {
        $this->expect_reject('SELECT * FROM mdl_user', [], 'WILDCARD_SELECT_FORBIDDEN');
    }

    public function test_row3_stacked_statement_rejected(): void {
        $sql = 'SELECT 1; DROP TABLE mdl_user';
        try {
            $this->validator()->validate($sql, []);
            $this->fail('expected validation_exception');
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertTrue(
                $e->reason === 'PARSE_FAILED' || $e->reason === 'FORBIDDEN_OP:DROP',
                "Got reason: $e->reason"
            );
        }
    }

    public function test_row12_update_rejected(): void {
        $sql = "UPDATE mdl_user SET firstname='x'";
        try {
            $this->validator()->validate($sql, []);
            $this->fail('expected validation_exception');
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertTrue(
                $e->reason === 'NOT_SELECT' || $e->reason === 'FORBIDDEN_OP:UPDATE',
                "Got reason: $e->reason"
            );
        }
    }

    public function test_row4_comment_trick_rejected(): void {
        // SELECT/**/password FROM mdl_user — comment between SELECT and column.
        $this->expect_reject('SELECT/**/password FROM mdl_user', [], 'COLUMN_NOT_ALLOWED:password');
    }

    public function test_row5_forbidden_table_rejected(): void {
        $this->expect_reject('SELECT id FROM mdl_config', [], 'TABLE_NOT_ALLOWED:mdl_config');
    }

    public function test_row6_union_to_forbidden_table_rejected(): void {
        $this->expect_reject(
            'SELECT id FROM mdl_user UNION SELECT id FROM mdl_config',
            [],
            'TABLE_NOT_ALLOWED:mdl_config'
        );
    }

    public function test_row7_subquery_rejected(): void {
        $this->expect_reject(
            'SELECT id FROM mdl_user WHERE id IN (SELECT userid FROM mdl_grade_grades)',
            [],
            'SUBQUERY_FORBIDDEN'
        );
    }

    public function test_row11_alias_resolution_passes(): void {
        $sql = 'SELECT u.id, u.firstname FROM mdl_user u WHERE u.id = ? LIMIT 10';
        $this->assertTrue($this->validator()->validate($sql, [1]));
    }

    public function test_row13_password_column_rejected(): void {
        $this->expect_reject('SELECT password FROM mdl_user', [], 'COLUMN_NOT_ALLOWED:password');
    }

    public function test_row14_join_passes(): void {
        $sql = 'SELECT u.id, gg.finalgrade FROM mdl_user u JOIN mdl_grade_grades gg ON u.id = gg.userid LIMIT 10';
        $this->assertTrue($this->validator()->validate($sql, []));
    }

    public function test_row8_missing_limit_gets_appended(): void {
        $sql = 'SELECT id, firstname FROM mdl_user WHERE id = ?';
        $this->assertTrue($this->validator()->validate($sql, [1]));
        $this->assertMatchesRegularExpression('/LIMIT\s+1000\s*$/i', $sql);
    }

    public function test_row9_oversized_limit_rewritten(): void {
        $sql = 'SELECT id FROM mdl_user LIMIT 5000';
        $this->assertTrue($this->validator()->validate($sql, []));
        $this->assertMatchesRegularExpression('/LIMIT\s+1000\b/i', $sql);
        $this->assertDoesNotMatchRegularExpression('/5000/', $sql);
    }

    public function test_row10_non_scalar_param_rejected(): void {
        $sql = 'SELECT id FROM mdl_user WHERE id = ? LIMIT 10';
        $this->expect_reject($sql, [['array']], 'INVALID_PARAM_TYPE');
    }

    /**
     * Regression (audit row 89): a weak model emitted '?' placeholders but
     * returned an empty params array. The mismatch previously escaped the
     * validator and died at execution as QUERY_FAILED, outside the
     * self-correction retry loop. The validator must reject it so the retry
     * loop can feed the reason back to the model.
     */
    public function test_placeholder_count_mismatch_zero_params_rejected(): void {
        $sql = 'SELECT id FROM mdl_user u JOIN mdl_grade_grades gg ON gg.userid = u.id'
             . ' WHERE u.id = ? AND gg.finalgrade < ? LIMIT 1000';
        $this->expect_reject($sql, [], 'PARAM_COUNT_MISMATCH');
    }

    public function test_placeholder_count_mismatch_too_few_params_rejected(): void {
        $sql = 'SELECT id FROM mdl_user WHERE id = ? AND city = ? LIMIT 10';
        $this->expect_reject($sql, [42], 'PARAM_COUNT_MISMATCH');
    }

    public function test_placeholder_count_mismatch_too_many_params_rejected(): void {
        $sql = 'SELECT id FROM mdl_user WHERE id = ? LIMIT 10';
        $this->expect_reject($sql, [42, 99], 'PARAM_COUNT_MISMATCH');
    }

    public function test_placeholder_count_match_passes(): void {
        $sql = 'SELECT id FROM mdl_user WHERE id = ? AND city = ? LIMIT 10';
        $this->assertTrue($this->validator()->validate($sql, [42, 'London']));
    }

    /**
     * A '?' inside a quoted string literal is not a placeholder and must not be
     * counted against the supplied params.
     */
    public function test_question_mark_in_string_literal_not_counted(): void {
        $sql = "SELECT id, city FROM mdl_user WHERE city = 'why? london' AND id = ? LIMIT 10";
        $this->assertTrue($this->validator()->validate($sql, [42]));
    }

    /**
     * Regression: a UNION query that ends with an explicit LIMIT must remain
     * a single, syntactically valid LIMIT clause. The previous AST-based
     * implementation appended a second LIMIT for UNION queries (the parser
     * does not surface LIMIT at top level for UNION) producing
     * "... LIMIT 50 LIMIT 1000" which MariaDB rejects.
     */
    public function test_union_with_trailing_limit_does_not_double(): void {
        $sql = 'SELECT id FROM mdl_user UNION SELECT userid FROM mdl_grade_grades LIMIT 50';
        $this->assertTrue($this->validator()->validate($sql, []));
        $this->assertSame(1, preg_match_all('/\bLIMIT\b/i', $sql),
            'UNION+LIMIT must produce exactly one LIMIT clause');
        $this->assertMatchesRegularExpression('/LIMIT\s+50\s*$/i', $sql);
    }

    /**
     * Regression: a SQL value that contains the substring "LIMIT N" inside a
     * string literal earlier in the query must not confuse the rewriter — the
     * real trailing LIMIT is what gets enforced.
     */
    public function test_string_literal_containing_limit_does_not_mislead_rewrite(): void {
        // city is in the mdl_user manifest; quoted literal is treated as const_string.
        $sql = "SELECT id, city FROM mdl_user WHERE city = 'dummy LIMIT 5000' LIMIT 9000";
        $this->assertTrue($this->validator()->validate($sql, []));
        $this->assertStringContainsString("'dummy LIMIT 5000'", $sql,
            'String literal must be preserved untouched');
        $this->assertMatchesRegularExpression('/LIMIT\s+1000\s*$/i', $sql,
            'Real trailing LIMIT must be lowered to 1000');
        $this->assertDoesNotMatchRegularExpression('/LIMIT\s+9000/i', $sql);
    }

    private function expect_reject(string $sql, array $params, string $expected_reason): void {
        try {
            $this->validator()->validate($sql, $params);
            $this->fail("expected $expected_reason for: $sql");
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertSame($expected_reason, $e->reason, "for SQL: $sql");
        }
    }

    public function test_new_tables_join_validates(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT s.id, s.userid, s.status, a.name FROM mdl_assign_submission s'
             . ' JOIN mdl_assign a ON s.assignment = a.id LIMIT 100';
        $this->assertTrue($v->validate($sql, []));
    }

    public function test_new_tables_disallowed_column_rejected(): void {
        $manifest = \local_ai_analysis\manifest\manifest_builder::build('admin', 0);
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT intro FROM mdl_assign LIMIT 10';
        try {
            $v->validate($sql, []);
            $this->fail('expected validation_exception for disallowed column mdl_assign.intro');
        } catch (\local_ai_analysis\exception\validation_exception $e) {
            $this->assertStringContainsString('COLUMN_NOT_ALLOWED', $e->reason, "Got reason: $e->reason");
        }
    }

    public function test_column_source_map_plain_columns(): void {
        $manifest = ['mdl_user' => ['id', 'firstname', 'email']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT id, firstname, email FROM mdl_user LIMIT 10';
        $v->validate($sql, []);
        $this->assertSame([
            'id'        => 'mdl_user.id',
            'firstname' => 'mdl_user.firstname',
            'email'     => 'mdl_user.email',
        ], $v->get_column_source_map());
    }

    public function test_column_source_map_resolves_alias_qualified(): void {
        $manifest = ['mdl_user' => ['id', 'firstname']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT u.id, u.firstname AS fn FROM mdl_user u LIMIT 10';
        $v->validate($sql, []);
        $map = $v->get_column_source_map();
        $this->assertSame('mdl_user.id', $map['id']);
        $this->assertSame('mdl_user.firstname', $map['fn']);
    }

    public function test_column_source_map_derived_is_null_with_references(): void {
        $manifest = ['mdl_user' => ['id', 'firstname', 'lastname']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = 'SELECT COUNT(id) AS n, CONCAT(firstname, lastname) AS full FROM mdl_user LIMIT 10';
        $v->validate($sql, []);
        $map = $v->get_column_source_map();
        $refs = $v->get_column_references();
        $this->assertNull($map['n']);
        $this->assertNull($map['full']);
        $this->assertSame([], $refs['n']);
        $this->assertSame(['mdl_user.firstname', 'mdl_user.lastname'], $refs['full']);
    }

    public function test_column_source_map_single_quoted_alias(): void {
        $manifest = ['mdl_user' => ['id', 'firstname']];
        $v = new \local_ai_analysis\security\sql_validator($manifest);
        $sql = "SELECT firstname AS 'fn' FROM mdl_user LIMIT 10";
        $v->validate($sql, []);
        $map = $v->get_column_source_map();
        $this->assertArrayHasKey('fn', $map);
        $this->assertSame('mdl_user.firstname', $map['fn']);
    }
}
