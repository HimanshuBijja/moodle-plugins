<?php
namespace local_ai_analysis;

use local_ai_analysis\intent\query_normalizer;
use local_ai_analysis\intent\intent_classifier;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\intent\query_normalizer
 * @covers \local_ai_analysis\intent\synonym_dictionary
 * @covers \local_ai_analysis\intent\intent_classifier
 */
class intent_classifier_test extends \advanced_testcase {

    public function test_normalizer_lowercases_strips_and_maps_synonyms(): void {
        // "Show" -> list, "pupils" -> students, punctuation stripped.
        $tokens = query_normalizer::normalize('Show me the Pupils!');
        $this->assertContains('list', $tokens);
        $this->assertContains('students', $tokens);
    }

    public function test_normalizer_maps_context_words(): void {
        // "current" and "course" both canonicalize to the context token "enrolled".
        $tokens = query_normalizer::normalize('current course students');
        $this->assertContains('students', $tokens);
        $this->assertContains('enrolled', $tokens);
    }

    public function test_normalizer_leaves_unknown_tokens_intact(): void {
        $tokens = query_normalizer::normalize('students in DBMS');
        $this->assertContains('students', $tokens);
        $this->assertContains('dbms', $tokens);
        // No list-verb and no context word present.
        $this->assertNotContains('list', $tokens);
        $this->assertNotContains('enrolled', $tokens);
    }

    /**
     * @dataProvider listing_phrasings
     */
    public function test_listing_phrasings_classify_as_student_listing(string $prompt): void {
        $this->assertSame('student_listing', intent_classifier::classify($prompt));
    }

    public static function listing_phrasings(): array {
        return [
            ['list students'],
            ['students list'],
            ['show students'],
            ['show me the students'],
            ['current course students'],
            ['all students'],
            ['list enrolled students'],
        ];
    }

    /**
     * @dataProvider non_matching_phrasings
     */
    public function test_non_matching_prompts_return_null(string $prompt): void {
        $this->assertNull(intent_classifier::classify($prompt));
    }

    public static function non_matching_phrasings(): array {
        return [
            ['failed students'],          // grade qualifier disqualifies
            ['students who failed'],
            ['top students by marks'],
            ['who submitted assignment 3'], // submission terms, no students-noun
            ['students in DBMS'],          // named course: no list-verb, no context word
            ['what is the meaning of life'],
            ['what is this course'],       // no students-noun
        ];
    }

    /**
     * @dataProvider staff_phrasings
     */
    public function test_staff_phrasings_classify_as_course_staff(string $prompt): void {
        $this->assertSame('course_staff', intent_classifier::classify($prompt));
    }

    public static function staff_phrasings(): array {
        return [
            ['who teaches this course'],
            ['who is the lecturer'],
            ['list teachers'],
            ['show lecturers'],
            ['faculty of this course'],
            ['list the instructors'],
        ];
    }

    public function test_student_and_staff_stay_distinct(): void {
        // Student phrasings must still resolve to student_listing, not course_staff.
        $this->assertSame('student_listing', intent_classifier::classify('list students'));
        $this->assertSame('student_listing', intent_classifier::classify('who are the students'));
        // Grade/submission staff phrasings fall through to the AI (null).
        $this->assertNull(intent_classifier::classify('top teachers by grade'));
    }

    /**
     * @dataProvider risk_phrasings
     */
    public function test_risk_phrasings_classify_as_at_risk_students(string $prompt): void {
        $this->assertSame('at_risk_students', intent_classifier::classify($prompt));
    }

    public static function risk_phrasings(): array {
        return [
            ['students at risk'],
            ['at risk students'],
            ['who is at risk'],
            ['struggling students'],
            ['show at risk students'],
        ];
    }

    public function test_risk_does_not_collide_with_listing_or_staff(): void {
        $this->assertSame('student_listing', intent_classifier::classify('list students'));
        $this->assertSame('course_staff', intent_classifier::classify('who teaches this course'));
    }

    /**
     * @dataProvider performance_phrasings
     */
    public function test_performance_phrasings_classify_as_course_performance(string $prompt): void {
        $this->assertSame('course_performance', intent_classifier::classify($prompt));
    }

    public static function performance_phrasings(): array {
        return [
            ['underperforming courses'],
            ['course performance'],
            ['how is this course performing'],
            ['course health'],
        ];
    }

    public function test_performance_distinct_from_other_intents(): void {
        $this->assertSame('at_risk_students', intent_classifier::classify('students at risk'));
        $this->assertSame('student_listing', intent_classifier::classify('list students'));
        $this->assertSame('course_staff', intent_classifier::classify('who teaches this course'));
    }

    public function test_poor_feedback_matches_course_feedback(): void {
        $this->assertSame('course_feedback',
            \local_ai_analysis\intent\intent_classifier::classify('which courses have poor feedback'));
    }

    public function test_course_feedback_rating_matches_course_feedback(): void {
        $this->assertSame('course_feedback',
            \local_ai_analysis\intent\intent_classifier::classify('show feedback rating for this course'));
    }

    public function test_list_students_not_shadowed_by_feedback(): void {
        $this->assertSame('student_listing',
            \local_ai_analysis\intent\intent_classifier::classify('list students'));
    }

    public function test_student_feedback_prefers_course_feedback(): void {
        // "feedback" is a disqualifier for student_listing, so this routes to feedback.
        $this->assertSame('course_feedback',
            \local_ai_analysis\intent\intent_classifier::classify('list student feedback'));
    }
}
