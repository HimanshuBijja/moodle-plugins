<?php
namespace local_ai_analysis;

use local_ai_analysis\ai\http_transport_interface;
use local_ai_analysis\exception\ai_client_exception;
use local_ai_analysis\exception\transport_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\ai\base_http_ai_client
 */
class base_http_ai_client_test extends \advanced_testcase {

    private function make_transport(int $status, string $body): http_transport_interface {
        return new class($status, $body) implements http_transport_interface {
            public function __construct(private int $status, private string $body) {}
            public function post(string $url, array $headers, string $body, int $timeout = 30): array {
                return ['status' => $this->status, 'headers' => [], 'body' => $this->body];
            }
        };
    }

    private function make_client(http_transport_interface $transport): \local_ai_analysis\ai\claude_client {
        return new \local_ai_analysis\ai\claude_client($transport, 'test-key');
    }

    public function test_http_429_throws_transport_exception(): void {
        $transport = $this->make_transport(429, '{"error":"rate_limit_exceeded"}');
        $client = $this->make_client($transport);
        $this->expectException(transport_exception::class);
        $client->generate_sql('sys', 'usr');
    }

    public function test_http_503_throws_transport_exception(): void {
        $transport = $this->make_transport(503, 'Service Unavailable');
        $client = $this->make_client($transport);
        $this->expectException(transport_exception::class);
        $client->generate_sql('sys', 'usr');
    }

    public function test_http_400_throws_ai_client_exception(): void {
        $transport = $this->make_transport(400, '{"error":"bad_request"}');
        $client = $this->make_client($transport);
        $this->expectException(ai_client_exception::class);
        $client->generate_sql('sys', 'usr');
    }

    public function test_generate_sql_accepts_history_parameter(): void {
        // Verify the base signature accepts $history without error.
        $transport = $this->make_transport(200, json_encode([
            'content' => [['type' => 'text', 'text' => '{"sql":"SELECT id FROM mdl_user LIMIT 1","params":[],"explanation":""}']],
        ]));
        $client = $this->make_client($transport);
        $history = [['prompt' => 'prior question', 'sql' => 'SELECT id FROM mdl_user LIMIT 10']];
        $result = $client->generate_sql('sys', 'usr', $history);
        $this->assertSame('sql', $result['type']);
    }

    public function test_generate_sql_surfaces_chart_object(): void {
        $chart = ['type' => 'bar', 'x' => 'name', 'y' => 'score'];
        $inner = json_encode([
            'sql'         => 'SELECT name, score FROM mdl_user LIMIT 10',
            'params'      => [],
            'explanation' => 'chart test',
            'chart'       => $chart,
        ]);
        $transport = $this->make_transport(200, json_encode([
            'content' => [['type' => 'text', 'text' => $inner]],
        ]));
        $client = $this->make_client($transport);
        $result = $client->generate_sql('sys', 'usr');
        $this->assertSame('sql', $result['type']);
        $this->assertArrayHasKey('chart', $result);
        $this->assertSame($chart, $result['chart']);
    }

    public function test_generate_sql_chart_absent_is_null(): void {
        $inner = json_encode([
            'sql'         => 'SELECT id FROM mdl_user LIMIT 1',
            'params'      => [],
            'explanation' => '',
        ]);
        $transport = $this->make_transport(200, json_encode([
            'content' => [['type' => 'text', 'text' => $inner]],
        ]));
        $client = $this->make_client($transport);
        $result = $client->generate_sql('sys', 'usr');
        $this->assertSame('sql', $result['type']);
        $this->assertArrayHasKey('chart', $result);
        $this->assertNull($result['chart']);
    }
}
