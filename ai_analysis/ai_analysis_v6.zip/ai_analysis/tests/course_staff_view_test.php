<?php
namespace local_ai_analysis;

defined('MOODLE_INTERNAL') || die();

/**
 * @covers \local_ai_analysis\db\course_staff_view
 */
class course_staff_view_test extends \advanced_testcase {

    /**
     * Create (or replace) the view before each test.
     * install.php skips view creation in PHPUNIT context to avoid breaking
     * reset_database() (which can't DELETE from a non-updatable join view).
     */
    protected function setUp(): void {
        global $DB;
        parent::setUp();
        \local_ai_analysis\db\course_staff_view::create($DB);
    }

    /**
     * Drop the view after each test so reset_database() doesn't try
     * to DROP TABLE it (which fails on a VIEW).
     */
    protected function tearDown(): void {
        global $DB;
        $DB->execute('DROP VIEW IF EXISTS ' . $DB->get_prefix() . \local_ai_analysis\db\course_staff_view::VIEW);
        parent::tearDown();
    }

    /** Seed a course-context role assignment directly (no enrol/role hooks). */
    private function assign(int $roleid, int $contextid, int $userid): void {
        global $DB;
        $DB->insert_record('role_assignments', (object) [
            'roleid'       => $roleid,
            'contextid'    => $contextid,
            'userid'       => $userid,
            'timemodified' => time(),
            'modifierid'   => 0,
            'component'    => '',
            'itemid'       => 0,
            'sortorder'    => 0,
        ]);
    }

    public function test_view_lists_course_teacher_but_excludes_siteadmin_manager(): void {
        global $DB;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $coursectx = \context_course::instance($course->id);

        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher'], '*', MUST_EXIST);
        $managerrole = $DB->get_record('role', ['shortname' => 'manager'], '*', MUST_EXIST);

        $teacher = $this->getDataGenerator()->create_user();
        $adminmanager = $this->getDataGenerator()->create_user();

        // A normal course teacher: must appear.
        $this->assign((int) $teacherrole->id, (int) $coursectx->id, (int) $teacher->id);
        // A manager on the course who is ALSO a configured site admin: must NOT appear.
        $this->assign((int) $managerrole->id, (int) $coursectx->id, (int) $adminmanager->id);
        set_config('siteadmins', (string) $adminmanager->id);

        // Clear any debugging from half-installed sibling themes (sprout/verdant) triggered
        // during course/user/context setup — unrelated to our plugin under test.
        $this->resetDebugging();

        $rows = $DB->get_records('ai_course_staff', ['courseid' => $course->id]);
        $userids = array_map(static fn($r) => (int) $r->userid, $rows);

        $this->assertContains((int) $teacher->id, $userids, 'course teacher should be visible');
        $this->assertNotContains((int) $adminmanager->id, $userids, 'site-admin manager must be hidden');

        // Identity columns present; no username/email column exists on the view.
        $row = $DB->get_record('ai_course_staff', ['userid' => $teacher->id]);
        $this->assertTrue(property_exists($row, 'firstname'));
        $this->assertTrue(property_exists($row, 'lastname'));
        $this->assertTrue(property_exists($row, 'role'));
        $this->assertFalse(property_exists($row, 'username'));
        $this->assertFalse(property_exists($row, 'email'));
    }

    public function test_view_excludes_non_course_context_assignments(): void {
        global $DB;
        $this->resetAfterTest();

        $managerrole = $DB->get_record('role', ['shortname' => 'manager'], '*', MUST_EXIST);
        $sysmanager = $this->getDataGenerator()->create_user();
        // Manager assigned at SYSTEM context (contextlevel 10) — not a course, must be absent.
        $this->assign((int) $managerrole->id, (int) \context_system::instance()->id, (int) $sysmanager->id);

        // Clear any debugging from half-installed sibling themes (sprout/verdant) — unrelated to our plugin.
        $this->resetDebugging();

        $rows = $DB->get_records('ai_course_staff');
        $userids = array_map(static fn($r) => (int) $r->userid, $rows);
        $this->assertNotContains((int) $sysmanager->id, $userids);
    }
}
