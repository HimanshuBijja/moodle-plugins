<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_ai_analysis';
$plugin->version   = 2026061502;
$plugin->requires  = 2024100700; // Moodle 4.5
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.13.1';
