<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_student_engagement` view. Grain: one row
 * per (course, student) where student = active enrolment that is NOT course
 * staff (excluded via mdl_ai_course_staff). courseid = 0 (system context) is
 * unconditionally excluded. Aggregates logstore activity, assignment
 * submissions, and course grades into flat metrics + a transparent risk_band,
 * all internal to the view. Created by install/upgrade; skipped under PHPUNIT
 * (a non-updatable aggregate view breaks reset_database()) — tests create/drop
 * it per-class. Requires mdl_ai_course_staff to exist first.
 */
class student_engagement_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_student_engagement';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_student_engagement AS
SELECT m.courseid, m.userid, m.firstname, m.lastname,
       m.last_activity_days, m.activity_count, m.missing_submissions, m.avg_grade,
       CASE WHEN m.badcount >= 3 THEN 'high'
            WHEN m.badcount >= 1 THEN 'medium'
            ELSE 'low' END AS risk_band
FROM (
    SELECT e.courseid AS courseid,
           u.id AS userid,
           u.firstname AS firstname,
           u.lastname AS lastname,
           CASE WHEN act.last_activity IS NULL THEN NULL
                ELSE DATEDIFF(NOW(), FROM_UNIXTIME(act.last_activity)) END AS last_activity_days,
           COALESCE(act.activity_count, 0) AS activity_count,
           COALESCE(asg.total_assigns, 0) - COALESCE(sub.submitted, 0) AS missing_submissions,
           grd.avg_grade AS avg_grade,
           ( CASE WHEN act.last_activity IS NULL
                       OR DATEDIFF(NOW(), FROM_UNIXTIME(act.last_activity)) > 14 THEN 1 ELSE 0 END
           + CASE WHEN COALESCE(asg.total_assigns, 0) - COALESCE(sub.submitted, 0) > 0 THEN 1 ELSE 0 END
           + CASE WHEN grd.avg_grade IS NOT NULL AND grd.avg_grade < 40 THEN 1 ELSE 0 END
           + CASE WHEN COALESCE(act.activity_count, 0) < 5 THEN 1 ELSE 0 END ) AS badcount
    FROM {$p}user_enrolments ue
    JOIN {$p}enrol e ON e.id = ue.enrolid AND e.status = 0
    JOIN {$p}user u ON u.id = ue.userid
    LEFT JOIN (
        SELECT userid, courseid, COUNT(*) AS activity_count, MAX(timecreated) AS last_activity
        FROM {$p}logstore_standard_log
        WHERE courseid > 0
        GROUP BY userid, courseid
    ) act ON act.userid = u.id AND act.courseid = e.courseid
    LEFT JOIN (
        SELECT course, COUNT(*) AS total_assigns FROM {$p}assign GROUP BY course
    ) asg ON asg.course = e.courseid
    LEFT JOIN (
        SELECT a.course AS course, s.userid AS userid, COUNT(*) AS submitted
        FROM {$p}assign a
        JOIN {$p}assign_submission s ON s.assignment = a.id AND s.status = 'submitted'
        GROUP BY a.course, s.userid
    ) sub ON sub.course = e.courseid AND sub.userid = u.id
    LEFT JOIN (
        SELECT gi.courseid AS courseid, gg.userid AS userid, AVG(gg.finalgrade) AS avg_grade
        FROM {$p}grade_items gi
        JOIN {$p}grade_grades gg ON gg.itemid = gi.id
        WHERE gi.itemtype = 'course'
        GROUP BY gi.courseid, gg.userid
    ) grd ON grd.courseid = e.courseid AND grd.userid = u.id
    WHERE ue.status = 0
      AND e.courseid > 0
      AND NOT EXISTS (
          SELECT 1 FROM {$p}ai_course_staff cs
          WHERE cs.courseid = e.courseid AND cs.userid = u.id
      )
) m";
    }

    /** Create (or replace) the view. Requires mdl_ai_course_staff to already exist. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
