<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_course_performance` view: one row per
 * course, rolling up mdl_ai_student_engagement (B1) by courseid and joining
 * mdl_course for the name. Inherits the engagement view's enrolled-minus-staff
 * population and courseid > 0 exclusion. Exposes at-risk counts/pct, avg grade,
 * and completion metrics — no student identity, so no PII. Created by
 * install/upgrade; skipped under PHPUNIT — tests create/drop the 3-view chain
 * per-class. Requires mdl_ai_student_engagement (and mdl_ai_course_staff) first.
 */
class course_performance_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_course_performance';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_course_performance AS
SELECT se.courseid AS courseid,
       c.fullname AS coursename,
       COUNT(*) AS student_count,
       SUM(CASE WHEN se.risk_band = 'high' THEN 1 ELSE 0 END) AS at_risk_high,
       SUM(CASE WHEN se.risk_band = 'medium' THEN 1 ELSE 0 END) AS at_risk_medium,
       SUM(CASE WHEN se.risk_band = 'low' THEN 1 ELSE 0 END) AS at_risk_low,
       ROUND(100 * SUM(CASE WHEN se.risk_band = 'high' THEN 1 ELSE 0 END) / COUNT(*), 1) AS at_risk_pct,
       AVG(se.avg_grade) AS avg_grade,
       AVG(se.missing_submissions) AS avg_missing_submissions,
       ROUND(100 * SUM(CASE WHEN se.missing_submissions = 0 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_no_missing
FROM {$p}ai_student_engagement se
JOIN {$p}course c ON c.id = se.courseid
GROUP BY se.courseid, c.fullname";
    }

    /** Create (or replace) the view. Requires mdl_ai_student_engagement to exist. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
