<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_course_staff` view — the single, safe
 * gateway to course-staff identity. Used by db/install.php (fresh installs +
 * the PHPUnit test DB) and db/upgrade.php (existing installs) so the view
 * exists everywhere the plugin runs. The view bakes in the privacy policy:
 * only the 4 staff roles at course context, site-admins excluded dynamically,
 * and only firstname/lastname/role projected (no username/email/idnumber).
 */
class course_staff_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_course_staff';

    /** @param string $prefix runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $prefix): string {
        return "CREATE OR REPLACE VIEW {$prefix}ai_course_staff AS
SELECT ra.id, ctx.instanceid AS courseid, u.id AS userid,
       u.firstname, u.lastname, r.shortname AS role
FROM {$prefix}role_assignments ra
JOIN {$prefix}context ctx ON ctx.id = ra.contextid AND ctx.contextlevel = 50
JOIN {$prefix}role r ON r.id = ra.roleid
JOIN {$prefix}user u ON u.id = ra.userid
WHERE r.shortname IN ('manager','coursecreator','editingteacher','teacher')
  AND NOT EXISTS (SELECT 1 FROM {$prefix}config c
                  WHERE c.name = 'siteadmins' AND FIND_IN_SET(u.id, c.value))";
    }

    /** Create (or replace) the view in the given database. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
