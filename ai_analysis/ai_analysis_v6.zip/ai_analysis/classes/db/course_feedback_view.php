<?php
namespace local_ai_analysis\db;

defined('MOODLE_INTERNAL') || die();

/**
 * Owns the DDL for the read-only `ai_course_feedback` view: one row per course
 * (course > 1) with at least one custom-feedback star rating, aggregating
 * mdl_customfeedback* directly. Exposes avg_rating (1-5), avg_rating_pct,
 * pct_low and counts — no respondent identity, so no PII. Created by
 * install/upgrade; skipped under PHPUNIT (tests create/drop it per-class).
 */
class course_feedback_view {

    /** Unprefixed view name. */
    public const VIEW = 'ai_course_feedback';

    /** @param string $p runtime table prefix (e.g. mdl_ or phpu_) */
    public static function definition_sql(string $p): string {
        return "CREATE OR REPLACE VIEW {$p}ai_course_feedback AS
SELECT cf.course AS courseid,
       c.fullname AS coursename,
       COUNT(DISTINCT cf.id) AS activity_count,
       COUNT(DISTINCT r.id) AS submission_count,
       COUNT(a.valuestar) AS rating_count,
       ROUND(AVG(a.valuestar), 2) AS avg_rating,
       ROUND(100 * (AVG(a.valuestar) - 1) / 4, 1) AS avg_rating_pct,
       ROUND(100 * SUM(CASE WHEN a.valuestar <= 2 THEN 1 ELSE 0 END) / COUNT(a.valuestar), 1) AS pct_low
FROM {$p}customfeedback cf
JOIN {$p}customfeedback_r r ON r.customfeedbackid = cf.id
JOIN {$p}customfeedback_a a ON a.responseid = r.id AND a.valuestar IS NOT NULL
JOIN {$p}customfeedback_q q ON q.id = a.questionid AND q.type = 'star'
JOIN {$p}course c ON c.id = cf.course
WHERE cf.course > 1
GROUP BY cf.course, c.fullname";
    }

    /** Create (or replace) the view. */
    public static function create(\moodle_database $db): void {
        $db->execute(self::definition_sql($db->get_prefix()));
    }
}
