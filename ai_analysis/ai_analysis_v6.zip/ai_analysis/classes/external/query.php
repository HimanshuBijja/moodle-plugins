<?php
namespace local_ai_analysis\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;

use local_ai_analysis\ai\ai_client_factory;
use local_ai_analysis\ai\prompt_builder;
use local_ai_analysis\audit\audit_writer;
use local_ai_analysis\db\query_executor;
use local_ai_analysis\exception\ai_client_exception;
use local_ai_analysis\exception\query_execution_exception;
use local_ai_analysis\exception\transport_exception;
use local_ai_analysis\exception\validation_exception;
use local_ai_analysis\intent\intent_classifier;
use local_ai_analysis\intent\sql_template;
use local_ai_analysis\manifest\manifest_builder;
use local_ai_analysis\security\rate_limiter;
use local_ai_analysis\security\sql_validator;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../vendor/autoload.php');

/**
 * AJAX gateway: orchestrates the full pipeline from sanitised prompt to
 * validated query result. Writes an audit row on every code path including
 * the catch-all. Returns a well-typed envelope to the AJAX layer rather
 * than throwing, except for capability denials (Moodle's external API
 * translates required_capability_exception to a structured error itself).
 */
class query extends external_api {

    /** Maximum number of prior conversation turns forwarded to the AI. */
    private const MAX_HISTORY_TURNS = 5;

    /** Chart types accepted from the AI. */
    private const CHART_TYPES = ['bar', 'line', 'pie'];

    /** Total generate+validate attempts (1 initial + self-correction retries). */
    private const MAX_SQL_ATTEMPTS = 2;

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'prompt'     => new external_value(PARAM_TEXT, 'User prompt', VALUE_REQUIRED),
            'courseid'   => new external_value(PARAM_INT, 'Course context (0 = system)', VALUE_DEFAULT, 0),
            'request_id' => new external_value(PARAM_ALPHANUMEXT, 'Client-supplied request id for race tracking', VALUE_REQUIRED),
            'format'     => new external_value(PARAM_BOOL, 'Run the AI formatting pass (layer 7)', VALUE_DEFAULT, false),
            'history'    => new external_multiple_structure(
                new external_single_structure([
                    'prompt' => new external_value(PARAM_TEXT, 'Prior turn user prompt'),
                    'sql'    => new external_value(PARAM_RAW, 'Prior turn generated SQL'),
                ]),
                'Prior conversation turns (oldest first) for multi-turn context',
                VALUE_DEFAULT,
                []
            ),
        ]);
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'request_id' => new external_value(PARAM_ALPHANUMEXT, 'Echoed back from request'),
            'userid'     => new external_value(PARAM_INT, 'Acting user id'),
            'courseid'   => new external_value(PARAM_INT, 'Course context'),
            'status'     => new external_value(PARAM_ALPHANUMEXT, 'SUCCESS or an error code'),
            'sql'        => new external_value(PARAM_RAW, 'Validated SQL when SUCCESS', VALUE_DEFAULT, ''),
            'params'     => new external_multiple_structure(
                new external_value(PARAM_RAW, 'Bound parameter value'),
                'Bound parameters',
                VALUE_DEFAULT,
                []
            ),
            'row_count'  => new external_value(PARAM_INT, 'Number of rows', VALUE_DEFAULT, 0),
            'rows'       => new external_multiple_structure(
                new external_value(PARAM_RAW, 'Row as JSON-encoded string'),
                'Result rows (each row JSON-encoded to keep external_api happy)',
                VALUE_DEFAULT,
                []
            ),
            'answer'     => new external_value(PARAM_RAW, 'Natural-language answer when format=true', VALUE_DEFAULT, ''),
            'format_note' => new external_value(PARAM_TEXT, 'Soft note when formatting falls back', VALUE_DEFAULT, ''),
            'error'      => new external_value(PARAM_TEXT, 'Human-readable error message; empty on SUCCESS', VALUE_DEFAULT, ''),
            'chart'      => new external_value(PARAM_RAW, 'Validated chart spec as JSON, or empty', VALUE_DEFAULT, ''),
            'links'      => new external_value(PARAM_RAW, 'Map of output column => entity type (course|user) as JSON', VALUE_DEFAULT, '{}'),
        ]);
    }

    public static function execute(string $prompt, int $courseid, string $request_id, bool $format = false, array $history = []): array {
        global $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'prompt' => $prompt, 'courseid' => $courseid, 'request_id' => $request_id,
            'format' => $format, 'history' => $history,
        ]);
        $prompt     = $params['prompt'];
        $courseid   = (int) $params['courseid'];
        $request_id = $params['request_id'];
        $format     = (bool) $params['format'];
        $history    = (array) $params['history'];

        $start = microtime(true);

        // L2: auth + caps + courseid validation.
        if ($courseid > 0) {
            $course = get_course($courseid);
            $context = \context_course::instance($course->id);
        } else {
            $context = \context_system::instance();
        }
        self::validate_context($context);
        require_capability('local/ai_analysis:query', $context);
        if ($courseid === 0) {
            require_capability('local/ai_analysis:queryglobal', $context);
        }

        $is_admin = has_capability('moodle/site:config', \context_system::instance());
        $role = $is_admin ? 'admin' : 'editingteacher';

        // L2: input sanitisation. Catch + audit + return envelope (do not throw to the AJAX layer).
        try {
            $prompt = prompt_builder::sanitise_user_prompt($prompt);
        } catch (\moodle_exception $e) {
            $reason = $e->a ? (string) $e->a : $e->errorcode;
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'BLOCKED_INJECTION', reason: $reason,
                provider: '', row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'BLOCKED_INJECTION', $reason);
        }

        // L2: rate limit.
        $rl = new rate_limiter();
        if (!$rl->consume((int) $USER->id, $is_admin)) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: null, status: 'RATE_LIMITED', reason: '', provider: '',
                row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'RATE_LIMITED', get_string('ratelimited', 'local_ai_analysis'));
        }

        // L3: manifest.
        $manifest  = manifest_builder::build($role, $courseid);
        $validator = new sql_validator($manifest);

        // L4a: deterministic intent fast-path. A known intent is served by a
        // hand-written template with NO AI call; unknown questions fall through
        // to the AI pipeline below. Template SQL still passes through the same
        // validator + executor + audit, so no security guarantee is bypassed.
        $ai       = null;
        $provider = get_config('local_ai_analysis', 'provider') ?: 'claude';
        $sql          = '';
        $bound_params = [];
        $template_chart = null;

        $intent = intent_classifier::classify($prompt);
        if ($intent !== null) {
            $provider = 'template';
            [$sql, $bound_params, $template_chart] = sql_template::build($intent, $courseid);
            try {
                $validator->validate($sql, $bound_params);
            } catch (validation_exception $e) {
                // A template that fails validation is a bug, not a user error;
                // surface it with the normal envelope rather than masking it.
                audit_writer::write(
                    userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                    sql: $sql, status: 'SQL_INVALID', reason: $e->reason,
                    provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
                );
                return self::error_envelope($request_id, (int) $USER->id, $courseid, 'SQL_INVALID', $e->reason);
            }
        } else {
            // L4 + L5: generate then validate, with one self-correction retry. Weak
            // models sometimes reference a table/column outside the manifest (e.g. an
            // invented mdl_enrolment_status). Feeding the validator's rejection reason
            // back as a corrective turn usually recovers a valid query. Every attempt
            // is still validated, so this never weakens the allow-list.
            $system = prompt_builder::build_system($manifest, $role, $courseid, time());

            // Build multi-turn context: keep the last N turns, re-sanitise each
            // prior prompt, and silently drop any that fail (best-effort context).
            $clean_history = [];
            foreach (array_slice($history, -self::MAX_HISTORY_TURNS) as $turn) {
                try {
                    $hp = prompt_builder::sanitise_user_prompt((string) ($turn['prompt'] ?? ''));
                } catch (\moodle_exception $e) {
                    continue;
                }
                $clean_history[] = ['prompt' => $hp, 'sql' => (string) ($turn['sql'] ?? '')];
            }

            $cur_prompt    = $prompt;
            $retry_history = $clean_history;
            $attempt       = 0;
            while (true) {
                $attempt++;
                try {
                    $ai = ai_client_factory::make()->generate_sql($system, $cur_prompt, $retry_history);
                } catch (ai_client_exception $e) {
                    audit_writer::write(
                        userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                        sql: null, status: 'AI_INVALID_JSON', reason: $e->reason,
                        provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
                    );
                    return self::error_envelope($request_id, (int) $USER->id, $courseid, 'AI_INVALID_JSON', $e->reason);
                } catch (transport_exception $e) {
                    audit_writer::write(
                        userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                        sql: null, status: 'AI_TRANSPORT_ERROR', reason: $e->getMessage(),
                        provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
                    );
                    return self::error_envelope($request_id, (int) $USER->id, $courseid, 'AI_TRANSPORT_ERROR', $e->getMessage());
                }

                if ($ai['type'] === 'out_of_scope') {
                    audit_writer::write(
                        userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                        sql: null, status: 'OUT_OF_SCOPE', reason: $ai['message'] ?? '',
                        provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
                    );
                    return self::error_envelope($request_id, (int) $USER->id, $courseid, 'OUT_OF_SCOPE', $ai['message'] ?? '');
                }

                $sql = (string) $ai['sql'];
                $bound_params = (array) $ai['params'];

                try {
                    $validator->validate($sql, $bound_params);
                    break;
                } catch (validation_exception $e) {
                    if ($attempt < self::MAX_SQL_ATTEMPTS) {
                        // Replay the rejected attempt + reason so the model self-corrects.
                        $retry_history[] = ['prompt' => $cur_prompt, 'sql' => $sql];
                        $cur_prompt = 'Your previous SQL was rejected (' . $e->reason . '). '
                            . 'Only use tables and columns from ALLOWED SCHEMA; never invent a table. '
                            . 'Every ? placeholder must have exactly one matching value in the params '
                            . 'array, in order (the params array length must equal the number of ? marks). '
                            . 'Return corrected JSON answering the original question: ' . $prompt;
                        continue;
                    }
                    audit_writer::write(
                        userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                        sql: $sql, status: 'SQL_INVALID', reason: $e->reason,
                        provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
                    );
                    return self::error_envelope($request_id, (int) $USER->id, $courseid, 'SQL_INVALID', $e->reason);
                }
            }
        } // end else (AI path)

        // Validate the AI-proposed chart spec against the output columns produced by this query.
        $source_map = $validator->get_column_source_map();
        $chart_spec = self::validate_chart(($ai !== null ? ($ai['chart'] ?? null) : $template_chart), array_keys($source_map));
        $chart_json = $chart_spec !== null ? json_encode($chart_spec) : '';

        // Build link card map: output columns that are course/user ids.
        $links = self::build_links($source_map);
        $links_json = json_encode((object) $links);

        // L6: execute. In tests we have no $CFG->ai_analysis_db* — fall back to global $DB.
        // Translate the canonical mdl_ prefix to the runtime prefix (differs in PHPUnit test runs).
        $exec_sql = self::translate_prefix($sql);
        global $DB;
        $executor = self::build_executor($DB);
        try {
            $rows = $executor->run($exec_sql, $bound_params);
        } catch (query_execution_exception $e) {
            audit_writer::write(
                userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
                sql: $sql, status: 'QUERY_FAILED', reason: $e->getMessage(),
                provider: $provider, row_count: null, duration_ms: self::elapsed_ms($start),
            );
            return self::error_envelope($request_id, (int) $USER->id, $courseid, 'QUERY_FAILED', $e->getMessage());
        }

        $row_count = count($rows);

        $answer = '';
        $format_note = '';
        if ($format) {
            try {
                $classified = \local_ai_analysis\security\pii_scrubber::classify_columns(
                    $validator->get_column_source_map(),
                    $validator->get_column_references()
                );
                $scrubber  = new \local_ai_analysis\security\pii_scrubber();
                $safe_rows = $scrubber->tokenize($rows, $classified);
                $tokanswer = ai_client_factory::make()->format_result($prompt, $safe_rows);
                $answer    = $scrubber->detokenize($tokanswer);
            } catch (ai_client_exception | transport_exception $e) {
                $answer = '';
                $format_note = get_string('formatunavailable', 'local_ai_analysis');
                debugging('format_result failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            }
        }

        audit_writer::write(
            userid: (int) $USER->id, courseid: $courseid, prompt: $prompt,
            sql: $sql, status: 'SUCCESS', reason: '',
            provider: $provider, row_count: $row_count, duration_ms: self::elapsed_ms($start),
        );

        return [
            'request_id' => $request_id,
            'userid'     => (int) $USER->id,
            'courseid'   => $courseid,
            'status'     => 'SUCCESS',
            'sql'        => $sql,
            'params'     => array_map(fn($p) => (string) $p, $bound_params),
            'row_count'  => $row_count,
            'rows'       => array_map(fn($r) => json_encode($r), $rows),
            'answer'      => $answer,
            'format_note' => $format_note,
            'error'       => '',
            'chart'       => $chart_json,
            'links'       => $links_json,
        ];
    }

    /**
     * Translates the canonical mdl_ table prefix to the runtime DB prefix.
     * This is a no-op in production (where $CFG->prefix === 'mdl_') but is
     * essential during PHPUnit runs where the prefix is 'phpu_'.
     */
    private static function translate_prefix(string $sql): string {
        global $CFG;
        $runtime_prefix = $CFG->prefix ?? 'mdl_';
        if ($runtime_prefix === 'mdl_') {
            return $sql;
        }
        return str_replace('mdl_', $runtime_prefix, $sql);
    }

    private static function build_executor(\moodle_database $db_for_tests): query_executor {
        global $CFG;
        if (empty($CFG->ai_analysis_dbuser) || empty($CFG->ai_analysis_dbpass)) {
            return new query_executor($db_for_tests);
        }
        return new query_executor();
    }

    private static function elapsed_ms(float $start): int {
        return (int) round((microtime(true) - $start) * 1000);
    }

    /**
     * Validate an AI-proposed chart spec against the query's output columns.
     * Returns a clean ['type','x','y'] array, or null when the spec is unusable.
     *
     * @param array|null $chart The chart array from the AI response, or null.
     * @param string[] $output_cols The output column names from the validated SQL.
     * @return array|null A clean chart spec, or null.
     */
    private static function validate_chart(?array $chart, array $output_cols): ?array {
        if ($chart === null) {
            return null;
        }
        $type = (string) ($chart['type'] ?? '');
        $x    = (string) ($chart['x'] ?? '');
        $y    = (string) ($chart['y'] ?? '');
        if (!in_array($type, self::CHART_TYPES, true)) {
            return null;
        }
        if (!in_array($x, $output_cols, true) || !in_array($y, $output_cols, true)) {
            return null;
        }
        return ['type' => $type, 'x' => $x, 'y' => $y];
    }

    private static function error_envelope(string $request_id, int $userid, int $courseid, string $status, string $error): array {
        return [
            'request_id' => $request_id,
            'userid'     => $userid,
            'courseid'   => $courseid,
            'status'     => $status,
            'sql'        => '',
            'params'     => [],
            'row_count'  => 0,
            'rows'       => [],
            'answer'      => '',
            'format_note' => '',
            'error'       => $error,
            'chart'       => '',
            'links'       => '{}',
        ];
    }

    /**
     * Map output columns that are course/user ids to a link entity type, using
     * the validator's output source map. Returns ['<colname>' => 'course'|'user'].
     *
     * @param array $source_map Output column name => "table.column" (or null).
     * @return array Map of column name to entity type.
     */
    private static function build_links(array $source_map): array {
        $links = [];
        foreach ($source_map as $col => $src) {
            if ($src === 'mdl_course.id') {
                $links[$col] = 'course';
            } else if ($src === 'mdl_user.id') {
                $links[$col] = 'user';
            }
        }
        return $links;
    }
}
