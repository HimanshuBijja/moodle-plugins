<?php
namespace local_ai_analysis\manifest;

defined('MOODLE_INTERNAL') || die();

/**
 * Builds the allow-list manifest of tables and columns the AI may reference.
 *
 * The same manifest array is fed to (a) the AI prompt builder so the model
 * knows what it may reference, and (b) the SQL validator so it can reject
 * any SQL that strays outside the allow-list. Single source of truth.
 */
class manifest_builder {

    /** @var array<string, string[]> Hardcoded — never derived from the live DB. */
    private static array $FULL_MANIFEST = [
        'mdl_user'                  => ['id', 'firstname', 'lastname', 'city', 'department', 'timecreated'],
        'mdl_course'                => ['id', 'fullname', 'shortname', 'summary', 'startdate', 'visible'],
        'mdl_grade_grades'          => ['userid', 'itemid', 'finalgrade', 'timemodified'],
        'mdl_grade_items'           => ['id', 'courseid', 'itemname', 'itemtype', 'grademax'],
        'mdl_course_modules'        => ['id', 'course', 'module', 'completion'],
        'mdl_enrol'                 => ['id', 'courseid', 'enrol', 'status'],
        'mdl_user_enrolments'       => ['id', 'userid', 'enrolid', 'status'],
        'mdl_logstore_standard_log' => ['userid', 'courseid', 'eventname', 'timecreated'],
        'mdl_assign'                => ['id', 'course', 'name', 'duedate'],
        'mdl_assign_submission'     => ['id', 'assignment', 'userid', 'status', 'timemodified'],
        'mdl_quiz'                  => ['id', 'course', 'name'],
        'mdl_quiz_grades'           => ['id', 'quiz', 'userid', 'grade', 'timemodified'],
        'mdl_groups'                => ['id', 'courseid', 'name'],
        'mdl_groups_members'        => ['id', 'groupid', 'userid'],
        'mdl_ai_course_staff'       => ['courseid', 'userid', 'firstname', 'lastname', 'role'],
        'mdl_ai_student_engagement' => ['courseid', 'userid', 'firstname', 'lastname', 'last_activity_days', 'activity_count', 'missing_submissions', 'avg_grade', 'risk_band'],
        'mdl_ai_course_performance' => ['courseid', 'coursename', 'student_count', 'at_risk_high', 'at_risk_medium', 'at_risk_low', 'at_risk_pct', 'avg_grade', 'avg_missing_submissions', 'pct_no_missing'],
        'mdl_ai_course_feedback'    => ['courseid', 'coursename', 'activity_count', 'submission_count', 'rating_count', 'avg_rating', 'avg_rating_pct', 'pct_low'],
        'mdl_ai_feedback_activity'  => ['activityid', 'activityname', 'courseid', 'coursename', 'star_question_count', 'submission_count', 'rating_count', 'avg_rating', 'avg_rating_pct', 'pct_low'],
    ];

    /**
     * Returns a manifest array. For non-admin roles with courseid > 0, the
     * returned mdl_user and mdl_logstore_standard_log entries gain a
     * string-valued '_scope_note' key alongside their column list. The static
     * $FULL_MANIFEST itself is never mutated (PHP copies the array by value).
     *
     * @return array<string, mixed>
     */
    public static function build(string $role, int $courseid): array {
        $manifest = self::$FULL_MANIFEST;

        if ($role !== 'admin' && $courseid > 0) {
            $manifest['mdl_user']['_scope_note'] =
                'Only users enrolled in course ' . $courseid;
            $manifest['mdl_logstore_standard_log']['_scope_note'] =
                'Always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_course']['_scope_note'] =
                'The current course is id ' . $courseid . '; filter WHERE id = ' . $courseid;
            $manifest['mdl_grade_items']['_scope_note'] =
                'Grades link to a course only through this table; always filter WHERE courseid = ' . $courseid
                . ' (itemtype = \'course\' is the course total)';
            $manifest['mdl_enrol']['_scope_note'] =
                'Always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_user_enrolments']['_scope_note'] =
                'Join to mdl_enrol via enrolid to scope to course ' . $courseid
                . '; status 0 = active, 1 = suspended';
            $manifest['mdl_assign']['_scope_note'] =
                'Always filter WHERE course = ' . $courseid;
            $manifest['mdl_assign_submission']['_scope_note'] =
                'Join to mdl_assign via assignment to scope to course ' . $courseid
                . '; status = \'submitted\' means handed in';
            $manifest['mdl_quiz']['_scope_note'] =
                'Always filter WHERE course = ' . $courseid;
            $manifest['mdl_quiz_grades']['_scope_note'] =
                'Join to mdl_quiz via quiz to scope to course ' . $courseid;
            $manifest['mdl_groups']['_scope_note'] =
                'Always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_groups_members']['_scope_note'] =
                'Join to mdl_groups via groupid to scope to course ' . $courseid;
            $manifest['mdl_ai_course_staff']['_scope_note'] =
                'Teaching staff (teacher/manager roles) for a course; always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_ai_student_engagement']['_scope_note'] =
                'Per-student engagement metrics + risk_band (high/medium/low) for a course; always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_ai_course_performance']['_scope_note'] =
                'Course-level performance rollup (at-risk counts, avg grade, completion); always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_ai_course_feedback']['_scope_note'] =
                'Course-level student-feedback rating summary (avg_rating 1-5, pct_low = % ratings <=2); always filter WHERE courseid = ' . $courseid;
            $manifest['mdl_ai_feedback_activity']['_scope_note'] =
                'Per-feedback-activity rating summary (avg_rating 1-5); always filter WHERE courseid = ' . $courseid;
        }
        return $manifest;
    }
}
