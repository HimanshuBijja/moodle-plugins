<?php
namespace local_ai_analysis\security;

defined('MOODLE_INTERNAL') || die();

/**
 * Reversible, column-classified PII tokeniser. One instance per request; the
 * token map lives as instance state and is never persisted. tokenize() masks
 * PII column values with stable tokens (PERSON_1, EMAIL_2, …) before rows are
 * sent to the formatting AI; detokenize() restores the real values in the AI's
 * answer before it is shown to the authorised educator.
 */
class pii_scrubber {

    /** Curated source-of-truth: "table.column" => token prefix. */
    private const PII_MAP = [
        'mdl_user.firstname'         => 'PERSON',
        'mdl_user.lastname'          => 'PERSON',
        'mdl_user.firstnamephonetic' => 'PERSON',
        'mdl_user.lastnamephonetic'  => 'PERSON',
        'mdl_user.middlename'        => 'PERSON',
        'mdl_user.alternatename'     => 'PERSON',
        'mdl_user.email'             => 'EMAIL',
        'mdl_user.username'          => 'USERNAME',
        'mdl_user.idnumber'          => 'ID',
        'mdl_user.phone1'            => 'PHONE',
        'mdl_user.phone2'            => 'PHONE',
        'mdl_user.address'           => 'ADDRESS',
        'mdl_user.city'              => 'LOCATION',
        'mdl_user.country'           => 'LOCATION',
        'mdl_user.institution'       => 'ORG',
        'mdl_user.department'        => 'ORG',
        'mdl_user.lastip'            => 'IP',
        'mdl_ai_course_staff.firstname' => 'PERSON',
        'mdl_ai_course_staff.lastname'  => 'PERSON',
        'mdl_ai_student_engagement.firstname' => 'PERSON',
        'mdl_ai_student_engagement.lastname'  => 'PERSON',
    ];

    /** Sentinel classification for derived expressions that reference PII. */
    public const REDACT = '__REDACT__';

    /** @var array<string, string> token => real value */
    private array $map = [];
    /** @var array<string, string> "prefix\0value" => token (stable assignment) */
    private array $reverse = [];
    /** @var array<string, int> prefix => last counter */
    private array $counters = [];

    public static function is_pii(string $tablecolumn): bool {
        return isset(self::PII_MAP[$tablecolumn]);
    }

    /**
     * Compose the per-output classification map from the validator's accessors.
     *
     * @param array $source_map output => "table.column" | null
     * @param array $references output => string[] underlying "table.column" list
     * @return array output => "table.column" | null | self::REDACT
     */
    public static function classify_columns(array $source_map, array $references): array {
        $out = [];
        foreach ($source_map as $name => $src) {
            if ($src !== null && self::is_pii($src)) {
                $out[$name] = $src;
                continue;
            }
            if ($src === null) {
                $hits = false;
                foreach ($references[$name] ?? [] as $ref) {
                    if (self::is_pii($ref)) {
                        $hits = true;
                        break;
                    }
                }
                $out[$name] = $hits ? self::REDACT : null;
                continue;
            }
            $out[$name] = null;
        }
        return $out;
    }

    /**
     * @param array $rows       Result rows (each array or object).
     * @param array $column_map output => "table.column" | null | self::REDACT (from classify_columns)
     * @return array            Rows (as arrays) with PII values replaced by tokens.
     */
    public function tokenize(array $rows, array $column_map): array {
        $result = [];
        foreach ($rows as $row) {
            $arr = (array) $row;
            foreach ($arr as $col => $val) {
                if ($val === null || $val === '' || $val === false) {
                    continue;
                }
                $class = $column_map[$col] ?? null;
                if ($class === null) {
                    continue;
                }
                $prefix = $class === self::REDACT ? 'REDACTED' : (self::PII_MAP[$class] ?? null);
                if ($prefix === null) {
                    continue;
                }
                $arr[$col] = $this->token_for($prefix, (string) $val);
            }
            $result[] = $arr;
        }
        return $result;
    }

    public function detokenize(string $text): string {
        return strtr($text, $this->map);
    }

    private function token_for(string $prefix, string $value): string {
        $key = $prefix . "\0" . $value;
        if (isset($this->reverse[$key])) {
            return $this->reverse[$key];
        }
        $n = ($this->counters[$prefix] ?? 0) + 1;
        $this->counters[$prefix] = $n;
        $token = $prefix . '_' . $n;
        $this->reverse[$key] = $token;
        $this->map[$token]   = $value;
        return $token;
    }
}
