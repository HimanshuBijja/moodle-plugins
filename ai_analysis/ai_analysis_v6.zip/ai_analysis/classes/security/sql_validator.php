<?php
namespace local_ai_analysis\security;

use local_ai_analysis\exception\validation_exception;
use PHPSQLParser\PHPSQLParser;

defined('MOODLE_INTERNAL') || die();

/**
 * AST-based SQL validator. Receives the same manifest array that was sent
 * to the AI prompt, so allow-lists cannot drift.
 *
 * validate() mutates $sql only to inject or lower LIMIT. Any other
 * deviation from policy is thrown as validation_exception with a
 * machine-readable reason code.
 */
class sql_validator {

    /** @var array<string, string[]> */
    private array $manifest;

    /** @var array<string, string|null> output column name => "table.column" | null */
    private array $column_source_map = [];

    /** @var array<string, string[]> output column name => underlying "table.column" list */
    private array $column_references = [];

    public function get_column_source_map(): array {
        return $this->column_source_map;
    }

    public function get_column_references(): array {
        return $this->column_references;
    }

    private const FORBIDDEN_OPS = [
        'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE',
        'ALTER', 'TRUNCATE', 'REPLACE', 'CALL', 'EXEC',
    ];

    public function __construct(array $manifest) {
        foreach ($manifest as $table => $cols) {
            if (is_array($cols)) {
                $manifest[$table] = array_values(array_filter(
                    $cols,
                    fn($c, $k) => $k !== '_scope_note',
                    ARRAY_FILTER_USE_BOTH
                ));
            }
        }
        $this->manifest = $manifest;
    }

    public function validate(string &$sql, array $params): bool {
        $this->column_source_map = [];
        $this->column_references = [];

        // Rule 0: parse.
        try {
            $parser = new PHPSQLParser($sql, true);
            $ast = $parser->parsed;
        } catch (\Throwable $e) {
            throw new validation_exception('PARSE_FAILED', $sql);
        }
        if (!is_array($ast)) {
            throw new validation_exception('PARSE_FAILED', $sql);
        }

        // Rule 1: statement type.
        foreach (self::FORBIDDEN_OPS as $op) {
            if (array_key_exists($op, $ast)) {
                throw new validation_exception('FORBIDDEN_OP:' . $op, $sql);
            }
        }
        if (!array_key_exists('SELECT', $ast) && !array_key_exists('UNION', $ast) && !array_key_exists('UNION ALL', $ast)) {
            throw new validation_exception('NOT_SELECT', $sql);
        }

        // Rule 5 (check FIRST): reject any subquery anywhere in the AST.
        // Top-level UNION branches are NOT subqueries; we detect subqueries by
        // walking for expr_type === 'subquery'.
        $this->reject_subqueries($ast, $sql);

        // Rule 2: no SELECT * — applies to every SELECT, including UNION branches.
        $this->check_wildcards($ast, $sql);

        // Rules 3 + 4: for each top-level SELECT (including UNION branches),
        // build alias→table map then verify all column references.
        $first = true;
        foreach ($this->iter_top_selects($ast) as $select_ast) {
            $alias_to_table = $this->collect_tables($select_ast, $sql);
            $this->check_columns($select_ast, $alias_to_table, $sql);
            if ($first) {
                $this->build_output_map($select_ast, $alias_to_table);
                $first = false;
            }
        }

        // Rule 7: param types — scalar or null only.
        foreach ($params as $p) {
            if ($p !== null && !is_scalar($p)) {
                throw new validation_exception('INVALID_PARAM_TYPE', $sql);
            }
        }

        // Rule 8: positional placeholder count must equal the supplied param
        // count. Weak models sometimes emit '?' placeholders but return an empty
        // params array; the mismatch would otherwise escape validation and die at
        // execution (QUERY_FAILED), outside the self-correction retry loop.
        // Strip quoted string literals first so a '?' inside a literal is not
        // counted as a placeholder.
        $without_literals = preg_replace(
            ['/\'(?:[^\'\\\\]|\\\\.)*\'/', '/"(?:[^"\\\\]|\\\\.)*"/'],
            ['', ''],
            $sql
        );
        $placeholders = substr_count($without_literals, '?');
        if ($placeholders !== count($params)) {
            throw new validation_exception('PARAM_COUNT_MISMATCH', $sql);
        }

        // Rule 6: LIMIT enforcement.
        $sql = $this->enforce_limit($sql, $ast, 1000);

        return true;
    }

    /**
     * Enforce LIMIT <= $max on the final query.
     *
     * The AST is unreliable here: PHPSQLParser does not surface a top-level
     * LIMIT key for UNION queries. Instead we anchor on the trailing
     * LIMIT-or-nothing form of the raw SQL.
     *
     * A trailing-anchored regex is safe against LIMIT-shaped fragments inside
     * string literals because such literals never end the SQL (more SQL
     * follows). The $ast argument is kept in the signature for forward use
     * but is not consulted here.
     */
    private function enforce_limit(string $sql, array $ast, int $max): string {
        // Match a LIMIT clause at the very end of the SQL, optionally followed
        // by a semicolon and whitespace. Group 2 captures the rowcount; group
        // 1 captures the offset+comma when present (e.g. "LIMIT 10, 50").
        $pattern = '/\s+LIMIT\s+(\d+\s*,\s*)?(\d+)\s*;?\s*$/i';
        if (preg_match($pattern, $sql, $m) === 1) {
            $rowcount = (int)$m[2];
            if ($rowcount > $max) {
                return preg_replace($pattern, ' LIMIT ' . $max, $sql, 1);
            }
            return $sql;
        }
        // No trailing LIMIT — append one. Strip any trailing semicolon first.
        return rtrim(rtrim($sql), ';') . ' LIMIT ' . $max;
    }

    /** Yields each top-level SELECT statement (handles UNION branches). */
    private function iter_top_selects(array $ast): iterable {
        if (array_key_exists('UNION', $ast) || array_key_exists('UNION ALL', $ast)) {
            $branches = $ast['UNION'] ?? $ast['UNION ALL'];
            foreach ($branches as $branch) {
                if (is_array($branch) && array_key_exists('SELECT', $branch)) {
                    yield $branch;
                }
            }
            return;
        }
        if (array_key_exists('SELECT', $ast)) {
            yield $ast;
        }
    }

    private function check_wildcards(array $ast, string $sql): void {
        foreach ($this->iter_top_selects($ast) as $select_ast) {
            foreach ($select_ast['SELECT'] ?? [] as $col) {
                if (($col['expr_type'] ?? '') === 'comment') {
                    continue;
                }
                if (($col['base_expr'] ?? '') === '*') {
                    throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
                }
                if (($col['expr_type'] ?? '') === 'colref' && ($col['base_expr'] ?? '') === '*') {
                    throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
                }
            }
        }
    }

    /**
     * Collects every table referenced in FROM/JOIN. Returns alias→table map.
     * Throws TABLE_NOT_ALLOWED on any unknown table.
     */
    private function collect_tables(array $select_ast, string $sql): array {
        $aliases = [];
        $from = $select_ast['FROM'] ?? [];
        foreach ($from as $node) {
            if (($node['expr_type'] ?? '') !== 'table') {
                continue;
            }
            $table = $node['table'] ?? null;
            if (!$table || !array_key_exists($table, $this->manifest)) {
                throw new validation_exception('TABLE_NOT_ALLOWED:' . ($table ?? '?'), $sql);
            }
            // Register the alias (if present) and the bare table name.
            $alias = is_array($node['alias']) ? ($node['alias']['name'] ?? $table) : $table;
            $aliases[$alias] = $table;
            $aliases[$table] = $table;
        }
        return $aliases;
    }

    /**
     * Walks SELECT, WHERE, GROUP, HAVING, ORDER, FROM for any colref and
     * verifies each column is in the manifest for its (possibly aliased) table.
     * Also walks ref_clause inside FROM entries (for JOIN ON conditions).
     */
    private function check_columns(array $select_ast, array $aliases, string $sql): void {
        // Walk the standard clauses.
        $clauses = ['SELECT', 'WHERE', 'GROUP', 'HAVING', 'ORDER'];
        foreach ($clauses as $clause) {
            if (!isset($select_ast[$clause])) {
                continue;
            }
            $this->walk_colrefs($select_ast[$clause], $aliases, $sql);
        }
        // Walk JOIN ON conditions (ref_clause inside FROM entries).
        foreach ($select_ast['FROM'] ?? [] as $from_node) {
            if (is_array($from_node['ref_clause'] ?? null)) {
                $this->walk_colrefs($from_node['ref_clause'], $aliases, $sql);
            }
        }
    }

    private function walk_colrefs($node, array $aliases, string $sql): void {
        if (!is_array($node)) {
            return;
        }
        // A single AST node (associative with expr_type) vs a list of nodes.
        if (isset($node['expr_type'])) {
            if ($node['expr_type'] === 'colref') {
                $base = $node['base_expr'] ?? '';
                // Skip placeholder params.
                if ($base === '?') {
                    return;
                }
                if ($base === '*' || str_ends_with($base, '.*')) {
                    throw new validation_exception('WILDCARD_SELECT_FORBIDDEN', $sql);
                }
                $parts = explode('.', $base);
                if (count($parts) === 2) {
                    [$alias, $col] = $parts;
                    $col   = trim($col, '`"');
                    $alias = trim($alias, '`"');
                    if (!isset($aliases[$alias])) {
                        throw new validation_exception('TABLE_NOT_ALLOWED:' . $alias, $sql);
                    }
                    $table = $aliases[$alias];
                    if (!in_array($col, $this->manifest[$table], true)) {
                        throw new validation_exception('COLUMN_NOT_ALLOWED:' . $col, $sql);
                    }
                } else if (count($parts) === 1) {
                    $col = trim($parts[0], '`"');
                    // Unqualified — resolve across all aliased tables.
                    $tables = array_unique(array_values($aliases));
                    $matches = [];
                    foreach ($tables as $t) {
                        if (in_array($col, $this->manifest[$t], true)) {
                            $matches[] = $t;
                        }
                    }
                    if (count($matches) === 0) {
                        throw new validation_exception('COLUMN_NOT_ALLOWED:' . $col, $sql);
                    }
                    if (count($matches) > 1) {
                        throw new validation_exception('AMBIGUOUS_COLUMN:' . $col, $sql);
                    }
                }
            }
            // Recurse into sub_tree for function args, expressions, etc.
            if (isset($node['sub_tree']) && is_array($node['sub_tree'])) {
                $this->walk_colrefs($node['sub_tree'], $aliases, $sql);
            }
            return;
        }
        // List of nodes.
        foreach ($node as $child) {
            $this->walk_colrefs($child, $aliases, $sql);
        }
    }

    private function reject_subqueries($node, string $sql): void {
        if (!is_array($node)) {
            return;
        }
        if (isset($node['expr_type']) && $node['expr_type'] === 'subquery') {
            throw new validation_exception('SUBQUERY_FORBIDDEN', $sql);
        }
        foreach ($node as $child) {
            if (is_array($child)) {
                $this->reject_subqueries($child, $sql);
            }
        }
    }

    /**
     * Records the output-column → source map for the first top-level SELECT.
     * Plain column references resolve to "table.column"; derived expressions
     * (functions/operators/constants) map to null but record their underlying
     * column references for the PII scrubber's redaction rule.
     */
    private function build_output_map(array $select_ast, array $aliases): void {
        $this->column_source_map = [];
        $this->column_references = [];
        foreach ($select_ast['SELECT'] ?? [] as $col) {
            $etype = $col['expr_type'] ?? '';
            if ($etype === 'comment') {
                continue;
            }
            $alias = null;
            if (is_array($col['alias'] ?? null)) {
                $alias = $col['alias']['no_quotes']['parts'][0]
                    ?? trim($col['alias']['name'] ?? '', "`\" ");
            }
            if ($etype === 'colref') {
                $src  = $this->resolve_colref($col['base_expr'] ?? '', $aliases);
                $name = $alias ?? $this->output_name_for_colref($col['base_expr'] ?? '');
                $this->column_source_map[$name] = $src;
                $this->column_references[$name] = $src !== null ? [$src] : [];
            } else {
                $name = $alias ?? trim($col['base_expr'] ?? '', '`" ');
                $refs = [];
                // Aggregate functions (COUNT, SUM, AVG, …) produce a scalar;
                // their inner column references are not surfaced as output sources.
                if ($etype !== 'aggregate_function') {
                    $this->collect_colref_sources($col['sub_tree'] ?? null, $aliases, $refs);
                }
                $this->column_source_map[$name] = null;
                $this->column_references[$name] = array_values(array_unique($refs));
            }
        }
    }

    /** Resolve a colref base_expr to "table.column" or null if unresolvable. */
    private function resolve_colref(string $base, array $aliases): ?string {
        $base = trim($base);
        if ($base === '' || $base === '*' || str_ends_with($base, '.*')) {
            return null;
        }
        $parts = explode('.', $base);
        if (count($parts) === 2) {
            $alias = trim($parts[0], '`"');
            $colnm = trim($parts[1], '`"');
            return isset($aliases[$alias]) ? $aliases[$alias] . '.' . $colnm : null;
        }
        $colnm  = trim($parts[0], '`"');
        $tables = array_unique(array_values($aliases));
        $match  = null;
        foreach ($tables as $t) {
            if (in_array($colnm, $this->manifest[$t] ?? [], true)) {
                if ($match !== null) {
                    return null; // Ambiguous; validation would already have rejected.
                }
                $match = $t;
            }
        }
        return $match !== null ? $match . '.' . $colnm : null;
    }

    /** Output column name for a colref base_expr (table qualifier stripped). */
    private function output_name_for_colref(string $base): string {
        $parts = explode('.', trim($base));
        return trim(end($parts), '`"');
    }

    /** Recursively collect resolved "table.column" sources from an expression sub_tree. */
    private function collect_colref_sources($node, array $aliases, array &$out): void {
        if (!is_array($node)) {
            return;
        }
        if (isset($node['expr_type'])) {
            if ($node['expr_type'] === 'colref') {
                $src = $this->resolve_colref($node['base_expr'] ?? '', $aliases);
                if ($src !== null) {
                    $out[] = $src;
                }
            }
            if (isset($node['sub_tree']) && is_array($node['sub_tree'])) {
                $this->collect_colref_sources($node['sub_tree'], $aliases, $out);
            }
            return;
        }
        foreach ($node as $child) {
            $this->collect_colref_sources($child, $aliases, $out);
        }
    }
}
