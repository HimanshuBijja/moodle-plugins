<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Google Gemini generateContent client. The model is part of the URL path;
 * the API key travels as the x-goog-api-key header (kept out of URL logs).
 */
class gemini_client extends base_http_ai_client {

    protected const DEFAULT_MODEL = 'gemini-2.0-flash';
    private const BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::BASE . $this->model() . ':generateContent';
    }

    protected function auth_headers(): array {
        return [
            'x-goog-api-key: ' . $this->api_key,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt, array $history = []): array {
        $contents = [];
        foreach ($history as $turn) {
            $t = $this->history_turn($turn);
            $contents[] = ['role' => 'user',  'parts' => [['text' => $t['prompt']]]];
            $contents[] = ['role' => 'model', 'parts' => [['text' => $this->history_assistant_json($t['sql'])]]];
        }
        $contents[] = ['role' => 'user', 'parts' => [['text' => $user_prompt]]];
        return [
            'systemInstruction' => ['parts' => [['text' => $system_prompt]]],
            'contents'          => $contents,
            'generationConfig'  => [
                'maxOutputTokens'  => self::MAX_TOKENS_SQL,
                'responseMimeType' => 'application/json',
            ],
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'systemInstruction' => ['parts' => [['text' => prompt_builder::build_format_system()]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => json_encode([
                'question' => $user_prompt,
                'rows'     => $safe_rows,
            ])]]]],
            'generationConfig'  => ['maxOutputTokens' => self::MAX_TOKENS_FORMAT],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['candidates'][0]['content']['parts'][0]['text'] ?? null;
        return is_string($t) ? $t : '';
    }
}
