<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Anthropic Messages API client. Provider-specific hooks only; all shared
 * request/parse flow lives in base_http_ai_client.
 */
class claude_client extends base_http_ai_client {

    protected const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
    private const ENDPOINT = 'https://api.anthropic.com/v1/messages';
    private const ANTHROPIC_VERSION = '2023-06-01';
    private const MAX_TOKENS_SQL = 800;
    private const MAX_TOKENS_FORMAT = 1024;

    protected function endpoint(): string {
        return self::ENDPOINT;
    }

    protected function auth_headers(): array {
        return [
            'x-api-key: ' . $this->api_key,
            'anthropic-version: ' . self::ANTHROPIC_VERSION,
            'content-type: application/json',
        ];
    }

    protected function build_sql_payload(string $system_prompt, string $user_prompt, array $history = []): array {
        $messages = [];
        foreach ($history as $turn) {
            $t = $this->history_turn($turn);
            $messages[] = ['role' => 'user', 'content' => $t['prompt']];
            $messages[] = ['role' => 'assistant', 'content' => $this->history_assistant_json($t['sql'])];
        }
        $messages[] = ['role' => 'user', 'content' => $user_prompt];
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_SQL,
            'system'     => $system_prompt,
            'messages'   => $messages,
        ];
    }

    protected function build_format_payload(string $user_prompt, array $safe_rows): array {
        return [
            'model'      => $this->model(),
            'max_tokens' => self::MAX_TOKENS_FORMAT,
            'system'     => prompt_builder::build_format_system(),
            'messages'   => [['role' => 'user', 'content' => json_encode([
                'question' => $user_prompt,
                'rows'     => $safe_rows,
            ])]],
        ];
    }

    protected function extract_text(array $response): string {
        $t = $response['content'][0]['text'] ?? null;
        return is_string($t) ? $t : '';
    }
}
