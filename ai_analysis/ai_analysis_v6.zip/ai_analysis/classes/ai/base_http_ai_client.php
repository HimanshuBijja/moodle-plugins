<?php
namespace local_ai_analysis\ai;

use local_ai_analysis\exception\ai_client_exception;
use local_ai_analysis\exception\transport_exception;

defined('MOODLE_INTERNAL') || die();

/**
 * Template-method base for JSON-over-HTTP AI providers. Owns the entire
 * provider-independent flow; concrete providers implement five small hooks.
 * generate_sql()/format_result() are final so the SQL-output parsing cannot
 * drift between providers.
 */
abstract class base_http_ai_client implements ai_client_interface {

    public function __construct(
        protected http_transport_interface $transport,
        protected string $api_key,
        protected string $model = '',
        protected int $timeout = 30,
    ) {}

    final public function generate_sql(string $system_prompt, string $user_prompt, array $history = []): array {
        $response = $this->post($this->build_sql_payload($system_prompt, $user_prompt, $history));
        $text     = $this->extract_text($response);
        $stripped = $this->strip_fences($text);
        $decoded  = json_decode($stripped, true);
        if (!is_array($decoded)) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        if (isset($decoded['error']) && is_string($decoded['error'])) {
            return ['type' => 'out_of_scope', 'message' => $decoded['error']];
        }
        if (!isset($decoded['sql']) || !isset($decoded['params']) || !is_array($decoded['params'])) {
            throw new ai_client_exception('PARSE_FAILED', $text);
        }
        return [
            'type'        => 'sql',
            'sql'         => (string) $decoded['sql'],
            'params'      => $decoded['params'],
            'explanation' => (string) ($decoded['explanation'] ?? ''),
            'chart'       => (isset($decoded['chart']) && is_array($decoded['chart'])) ? $decoded['chart'] : null,
        ];
    }

    final public function format_result(string $user_prompt, array $safe_rows): string {
        $response = $this->post($this->build_format_payload($user_prompt, $safe_rows));
        return trim($this->strip_fences($this->extract_text($response)));
    }

    /** POST the JSON-encoded payload; return the decoded response envelope. */
    protected function post(array $payload): array {
        $response = $this->transport->post($this->endpoint(), $this->auth_headers(), json_encode($payload), $this->timeout);
        if ($response['status'] < 200 || $response['status'] >= 300) {
            $code = (int) $response['status'];
            if ($code === 429 || $code >= 500) {
                throw new transport_exception('HTTP_' . $code . ': ' . substr($response['body'], 0, 500));
            }
            throw new ai_client_exception('HTTP_' . $code, $response['body']);
        }
        $decoded = json_decode($response['body'], true);
        if (!is_array($decoded)) {
            throw new ai_client_exception('PARSE_FAILED', $response['body']);
        }
        return $decoded;
    }

    protected function strip_fences(string $text): string {
        $stripped = trim($text);
        $stripped = preg_replace('/^```\w*\s*/i', '', $stripped);
        $stripped = preg_replace('/\s*```\s*$/', '', $stripped);
        return $stripped;
    }

    /** Effective model: explicit config else provider default. */
    protected function model(): string {
        return $this->model !== '' ? $this->model : static::DEFAULT_MODEL;
    }

    abstract protected function endpoint(): string;
    abstract protected function auth_headers(): array;
    abstract protected function build_sql_payload(string $system_prompt, string $user_prompt, array $history = []): array;

    /**
     * Normalises a history turn to ['prompt' => string, 'sql' => string].
     * Shared by providers so the multi-turn message shape cannot drift.
     */
    protected function history_turn(array $turn): array {
        return [
            'prompt' => (string) ($turn['prompt'] ?? ''),
            'sql'    => (string) ($turn['sql'] ?? ''),
        ];
    }

    /** JSON the model would have returned for a prior turn (assistant echo). */
    protected function history_assistant_json(string $sql): string {
        return json_encode(['sql' => $sql, 'params' => [], 'explanation' => '']);
    }
    abstract protected function build_format_payload(string $user_prompt, array $safe_rows): array;

    /** Extract assistant text from the decoded response, or '' if the path is absent. */
    abstract protected function extract_text(array $response): string;
}
