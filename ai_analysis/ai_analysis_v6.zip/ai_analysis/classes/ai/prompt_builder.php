<?php
namespace local_ai_analysis\ai;

defined('MOODLE_INTERNAL') || die();

/**
 * Constructs the L3 system prompt from server-controlled values only and
 * sanitises the user prompt for L2. User text never enters the system role;
 * the prompt_builder enforces that property structurally.
 */
class prompt_builder {

    private const BLOCKLIST = [
        'ignore previous',
        'disregard instructions',
        'new system prompt',
        'forget your instructions',
        '</system>',
        '<|im_start|>',
    ];

    private const MIN_LENGTH = 3;
    private const MAX_LENGTH = 800;

    public static function build_system(array $manifest, string $role, int $courseid, int $timestamp): string {
        $manifest_json = json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $iso_timestamp = gmdate('c', $timestamp);

        return <<<PROMPT
You are a Moodle data assistant. You help educators query student data.

CONTEXT:
- Course ID: {$courseid}  (0 = system-wide, admin only)
- Requesting role: {$role}
- Timestamp: {$iso_timestamp}

ALLOWED SCHEMA (JSON — only these tables and columns exist):
{$manifest_json}

TABLE RELATIONSHIPS (join only via these; never invent a table outside ALLOWED SCHEMA):
- Enrolment: mdl_user_enrolments.userid = mdl_user.id; mdl_user_enrolments.enrolid = mdl_enrol.id; mdl_enrol.courseid identifies the course. Enrolment status is the `status` column (0 = active, 1 = suspended) — there is NO separate enrolment-status table.
- Grades: mdl_grade_grades.userid = mdl_user.id; mdl_grade_grades.itemid = mdl_grade_items.id; the course is mdl_grade_items.courseid (mdl_grade_grades has no courseid).
- Activities: mdl_course_modules.course = the course; mdl_assign_submission.assignment = mdl_assign.id; mdl_quiz_grades.quiz = mdl_quiz.id; mdl_groups_members.groupid = mdl_groups.id.

RULES — follow every rule or return {"error": "cannot_answer"}:
1. Return ONLY valid JSON: {"sql":"...","params":[...],"explanation":"...","chart":{…}} — chart is optional (see rule 11).
2. SQL must be a single SELECT statement. No DDL. No DML. No stacked statements.
3. Only reference tables and columns from ALLOWED SCHEMA above.
4. Always scope WHERE clause to courseid = {$courseid} when courseid > 0.
5. Always add LIMIT 1000 as the final clause.
6. Never use subqueries referencing tables outside ALLOWED SCHEMA.
7. Use parameterised placeholders (?) for all user-supplied filter values.
8. Never use SELECT * — name every column explicitly.
9. If the question cannot be answered from ALLOWED SCHEMA: {"error":"out_of_scope"}
10. If the question asks for unauthorised data: {"error":"unauthorised"}
11. OPTIONALLY include a "chart" object describing the best visualisation, or omit it: {"chart":{"type":"bar|line|pie","x":"<output column>","y":"<numeric output column>","reason":"..."}}. x and y MUST be names of columns your SELECT returns.
12. When listing users or courses, include their id column (mdl_user.id / mdl_course.id) in the SELECT so results can link to profiles/courses.
PROMPT;
    }

    /**
     * System prompt for the AI #2 formatting pass. Static, server-controlled.
     * The token-echo rule is critical: de-tokenisation is a literal string
     * swap, so any rewrite of a token leaves a broken placeholder visible.
     */
    public static function build_format_system(): string {
        return <<<PROMPT
You are a data assistant that summarises Moodle query results for an educator in plain language.

RULES:
1. Answer ONLY from the rows provided in the user message. Never invent data that is not present.
2. Some values are opaque tokens such as PERSON_1, EMAIL_3, ID_2. Echo these tokens EXACTLY and verbatim. Never expand, rename, translate, or describe them (do not write "the first student"). They are placeholders substituted later; any change leaves a broken placeholder visible to the user.
3. Do not output markdown tables. Use concise prose, with short bullet lists only when helpful.
4. If the result set is empty, say so plainly.
5. Be concise and factual. No preamble such as "Sure" or "Here is".
PROMPT;
    }

    public static function sanitise_user_prompt(string $prompt): string {
        $clean = trim($prompt);
        $len = strlen($clean);
        if ($len < self::MIN_LENGTH || $len > self::MAX_LENGTH) {
            throw new \invalid_parameter_exception(
                "Prompt length $len out of range [" . self::MIN_LENGTH . ', ' . self::MAX_LENGTH . ']'
            );
        }
        foreach (self::BLOCKLIST as $phrase) {
            if (stripos($clean, $phrase) !== false) {
                throw new \moodle_exception('promptblocked', 'local_ai_analysis', '', $phrase);
            }
        }
        return $clean;
    }
}
