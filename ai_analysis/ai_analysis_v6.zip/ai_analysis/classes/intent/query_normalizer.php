<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Turns a free-text prompt into a list of canonical tokens for classification.
 * Used ONLY for intent matching — the AI fallback still receives the original
 * sanitised prompt, so this can never change AI-path behaviour.
 */
class query_normalizer {

    /**
     * @param string $prompt sanitised user prompt
     * @return string[] canonical tokens (order preserved, may contain duplicates)
     */
    public static function normalize(string $prompt): array {
        $lower = \core_text::strtolower($prompt);
        // Replace any non-alphanumeric run with a single space, then split.
        $clean = preg_replace('/[^a-z0-9]+/', ' ', $lower);
        $raw = preg_split('/\s+/', trim($clean), -1, PREG_SPLIT_NO_EMPTY);
        $tokens = [];
        foreach ($raw as $t) {
            $tokens[] = synonym_dictionary::canonicalize($t);
        }
        return $tokens;
    }
}
