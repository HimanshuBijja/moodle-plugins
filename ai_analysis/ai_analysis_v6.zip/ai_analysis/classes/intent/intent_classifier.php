<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Deterministic keyword/synonym intent classifier. Returns a known intent id
 * for a confident match, or null to signal "fall through to the AI pipeline".
 * Never throws — any internal anomaly resolves to null (no exceptions to AJAX).
 */
class intent_classifier {

    /** @return string|null intent id, or null when no intent confidently matches */
    public static function classify(string $prompt): ?string {
        try {
            $tokens = array_flip(query_normalizer::normalize($prompt));
            foreach (intent_registry::all() as $intent) {
                if (self::matches($tokens, $intent)) {
                    return $intent['id'];
                }
            }
        } catch (\Throwable $e) {
            debugging('intent classify failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
        return null;
    }

    /** @param array<string,int> $tokens canonical token => any value (set membership) */
    private static function matches(array $tokens, array $intent): bool {
        foreach ($intent['requires'] as $t) {
            if (!isset($tokens[$t])) {
                return false;
            }
        }
        foreach ($intent['none_of'] as $t) {
            if (isset($tokens[$t])) {
                return false;
            }
        }
        if (empty($intent['any_of'])) {
            return true;
        }
        foreach ($intent['any_of'] as $t) {
            if (isset($tokens[$t])) {
                return true;
            }
        }
        return false;
    }
}
