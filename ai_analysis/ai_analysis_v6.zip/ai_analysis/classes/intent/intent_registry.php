<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Declarative catalogue of known intents. Data only — the matching algorithm
 * lives in intent_classifier. Each entry is matched against the canonical token
 * SET produced by query_normalizer:
 *   - requires : every token must be present
 *   - any_of   : at least one token must be present
 *   - none_of  : no token may be present (disqualifiers)
 * Adding an intent later = one new entry here + one branch in sql_template.
 */
class intent_registry {

    /** @return array<int,array{id:string,requires:string[],any_of:string[],none_of:string[]}> */
    public static function all(): array {
        return [
            [
                'id'       => 'student_listing',
                'requires' => ['students'],
                'any_of'   => ['list', 'enrolled'],
                'none_of'  => [
                    // grade qualifiers
                    'failed', 'fail', 'passed', 'pass', 'grade', 'grades',
                    'mark', 'marks', 'score', 'scores', 'below', 'above',
                    'top', 'best', 'worst', 'lowest', 'highest', 'risk',
                    // submission/activity qualifiers
                    'submitted', 'submission', 'submissions',
                    'assignment', 'assignments', 'quiz', 'quizzes',
                    'feedback',
                ],
            ],
            [
                'id'       => 'course_staff',
                'requires' => ['staff'],
                'any_of'   => ['list', 'enrolled'],
                'none_of'  => [
                    // student listing belongs to student_listing
                    'students',
                    // grade qualifiers
                    'failed', 'fail', 'passed', 'pass', 'grade', 'grades',
                    'mark', 'marks', 'score', 'scores', 'below', 'above',
                    'top', 'best', 'worst', 'lowest', 'highest', 'risk',
                    // submission/activity qualifiers
                    'submitted', 'submission', 'submissions',
                    'assignment', 'assignments', 'quiz', 'quizzes',
                    'feedback',
                ],
            ],
            [
                'id'       => 'at_risk_students',
                'requires' => ['risk'],
                'any_of'   => ['students', 'list', 'enrolled'],
                'none_of'  => ['staff'],
            ],
            [
                'id'       => 'course_performance',
                'requires' => ['performance'],
                'any_of'   => ['enrolled'],
                'none_of'  => ['students', 'staff', 'risk'],
            ],
            [
                'id'       => 'course_feedback',
                'requires' => ['feedback'],
                'any_of'   => [],
                'none_of'  => ['staff', 'risk', 'performance'],
            ],
        ];
    }
}
