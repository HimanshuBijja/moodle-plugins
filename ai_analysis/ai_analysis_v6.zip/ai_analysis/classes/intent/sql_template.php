<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Maps a matched intent id (+ slots) to a hand-written, parameterized SELECT.
 * SQL uses the canonical mdl_ prefix (translated to the runtime prefix by the
 * gateway, exactly as for AI SQL) and positional ? params (matching the AI
 * path). Every template is unit-tested to pass sql_validator.
 */
class sql_template {

    /** Teaching staff for a course, from the privacy-filtered view. */
    private const COURSE_STAFF_SQL =
        'SELECT s.userid, s.firstname, s.lastname, s.role '
        . 'FROM mdl_ai_course_staff s '
        . 'WHERE s.courseid = ? '
        . 'ORDER BY s.lastname '
        . 'LIMIT 1000';

    /** High-risk students for a course, from the engagement view. */
    private const AT_RISK_SQL =
        'SELECT s.userid, s.firstname, s.lastname, s.last_activity_days, '
        . 's.missing_submissions, s.avg_grade, s.risk_band '
        . 'FROM mdl_ai_student_engagement s '
        . "WHERE s.courseid = ? AND s.risk_band = 'high' "
        . 'ORDER BY s.last_activity_days DESC '
        . 'LIMIT 1000';

    /** Output columns for the course-performance template (both shapes). */
    private const COURSE_PERFORMANCE_COLS =
        'p.courseid, p.coursename, p.student_count, p.at_risk_high, p.at_risk_pct, '
        . 'p.avg_grade, p.avg_missing_submissions, p.pct_no_missing';

    /** Output columns for the course-feedback template (both shapes). */
    private const COURSE_FEEDBACK_COLS =
        'f.courseid, f.coursename, f.activity_count, f.submission_count, '
        . 'f.rating_count, f.avg_rating, f.avg_rating_pct, f.pct_low';

    /** Active enrolled users for a course. status=0 means an active enrolment. */
    private const STUDENT_LISTING_SQL =
        'SELECT u.id, u.firstname, u.lastname '
        . 'FROM mdl_user u '
        . 'JOIN mdl_user_enrolments ue ON ue.userid = u.id '
        . 'JOIN mdl_enrol e ON e.id = ue.enrolid '
        . 'WHERE e.courseid = ? AND ue.status = 0 AND e.status = 0 '
        . 'ORDER BY u.lastname '
        . 'LIMIT 1000';

    /**
     * @param string $intentid a known intent id from intent_registry
     * @param int $courseid current course context
     * @return array{0:string,1:array,2:?array} [sql, positional params, chart hint or null]
     */
    public static function build(string $intentid, int $courseid): array {
        switch ($intentid) {
            case 'student_listing':
                return [self::STUDENT_LISTING_SQL, [$courseid], null];
            case 'course_staff':
                return [self::COURSE_STAFF_SQL, [$courseid], null];
            case 'at_risk_students':
                return [self::AT_RISK_SQL, [$courseid], null];
            case 'course_performance':
                if ($courseid > 0) {
                    return ['SELECT ' . self::COURSE_PERFORMANCE_COLS
                        . ' FROM mdl_ai_course_performance p WHERE p.courseid = ? LIMIT 1000', [$courseid], null];
                }
                return ['SELECT ' . self::COURSE_PERFORMANCE_COLS
                    . ' FROM mdl_ai_course_performance p ORDER BY p.at_risk_pct DESC LIMIT 1000', [],
                    ['type' => 'bar', 'x' => 'coursename', 'y' => 'at_risk_pct']];
            case 'course_feedback':
                if ($courseid > 0) {
                    return ['SELECT ' . self::COURSE_FEEDBACK_COLS
                        . ' FROM mdl_ai_course_feedback f WHERE f.courseid = ? LIMIT 1000', [$courseid], null];
                }
                return ['SELECT ' . self::COURSE_FEEDBACK_COLS
                    . ' FROM mdl_ai_course_feedback f ORDER BY f.avg_rating ASC LIMIT 1000', [],
                    ['type' => 'bar', 'x' => 'coursename', 'y' => 'avg_rating']];
            default:
                throw new \coding_exception('Unknown intent template: ' . $intentid);
        }
    }
}
