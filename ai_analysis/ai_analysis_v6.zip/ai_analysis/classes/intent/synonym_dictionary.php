<?php
namespace local_ai_analysis\intent;

defined('MOODLE_INTERNAL') || die();

/**
 * Surface-term → canonical-token map for deterministic intent matching.
 * Same hardcoded-array pattern as manifest_builder: a single source of truth,
 * never derived from live data.
 */
class synonym_dictionary {

    /** @var array<string,string> surface token => canonical token */
    private const MAP = [
        // students-noun family
        'student'   => 'students',
        'students'  => 'students',
        'pupil'     => 'students',
        'pupils'    => 'students',
        'learner'   => 'students',
        'learners'  => 'students',
        // list-verb family
        'list'      => 'list',
        'show'      => 'list',
        'get'       => 'list',
        'display'   => 'list',
        'give'      => 'list',
        'view'      => 'list',
        'see'       => 'list',
        'all'       => 'list',
        // course-context family
        'enrolled'  => 'enrolled',
        'enrol'     => 'enrolled',
        'enrolment' => 'enrolled',
        'course'    => 'enrolled',
        'courses'   => 'enrolled',
        'class'     => 'enrolled',
        'current'   => 'enrolled',
        'this'      => 'enrolled',
        'here'      => 'enrolled',
        // staff-noun family
        'teacher'     => 'staff',
        'teachers'    => 'staff',
        'lecturer'    => 'staff',
        'lecturers'   => 'staff',
        'faculty'     => 'staff',
        'instructor'  => 'staff',
        'instructors' => 'staff',
        'professor'   => 'staff',
        'professors'  => 'staff',
        'tutor'       => 'staff',
        'tutors'      => 'staff',
        'staff'       => 'staff',
        // teaching verbs canonicalize to the staff noun for matching
        'teach'       => 'staff',
        'teaches'     => 'staff',
        'teaching'    => 'staff',
        // interrogative implies a listing intent
        'who'         => 'list',
        // risk family
        'risk'        => 'risk',
        'struggling'  => 'risk',
        'disengaged'  => 'risk',
        'failing'     => 'risk',
        // course-performance family
        'performance'     => 'performance',
        'performing'      => 'performance',
        'underperforming' => 'performance',
        'health'          => 'performance',
        // feedback / ratings family
        'feedback'     => 'feedback',
        'feedbacks'    => 'feedback',
        'rating'       => 'feedback',
        'ratings'      => 'feedback',
        'rated'        => 'feedback',
        'star'         => 'feedback',
        'stars'        => 'feedback',
        'satisfaction' => 'feedback',
        'survey'       => 'feedback',
        'surveys'      => 'feedback',
        'review'       => 'feedback',
        'reviews'      => 'feedback',
    ];

    /** Canonicalize a single lowercase token; unknown tokens pass through unchanged. */
    public static function canonicalize(string $token): string {
        return self::MAP[$token] ?? $token;
    }
}
